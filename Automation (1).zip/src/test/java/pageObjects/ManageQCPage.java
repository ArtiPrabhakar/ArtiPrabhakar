package pageObjects;

import com.fasterxml.jackson.databind.ObjectMapper;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.*;
@Slf4j
public class ManageQCPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public GenericFunction genericFuncObj;
    public String checkBoxesXpath = ".//*[contains(text(),\"%s\")]//parent::div//input[@role='checkbox']";
    public String clickCheckBoxXpath = ".//*[contains(text(),\"%s\")]//parent::div/label";
    public String staticContentExactMatch = ".//*[text()=\"%s\"]";
    public By closeIconXpath = By.xpath(".//*[@class='close-icn bk']");
    public String ManageCquickViewtitlesXpath = ".//*[@class='cdk-drag sr-quickview-tile cursor-move bg-wt']//*[@class='sr-quickview-tile__txt']";
    public String removeSpecificQC = "//div[contains(text(),\"%s\")]/parent::div/following-sibling::div";
    public By removeAllQCs = By.xpath("//div[contains(@class,'delete-icn')]");
    public String dragSpecificQC = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='cdk-drop-list']";
    public By dragQCToDestination = By.xpath("//div/div[contains(@class,'cdk-drop-list')][8]");
    public By AvailableXpath = By
            .xpath("(.//*[contains(text(),'Available')]//ancestor::div[@class='cdk-drop-list'])[1]");
    public String unSelectedQVC = "//input[@aria-checked='false']";
    String manageCards_checkbox=".//*[contains(text(),\"%s\")]//parent::div/input";

    public By customViewQVC = By.xpath("//label[@class='sr-modal__section-title d-flex']/../ul[2]//li//input");
    public ManageQCPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.genericFuncObj = new GenericFunction();
    }

    public Boolean ValidateCheckBoxes(String checkBox1, String checkBox2) {
        List<String> types = new ArrayList();

        if (checkBox1.equalsIgnoreCase("Hide Quick View Cards")) {
            types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, checkBox1))).getAttribute("role"));
        }
        List<String> QVCCards = new ArrayList<>();
        QVCCards.addAll(Constants.QuickViewCardXpaths);

        List<String> HybridQVCCards = new ArrayList<>();
        HybridQVCCards.addAll(Constants.HybridlQuickViewCardXpaths);


        if (checkBox2.equalsIgnoreCase("quick view cards")) {
            for (String QC : QVCCards) {
                types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
            }
        } else if (checkBox2.equalsIgnoreCase("quick view cards for hybrid")) {
            for (String QC : HybridQVCCards) {
                // We are not translating SELECT
                if(GenericFunction.locale!=Constants.EN_US && QC!="Select")
                {
                    QC = this.genericFunctionObject.getLocalizedValue(QC);
                }
                types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
            }
        } else if (checkBox2.equalsIgnoreCase("quick view cards for digital")) {
            for (String QC : Constants.DigitalQuickViewCardXpaths) {
                types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
            }
        }
        Set<String> typesSet = new HashSet<>(types);
        return typesSet.contains("checkbox") && typesSet.size()==1;
    }

        public Boolean ValidateCheckBoxesForLocalization(String checkBox1, String checkBox2) {
            List<String> types = new ArrayList();

            if (checkBox1.equalsIgnoreCase("Hide Quick View Cards")) {
                types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, checkBox1))).getAttribute("role"));
            }
            List<String> QVCCards = new ArrayList<>();
            QVCCards.addAll(Constants.QuickViewCardXpaths);

            List<String> HybridQVCCards = new ArrayList<>();
            HybridQVCCards.addAll(Constants.HybridlQuickViewCardXpaths);

            if(!GenericFunction.locale.contains(Constants.EN_US))
            {
                QVCCards = this.genericFunctionObject.getLocalizedValue(Constants.QuickViewCardXpaths);
                HybridQVCCards = this.genericFunctionObject.getLocalizedValue(Constants.HybridlQuickViewCardXpaths);
            }

            if (checkBox2.equalsIgnoreCase("quick view cards")) {
                for (String QC : QVCCards) {
                    types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
                }
            }else if (checkBox2.equalsIgnoreCase("quick view cards for hybrid")) {
                for (String QC : HybridQVCCards) {
                    types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
                }
            }
            else if (checkBox2.equalsIgnoreCase("quick view cards for digital")) {
                for (String QC : Constants.DigitalQuickViewCardXpaths) {
                    types.add(this.findElement(By.xpath(String.format(this.checkBoxesXpath, QC))).getAttribute("role"));
                }
            }

        Set<String> typesSet = new HashSet<>(types);
        return typesSet.contains("checkbox") && typesSet.size()==1;
    }

    public Boolean ValidateStaticContent() {
        return ValidateStaticContentCommon();
    }

    public Boolean ValidateStaticContentForLocalization() {
        return ValidateStaticContentCommon("forLocalisation");
    }

    public Boolean ValidateStaticContentCommon(String... localeSet) {
        boolean flag = true;
        List<String> ManageCards = new ArrayList<>();
        ManageCards.addAll(Constants.StaticContentinManageCards);
        if(GenericFunction.locale!=Constants.EN_US)
        {
            ManageCards = this.genericFunctionObject.getLocalizedValue(Constants.StaticContentinManageCards);
        }
        for (String staticContent : ManageCards) {
            log.info("Static text in Manage QVC: " + staticContent);
            if (flag) {
                flag = this.elementIsDisplayed(By.xpath(String.format(this.staticContentExactMatch, staticContent)));
            } else
                return false;
        }
        return flag;
    }

    public boolean verifyCheckBoxDisplayed(String cbName) {
        try {
            return this.waitUntilVisible(By.xpath(String.format(this.clickCheckBoxXpath, cbName)));
        } catch (Exception e) {
            log.error("**EXCEPTION** Element is not displayed");
            return false;
        }

    }

    public boolean verifyCheckBoxIsSelected(String value) {
        return this.findElement(By.xpath(String.format(this.checkBoxesXpath, value))).isSelected();
    }

    public Boolean ValidateLinksinManageQC(List<String> links) {
        boolean flag = true;
        //List<String> AvailableLinks = links.asList(String.class);
        for (String link : links) {
            if (link.equalsIgnoreCase("Close Icon")) {
                flag = this.elementIsDisplayed(this.closeIconXpath);
            } else {
                if (flag) {
                    flag = this.elementIsDisplayed(By.xpath(this.buildXpathForString(link)));
                } else {
                    return false;
                }

            }
        }
        return flag;
    }

    public void ClickCheckBox(String cbName) {
        this.clickOnElement(By.xpath(String.format(this.clickCheckBoxXpath, cbName)));
    }

    public Boolean ValidateCardCountandPlacement(String operation, String ContextStoreVariable1,
                                                 String ContextStoreVariable2) {
        Boolean flag = true;
        Map<String, Integer> quickViews = new ObjectMapper()
                .convertValue(this.commonHelpers.getValuefromContextStore(ContextStoreVariable1), Map.class);
        Map<String, Integer> manageQuickViews = new ObjectMapper()
                .convertValue(this.commonHelpers.getValuefromContextStore(ContextStoreVariable2), Map.class);
        if (operation.equalsIgnoreCase("same")) {
            flag = quickViews.size() == manageQuickViews.size();
            if (flag) {
                for (String card : quickViews.keySet()) {
                    if (flag) {
                        flag = quickViews.get(card).equals(manageQuickViews.get(card));
                    }
                }
            } else {
                return false;
            }
        } else if (operation.equalsIgnoreCase("Zero")) {
            if (flag) {
                flag = quickViews.size() == 0;
            } else {
                return flag;
            }
        } else if (operation.equalsIgnoreCase("different")) {
            // flag = quickViews.size() == manageQuickViews.size();
            if (flag) {
                for (String card : quickViews.keySet()) {
                    if (flag) {
                        flag = !quickViews.get(card).equals(manageQuickViews.get(card));
                    }
                }
            } else {
                return !flag;
            }
        }
        return flag;
    }

    public void StoreQuickViewsinContextStore(String contextStoreKey) {
        HashMap<String, Integer> quickViews = new HashMap<>();
        for (int index = 0; index < this.findElements(By.xpath(this.ManageCquickViewtitlesXpath)).size(); ++index) {
            quickViews.put(this.findElements(By.xpath(this.ManageCquickViewtitlesXpath)).get(index).getText(), index);
        }
        this.commonHelpers.AddToContextStore(contextStoreKey, quickViews);
    }

    /**
     * @param type
     * @param table
     */
    public void RemoveQCInManageCards(String type, DataTable table) {
         this.commonHelpers.thinkTimer(2000);
        if (type.equalsIgnoreCase("Specific")) {
            List<String> cards = table.asList(String.class);
            for (String card : cards) {
                this.clickOnElement(By.xpath(String.format(this.removeSpecificQC, card)));
            }
        } else if (type.equalsIgnoreCase("All")) {
            int totalCards = this.findElements(this.removeAllQCs).size();
            for (int i = 0; i < totalCards; i++) {
                this.JavaScriptClick(this.removeAllQCs);
            }
        }
    }

    public void SelectQCInManageCards(List<String> cards) {
        for (String card : cards) {
                boolean clickFlag = this.clickOnElementEvent(By.xpath(String.format(this.clickCheckBoxXpath, card)));
                if(!clickFlag){
                    this.ScrollToBottom();
                    this.clickOnElementEvent(By.xpath(String.format(this.clickCheckBoxXpath, card)));
                }
        }
    }

    public void SelectQCInManageCardsUI(List<String> cards) {
        for (String card : cards) {
            //boolean clickFlag = this.clickOnElementEvent(By.xpath(String.format(this.clickCheckBoxXpath, card)));
           // if(!clickFlag){
           // By quickViewcards=By.xpath("//div[@class='sr-quickview-tile__txt' and contains(text(),'"+card+"')]");
             //   this.ScrollToBottom();
                boolean flag=this.findElement(By.xpath(String.format(this.manageCards_checkbox,card))).getAttribute("aria-checked").contains("true");
                if(!flag) {
                    this.clickOnElementEvent(By.xpath(String.format(this.clickCheckBoxXpath, card)));
                }
            //}
        }
    }

    public void DragAndDropQCCard(String source, String destination) {
        WebElement ToElement;
        WebElement FromElement = this.findElement(By.xpath(String.format(this.dragSpecificQC, source)));
        if (destination.equalsIgnoreCase("Available")) {
            ToElement = this.findElement(this.AvailableXpath);
        } else {
            ToElement = this.findElement(By.xpath(String.format(this.dragSpecificQC, destination)));
        }
        this.DragAndDropQC(FromElement, ToElement);
    }

    public void DragAndDropQC(WebElement Fromelement, WebElement ToElement) {
        Actions builder = new Actions(DriverManager.getDrv());
        builder.moveToElement(Fromelement).clickAndHold(Fromelement).perform();
        this.commonHelpers.thinkTimer(1000);
        builder.moveToElement(Fromelement).clickAndHold(Fromelement).moveToElement(ToElement).perform();
        this.commonHelpers.thinkTimer(1000);
        builder.moveToElement(ToElement).perform();
        this.commonHelpers.thinkTimer(1000);
        builder.release().perform();
    }

    public boolean verifyQuickViewCardsLimit() {
        List<WebElement> qvCardsState = this.findElements(getByusingString(this.unSelectedQVC));
        List<WebElement> qvCardsName = this.findElements(getByusingString(this.unSelectedQVC + "/../label"));
        boolean flag = true;
        for (int i = 0; i < qvCardsState.size(); i++) {
            String qvcname = qvCardsName.get(i).getText();
            boolean state = qvCardsState.get(i).isEnabled();
            if (!qvcname.equalsIgnoreCase(this.genericFuncObj.getLocalizedValue("ManageQVC.Hide Quick View Cards"))){
           // if (!qvcname.equalsIgnoreCase("Hide Quick View Cards")) {
                if (state) {
                    flag = false;
                    break;
                }
            }
        }
        return flag;
    }

    public boolean verifyQVCinCustomViews(String expViewName) {
        boolean flag = false;
        List<WebElement> customViewsList = this.findElements(this.customViewQVC);
        for (WebElement webElement : customViewsList) {
            String actViewName = webElement.getAttribute("value");
            if (actViewName.equalsIgnoreCase(expViewName)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    public boolean verifySelectionOfQVCChangesLayout(String viewName) {
        this.JavaScriptClick(By.xpath(String.format(this.clickCheckBoxXpath, viewName)));
        boolean qvcDisplayedOnSelction = this.elementIsDisplayed(By.xpath(String.format(this.removeSpecificQC, viewName.toUpperCase())), true);
        this.JavaScriptClick(By.xpath(String.format(this.clickCheckBoxXpath, viewName)));
        boolean qvcDisplayedOnDeSelction = this.elementIsDisplayed(By.xpath(String.format(this.removeSpecificQC, viewName.toUpperCase())), true);
        return qvcDisplayedOnSelction && !qvcDisplayedOnDeSelction;
    }
}
