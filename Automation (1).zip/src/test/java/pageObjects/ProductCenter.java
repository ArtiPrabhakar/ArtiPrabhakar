package pageObjects;

import common.CommonHelpers;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.util.Map;
@Slf4j
public class ProductCenter extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;

    HomePage homePage;
    String leftSideMainMenu = "//span[text()=\"%s\"]/following-sibling::span";
    String leftSideSubMenu = "//a[contains(@class,'sr-aside__list-item')]//span[text()=\"%s\"]/parent::a/following-sibling::ul//span[text()=\"%s\"]";
    String leftSideSubMenuDisabled = "//a[contains(@class,'sr-aside__list-item')]//span[text()=\"%s\"]/parent::a/following-sibling::ul//a[contains(@class,'disabled')]/span[text()=\"%s\"]";
    String childMenuNotOpened = "//span[text()=\"%s\"]/parent::a/following-sibling::ul[@class='child-menu d-none']";
    public ProductCenter(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.homePage = new HomePage(this.commonHelpers);
    }

    /**
     * Click on Menu options to open submenu
     * and check if the options are enabled or not
     *
     * @param state = whether we want to validate for "enabled" or disabled state
     * @param table = Set of values to be checked if they are enabled or disabled
     * @return This can be enhanced/extended to pass multiple comma separated values for a parent menu
     */
    public boolean verifyMenuOptions(String state, DataTable table) {
        boolean flag = true;
        Map<String, String> menus = table.asMap(String.class, String.class);
        for (String menu : menus.keySet()) {
            // Click on element only if submenu is not already opened
            if (this.findElements(By.xpath(String.format(childMenuNotOpened, menu))).size() > 0) {
                this.clickOnElement(By.xpath(String.format(this.leftSideMainMenu, menu)));
            }
            // Now submenu would be open to validate if all options exist
            if (state.equalsIgnoreCase("enabled"))
                Assert.assertTrue("This element is not enabled  " + menu + " --> " + menus.get(menu)
                        , this.elementIsDisplayed(By.xpath(String.format(leftSideSubMenu, menu, menus.get(menu)))));

            else if (state.equalsIgnoreCase("disabled"))
                Assert.assertTrue("This element is not disabled " + menu + " --> " + menus.get(menu)
                        , this.elementIsDisplayed(By.xpath(String.format(leftSideSubMenuDisabled, menu, menus.get(menu)))));
        }
        return flag;
    }

}
