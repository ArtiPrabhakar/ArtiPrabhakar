package pageObjects;

import API.ResponseModels.CEdashboard;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.API_GenericFun;
import genericfunctions.Constants;
import genericfunctions.DateTimeUtils;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import stepDefinitions.TestAPI;
import stepDefinitions.TestUI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
public class ShipmentOverviewPage extends SeleniumGenericFunction {
    public static List<WebElement> rows;
    private final API_GenericFun apiobj;
    public HomePage homePage;
    public CommonHelpers commonHelpers;
    public GenericFunction genericFuncObj;

    public DateTimeUtils dateTimeUtils;
    public AccountAlias accountAlias;
    public AdvisoryPage advisoryPage;

    public List<String> columnsGrid = new ArrayList<>();
    public TestAPI api;
    public By qcrightArrow = By.xpath("//*[contains(@class,'arrow--right')]");
    public String QCHighlight = "//div[contains(text(),\"%s\")]//ancestor::div[contains(@class,\"%s\")]";
    public String disabledQCards = ".//*[contains(text(),\"%s\")]//ancestor::div[contains(@class,'disabled')]";
    public String cardCountxpath = ".//*[contains(text(),\"%s\")]//parent::div//div[contains(@class,'sr-quickview-tile__val')]";
    public By getViewCount = By.xpath("//div[contains(@class,'sr-actionbar-left')]//div[2]");
    public String filterBubble = "//app-sr-action-bar//*[contains(@class,'sr-active-filters')]//*[contains(text(),\"%s\")]";
    public By AllShipmentsCount = By.xpath(".//*[@class='sr-filter']//span");
    public By CompanyAccDefaultMessage = By.xpath(".//*[@class='sr-ctdropdown-info']");
    public By shipmentsCountSlection = By.xpath("//select[@name='sr-select']");
    public By shipmentsPageRightNavigation = By.xpath("//button[@class='sr-pagination__next']");
    public By shipmentsPageLeftNavigation = By.xpath("//button[@class='sr-pagination__prev']");
    public String columnViewxpath = ".//*[contains(text(),'%s (')]";// ".//*[contains(text(),'%s (')]";
    public By getColumnHeaders = By.xpath(".//*[contains(@class,'ag-header-row')]//span[@ref='eText']");
    public String SpecificColumnxpath = ".//*[contains(@class,'ag-header-row')]//span[contains(text(),\"%s\")]";
    public By TrackingNumResults = By.xpath(".//*[contains(@col-id,'trackingNumber')]");
    public By packageDelayStatus = By.xpath(".//*[contains(@col-id,'packageDelayStatus')]");
    public By Searchicon = By.xpath(".//*[@class='sr-header__acn-item lookup-icn']");
    public By searchinput = By.xpath("(.//*[@class='sr-advsearch']//input)[last()]");
    public String searchInputPlaceHolder = "//*[@placeholder=\"%s\"]";
    public String containsPlaceHolder = "//*[contains(text(),\"%s\")]";
    public String trackingNumberValidation = "//li[contains(text(),\"%s\")]";
    public String TrackingNumxpath = "(.//*[contains(@col-id,'trackingNumber')])[%s]//a";
    public By firstStatusCol = By.xpath("(.//*[contains(@col-id,'status')])[2]");
    public String TrackingNumberMyshipments = "(.//*[contains(@col-id,'trackingNumber')])//a[contains(text(),\"%s\")]";
    public String Statusxpath = "(//*[@col-id='status'])[%s]/parent::div/div/app-status//span[contains(@class,'atrk_shipment_status_top_text')]";// *[contains(text(),\"%s\")]//ancestor::div[@role='row']//div[@col-id='status']";
    public String DeliveryPredictionxpath="(//*[@col-id='finalPackageDelayStatus'])[%s]";
    public By shipmentsPageCount = By
            .xpath("//button[@class='sr-pagination__next']/parent::li/preceding-sibling::li[1]/button");
    public String clickShipmentsPageNum = "//button[contains(@class,'sr-pagination__prev')]/parent::li/following-sibling::li[%s]";
    public By activePageNum = By.xpath("//button[@class='active']");

    public By trackButton = By.xpath("(//button[contains(text(),'Track')])[last()]");
    public String pageNavigationItem = "//div[contains(@class,'sr-pagination')]/ul/li[%s]/button";
    public By pageNavEllipsisPosition = By.xpath("//ul/li[6]/span");
    public By ScrollBar = By.xpath(".//*[contains(@class,'ag-body-horizontal-scroll-viewport')]");
    public String columnCheckBoxState = ".//*[@value=\"%s\" and @type='checkbox']";
    public String expandIcon = "//*[contains(@class,'%s-icn')]";
    // For sorting //
    public String shipmentHeaderCellText = "ag-header-cell-text";
    public By aLLColumnCount = By.xpath("//*[contains(@class,'ag-root ag-unselectable ag-layout-auto-height')]");
    public String shipmentHeaderContainer = "ag-header-container";
    public String gridCellValue = "ag-cell ag-cell-not-inline-editing ag-cell-auto-height ag-cell-value";
    public By MonitoredToggle = By.xpath("//span[@class='sr-toggle-sliderbox__switch']");
    public By searchBtn = By.xpath(".//*[@class='sr-header__acn-item-search']");
    public By searchTextBx = By.xpath(".//*[@aria-label='search-tracking-number']");
    public By trackingNumber = By.xpath(".//*[@class='sr-header-search_item']");
    public By resultCount = By.xpath("//li[@class='sr-search-result_item'][1]/span"); // By.xpath("//li[@class='sr-header-search_item']/span");
    public By trackingNumCellValue = By.xpath("//div[@row-id='0']/div//a"); // By.xpath(".//*[@role='gridcell'][@tabindex='-1'][@aria-colindex='1']");
    public By shipDtlPageTrackingNum = By.xpath(".//*[contains(text(),'Tracking Number: ')]");
    public String searchBubble = ".//*[contains(text(),'Tracking Number:')]/parent::div//span[contains(text(),\"%s\")]";// ".//*[contains(text(),'Tracking
    public By searchMultiInput = By.xpath(".//input[@id='multiTrackingBox-input']");
    public By searchMultiTrack = By.xpath(".//a[contains(text(),'Multiple Tracking Numbers')]");
    public String searchMultiTrackNumber = ".//span[contains(text(),\"%s\")]/following-sibling::input[@id='multiTrackingBox-input']";
    public String errorSearchMsg = ".//div[@id='fileNameInvalid']/ancestor::*//span[contains(text(),'0%s')]";
    // Number:
    // %s')]";
    public By predictionHeader = By
            .xpath("//*[contains(text(),'PREDICTION')]/following-sibling::div[@class='sr-data sr-data--wt']");
    public By delayedReason = By
            .xpath("(//ul/li[contains(@class,'sr-list')][2]/div/div[contains(@class,'sr-data')])[2]");
    public String rowXPath = ".//*[@col-id='trackingNumber' and @role='gridcell']";
    public String trackingNumberxpath = ".//*[contains(text(),' View shipment details')]";
    public String zeroTrackingNumxpath = ".//*[contains(text(),\"%s\")]//span";
    public String columnSort = "(.//*[contains(text(),\"%s\")])//ancestor::div[contains(@class,'label-container')]";
    public String trackingColumnidName = "trackingNumber";
    public String firstRowShipment = "//div[@role='row'][1]/div[@role='gridcell' and @col-id=\"%s\"]";
    public String verifyShipmentIcon = "//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//*[@class='sr-hover-card__txt']//span[1]";
    public String verifyShipmentIconHoverOver = "//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//*[@class='sr-hover-card__txt']//span[@class=\"%s\"]";
    public String verifyShipmentsIcon = "//div/span[@class=\"%s\"]";
    public By filterCityBubbleXpath = By
            .xpath(".//*[contains(text(),'City:')]/following-sibling::span[@class='sr-pill__val'][1]");
    public String pageNumberXpath = ".//button[contains(text(),\"%s\")]";
    public String tabsUnderColumns = "//ul[@role='tablist']//li[@role='presentation']//span[contains(text(),\"%s\")]";
    public By defaultShipmentColumns = By.xpath("//span[contains(text(),'Shipment (12)')]");
    public By defaultShipperColumns = By.xpath("//span[contains(text(),'Shipper (2)')]");
    public By defaultRecipientColumns = By.xpath("//span[contains(text(),'Recipient (2)')]");
    public By defaultCEShipmentColumns = By.xpath("//span[contains(text(),'Shipment (11)')]");
    public By defaultCEShipperColumns = By.xpath("//span[contains(text(),'Shipper (0)')]");
    public By defaultCERecipientColumns = By.xpath("//span[contains(text(),'Recipient (2)')]");
    public String shipmentColumns = "//span[contains(text(),'Shipment (%s)')]";
    public String shipperColumns = "//span[contains(text(),'Shipper (%s)')]";
    public String recipientColumns = "//span[contains(text(),'Recipient (%s)')]";
    public String columnHeader = ".//*[contains(text(),\"%s\")]";
    public String columnValuesXpath = ".//div[@col-id=\"%s\" and @role='gridcell']";
    public String shipmentColumnHeaderXpath = ".//div[@col-id=\"%s\" and @role='columnheader']";
    public String columnLabelXpath = "//label[text()=\" %s \"]";
    // Quick View Indicators
    public By monitoredIcon = By.xpath("//span[contains(@class,'monitored-icn')]");
    public By intervenedIcon = By.xpath("//span[contains(@class,'intervened-icn')]");
    public By ToolTip = By.xpath(".//*[@class='sr-hover-card__txt']");
    public By allExceptionIcon = By.xpath("//*[contains(@class,'exception sr-grid-img')]");
  /*  public By viewingCountXpath = By
            .xpath("//div[contains(@class,'sr-actionbar-left')]/div[contains(text(),'Viewing')]//following-sibling::div");
   */
    public By viewingCountXpath=By.xpath("//div[contains(@class,'sr-actionbar-left')]/div//following-sibling::div");
    public By EditcolumnsChevron = By
            .xpath("//span[@class='sr-tabs__nav-lnk-txt'][contains(text(),'columns')]/following-sibling::span//..");

    // public By filterChevron =
    // By.xpath("//span[contains(text(),'FILTERS')]//parent::a");
    public By filterChevron = By.xpath("(//ul[@role='tablist']//a)[1]");
    public By columnChevron = By.xpath("(//ul[@role='tablist']//a)[2]");

    public By filterType = By.xpath("//span[contains(text(),'Types')]//parent::a");
    public String filterCategory = "//a[contains(text(),\"%s\")]";
    public By dateDropDown = By.xpath("//a[contains(text(), 'Shipment Information')]//following-sibling::ul//li//a");
    public By calenderLeftArrow = By.xpath(
            "//div[@class='calendar right']//th[@class='prev available']");
    public By calenderRightArrow = By.xpath(
            "//div[@class='calendar right']//th[@class='next available']");
    public By dateFieldText = By.xpath("//tr//td[contains(@class, 'available')]//span");
    public By monthField = By.xpath("//th[@class='month drp-animate']");
    public String applyButton = "//app-shipment-filter//button[contains(text(),\"%s\")]";
    public String dateXpath = "//tr//span[text()=\"%s\"]//parent::td[not(contains(@class,'disabled'))][not(contains(@class,'off'))]";
    public By currentDate = By.xpath("//td[contains(@class,'end-date start-date')]//span");
    public By futureDate = By.xpath("//td[contains(@class,'end-date start-date')]//span/../following-sibling::td");
    public By dateFilterXpath = By.xpath(
            "//div[@class='sr-active-filters p-x-4']//div/span[contains(text(),'Date')]/parent::div/span[contains(@class,'sr-pill__val')]");
    public By quickViewLoading = By.xpath("//div[contains(@class,'fdx-c-loading-indicator')]");
    // pop-up window
    public By okButton = By.xpath("//button[contains(text(),'OK')]");
    // first record
    public String cell = "//div[@role='row' and @row-id='0']//div[contains(@col-id,\"%s\")]";
    public String secndPanexpath = ".//*[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]";
    public String SearchAbbrevation = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//span";
    public String filterxpath = ".//*[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*//*[contains(text(),\"%s\")]//parent::div//input";
    public String durationxpath = "//label[contains(@for,'isWithinHours')]";
    public String filterExactMatchXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//*[text()=' %s ']//parent::div//input";
    public String weatherFilterXpath = "(.//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//*[contains(text(),\"%s\")]//parent::div//input)[2]";
    public String filterSearchBar = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//input[@type='text']";
    public String filterLabels = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//label";
    public String SelectSearchResults = ".//label[contains(normalize-space(),\"%s\")]";
    public String SelectSearchResultsExactMatch = ".//label[normalize-space()=\"%s\"]";
    public String filterValuesxpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//*[contains(text(),\"%s\")]";
    public String editColApplyBtn = "//app-shipments-edit-column//button[contains(text(),\"%s\")]";
    public String editColBackBtn = "//button[contains(text(),\"%s\")]";
    public By dotsXpath = By.xpath("//*[contains(@class,'indicator')]");
    public String filterBubbleXpath = "//*[@class='sr-pill__label']//span[contains(text(),\"%s\")]/parent::span/parent::div/span[contains(text(),\"%s:\")]";// ".//*[@class='sr-pill']//*[contains(text(),'
    public String filterBubbleXpathWithSingleHeading = "//span[text()='%s:']/parent::div[@class='sr-pill__label']//span[@class='sr-pill__val']";
    // %s:%s')]";
    public By TotalRecordsXpath = By.xpath(".//*[@class='sr-actionbar-left']//span");
    public String cancelFilterBubble = ".//*[contains(text(),\"%s\")]//ancestor::div/following-sibling::span[@class='sr-pill__close']";
    public String cancelSpecificFilterItemFromBubble = ".//*[contains(text(),\"%s\")]/following-sibling::span[@class='sr-pill-item__close']";
    public String filterAncestor = ".//*[contains(text(),\"%s\")]//ancestor::li";
    public String toggleSwitchStatus = "//div[contains(text(), \"%s\")]";
    public String toggleSwitch = "//div[contains(text(), \"%s\")]/preceding-sibling::label/span";
    public String buttonStateinCalander = ".//*[@class='sr-multinav-subchild']//button[contains(text(),\"%s\")]";
    // filter
    public By filterSearchInput = By.xpath("//li//input[contains(@class,'sr-searchbox__input')]");
    public By companySearchInput = By.xpath("//div//input[contains(@class,'sr-searchbox__input')]");
    public String filterSearchResult = "//mat-tree-node[contains(@class,'mat-tree-node') and descendant::label[contains(@for,\"%s\")]]//input";
    public String filterEmptySearchResult = "//mat-tree-node";
    public String fieldTrkNbr = "//a[contains(text(),\"%s\")]//following::div[@col-id=\"%s\"][1]";
    public String searchCountText = "//li[contains(text(),\"%s\")]";
    public String searchExactCountText = "//li[text()=' %s ']//span";
    public String searchViewDetailsLink = "//li[contains(text(),\"%s\")]";
    public String trkNbrFieldData = "//a[contains(text(),\"%s\")]//ancestor::div[@col-id='trackingNumber']/following::div[@col-id=\"%s\"][1]";
    public By filterCancelButton = By.xpath("//app-shipment-filter//button[contains(text(),'CANCEL')]");
    public By specificDateRangeFrom = By.xpath("//input[@name='fromDate']");
    public By specificDateRangeTo = By.xpath("//input[@name='toDate']");
    public By specificDateOk = By.xpath("//button[@type='button' and contains(text(),'OK')]");
    public By firstStarIcon = By.xpath("(//div[@class='star-icn'])[1]");
    public By firstFilledStarIcon = By.xpath("(//div[@class='star-icn filled'])[1]");
    public By unwatchedList = By.xpath("(//div[@class='star-icn'])");
    public By watchedList = By.xpath("(//div[@class='star-icn filled'])");
    public String shipDateDropdownFilter = "//select[@name ='sr-select']";
    public By subFilterTitle = By.xpath("//div[contains(@class,'sr-multinav-subchild-title')]");
    // Views
    public By viewNameInput = By.xpath("//label[contains(text(),'View Name')]/preceding-sibling::input");
    public String viewNameInputLocalized = "//label[contains(text(),\"%s\")]/preceding-sibling::input";

    public By viewSaveButton = By.xpath("//div/button[contains(text(),'Save')]");
    public String viewSaveButtonLocalized = "//div/button[contains(text(),\"%s\")]";
    public String viewSuccessfulMessage = "//div[contains(text(),'%s successfully created.')]";
    public String viewSuccessfulMessageLocalized = "//div[contains(text(),\"%s %s\")]";

    public By viewSuccessfulMsgCloseButton = By.xpath("//button[contains(text(),'Close')]");
    public By dcfileloadingIndicator = By.xpath("//div[@class ='fdx-c-loading-indicator__part']");
    public String viewSuccessfulMsgCloseButtonLocalized = "//button[contains(text(),\"%s\")]";

    public String verifyViewInList = "//ul/li/a[text()=\"%s\"]";
    public String rename_Icon = "//a[contains(text(),\"%s\")]/parent::li//span[@class='edit-icn']";
    public String renameViewIconShipmentPage1 = "//span[contains(text(),\"%s\")]//span[contains(@class,'edit-icn')]";
    public String renameViewIconShipmentPage = "//a[contains(text(),\"%s\")]/following::span[contains(@class,'edit-icn')]";
    public String shareViewIconShipmentPage = "//a[contains(text(),\"%s\")]/parent::li//span[contains(@class,'share-icn')]";
    public By renameOrSaveViewPopupCancel = By.xpath("//span[contains(text(),'Cancel')]");
    public By renameOrSaveViewPopupSave = By.xpath("//button[text()=' Save ']");
    public By shareViewPopup = By.xpath("//button[text()=' Share ']");
    public By viewNameInputText = By.id("INPUT");
    public By viewUniqueNameErrorMessage = By.xpath("//span[@class='char-length']//preceding-sibling::span");
    public String viewRenamePopupMessage = "//div[@class='fdx-c-modal__body']/div[%s]";
    public String viewRenamePopupLowerMessage = "//div[@class='fdx-c-modal__body']//div[2]/div/div[3]/div[3]/div";
    public By viewNameLabelInPopup = By.xpath("//input[@id='INPUT']/following-sibling::label");
    public By viewNameMaxLenght = By.xpath("//span[@class='char-length']");
    // public String renameViewSuccessMessage = "//div[contains(text(),'%s renamed
    // to %s')]";
    public String renameViewSuccessMessage = "//div[contains(text(),'Updated successfully')]";
    public By viewSuccessDailogXButton = By.xpath("//div[contains(@class,'close-icn')]");
    public String verifyViewBubbleValue = "//*[contains(text(),\"%s\")]";
    public By verifyErrorMsg = By.xpath(".//span[@class='error-text']");
    public String verifySearchBubble = "//*[contains(text(),'CUSTOM SEARCH:')]";
    public String verifyViewBubble = "//div[text()=' view: ']";
    public String viewDeleteIcon = "//a[text()=\"%s\"]/parent::li//span[contains(@class,'delete-icn')]";
    public By viewDelete_DeleteButton = By.xpath("//button[contains(text(),'Delete')]");
    public By viewDelete_CancelButton = By.xpath("//button/span[contains(text(),'Cancel')]");
    public String activeView = "//span[contains(@class,'indicator selected')]/ancestor::ul//a[contains(text(),\"%s\")]";
    public String defaultViewText = "//span[contains(text(),'(Default)')]/ancestor::ul//a[contains(text(),\"%s\")]";
    public By inactiveViewsList = By.xpath("//span[@class='indicator']/following-sibling::a");
    public String TypesOptionsXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-tabs']//.//*[@Value=\"%s\"]/parent::div";
    public String TypesIconsXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-tabs']//.//*[@Value=\"%s\"]/parent::div//span[contains(@class,'icn')]";
    public String TypesCollapse = ".//*[contains(text(),\"%s\")]//ancestor::a//span[@class='chevron']";
    public String TypesOptionsCBXpath = "//label[text()=' %s ']";
    public String bulkOptionMenu = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-tabs']//.//*[contains(text(),\"%s\")]";
    public String WatchedTypesOptionsCBXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-tabs']//*[@class='star-filled-icn']//ancestor::a//input[@role='checkbox']";

    public String ShipmentTypeApply = "//app-shipment-type//button[contains(text(),\"%s\")]";
    public By TypesCountXpath = By.xpath(".//*[contains(text(),'TYPES')]//parent::a//*[@class='sr-tabs-badge']");
    public String ContentinGrid = ".//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//div[@col-id=\"%s\"]";
    public String topView = "//div[@class='sr-viewlist']//ul/li[1]/a[text()=\"%s\"]";
    public String viewEditIcon = "//a[text()=\"%s\"]/parent::li//span[@class='edit-icn']";
    public String views = "//a[normalize-space()=\"%s\"]";
    public String defaultViews = "//a[normalize-space()='%s(Default)']";
    public String editColumnCheckbox = "//input[@id=\"%s\"]";
    // End
    public String columnFromShipmentList = "//a[contains(text(),\"%s\")]/ancestor::div[@col-id='trackingNumber']/following-sibling::div[@col-id=\"%s\"]";
    public String commentColumn = ".//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//div[@col-id='interventionLog.intervention.comment']";
    public String shipmetTypeCheckedState = ".//input[@id=\"%s\"]";
    public By shipmentTypeBadge = By.xpath(".//*[@class='sr-tabs-badge']");
    public By saveThisViewIcon = By.xpath("//span[contains(@class,'save-view-icn')]//parent::a");
    public String saveThisViewIconVisibility = "//span[contains(@class,'save-view-icn')]//parent::a[contains(@class,\"%s\")]";
    public String saveThisViewIconEnablement = "//span[contains(@class,'save-view-icn')]//parent::a//span[contains(@class,\"%s\")]";
    public String LeftActionBar = ".//*[contains(text(),\"%s\")]//parent::div[@class='sr-actionbar-left']";
    public String RightActionBar = ".//*[contains(text(),\"%s\")]//ancestor::div[contains(@class,'sr-actionbar-right')]";
    public String RightActionIconBar = "//span[contains(@class,\"%s\")]";
    public String ChevronXpath = ".//*[contains(text(),\"%s\")]//following-sibling::span";
    public String ChevronState = ".//*[contains(text(),\"%s\")]//ancestor::a[@class='sr-tabs__nav-lnk sr-tabs__nav-lnk--menu %s']";
    public String quickViewtitlesXpath = ".//*[contains(@class,'sr-quickview-tile')]//*[@class='sr-quickview-tile__txt']";

    public String ColumnIdXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@role='columnheader']";
    public String ColumnHeaderXpath = ".//*[text()=\"%s\"]";
    public By ShipmentTypeIdXpath = By.xpath(".//*[contains(@class,'ag-header-row')]//*[@col-id='isPayer']");
    public String ColumnHeaderState = ".//*[contains(text(),\"%s\")]//ancestor::*[@role='columnheader']";
    public String TrackingNumStatus = ".//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//*[contains(@col-id,'commitTimer')]";
    public String Rowhighlight = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='ag-center-cols-clipper']//*[@aria-selected='true']";
    public String columnheaderXpath = ".//*[contains(text(),\"%s\")]//parent::div";
    public String quickViewtitlesValueXpath = ".//*[contains(@class,'sr-quickview-tile')]//*[@class='sr-quickview-tile__val']";
    public String clilckQuickView = ".//*[contains(@class,'sr-quickview-tile')]//*[contains(text(),\"%s\")]";
    public By resetPopupHeader = By.xpath(".//div[@class='sr-modal__message']");
    public By resetpopupSubtitleOne = By.xpath("(.//div[contains(@class,'sr-modal__sub-title')])[2]");
    public By resetpopupSubtitleTwo = By.xpath("(.//div[contains(@class,'sr-modal__sub-title')])[3]");
    public By resetpopupSubtitleThree = By.xpath("(.//div[contains(@class,'sr-modal__sub-title')])[4]");
    public By resetpopupCancelButton = By.xpath("//span[contains(text(),'Cancel')]");
    public String TrackingIDRowhighlight = ".//a[contains(.,\"%s\")]//ancestor::*[@class='ag-center-cols-clipper']//*[contains(@class,'ag-row-selected ')]";
    public String bubbleFilters = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s %s Days')]";
    public String bubbleFiltersHours = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s %s Hours')]";
    public String todayBubbleFilter = "//div/span[contains(text(),'%s:')]//following-sibling::span//*[contains(text(),\"%s\")]";
    public String specificDate = "//*[contains(text(),'Shipment Information')]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),'Delivered Date')]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild date-time-box']//*[contains(text(),' Specific date range ')]";
    public String selectDaysDateTimeBox = "//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild date-time-box']//select[@id='%s ']";
    public String selectDays = "//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[@class='sr-multinav']//*[@class='sr-multinav-subchild']//select[@id='%s ']";
    public By lastUpdatedAtTime = By.xpath(".//*[contains(text(),' Updated at ')]//parent::p//span");
    public By savedFilename = By.xpath(".//div[@class='file-detailsSP__nameTxt' or @class='file-detailsLP__nameTxt' ]");
    public String downLoadPageFileName = ".//span[text()=\"%s\"]";
    public String deleteDownloadFile = ".//div[@title=\"%s\"]/..//div[contains(@class,'remove-icn')]";
    public String downloaddFileButton = ".//div[@title=\"%s\"]/..//div[contains(@class,'download-file-icn')]";
    public String lastdownloadTime = ".//div[@title=\"%s\"]/..//span[contains(@class,'lastDownloadDateTime')]";
    public By displayedAvailableReports = By.xpath("//div[@class='sr-download-center__title']");
    public String deleteFileFromDC = ".//button//span[text()='Delete']";
    public String cancelButtonPopUpDC = ".//button//span[text()='Cancel']";
    public By deleteMessagePopUpDC = By.xpath("//div[contains(text(),'You are about to delete')]");
    public String downloadFileChecboxButtonDownloaded = "//span[text()=\"%s\"]/ancestor::span/preceding-sibling::div[@class='ag-selection-checkbox']";
    public String downloadFileChecboxButtonDownloadInProgress = "//span[contains(text(),\"%s\")]/ancestor::span/preceding-sibling::div[@class='ag-selection-checkbox ag-hidden']";
    public String reportDateValue = "//span[contains(text(),\"%s\")]//following::div[2]";
    public By reportDateValueCE = By.xpath("//span[contains(@class,'fw-600 requestDateTime_0')]");
    public String ShipmentListColumn = ".//*[contains(@class,'ag-header-row')]//span[contains(text(),\"%s\")]";
    public String ShipmentEditColumn = ".//li[@class='sr-shipment-filter']//div//div//input[@id=\"%s\"]";
    public By searchForColumnInfoText = By
            .cssSelector(("app-shipments-edit-column .sr-legacy-search-searchbox-character"));
    public By searchForColumnInput = By.cssSelector(("app-shipments-edit-column .search-filter .sr-searchbox__input"));
    public By columnSearchIcon = By.cssSelector(("app-shipments-edit-column .search-filter .sr-searchbox__icon"));
    public String columnAncestor = ".//*[contains(text(),\"%s\")]//ancestor::li";
    public By ExceptionIcon = By.xpath("(.//*[@class='exception sr-grid-img'])[1]");
    public By ExceptionIcons = By.xpath(".//*[@class='exception sr-grid-img']");
    public String shipment_ColumnName = "//div[@col-id='%s' and @role='gridcell']";
    public String shipmentListColumnHeader = ".//*[@class='ag-header-row ag-header-row-column']//div[@col-id=\"%s\"]";
    public By enterFilename = By.xpath(".//input[@id='fileName']");
    public By dcPopupTitle = By.xpath("//div[@class='d-flex d-flex--space-between']//div[contains(@class,'title')]");
    public By saveUptoDownloads = By.xpath("//div[@class='file-detailsSP__saveUpToTxt']");
    public String iconColor = ".//*[contains(text(),\"%s\")]//ancestor::div[contains(@class,'sr-quickview-tile')]//img";
    public By searchWatermark = By.xpath(".//*[@class='sr-multinav-subchild']//input");
    public By SearchResults = By.xpath(".//*[@class='sr-multinav-subchild']//*[@class='fdx-c-form-group__label']");
    public By CompanyAccddXpath = By.xpath(".//*[@class='sr-ctdropdown-chevron float-r m-t-1']");
    public String companyNameinDD = ".//*[contains(text(),\"%s\")]/preceding-sibling::input";
    public String workgroupNameinDD = ".//label[ contains(text(),\"%s\")]";
    public String companyAccountInDD = ".//input[@id=\"%s\"]/parent::div//span[@mat-icon-button]";
    public By CheckedColumns = By.xpath("//input[@aria-checked='true']");
    public String defaultMessageCompanyDD = ".//div[contains(text(),\"%s\")]";
    public By SelectedCompanies = By.xpath("//*[@class='sr-ctdropdown-val']");
    public String hreflink = "//div[@col-id=\"%s\"]//a";
    public String colValues = "//div[@col-id=\"%s\"]";
    public String CompanyAccountSelected = ".//input[@id=\"%s\"]/parent::div//span[contains(text(),\"%s\")]";
    public String CompanySenseawareIdLink = "//a[text()=\"%s\"]/ancestor::div[@role='row']//div[@col-id='senseAwareIdSerial']//a";
    public String ExternalLinksUnderTooling = "//*[@tabtitle='Tooling']//div[contains(text(),\"%s\")]/a";
    public String DamagedPackageColumnValue = "//a[text()=\"%s\"]/ancestor::div[@role='row']//div[@col-id='damagedPackage']";
    public String submenuText = ".//label[contains(text(),\"%s\")]";

    public String SubmenuOption = "//label[text()[normalize-space() = \"%s\"]]";

    public String ShipmentColumnValue = ".//a[text()=\"%s\"]/ancestor::div[@role='row']//div[@col-id=\"%s\"]";
    public String MyViewChevron = ".//span[text()='My Views']";
    public String StandardViewsChevron = ".//span[text()='Standard Views']";
    public String SharedViewsChevron = ".//span[text()='Shared Views']";
    public String ViewsChevron = ".//span[text()=\"%s\"]";
    public String MyViewChevronOpen = ".//span[text()='My Views']/parent::div";
    public String StandardViewsChevronOpen = ".//span[text()='Standard Views']/parent::div";
    public String SharedViewsChevronOpen = ".//span[text()='Shared Views']/parent::div";
    public String updateView = "//label[@for='updateView']";
    public String labelFor = "//label[@for=\"%s\"]";
    public String setAsDefaultView = "//label[@for='defaultView']";
    public String viewSaveDisabled = "//button[contains(text(),'Save') and @disabled]";
    public String viewSaveEnabled = "//button[contains(text(),'Save') and not(@disabled)]";
    public String StandardViewPopUpMessage = "//div[contains(text(),'You are about to make “%s” your default view, are you sure?')]";
    public By updateAtTimeFormat = By.cssSelector(".sr-aside-timestamp span");
    public String CalenderTimeOption = "//*[contains(@class,'hourselect')]";
    public String CalenderOKButton = "//button[contains(text(),'OK')]";
    public String specificDateRangeFromLast = "(//a[@class= 'calender-blue-icon'])[1]";
    // File Download Dialogue
    public By exportPrefixTextbox = By.id("fileName");
    public By invalidFilePrefixErrorMessage = By.xpath("//div[@id='fileNameInvalid']/span");
    public By downloadFileNamePostDownload = By.xpath("//span[@class='m-l-1'][1]");
    public By searchForfilterInfoText = By.cssSelector((".sr-legacy-search-searchbox-character"));
    public By searchForfilterInput = By.cssSelector((".search-filter .sr-searchbox__input"));
    public By legacyFilterSearchIcon = By.cssSelector((".search-filter .sr-searchbox__icon"));
    public String searchForFilterResultText = "//li[contains(text(),\"%s\")]";
    public By searchBoxmessage = By.cssSelector(".sr-legacy-search-searchbox-message");
    public By typesColumnValues = By.xpath(".//app-shipment-specifications/div");
    public By watchList = By.xpath("//div[@role='row']//div[@col-id='isWatched']//div[@class='watchlist']/div");
    public String expandReportInDownloadCentre = "//*[contains(text(),\"%s\")]/../../..//*[@class='plus-icn']";
    public By exportPrefixCompanyTextbox = By.xpath("//input[@aria-describedby='fileName']");
    public By exportPrefixCompanyCombinedFilesTextbox = By.xpath("(//input[@aria-describedby='fileName'])[last()]");
    public String shipmentRow = "//*[contains(text(),\"%s\")]/../../../..";
    public By shipmentOverviewFirstRow = By.xpath("//div[@row-id=0]");
    public String watchIcon = "//*[contains(text(),\"%s\")]/../../../..//*[@class='watchlist']/div";
    public By tabList = By.xpath("//ul[@role='tablist']/li");
    public By helpTextbulkTab = By.xpath("//div[@class='sr-action__tooltip-desc-bulkDesc']");
    public String deliveredDateOptions = "//*[contains(text(),\"%s\")]/../ul//li";
    public By collapseFullScreen =By.xpath("//div[@class='sr-shipment-toolbar__expand']/a[@class='close-icn bk']");

    public String editViewIconShipmentPage = "//a[contains(text(),\"%s\")]/parent::li//span[contains(@class,'edit-icn')]";
    public By deliveredDateInTheLastOptions = By.xpath("//*[@id='In the last ']");
    public String commentsInRepeatLastCommentPopUp = "//*[contains(text(),\"%s\")]/../following-sibling::div";
    public By quickViewPanelItems = By.xpath("//*[@class='sr-quickview__panel']/div");
    public By timeHourDrodown = By.xpath("//*[contains(@class,'hourselect')] | //*[contains(@class,'mat-select hourselect')]");
    public By minutesDropdown = By.xpath("//*[contains(@class,'mat-select minuteselect')]");
    //    public By timeAmPmDrodown = By.xpath("//span[contains(@class,'ng-tn')]//span[contains(text(),'AM')]");
    public By timeAmPmDrodown = By.xpath("//mat-select[contains(@class,'ampmselect')]//span/span");
    public By filterValue = By.xpath("//span[@class='sr-pill-item__txt']");
    public By bulkMenuList = By.xpath("//*[@class='sr-bulkMenulist']//li//a");
    public By addCommentsDropdown = By.xpath("//*[@id='Comments']");
    public By searchAccount = By.xpath("//mat-tree-node[@role='treeitem']");
    public By selectedCompanies = By.xpath("//*[contains(@class,'m-l-1')]/../span[last()]");
    public By companyId = By.xpath("//*[@role='treeitem']//div//input");
    public String accountIds = "//*[contains(@class,'m-x-3')]//input";
    public String filterBubleValue = ".//*[contains(text(),'%s:')]/following-sibling::span";
    public String headerMultiTrackNumbersPopUp = "//*[@class='sr-mTF1']";
    public By headerMultiTrackNumbersPopUpEle = By.xpath("//*[@class='sr-mTF1']");
    public By headerMultiTrackNumbersMt2 = By.xpath("//*[@class='sr-mTF2']");
    public By viewLimitMsg = By.xpath(".//*[@class='sr-modal__sub-title']");
    public By filterApplied = By.xpath("//*[contains(@class,'sr-active-filters')]/div");
    public String companyWorkgroupChevron = "//*[@class='chevron-icon-wrapper']";
    public String companyWorkgroupList = "//*[contains(text(),\"%s\")]/../..//label";
    public String companyChevronString = "//span[@aria-label='toggle %s']";
    public String appliedFilterCoindition = "//*[@class='sr-pill__label']/span[@class='sr-pill__filter-txt ng-star-inserted'][contains(text(),\"%s\")]/following-sibling::span";
    public By resetCompaniesBy = By.xpath("//*[contains(@class,'reset-to-default-icn')]");
    public By allColumns = By.xpath("//*[@role='columnheader']");
    public String typesIcon = ".//*[contains(text(),\"%s\")]//following-sibling::span[contains(@class,'-icn')]";
    public By companyListDropdownCheckBoxes = By.xpath("//mat-tree//input[@role='checkbox' and @aria-checked='true']");
    public String selectedRegion = "//*[@for=\"%s\"]/../../..";
    public String selectedWorkGroupInRegion = "//*[contains(text(),\"%s\")]/preceding-sibling::input";
    public String typesColIcon = "//span[@class=\"%s\"]";
    public String typesColIconHoverText = "//span[@class=\"%s\"]//following-sibling::span";
    public By workGroupCategoriesRegion = By
            .xpath("//*[@role='wg-tree']//mat-tree-node//span[contains(@aria-label,'toggle')]");
    public By fileDownloadPopUpHeader = By.xpath("//*[contains(@class,'sr-modal__titleSmallPopup')]");
    public String expandCollapseReportDownloadCentre = "//*[contains(text(),\"%s\")]/../../..//*[contains(@class,'-icn')]";
    public String workgroupAccountIds = "//*[text() = ' %s ']/../../../following-sibling::mat-tree-node//input/../label";
    public String packageDimesionsInfilter = "//div[contains(text(),\"%s\")]/../li/input";
    public String getElementWithAttribute = "//*[@type=\"%s\"]";
    public By totalSearchResults = By.xpath("//ul[@class='sr-multinav-subchild']//ul/li[@role='tab']//label");
    public By companiesInDownloadpopUp = By.xpath("//input[@class='fdx-c-form-group__checkbox']/../label");
    public By fileDetails = By.xpath("//div[@class='file-detailsSP']");
    public By senseAwareLoginPage = By.xpath("//div[@id='login-wrapper']/h2");
    public String checkboxIndicator = "//label[contains(.,\"%s\")]";
    // public By quickViewLoading =
    // By.xpath("//div[contains(@class,'fdx-c-loading-indicator')]");
    // My Shipments menu bar
    public String bulkChevronText = "//span[contains(text(),\"%s\")]";
    public String KBulk = "(//a[@aria-controls=\"%s\"]/span)[1]";
    public String hoverOverMenuText = "//div[contains(text(),\"%s\")]";
    public String hoverOverMenuIcon = "//span[@class=\"%s\"]";
    public String recipientFullAddress = "(//div[@col-id='recipientFullAddress'])[2]";
    public String recipientStreet = "(//div[@col-id='recipAddress'])[2]";
    public By resetPopup = By.xpath("//button[contains(text(),'Reset')]");
    public String recipientCity = "(//div[@col-id='recipCity'])[2]";
    public String recipientStateProvince = "(//div[@col-id='recipState'])[2]";
    public String recipientCountryTerritory = "(//div[@col-id='recipCountryOrTerritory'])[2]";
    public String recipientPostal = "(//div[@col-id='recipPostal'])[2]";
    public String timeInNetwork = "(//div[@col-id='timeSincePickup'])[2]";
    public String bubbleFiltersDay = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s %s Days')]";
    public String bubbleFiltersHour = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s %s hours')]";
    public String timeInNetworkDropdownFilter = "//select[@name ='sr-select']";
    public String durationInNetworkDropdownFilter = "(//select[@name='sr-select'])[2]";
    public By countryOrTerritoryDropdown = By.xpath("//a[contains(@aria-controls,'Country/Territory')]");
    public String countryOrTerritoryLabelInDD = "//label[contains(text(),\"%s\")]";
    public String countryOrTerritoryCheckboxinDD = ".//*[contains(text(),\"%s\")]/preceding-sibling::input";
    public By searchForPlaceholderText = By.cssSelector((".sr-searchbox__input"));
    public By dropdownSearchIcon = By.cssSelector((".sr-searchbox__icon"));
    public By clear = By.xpath("//button[contains(text(),'Clear')]");
    public String countryTerritoryShipmentXpath = "//span[contains(text(),\"%s\")]";
    public By CompanyAccddXpathRR = By.xpath(".//*[@class='sr-ctdropdown-chevron float-r']");
    public String companyAccountInDDRR = "(.//input[@id=\"%s\"]/parent::div//span[@mat-icon-button])[2]";
    public String companyNameinDDRR = ".//*[contains(text(),\"%s\")]/preceding-sibling::input";
    public By companySearchInputRR = By.xpath("//div//input[contains(@class,'sr-searchbox__input')]");
    public By columnHeaders=By.xpath("//div[@class='ag-header-cell-label']/span[@class='ag-header-cell-text']");
    public String disabledCheckBox="//label[normalize-space()=\"%s\"]//..//input[@disabled]";
    public String containerConsInputTextSearchBox="//input[@placeholder=\"%s\"]";
    public By containerColumnsLinks=By.xpath("//div[@col-id='latestContainerCONS']//a");
    public By noResultsFoundText=By.xpath("//div[text()=' No results found. ']");
    public By dropDownCheckBoxes=By.xpath("//input[@role='checkbox' and contains(@id,'sr-checkbox')]");
    public String checkBoxIndex="(//li[@class='sr-multinav-subchild__item is-alias']//input[@role='checkbox'])[%s]";
    public String aliasNameWRTAccNum="(//input[@value=%s]/ancestor::li)[2]//span[@class]";
    public By exportArrowBtn=By.xpath("//span[contains(@class,'download-icn active')]");
    public By exportIcnBtn = By.xpath("//span[@class='download-icn d-inline-block active']");
    public  By resetBtn = By.xpath("//span[@class='reset-icn active']");
    public  String checkBoxMyShipmentsFilterAliasName="//span[@class='alias-link' and contains(text(),%s)]//..//input";
    public By shipperAccountNumberColumnData=By.xpath("//div[@col-id='shipperAccountNumber' and not(contains(@role,'columnheader'))]//span");
    public By billToColumn =By.xpath("//div[@col-id='billToAccount' and not(contains(@role,'columnheader'))]//span");
    public By viewingNumber=By.xpath("//div[text()='Viewing']/following-sibling::div");
    public By yesBtnInPopUp=By.xpath("//button[contains(text(),'Yes')]");
    public By shipmentAccNumInfo=By.xpath("//label[contains(text(),' Shipper Account # ')]/following-sibling::div[@class='sr-data']");
    public By shipmentAliasNameInfo=By.xpath("//label[contains(text(),' Shipper Account # ')]/following-sibling::div[@class='sr-data']/span");
    public By aliasNameLink=By.xpath("//span[@class='sr-aliaslink']");
    public By shipmentTrackingAccNumAliasNameInfo=By.xpath("//label[contains(text(),' Shipper Account # ')]/following-sibling::div");
    public By firstTrackingNum=By.xpath("(//div[@class='sr-grid__cell--lnk']/a)[1]");
    public By filterCloseCrossIcn=By.xpath("//span[contains(@class,'sr-pill__close')]");
    public By firstfilterCloseIcon=By.xpath("(//span[contains(@class,'sr-pill__close')])[1]");
    public String scheduledDeliveryText="//label[contains(text(),\"%s\")]//..//div";
    public By firstEstimatedDelivery =By.xpath("(//span[contains(@class,'edtWindowStart')])[1]");
    public By estimatedDeliveryColDates=By.xpath("//span[contains(@class,'edtWindowStart')]");
    public By noCheckBox =By.xpath("//label[text()=' No ']/preceding-sibling::input");
    public String deleteIcnBesideFileName="//span[contains(text(),%s)]//..//..//..//..//..//../div[@col-id='remove']//div[contains(@class,'remove-icn')]";
    public By deleteBtnInPopUp =By.xpath("//button/span[contains(text(),'Delete')]");
    public By getColumnNames = By.xpath("(.//*[contains(@class,'ag-header-row')]//span[@ref='eText'])[position()>1]");
    public By recipientAddress = By.xpath("//span[@class='recipientFullAddress_0']");
    public String DropDownRegion = "//*[@id='region']";
    public String RegionOption =  "//option[contains(text(),\"%s\")]";
    String gridColumnNamesList="(//div[@class='sr-grid-row']/div[@class='sr-grid-6col'])[%s]//input/following-sibling::label";

    public By SearchBarValidation = By.xpath("//input[@placeholder='Search e.g. HEX or HOPS']");
    public String ButtonEnabled = "//button[contains(text(),\"%s\")]";
    public String ButtonDisabled = "//button[contains(text(),\"%s\") and @disabled]";
    public By Result_Chckbox = By.xpath("//li[@tabindex='0' and @role='tab']//input[@role='checkbox']");
    public By FilterResult = By.xpath("(//li[@class='sr-multinav-subchild__item']//input)[position()>1]");
    public By FilterName = By.xpath("//div[@class='sr-pill__label']//span[@class='sr-pill__filter-txt']");
    public By FilterItemResult = By.xpath("//div[@class='sr-pill__label']//span[@class='sr-pill-item__txt']");
    public  String columnHeaderMS = "//span[contains(text(),\"%s\")]";

    String currentLocalTime;
    List<String> secondViewCards = Arrays.asList("All Exceptions", "Delivery Exception", "SenseAware ID");
    List<String> thirdViewCards = Arrays.asList("Monitored", "Priority Alert", "Intervened");
    String delayedStatus = "At Risk";
    String detailedDelayReason = "Delayed Movement in ";


    public By DashboardLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View on Dashboard')]");
    public By ActSummaryLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View Account Summary')]");
    public By MyShipmentLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View in My Shipments')]");

    public By DashboardCountLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View on Dashboard')]//..//div[@class='sr-tile-val']");
    public By ActSummaryCountLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View Account Summary')]//..//div[@class='sr-tile-val']");
    public By MyShipmentCountLink = By.xpath("//li[@class='sr-tile-list__item']//a[contains(.,'View in My Shipments')]//..//div[@class='sr-tile-val']");
    public By Errorpage= By.xpath("//a[text()=\"breadCrumb.fedex\"]");
    public String filtername="//span[contains(text(),\"%s\")]";
    public By searchlistcolumn=By.xpath("//ul[@class='sr-legacy-search-list__colfilter']/li");

    public String FilterOptions="//li[@class='sr-multinav-subchild__list']/div[contains(text(),\"%s\")]/following-sibling::ul//label[contains(text(),\"%s\")]";
    public By filterValues=By.xpath("//div[@class='sr-pill__label']/span");
    public String FilterOptionCheckbox="//li[@class='sr-multinav-subchild__list']/div[contains(text(),\"%s\")]/following-sibling::ul//label[contains(text(),\"%s\")]/preceding-sibling::input";
    public By FilterBubbleValues=By.xpath("//div[@class='sr-pill__label']/span");
    public By FilterBubbleVerifyValues=By.xpath("(//div[@class='sr-pill__label']/span)[4]");
    public String searchBox=".//*[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*//input[@placeholder='Search']";

    public String searchBox1=".//*[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*[@class='sr-multinav-child']//a[contains(text(),\"%s\")]//ancestor::*[contains(@class,'sr-multinav')]//*//input[contains(@placeholder,\"%s\")]";
    public String editaliasinshipmentdata="//span[@class=\"sr-aliaslink\"]";

    public String searchOptions="//ul[contains(@class,'sr-multinav-subchild-items sr-multinav-subchild-items')]/li//label[contains(text(),\"%s\")]";
    public String searchOptions1="//ul[contains(@class,'sr-multinav-subchild-items sr-multinav-subchild-items')]//li//label[contains(text(),\"%s\")]";

    public String AccountNumber="//div[contains(@class,'ag-cell-label-container ag-header-cell-sorted')]";
    public String account="//div[@class=\"ag-header-cell-label\"]//span[contains(.,'Accounts (')]";


    public By calenderLeftArrowPrev = By.xpath("//div[@class='calendar left']//th[@class='prev available']");
    public By calenderLeftArrowNext = By.xpath("//div[@class='calendar left']//th[@class='next available']");

    public By okButtonAfterRefresh = By.xpath("//button[contains(text(),'ok')]");
    public By expandButton=By.xpath("//div[@class='sr-shipment-toolbar__expand']/a[contains(@class,'expand')]");
    public By closeFulLScreen=By.xpath("//div[@class='sr-shipment-toolbar__expand']/a[contains(@class,'close')]");
    public By filterIsNotDisplayed = By.xpath("//label[contains(text(),\"%s\")]/preceding-sibling::input[@id='04']");
    public By resetDisableButton=By.xpath("//a/span[@class='reset-icn']");
    //  public By validateFilterBubble= By.xpath("//span[contains(text(),'Scheduled Delivery Date/Time:')]");
    public String headerButton="//span[text()=\"%s\"]/parent::a[contains(@class,'disable')]";
    public By saveViewDisableButton=By.xpath("//span[@class='save-view-icn']/parent::a[contains(@class,'disable')]");
    public By typesColumn=By.xpath("//div[@role='gridcell' and @col-id='isPayer']");
    public By typesHover=By.xpath("(//div[@role='gridcell' and @col-id='isPayer']//div[@class='sr-hover-card__txt']/span)[2]");
    List<String> expandedFirstViewCards = Arrays.asList("Out For Delivery", "In Transit", "At Risk", "All Exceptions",
            "Delivery Exception", "SenseAware ID");
    public String apply = GenericFunction.locale != Constants.EN_US
            ? this.genericFunctionObject.getLocalizedValue("Apply")
            : "Apply";
    public String applyUpperCase = apply.toUpperCase();

    public ShipmentOverviewPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.genericFuncObj = new GenericFunction();
        this.api = new TestAPI(commonHelpers);
        this.apiobj = new API_GenericFun(this.commonHelpers);
        this.homePage = new HomePage(this.commonHelpers);
        this.dateTimeUtils = new DateTimeUtils();
        this.accountAlias= new AccountAlias(this.commonHelpers);
        this.advisoryPage=new AdvisoryPage(this.commonHelpers);
    }

    public String getShipmentEditColumn() {
        return ShipmentEditColumn;
    }

    public String getShipmentListColumn() {
        return ShipmentListColumn;
    }

    /**
     * Function for setting value in File Download Text field
     *
     * @param textBoxElement,textToEnter textBoxElement would be logical text (or a
     *                                   defined 'By' object name) which represents
     *                                   the textbox displayed on screen.
     */
    public void setTextInFileDownloadTextBox(String textBoxElement, String textToEnter) {
        By textBoxByElement = null;
        if (textBoxElement.equalsIgnoreCase("exportPrefixTextbox"))
            textBoxByElement = exportPrefixTextbox;
        else if (textBoxElement.equalsIgnoreCase("exportPrefixCompanyTextbox")) {
            textBoxByElement = exportPrefixCompanyTextbox;
        } else if (textBoxElement.equalsIgnoreCase("exportPrefixCompanyCombinedFilesTextbox")) {
            textBoxByElement = exportPrefixCompanyCombinedFilesTextbox;
        }
        this.enterText(textBoxByElement, textToEnter);
    }

    /**
     * Function for verifying any message on FileDownload screen.
     *
     * @param elementName,expectedMessage elementName will be logical text (or a
     *                                    defined 'By' object name which holds the
     *                                    message on screen)
     *                                    that would describe the message is on
     *                                    screen.
     */
    public void verifyMessageOnFileDownloadScreen(String elementName, String expectedMessage) {
        String actualMessageText = "";
        if (elementName.equalsIgnoreCase("invalidFilePrefixErrorMessage")) {
            actualMessageText = this.findElement(invalidFilePrefixErrorMessage).getText();
            actualMessageText = actualMessageText.substring(1);
        }
        Assert.assertTrue("Actual message does not match with expected message ",
                actualMessageText.equalsIgnoreCase(expectedMessage));
    }

    /**
     * Function for Moving left most and than click on Arrow to find and Click Quick
     * Card Method is similar to Carousel.
     *
     * @param cardName
     */
    public void ClickOncardView(String cardName) {

        boolean flag;
        if (!Constants.QuickViewCardNames.contains(cardName)) {
            if (cardName.equalsIgnoreCase("NO COMMIT")) {
                cardName = "No commit";
            } else if (cardName.equalsIgnoreCase("NEAR COMMIT")) {
                cardName = "Near commit";
            } else if (cardName.equalsIgnoreCase("PAST COMMIT")) {
                cardName = "Past commit";
            } else if (cardName.equalsIgnoreCase("IPD SHIPMENTS")) {
                cardName = "IPD Shipments";
            } else if (cardName.equalsIgnoreCase("SenseAware ID")) {
                cardName = "SenseAware ID";
            }
            else if (cardName.equalsIgnoreCase("On the way")) {
                cardName = "On the way";
            }
            else if (cardName.equalsIgnoreCase("Delay")) {
                cardName = "Delay";
            }else if (cardName.equalsIgnoreCase("RETURNING TO SHIPPER")) {
                cardName = "Returning to Shipper";
            }
            else {
                cardName = WordUtils.capitalizeFully(cardName);
            }
        }
        this.waitUntilVisible(this.loadingIndicator);
        this.waitUntilNotVisible(this.loadingIndicator);
        // this.commonHelpers.thinkTimer(5000);
        int number = Integer.parseInt(this.getText(this.getByusingString(String.format(cardCountxpath, cardName)))
                .replace(",", ""));
        flag = number > 0;
        String cardCount = this.getText(this.getByusingString(String.format(cardCountxpath, cardName))).replace(",",
                "");
        if (flag) {
            this.clickOnElement(this.getByusingString(String.format(cardCountxpath, cardName)));
            this.waitUntilNotVisible(this.loadingIndicator);
        } else {
            log.info(
                    " **ALERT** Since the card count is 0. So skipping any further validations for QVC cardname = "
                            + cardName);
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        this.commonHelpers.AddToContextStore(cardName, cardCount);
    }

    public void ClickOncardViewLocalization(String cardName) {

        boolean flag;
        if (!Constants.QuickViewCardNames.contains(cardName)) {
            if (cardName.equalsIgnoreCase("NO COMMIT")) {
                cardName = "No commit";
            } else if (cardName.equalsIgnoreCase("NEAR COMMIT")) {
                cardName = "Near commit";
            } else if (cardName.equalsIgnoreCase("PAST COMMIT")) {
                cardName = "Past commit";
            } else if (cardName.equalsIgnoreCase("IPD SHIPMENTS")) {
                cardName = "IPD Shipments";
            } else if (cardName.equalsIgnoreCase("SenseAware ID")) {
                cardName = "SenseAware ID";
            }
            else if (cardName.equalsIgnoreCase("On the way")) {
                cardName = "On the way";
            }
            else if (cardName.equalsIgnoreCase("Delay")) {
                cardName = "Delay";
            }else if (cardName.equalsIgnoreCase("RETURNING TO SHIPPER")) {
                cardName = "Returning to Shipper";
            }
            else {
                cardName = WordUtils.capitalizeFully(cardName);
            }
        }
        this.waitUntilVisible(this.loadingIndicator);
        this.waitUntilNotVisible(this.loadingIndicator);
        // this.commonHelpers.thinkTimer(5000);
        cardName=this.genericFuncObj.getLocalizedValue(cardName);
        int number = Integer.parseInt(this.getText(this.getByusingString(String.format(cardCountxpath, cardName)))
                .replace(",", ""));
        flag = number > 0;
        String cardCount = this.getText(this.getByusingString(String.format(cardCountxpath, cardName))).replace(",",
                "");
        if (flag) {
            this.clickOnElement(this.getByusingString(String.format(cardCountxpath, cardName)));
            this.waitUntilNotVisible(this.loadingIndicator);
        } else {
            log.info(
                    " **ALERT** Since the card count is 0. So skipping any further validations for QVC cardname = "
                            + cardName);
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        this.commonHelpers.AddToContextStore(cardName, cardCount);
    }

    public void ClickOnSaveViewCard(String cardName) {
        boolean flag;
        this.commonHelpers.thinkTimer(5000);
        int number = Integer.parseInt(this.getText(this.getByusingString(String.format(cardCountxpath, cardName)))
                .replace(",", ""));
        flag = number > 0;
        String cardCount = this.getText(this.getByusingString(String.format(cardCountxpath, cardName))).replace(",",
                "");
        if (flag) {
            this.clickOnElement(this.getByusingString(String.format(cardCountxpath, cardName)));
            this.waitUntilNotVisible(this.loadingIndicator);
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        this.commonHelpers.AddToContextStore(cardName, cardCount);
        Assert.assertTrue("save view count is mismatched",
                this.commonHelpers.AssertCountswithCorrection(Integer.parseInt(cardCount),
                        Integer.parseInt(this.getViewingCount())));
    }

    public Boolean ValidateViewingCount(String contextStoreKey) {
        String ExpectedCount = this.commonHelpers.getValuefromContextStore(contextStoreKey).toString();
        String actualCount = String.valueOf(this.getViewCount());
        return this.commonHelpers.AssertCountswithCorrection(Integer.parseInt(ExpectedCount),
                Integer.parseInt(actualCount));
    }

    /**
     * Function will search Carousel based on CardName and click on Carousel which
     * have quick view card
     *
     * @param cardName
     * @param isExpandedView
     */
    public void carouselNav(String cardName, String isExpandedView) {
        if (!Constants.QuickViewCardNames.contains(cardName)) {
            final char[] delimiters = {' ', '_'};
            cardName = WordUtils.capitalizeFully(cardName, delimiters);
        }
        if (isExpandedView.equalsIgnoreCase("No")) {
            if (secondViewCards.contains(cardName)) {
                this.clickOnElement(qcrightArrow);
            } else if (thirdViewCards.contains(cardName)) {
                this.clickOnElement(qcrightArrow);
                this.clickOnElement(qcrightArrow);
            }
        } else {
            if (!expandedFirstViewCards.contains(cardName)) {
                this.clickOnElement(qcrightArrow);
            }
        }
    }

    public boolean VerifyQuickViewCardHighlight(String cardName) {
        boolean flag;
        String filteredRecords = this.commonHelpers.getValuefromContextStore(cardName).toString();
        if (Integer.parseInt(filteredRecords) > 0) {
            ClickOncardView(cardName);
            // this.waitUntilNotVisible(this.loadingIndicator);
            String cardhighlight = "";
            switch (cardName) {
                case "IN TRANSIT":
                    cardhighlight = Constants.inprogressQChighlght;
                    break;
                case "OUT FOR DELIVERY":
                    cardhighlight = Constants.outfordeliveryQChighlght;
                    break;
                case "MONITORED":
                    cardhighlight = Constants.monitoredQChighlght;
                    break;
                case "ALL EXCEPTIONS":
                    cardhighlight = Constants.allexceptionsQChighlght;
                    break;
                case "DELIVERY EXCEPTION":
                    cardhighlight = Constants.deliveryExceptionsQChighlght;
                    break;
                case "AT RISK":
                    cardhighlight = Constants.atRiskQChighlght;
                    break;
                case "DELAYED":
                    cardhighlight = Constants.delayedQChighlght;
                    break;
                case "EARLY":
                    cardhighlight = Constants.earlyQChighlght;
                    break;
                case "NO COMMIT":
                    cardhighlight = Constants.noCommitQChighlght;
                    break;
                case "NEAR COMMIT":
                    cardhighlight = Constants.nearCommitQChighlght;
                    break;
                case "PAST COMMIT":
                    cardhighlight = Constants.pastCommitQChighlght;
                    break;
                case "IPD SHIPMENTS":
                    cardhighlight = Constants.ipdShipmentsQCHighlight;
                    break;
                case "CLEARANCE DELAY":
                    cardhighlight = Constants.clearanceDelayQCHighlight;
                    break;
                case "CUSTOMS CLEARANCE":
                    cardhighlight = Constants.customsClearanceQCHighlight;
                    break;
            }
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                if (cardName.equalsIgnoreCase("NO COMMIT")) {
                    cardName = "No commit";
                } else if (cardName.equalsIgnoreCase("NEAR COMMIT")) {
                    cardName = "Near commit";
                } else if (cardName.equalsIgnoreCase("PAST COMMIT")) {
                    cardName = "Past commit";
                } else if (cardName.equalsIgnoreCase("IPD SHIPMENTS")) {
                    cardName = "IPD Shipments";
                } else {
                    cardName = WordUtils.capitalizeFully(cardName);
                }
            }
            flag = this.elementIsDisplayed(this.getByusingString(String.format(QCHighlight, cardName, cardhighlight)));
        } else {
            this.carouselNav(cardName, "Yes");
            flag = this.elementIsDisplayed(this.getByusingString(String.format(disabledQCards, cardName)));
        }

        return flag;
    }

    /**
     * Function will do these works 1. Take the Quick View Card Count based on Card
     * Name 2. Add to Context Store based on CardName as Key 3. If in Viewing Count
     * = 0 - return false.
     *
     * @param cardName
     * @return
     */
    public boolean CompareCountonCardandViewing(String cardName) {
        if (!Constants.QuickViewCardNames.contains(cardName)) {
            if (cardName.equalsIgnoreCase("NO COMMIT")) {
                cardName = "No commit";
            } else if (cardName.equalsIgnoreCase("NEAR COMMIT")) {
                cardName = "Near commit";
            } else if (cardName.equalsIgnoreCase("PAST COMMIT")) {
                cardName = "Past commit";
            } else if (cardName.equalsIgnoreCase("IPD SHIPMENTS")) {
                cardName = "IPD Shipments";
            } else if (cardName.equalsIgnoreCase("RETURNING TO SHIPPER")) {
                cardName = "Returning to Shipper";
            } else {
                cardName = WordUtils.capitalizeFully(cardName);
            }
        }
        String cardCount = this.getText(this.getByusingString(String.format(cardCountxpath, cardName))).replaceAll(",",
                "");
        this.commonHelpers.AddToContextStore(cardName.toUpperCase(), cardCount);

        // if Count = 0 case
        if (Integer.parseInt(cardCount) == 0)
            return true; // because ideally in no case 0 should will come since 0 is disabled now//

            // For else cases
        else {
            return this.commonHelpers.AssertCountswithCorrection(Integer.parseInt(cardCount),
                    Integer.parseInt(this.getViewingCount()));
        }

    }

    public Boolean ValidateColorinUI(String iconorBackGround, String QCName) {
        Boolean flag = false;
        switch (QCName) {
            case "Delayed":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.DelayedIconColor);
                }
                break;
            case "Early":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.EarlyIconColor);
                }
                break;
            case "Near commit":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.EarlyIconColor);
                }
                break;
            case "No commit":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.EarlyIconColor);
                }
                break;
            case "Past commit":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.PastCommitIconColor);
                }
                break;
            case "Monitored":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.MonitoredIconColor);
                }
                break;
            case "All Exceptions":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.AllExceptionsIconColor);
                }
                break;
            case "IPD Shipments":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.IpdShipmentsIconColor);
                }
                break;
            case "Clearance Delay":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.ClearanceDelayIconColor);
                }
                break;
            case "Customs Clearance":
                if (iconorBackGround.equalsIgnoreCase("icon")) {
                    log.info("Icon Color: " + this
                            .findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src"));
                    flag = this.findElement(this.getByusingString(String.format(this.iconColor, QCName)))
                            .getAttribute("src").contains(Constants.CustomsClearanceIconColor);
                }
                break;

        }
        return flag;
    }

    public void clickAccountDropdown() {
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public void SelectMultipleCompanyAccountDD(DataTable dataTable) throws Exception {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.CompanyAccddXpath);
        // Clearing if any company/ies are already selected
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));

        for (String key : dataFilters.keySet()) {
            if (dataFilters.get(key) != null) {
                if (!dataFilters.get(key).isEmpty()) {
                    this.JavaScriptClick(By.xpath(String.format(this.companyAccountInDD, key)));

                    // if you have passed specific accounts id
                    String[] accountIds = dataFilters.get(key).trim().split(",");
                    for (String accountId : accountIds) {
                        this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, accountId)));
                    }
                }
            } else if (key.contains("ContextStore-")) {
                key = (String) this.commonHelpers.getValuefromContextStore(key.split("-")[1]);
            }
            // Searching the company, so it appears at the top and becomes clickable
            this.enterText(companySearchInput, key);
            this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, key)));
        }

        int number = this.getCompanyCountFromDropdownText(this.getCompanyDropdownText());
        log.info("The total number of accounts under company selected are " + number);

        // cannot click on apply if accounts are more than 250
        if (number > 250) {
            // Then the below button should be disabled
            Assert.assertFalse(" 'Apply' button is enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Apply "))));
            Assert.assertFalse(" 'Set As default' button is enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Set As Default "))));

            // Also validating the message for maximum accounts
            Assert.assertEquals(this.getText(this.CompanyAccDefaultMessage), Constants.maxAccountErrorMsg);

            // Since in this condition we should not try to click on apply button as its
            // disabled as expected
            return;
        }

        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
    }

    public void unSelectMultipleCompanyAccountDD(DataTable dataTable) throws Exception {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);

        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).isEmpty()) {
                this.JavaScriptClick(By.xpath(String.format(this.companyAccountInDD, key)));

                // if you have passed specific accounts id
                String[] accountIds = dataFilters.get(key).trim().split(",");
                for (String accountId : accountIds) {
                    this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, accountId)));
                }
            } else if (key.contains("ContextStore-")) {
                key = (String) this.commonHelpers.getValuefromContextStore(key.split("-")[1]);
            }
            // Searching the company so it appears at the top and becomes clickable
            this.enterText(companySearchInput, key);
            // now this will unselect
            this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, key)));
        }

        int number = this.getCompanyCountFromDropdownText(this.getCompanyDropdownText());
        log.info("The total number of accounts under company selected are " + number);

        // cannot click on apply if accounts are more than 250
        if (number <= 250) {
            // Then the below button should be disabled
            Assert.assertTrue(" 'Apply' button is not enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Apply "))));
            Assert.assertTrue(" 'Set As default' button is not enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Set As Default "))));

            // Also validating the message for maximum accounts is removed
            Assert.assertFalse(this.elementIsDisplayed(CompanyAccDefaultMessage));
        }
        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
    }

    public void searchCompanyAccount(String companyName) {
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.commonHelpers.thinkTimer(10000);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, companyName);
    }

    public void validateCompanySearchResult(DataTable dataTable) {
        List<String> searchResults = dataTable.asList(String.class);
        for (String key : searchResults) {
            Assert.assertTrue("Comapany: " + key + " is not present in company search result",
                    this.elementIsDisplayed(By.xpath(String.format(this.filterSearchResult, key))));
        }
    }

    public Boolean validateCompanyEmptySearchResult() {
        return this.elementIsDisplayed(By.xpath(this.filterEmptySearchResult));
    }

    public String getCompanyDropdownText() {
        return this.getText(this.SelectedCompanies);
    }

    public int getCompanyCountFromDropdownText(String companyDropdowntext) {
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(companyDropdowntext);
        int number = 0;
        while (matcher.find()) {
            number = Integer.parseInt(matcher.group());
        }
        return number;
    }

    public void ClearCompanyDDAndValidate() {

        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));

        Assert.assertTrue("Default message on account dropdown is not right", this.elementIsDisplayed(
                By.xpath(String.format(this.defaultMessageCompanyDD, Constants.noAccountSelectedMsg))));
        Assert.assertFalse(" 'Set As default' button is enabled ",
                this.IsElementEnabled(By.xpath(this.getXPathforButton("Set As Default "))));
        Assert.assertFalse(" 'Clear' button is enabled ",
                this.IsElementEnabled(By.xpath(this.getXPathforButton("Clear "))));
        Assert.assertFalse(" 'Apply' button is enabled ",
                this.IsElementEnabled(By.xpath(this.getXPathforButton("Apply "))));

        Assert.assertEquals("Some of the checkboxes are ticked when they should not be", 0,
                this.findElements(this.companyListDropdownCheckBoxes).size());

        Assert.assertTrue("Companies in the dropdown are not sorted ", verifyCompanyAccountsSorting());
        // closing the dropdown
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public boolean VerifyFilterBubbles(String cardName) {
        Boolean flag = this.elementIsDisplayed(this.getByusingString(String.format(filterBubble, cardName)));
        this.ClickOncardView(cardName);
        return flag;
    }

    public boolean VerifyFilterBubbleVisibility(String cardName) {
        if (this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            return true;
        } else {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
                if (cardName.equals("Out For Delivery")) {
                    cardName = "Out for Delivery";
                }
                if (cardName.equals("Delivery Exceptions")) {
                    cardName = "Delivery Exception";
                }
            }
            return this.elementIsDisplayed(this.getByusingString(String.format(filterBubble, cardName)));
        }
    }

    public Boolean ValidateDropdownValues(String DropDownType, DataTable table) {
        Boolean flag = true;
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType)));

        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();

        List<String> expectedValues = table.asList(String.class);
        for (String option : expectedValues) {
            if (user.equalsIgnoreCase("user2")
                    && (option.equalsIgnoreCase("Select") || option.equalsIgnoreCase("Monitored")))
                continue; // since for user2 , these 2 options dont come in dropdown

            if (flag) {
                if (option.equalsIgnoreCase("Monitored")) {
                    // There is no icon in case of monitored
                    flag = this
                            .elementIsDisplayed(By.xpath(String.format(this.TypesOptionsXpath, DropDownType, option)));

                } else {
                    flag = this
                            .elementIsDisplayed(By.xpath(String.format(this.TypesOptionsXpath, DropDownType, option)))
                            && this.elementIsDisplayed(
                            By.xpath(String.format(this.TypesIconsXpath, DropDownType, option)));
                }
                log.info("Shipment Type: " + option);
            }
        }
        this.JavaScriptClick(By.xpath(String.format(this.TypesCollapse, DropDownType)));
        return flag;
    }

    public Boolean ValidateBulkDropDownValues(String DropDownType, DataTable table) {
        Boolean flag = true;
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType)));
        List<String> expectedValues = table.asList(String.class);
        for (String option : expectedValues) {
            if (flag) {
                flag = this.elementIsDisplayed(By.xpath(String.format(this.bulkOptionMenu, DropDownType, option)));
            }
        }
        this.JavaScriptClick(By.xpath(String.format(this.TypesCollapse, DropDownType)));
        return flag;
    }

    public Boolean SelectValuesFromDD(String DropDownType, DataTable table) {
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType)));
        List<String> optionsToSelect = table.asList(String.class);
        for (String option : optionsToSelect) {
            if (option.equalsIgnoreCase("Watched")) {
                this.JavaScriptClick(By.xpath(String.format(this.WatchedTypesOptionsCBXpath, DropDownType, option)));
            } else {
                this.JavaScriptClick(By.xpath(String.format(this.TypesOptionsCBXpath, option)));
            }
        }
        this.JavaScriptClick(By.xpath(String.format(this.ShipmentTypeApply, this.apply)));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToTop();
        // Validation of number on shipment types
        return Integer.parseInt(this.getText(this.TypesCountXpath)) >= 1;
    }

    public Boolean SelectValuesFromDDForLocalization(String DropDownType, DataTable table) {
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType.toUpperCase())));
        List<String> optionsToSelect = table.asList(String.class);
        for (String option : optionsToSelect) {
            if (option.equalsIgnoreCase("Watched")) {
                this.JavaScriptClick(By.xpath(String.format(this.WatchedTypesOptionsCBXpath, DropDownType, option)));
            } else {
                this.JavaScriptClick(By.xpath(String.format(this.TypesOptionsCBXpath, option)));
            }
        }
        this.JavaScriptClick(By.xpath(String.format(this.ShipmentTypeApply, this.apply)));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToTop();
        // Validation of number on shipment types
        //return Integer.parseInt(this.getText(this.TypesCountXpath)) >= 1;
        return true;
    }

    public void GetShipmentsData(String cardName) {
        this.waitUntilNotVisible(this.quickViewLoading);
        if (!cardName.equalsIgnoreCase("Total Records")) {
            String filteredRecords = this.commonHelpers.getValuefromContextStore(cardName).toString();
            if (Integer.parseInt(filteredRecords) > 0) {
                // this.carouselNav(cardName, "Yes");
                if (!Constants.QuickViewCardNames.contains(cardName)) {
                    if (cardName.equalsIgnoreCase("NO COMMIT")) {
                        cardName = "No commit";
                    } else if (cardName.equalsIgnoreCase("NEAR COMMIT")) {
                        cardName = "Near commit";
                    } else if (cardName.equalsIgnoreCase("PAST COMMIT")) {
                        cardName = "Past commit";
                    } else if (cardName.equalsIgnoreCase("IPD SHIPMENTS")) {
                        cardName = "IPD Shipments";
                    } else {
                        cardName = WordUtils.capitalizeFully(cardName);
                    }
                }
                this.commonHelpers.thinkTimer(1000);
                this.commonHelpers.AddToContextStore("UI-" + cardName,
                        this.getText(this.getByusingString(String.format(cardCountxpath, cardName))));
            } else {
                this.commonHelpers.AddToContextStore("UI-" + cardName, "0");
            }

        } else {
            this.commonHelpers.AddToContextStore("UI-" + cardName, this.getText(TotalRecordsXpath));
        }
    }

    public int getShipmentRecordsCount() {
        commonHelpers.thinkTimer(5000);// Using force wait since not able to catch the spinner
        // return this.findElements(shipmentRecordsCount).size();

        int shipmentsPerPage = getSelectedShipmentsPerPageValue();
        int totalShipments = totalShipmentsCount();
        int pageCount = getExpectedShipmentsPageCount();
        int shipments = (totalShipments % shipmentsPerPage) == 0 ? (totalShipments / pageCount) : shipmentsPerPage;

        return shipments;
    }

    public void setShipmentsCountPerPage(String recordsCount) {
        this.selectDropdown(shipmentsCountSlection, "text", recordsCount);
        this.waitUntilNotVisible(loadingIndicator);
    }

    public void paginationToRight() {
        this.clickOnElement(shipmentsPageRightNavigation);
    }

    public void paginationToLeft() {
        this.clickOnElement(shipmentsPageLeftNavigation);
    }

    public void expandView(String viewState) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (viewState.equalsIgnoreCase("expand")
                && this.elementIsDisplayed(By.xpath(String.format(expandIcon, "expand")))) {
            this.JavaScriptClick(By.xpath(String.format(expandIcon, "expand")));
        } else {
            this.clickOnElement(By.xpath(String.format(expandIcon, "close")));
        }
    }

    public void clickOnApplyButton(String link) {
        this.JavaScriptClick(this.findElement(By.xpath(String.format(editColApplyBtn, link))));
        this.ScrollToTop();
    }

    public Boolean ValidateColumnValues(String columnName, DataTable Values) {
        List<String> expectedValues1 = Values.asList(String.class);
        List<String> expectedValues2 = new ArrayList<>();
        HashSet<Boolean> flag1 = new HashSet<>();
        // By default, user can verify first 13 records from UI
        // If user wants to verify same value against column, then below code will
        // handle it by adding
        // column value to list 13 times TC-122322

        for (int i = 0; i < expectedValues1.size(); i++) {
            String value = "";
            if (!expectedValues1.contains(null)) {
                value = this.commonHelpers.verifyKeyInContextStore(expectedValues1.get(i))
                        ? this.commonHelpers.getValuefromContextStore(expectedValues1.get(i)).toString().trim()
                        : expectedValues1.get(i);
            }
            expectedValues2.add(i, value);
        }

        if (columnName.contains("Package Dimensions")) {
            String unit = " cm.";
            if (columnName.contains("(In)")) {
                unit = " in.";
            }
            String newVal = String.join("x", expectedValues2) + unit;
            expectedValues2.removeAll(expectedValues2);
            expectedValues2.add(newVal);
        }

        Set<String> actualValues = new HashSet<String>();
        String columnId = "";
        boolean flag = this.elementIsDisplayed(By.xpath(String.format(this.columnHeader, columnName)));
        switch (columnName) {
            case "Weather Impacted":
                columnId = "weatherImpacted";
                break;
            case "Commit Time":
                columnId = "commitTimer";
                break;
            case "Nak Scan":
                columnId = "nakScan";
                break;
            case "Delivery Prediction":
                columnId = "packageDelayStatus";
                break;
            case "CER Number":
                columnId = "cerNumbers";
                break;
            case "Container ID":
                columnId = "latestContainerId";
                break;
            case "Last Known Ramp":
                columnId = "lastKnownRamp";
                break;
            case "Industry Vertical":
                columnId = "industryVerticalName";
                break;
            case "Damaged Package":
                columnId = "damagedPackage";
                break;
            case "Last Comment":
                columnId = "lastComment";
                break;
            case "Latest Primary Event":
                columnId = "latestPrimaryEvent";
                break;
            case "RMA":
                columnId = "rma";
                break;
            case "Personal Note":
                columnId = "personalNotesMessage";
                break;
            case "Address Correction":
                columnId = "addressCorrection";
                break;
            case "POD Exception":
                columnId = "podException";
                break;
            case "Exception Reason":
                columnId = "exceptionReason";
                break;
            case "Support Update":
                columnId = "supportUpdate";
                break;
            case "Commodity Information":
                columnId = "commodityInformation";
                break;
            case "Appointment Delivery":
                columnId = "appointmentDelivery";
                break;
            case "SenseAware Mobile":
                columnId = "senseAwareJourneyId";
                break;
            case "SenseAware Id Status":
                columnId = "senseAwareIdStatus";
                break;
            case "Status":
                columnId = "status";
                break;
            case "Special Handling":
                columnId = "specialHandling";
                break;
            case "Delivery Attempts":
                columnId = "deliveryAttempts";
                break;
            case "Package Weight (LBS)":
                columnId = "pkgWtLbs";
                break;
            case "Package Weight (KGS)":
                columnId = "pkgWtKg";
                break;
            case "Total Weight (LBS)":
                columnId = "totalWtLbs";
                break;
            case "Total Weight (KGS)":
                columnId = "totalWtKg";
                break;
            case "Types":
                columnId = "isPayer";
                break;
            case "CER Count":
                columnId = "cerCount";
                break;
            case "Package Dimensions (In)":
                columnId = "packageDimsIn";
                break;
            case "Scheduled Delivery Date/Time":
                columnId = "scheduledDeliveryDateDestTZ";
                break;
            case "Cold Storage Temp - Min (°C)":
                columnId = "coldStorageTemperatureMinC";
                break;
            case "Cold Storage Temp - Max (°C)":
                columnId = "coldStorageTemperatureMaxC";
                break;
            case "Recipient Country/ Territory":
                columnId = "recipCountryOrTerritory";
                break;
            case "Cold Storage Date/Time":
                columnId = "coldStorageTemperatureDateTime";
                break;
            case "Dry Ice Added (Kg)":
                columnId = "dryIceAddedKgs";
                break;
            case "Dry Ice Added (Lbs)":
                columnId = "dryIceAddedLbs";
                break;
            case "Dry Ice Added Date/Time":
                columnId = "dryIceAddedDateTime";
                break;
            case "Gel Pack Quantity":
                columnId = "gelPackQuantity";
                break;
            case "Gel Pack Date/Time":
                columnId = "gelPackDateTime";
                break;
            case "Estimated Delivery Date/Time":
                columnId = "edtWindowStart";
                break;
            case "Service Type":
                columnId = "serviceType";
                break;
            case "Workgroup":
                columnId = "workgroups";
                break;
        }
        List<WebElement> columnValues;
        // boolean types = false;
        if (columnName.equals("Types")) {
            List<String> uiTypesData = new ArrayList<>();
            columnValues = this.findElements(By.xpath(String.format(this.columnValuesXpath + "//span[1]", columnId)));
            if (columnValues.size() == 0) {
                log.error(
                        "**WARNING** - We did not find any data in shipment list hence skipping the next steps");
                this.commonHelpers.AddToContextStore("skipRemainingSteps", true);
                return true;
            }
            for (WebElement ele : columnValues) {
                String val = WordUtils.capitalizeFully(ele.getAttribute("class").split("-")[0]);
                actualValues.add(val);
                uiTypesData.add(val);
                if (actualValues.contains(expectedValues1)) {
                    flag1.add(true);
                    break;
                }
            }
            this.commonHelpers.AddToContextStore("Types", uiTypesData);
            return expectedValues2.size() <= actualValues.size() && flag && !flag1.contains(false);
        } else {
            columnValues = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
            for (WebElement ele : columnValues) {
                actualValues.add(ele.getText());
                System.out.println();
                if (expectedValues2.contains(ele.getText())) {
                    flag1.add(true);
                } else {
                    assertThat(ele.getText()).contains(expectedValues2);
                }
            }
        }

        // for (WebElement ele : columnValues) {
        // actualValues.add(ele.getText());
        // flag1.add(expectedValues2.contains(ele.getText()));
        // }

        // for (WebElement ele : columnValues) {
        // actualValues.add(ele.getText());
        // flag1.add(expectedValues2.contains(ele.getText()));
        // }

        return expectedValues2.size() >= actualValues.size() && flag && !flag1.contains(false);

    }

    public boolean isShipmentColumnPresent(DataTable dataTable) {
        Set<Boolean> result = new HashSet<>();
        List<String> filters = dataTable.asList(String.class);
        String columnId = "";
        int count=0;
        for (String filter : filters) {
            switch (filter) {
                case "Weather Impacted":
                    columnId = "weatherImpacted";
                    break;
                case "Commit Time":
                    columnId = "commitTimer";
                    break;
                case "Nak Scan":
                    columnId = "nakScan";
                    break;
                case "Delivery Prediction":
                    columnId = "finalPackageDelayStatus";
                    break;
                case "CER Number":
                    columnId = "cerNumbers";
                    break;
                case "Container ID":
                    columnId = "latestContainerId";
                    break;
                case "Last Known Ramp":
                    columnId = "lastKnownRamp";
                    break;
                case "Industry Vertical":
                    columnId = "industryVerticalName";
                    break;
                case "Service Type":
                    columnId = "serviceType";
                    break;
                case "Flight Number":
                    columnId = "latestFlightNumber";
                    break;
                case "Delivered Date":
                    columnId = "dateDelivered";
                    break;
                case "Special Handling":
                    columnId = "specialHandling";
                    break;
                case "Package Weight (LBS)":
                    columnId = "pkgWtLbs";
                    break;
                case "Package Weight (KGS)":
                    columnId = "pkgWtKg";
                    break;
                case "Total Weight (LBS)":
                    columnId = "totalWtLbs";
                    break;
                case "Total Weight (KGS)":
                    columnId = "totalWtKg";
                    break;
                case "Intervention Date/Time":
                    columnId = "latestInterventionDateTime";
                    break;
                case "Address Correction":
                    columnId = "addressCorrection";
                    break;
                case "Address Classification":
                    columnId = "recipientAddressClassification";
                    break;
                case "Case Count":
                    columnId = "cerCount";
                    break;
                case "Case Number":
                    columnId = "cerNumbers";
                    break;
                case "Tracking Number":
                    columnId = "trackingNumber";
                    break;
                case "Types":
                    columnId = "isPayer";
                    break;
                case "Status":
                    columnId = "status";
                    break;
                case "Sub-Status":
                    columnId = "subStatus";
                    break;
                case "Case Type":
                    columnId = "cerCodes";
                    break;
                case "Exception Reason":
                    columnId = "exceptionReason";
                    break;
                case "Standard Transit Date":
                    columnId = "standardTransitDate";
                    break;
                case "Standard Transit Time By":
                    columnId = "standardTransitTimeBy";
                    break;
                case "Scheduled Delivery Date/Time":
                    columnId = "scheduledDeliveryDateDestTZ";
                    break;
                case "Estimated Delivery Date/Time":
                    columnId = "edtWindowStart";
                    break;
                case "Time in Network":
                    columnId = "timeSincePickup";
                    break;
                case "Ship Date":
                    columnId = "shipDate";
                    break;
                case "Last Comment":
                    columnId = "lastComment";
                    break;
                case "Last Comment Date/Time":
                    columnId = "lastCommentOn";
                    break;
                case "Weather Advisory":
                    columnId = "weatherImpacted";
                    break;
                case "FedEx Origin Location":
                    columnId = "fedExOriginLocation";
                    break;
                case "FedEx Destination Location":
                    columnId = "fedExDestinationLocation";
                    break;
                case "Recipient Postal":
                    columnId = "recipPostal";
                    break;
                case "Recipient State/Province":
                    columnId = "recipState";
                    break;
                case "Case Status":
                    columnId = "cerStatus";
                    break;
                case "Dry Ice Added (Kgs)":
                    columnId = "dryIceAddedKgs";
                    break;
                case "Dry Ice Added (Lbs)":
                    columnId = "dryIceAddedLbs";
                    break;
                case "Dry Ice Added Date/time":
                    columnId = "dryIceAddedDateTime";
                    break;
                case "Get Pack Quantity":
                    columnId = "gelPackQuantity";
                    break;
                case "Gel Pack Date/Time":
                    columnId = "gelPackDateTime";
                    break;
                case "Cold Storage Temp - Min (C)":
                    columnId = "coldStorageTemperatureMinC";
                    break;
                case "Cold Storage Temp - Max (C)":
                    columnId = "coldStorageTemperatureMaxC";
                    break;
                case "Cold Storage Date/Time":
                    columnId = "coldStorageTemperatureDateTime";
                    break;
                case "Shipper company":
                    columnId = "shipperCompany";
                    break;
                case "Shipper Name":
                    columnId = "shipperName";
                    break;
                case "Shipper Account Number":
                    columnId = "shipperAccountNumber";
                    break;
                case "Reference":
                    columnId = "reference";
                    break;
                case "Recipient Company":
                    columnId = "recipCompany";
                    break;
                case "Recipient Contact Name":
                    columnId = "recipContactName";
                    break;
                case "Healthcare Identifier":
                    columnId = "healthcareIdentifier";
                    break;
                case "Monitoring and Intervention Options":
                    columnId = "monitoringAndInterventionsCode";
                    break;
                case "Last Known Location":
                    columnId = "lastKnownLocation";
                    break;
                case "Recipient Country/ Territory":
                    columnId = "recipCountryOrTerritory";
                    break;
                case "Shipper Country/ Territory":
                    columnId = "shipperCountryOrTerritory";
                    break;
                case "Shipper State/Province":
                    columnId = "shipperState";
                    break;
                case "Origin State/Province":
                    columnId = "originStateOrProvince";
                    break;
                case "Origin Country/Territory":
                    columnId = "originCountryOrTerritory";
                    break;
                case "Support Update":
                    columnId="supportUpdate";
                    break;
                case "Prediction Details":
                    columnId="packageRiskReason";
                    break;
            }
           // this.ScrollIntoView(this.findElement(By.xpath(String.format(this.shipmentColumnHeaderXpath, columnId))));
            result.add(this.elementIsDisplayed(By.xpath(String.format(this.shipmentColumnHeaderXpath, columnId))));
           if(count>4){
               this.scrollHorizontalBarOnPage("100");
           }
            count++;
        }
        return !result.contains(false);
    }

    public void selectCheckBoxForColumn(String columnName, String state) {
        this.JavaScriptClick(this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))));
        if (state.equalsIgnoreCase("c")) {
            if (this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))).getAttribute("aria-checked")
                    .equals("false")) {
                this.JavaScriptClick(this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))));
            }
        } else {
            if (this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))).getAttribute("aria-checked")
                    .equals("true")) {
                this.JavaScriptClick(this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))));
            }
        }
    }

    public void SortOnColumn(String columnName, String orderOfSort) {
        switch (orderOfSort) {
            case "Asc":
                this.JavaScriptClick(By.xpath(String.format(this.ColumnHeaderXpath, columnName)));
                this.waitUntilNotVisible(this.loadingIndicator);
                break;
            case "Desc":
                this.JavaScriptClick(By.xpath(String.format(this.ColumnHeaderXpath, columnName)));
                this.waitUntilNotVisible(this.loadingIndicator);
                this.JavaScriptClick(By.xpath(String.format(this.ColumnHeaderXpath, columnName)));
                this.waitUntilNotVisible(this.loadingIndicator);
                break;
        }

    }

    public void SelectColumnsinView(Map<String, String> columnTable) {
        // make a copy of Default Column, to perform update or delete
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        List<String> columnsGrid1 = new ArrayList<>();
        if (user.equalsIgnoreCase("CE")) {
            for (String columnheader : Constants.defaultColumnMyShipmentForCE) {
                if (!columnsGrid1.contains(columnheader))
                    columnsGrid1.add(columnheader);
            }
        } else {
            for (String columnheader : Constants.defaultColumnMyShipmentForShipper) {
                if (!columnsGrid1.contains(columnheader))
                    columnsGrid1.add(columnheader);
            }
        }
        for (String viewName : columnTable.keySet()) {
            log.info("View Name: " + viewName);
            if (this.elementIsNotDisplayed(this.getByusingString(String.format(columnViewxpath, viewName)))) {
                this.ScrollIntoView(this.findElement(this.getByusingString(String.format(columnViewxpath, viewName))));
            }
            this.JavaScriptClick(this.findElement(this.getByusingString(String.format(columnViewxpath, viewName))));
            String[] columns = columnTable.get(viewName).trim().split(",");
            for (String column : columns) {
                log.info("Column Name: " + column);
                // Removing : and spaces from column name
                // Shipment Date:C to ShipmentDate
                String columnName = column.split(":")[0].trim().replace(" ", "");

                if (columnName.equalsIgnoreCase("BillTo(Transportation)")) {
                    // As this column name is changed in UI but in DOM the id is billToAccount (old
                    // one) rather than transportation
                    columnName = "billToAccount";
                } else if (columnName.equalsIgnoreCase("BillTo(Duties)")) {
                    columnName = "billToDutiesAccount";
                } else if (columnName.equalsIgnoreCase("DeliveredDate")) {
                    columnName = "dateDelivered";
                }
                else if(columnName.equalsIgnoreCase("ContainerCONS")){
                    columnName="latestContainerCONS";
                }
                else if(columnName.equalsIgnoreCase("estimatedDeliveryDate/Time")){
                    columnName="edtWindowStart";
                }
                else if(columnName.equalsIgnoreCase("actualDeliveryAddress")){
                    columnName="deliveryAddress";
                }
                else {
                    // whatever column name is there if we make the first character to lowercase it
                    // becomes the column name of DOM
                    // Shipment Date to shipmentDate
                    columnName = Character.toLowerCase(columnName.charAt(0)) + columnName.substring(1); // converting
                }

                if (columnName.contains(".")) {
                    columnName = columnName.replace(".", "");
                    log.info("columnName: " + columnName);
                }
                if (this.elementIsDisplayed(By.xpath(String.format(columnCheckBoxState, columnName)))) {
                    this.selectCheckBoxForColumn(columnName, column.split(":")[1].trim());
                } else {
                    this.ScrollIntoView(this.findElement(By.xpath(String.format(columnCheckBoxState, columnName))));
                    this.selectCheckBoxForColumn(columnName, column.split(":")[1].trim());
                }
            }

            // get all default column count
            int count = 0;
            if (viewName.equalsIgnoreCase("Shipment")) {
                count = user.equalsIgnoreCase("CE") ? count + Constants.defaultColumnInShipmentCE
                        : count + Constants.defaultColumnInShipment;
            } else if (viewName.equalsIgnoreCase("Shipper")) {
                count = user.equalsIgnoreCase("CE") ? count + Constants.defaultColumnInShipperCE
                        : count + Constants.defaultColumnInShipper;
            } else if (viewName.equalsIgnoreCase("Recipient")) {
                count = user.equalsIgnoreCase("CE") ? count + Constants.defaultColumnInRecipientCE
                        : count + Constants.defaultColumnInRecipient;
            }

            // get actual column count
            for (String column : columns) {
                if (column.split(":")[1].trim().equalsIgnoreCase("c")
                        && !columnsGrid1.contains(column.split(":")[0].trim().toUpperCase())) {
                    count++;
                    columnsGrid1.add(column.split(":")[0].trim().toUpperCase());
                } else if (column.split(":")[1].trim().equalsIgnoreCase("u")) {
                    if (user.equalsIgnoreCase("CE") && Constants.defaultColumnMyShipmentForCE
                            .contains(column.split(":")[0].trim().toUpperCase())) {
                        count--;
                        columnsGrid1.remove(column.split(":")[0].trim().toUpperCase());
                    } else if (user.contains("user") && Constants.defaultColumnMyShipmentForShipper
                            .contains(column.split(":")[0].trim().toUpperCase())) {
                        count--;
                        columnsGrid1.remove(column.split(":")[0].trim().toUpperCase());
                    }

                }
            }
            this.commonHelpers.AddToContextStore(viewName, String.valueOf(count));
        }
        this.columnsGrid = columnsGrid1;
    }


    public boolean ValidateColumnsinView(DataTable dataTable) {
        Set<Boolean> result = new HashSet<>();
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return false;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        for (String viewName : table.keySet()) {
            String[] columns = table.get(viewName).trim().split(",");
            for (String column : columns) {
                log.info("View Name: " + viewName);
                if (this.elementIsNotDisplayed(this.getByusingString(String.format(columnViewxpath, viewName)))) {
                    this.ScrollIntoView(
                            this.findElement(this.getByusingString(String.format(columnViewxpath, viewName))));
                }
                this.JavaScriptClick(this.findElement(this.getByusingString(String.format(columnViewxpath, viewName))));
                log.info("Column Name: " + column);
                if (this.elementIsDisplayed(By.xpath(String.format(columnCheckBoxState, column)))) {
                    result.add(Boolean.valueOf(this.getAttributeValue(
                            By.xpath(String.format(columnCheckBoxState, column)), "aria-checked")));
                } else {
                    this.ScrollIntoView(this.findElement(By.xpath(String.format(columnCheckBoxState, column))));
                    result.add(Boolean.valueOf(this.getAttributeValue(
                            By.xpath(String.format(columnCheckBoxState, column)), "aria-checked")));
                }
            }

        }

        return !result.contains(false);
    }

    public boolean validateCountForColumn(String viewName) {
        if (this.elementIsNotDisplayed(this.getByusingString(String.format(columnViewxpath, viewName)))) {
            this.ScrollIntoView(this.findElement(this.getByusingString(String.format(columnViewxpath, viewName))));
        }
        String actualCount = this.findElement(this.getByusingString(String.format(columnViewxpath, viewName)), false)
                .getText();
        actualCount = actualCount.replace("(", "").replace(")", "").split(" ")[1];
        String expectedCount = this.commonHelpers.getValuefromContextStore(viewName).toString();
        System.out.printf("Expected columns count for \"%s\" is : %s and Actual Column count for \"%s\" is %s: %n",
                viewName, expectedCount, viewName, actualCount);
        return actualCount.equals(expectedCount);
    }

    public List<String> getColumnsingrid() {
        this.expandView("expand");
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        int columnCount = 0;
        if (this.commonHelpers.verifyKeyinContextStore("Shipper")) {
            columnCount = columnCount
                    + Integer.parseInt(this.commonHelpers.getValuefromContextStore("Shipper").toString());
        } else {
            columnCount = user.equalsIgnoreCase("CE") ? columnCount + Constants.defaultColumnInShipperCE
                    : Constants.defaultColumnInShipper;
        }

        if (this.commonHelpers.verifyKeyinContextStore("Recipient")) {
            columnCount = columnCount
                    + Integer.parseInt(this.commonHelpers.getValuefromContextStore("Recipient").toString());
        } else {
            columnCount = user.equalsIgnoreCase("CE") ? columnCount + Constants.defaultColumnInRecipientCE
                    : columnCount + Constants.defaultColumnInRecipient;
        }

        if (this.commonHelpers.verifyKeyinContextStore("Shipment")) {
            columnCount = columnCount
                    + Integer.parseInt(this.commonHelpers.getValuefromContextStore("Shipment").toString());
        } else {
            columnCount = user.equalsIgnoreCase("CE") ? columnCount + Constants.defaultColumnInShipmentCE
                    : columnCount + Constants.defaultColumnInShipment;
        }

        columnCount = columnCount + 1;

        if (this.columnsGrid.isEmpty()) {
            if (user.equalsIgnoreCase("CE")) {
                this.columnsGrid = Constants.defaultColumnMyShipmentForCE;
            } else {
                this.columnsGrid = Constants.defaultColumnMyShipmentForShipper;
            }
        }

        List<String> colmNames = new ArrayList<>();
        for (int i = 0; i <= columnCount; i++) {
            if (colmNames.size() == columnCount) {
                break;
            }
            List<WebElement> columns = this.findElements(getColumnHeaders);
            for (WebElement name : columns) {
                if (!colmNames.contains(name.getText())) {
                    if (name.getText().contains("(")) {
                        colmNames.add(name.getText().split("\\(")[0]);
                    } else {
                        colmNames.add(name.getText());
                    }
                }
            }
            colmNames.remove("");
            String col = this.genericFuncObj.convert(colmNames.get(colmNames.size() - 1)).replace(" ", "");
            col = Character.toLowerCase(col.charAt(0)) + col.substring(1).replace("/", "Or");
            this.clickOnElement(By.xpath(String.format(cell, col)));
            this.clickOnElement(By.xpath(String.format(cell, col)));
            for (int k = 0; k <= columnCount - colmNames.size(); k++)
                this.keyBoardEvent(Keys.ARROW_RIGHT);
        }
        keyBoardEvent(Keys.HOME);
        return colmNames;
    }

    public Boolean verifyShipmentIcon(String trackId, String icon) {
        Boolean flag = true;
        String expected = "";
        String actual = "";
        switch (icon) {
            case "intervened":
                expected = "intervened-icn";
                actual = this.findElement(By.xpath(String.format(this.verifyShipmentIconHoverOver, trackId, expected)))
                        .getAttribute("class");
                break;
            case "SenseAware":
                expected = "senseawareid-icn";
                actual = this.findElement(By.xpath(String.format(this.verifyShipmentIconHoverOver, trackId, expected)))
                        .getAttribute("class");
                break;
            case "Monitored":
                expected = "monitored-icn";
                actual = this.findElement(By.xpath(String.format(this.verifyShipmentIconHoverOver, trackId, expected)))
                        .getAttribute("class");
                flag = expected.equalsIgnoreCase(actual);
                if (!flag) {
                    expected = "intervened-icn";
                    actual = this
                            .findElement(By.xpath(String.format(this.verifyShipmentIconHoverOver, trackId, expected)))
                            .getAttribute("class");
                }
                break;
        }
        assertThat(actual).isEqualToIgnoringCase(expected);
        return flag;
    }

    public Boolean VerifyCommentForShipment(String columnName, String ContextStoreValue, DataTable table) {
        String trackId = ContextStoreValue.contains("ContextStore-")
                ? this.commonHelpers.getValuefromContextStore(ContextStoreValue).toString()
                : ContextStoreValue;
        List<String> ContentToValidate = table.asList(String.class);
        boolean flag = false;
        String actualUI = "";
        for (String content : ContentToValidate) {
            switch (columnName) {
                case "Comment":
                    String columnId = "interventionLog.intervention.comment";
                    actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, columnId)));
                    flag = content.contains(actualUI);
                    break;
                case "Delay Status":
                    String dscolumnId = "packageDelayStatus";
                    actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, dscolumnId)));
                    flag = content.contains(actualUI);
                    break;
                case "Delivery Prediction":
                    String dpcolumnId = "finalPackageDelayStatus";
                    actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, dpcolumnId)));
                    flag = (content != null) ? content.contains(actualUI) : true;
                    break;
                case "Delay Reason":
                    String drcolumnId = "delayedExceptionReason";
                    if (this.elementIsNotDisplayed(By.xpath(String.format(this.ContentinGrid, trackId, drcolumnId)))) {
                        this.scrollHorizontalBarOnPage("1500");
                        actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, drcolumnId)));
                        flag = (content != null) ? content.contains(actualUI) : true;
                    }
                    else{
                        actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, drcolumnId)));
                        flag = (content != null) ? content.contains(actualUI) : true;
                    }
                    break;
                case "Last Comment":
                    String lastCommentcolumnId = "lastComment";
                    if (content.contains("ContextStore-")) {
                        content = (String) this.commonHelpers.getValuefromContextStore(content.split("-")[1]);
                    }
                    actualUI = this.getText(By.xpath(String.format(this.ContentinGrid, trackId, lastCommentcolumnId)));
                    flag = content.contains(actualUI);
                    break;
            }
        }
        return flag;
    }

    public void SelectMonitoredToggle() {
        this.clickOnElement(MonitoredToggle);
    }

    public void SelectTrackRandom(String track) {
        this.clickOnElement(this.getByusingString(String.format(TrackingNumberMyshipments, track)));
    }

    public void SelectTrackingNumber(String trackingNum, boolean... selection) throws InterruptedException {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToLeft(this.findElement(ScrollBar));
        if (trackingNum.equalsIgnoreCase("random") && this.getViewCount() > 0) {
            int randomtrackingnum = this.commonHelpers
                    .GenerateRandomNumber(this.findElements(TrackingNumResults).size());
            randomtrackingnum = (randomtrackingnum <= 1) ? 2 : randomtrackingnum;
            this.commonHelpers.AddToContextStore("Tracking Number", this.getText(
                    this.getByusingString(String.format(TrackingNumxpath, randomtrackingnum))));
            String persona = this.commonHelpers.getValuefromContextStore("UserContext").toString();
            // int Statusrandomtrackingnum = persona.equalsIgnoreCase("CE") ?
            // randomtrackingnum + (randomtrackingnum - 1)
            // : randomtrackingnum;
            int Statusrandomtrackingnum = randomtrackingnum;
            // Added check, if the Status column is not on the grid
            if (this.elementIsDisplayed(
                    this.getByusingString(String.format(Statusxpath, Statusrandomtrackingnum)))) {
                this.commonHelpers.AddToContextStore("Status",
                        this.getText(this
                                        .getByusingString(String.format(Statusxpath, Statusrandomtrackingnum)))
                                .trim());
            }
            // Added check, fetch Delivery prediction column
            if (this.elementIsDisplayed(
                    this.getByusingString(String.format(DeliveryPredictionxpath, Statusrandomtrackingnum)))) {
                this.commonHelpers.AddToContextStore("deliveryPrediction",
                        this.getText(this
                                        .getByusingString(String.format(DeliveryPredictionxpath, Statusrandomtrackingnum)))
                                .trim());
            }
            if (selection.length > 0 && selection != null) {
               /* this.clickOnElement(
                        this.getByusingString(String.format(TrackingNumxpath, randomtrackingnum)));*/
                this.JavaScriptClick(
                        this.getByusingString(String.format(TrackingNumxpath, randomtrackingnum)));
                this.waitUntilNotVisible(this.loadingIndicator);
            }
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        this.waitUntilNotVisible(this.loadingIndicator);
    }


    public void SelectReturnToShipperTrackingNumber(String trackingNum, boolean... selection) throws InterruptedException {
        By returnToShipperResults=By.xpath(".//*[contains(@col-id,'returnToShipperTrkNo')]");
        String returnToShipperTrackingNumxpath = "(.//*[contains(@col-id,'returnToShipperTrkNo')])[%s]//a";

        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToLeft(this.findElement(ScrollBar));
        if (trackingNum.equalsIgnoreCase("random") && this.getViewCount() > 0) {
            int randomtrackingnum = this.commonHelpers
                    .GenerateRandomNumber(this.findElements(returnToShipperResults).size());
            randomtrackingnum = (randomtrackingnum <= 1) ? 2 : randomtrackingnum;
            this.commonHelpers.AddToContextStore("Return to Shipper Tracking Number", this.getText(
                    this.getByusingString(String.format(returnToShipperTrackingNumxpath, randomtrackingnum))));
            String persona = this.commonHelpers.getValuefromContextStore("UserContext").toString();
            // int Statusrandomtrackingnum = persona.equalsIgnoreCase("CE") ?
            // randomtrackingnum + (randomtrackingnum - 1)
            // : randomtrackingnum;
            int Statusrandomtrackingnum = randomtrackingnum;
            // Added check, if the Status column is not on the grid
            if (this.elementIsDisplayed(
                    this.getByusingString(String.format(Statusxpath, Statusrandomtrackingnum)))) {
                this.commonHelpers.AddToContextStore("Status",
                        this.getText(this
                                        .getByusingString(String.format(Statusxpath, Statusrandomtrackingnum)))
                                .trim());
            }
            if (selection.length > 0 && selection != null) {
               /* this.clickOnElement(
                        this.getByusingString(String.format(returnToShipperTrackingNumxpath, randomtrackingnum)));
              */

                this.JavaScriptClick(
                        this.getByusingString(String.format(returnToShipperTrackingNumxpath, randomtrackingnum)));

                this.waitUntilNotVisible(this.loadingIndicator);
            }
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public int getShipmentsPageCount() {
        commonHelpers.thinkTimer(5000);// Using force wait since not able to catch the spinner
        return Integer.parseInt(findElement(shipmentsPageCount).getText());
    }

    public int getSelectedShipmentsPerPageValue() {
        commonHelpers.thinkTimer(3000);// Using force wait since not able to catch the spinner
        return Integer.parseInt(getSelectedDropdownValue(shipmentsCountSlection));
    }

    public void clickOnShipmentsPageNumber(String pageNum) {
        if (pageNum.equalsIgnoreCase("random")) {
            int getPage = this.api.totalPageCount();
            int randomPageNum = this.commonHelpers.GenerateRandomNumber(4);
            randomPageNum = (randomPageNum <= 1 && randomPageNum < getPage) ? 2 : randomPageNum;
            pageNum = String.valueOf(randomPageNum);
        }
        this.clickOnElement(this.getByusingString(String.format(clickShipmentsPageNum, pageNum)));
        this.commonHelpers.AddToContextStore("PageNumber", pageNum);
    }

    public boolean isShipmentsPageClicked(String expectedPageNum) {
        boolean flag;
        if (expectedPageNum.equalsIgnoreCase("random")) {
            expectedPageNum = this.commonHelpers.getValuefromContextStore("PageNumber").toString();
        }
        String actualPageNum = getActivePageNum();
        flag = actualPageNum.equals(expectedPageNum);
        return flag;
    }

    public String getActivePageNum() {
        this.waitUntilVisible(activePageNum);
        return this.getText(activePageNum);
    }

    public boolean verifyShipmentsPageNavigation() {

        Set<Boolean> result = new HashSet<>();

        clickOnShipmentsPageNumber("1");
        result.add(isShipmentsPageClicked("1"));

        clickOnShipmentsPageNumber("2");
        result.add(isShipmentsPageClicked("2"));

        clickOnShipmentsPageNumber("3");
        result.add(isShipmentsPageClicked("3"));

        paginationToRight();
        result.add(isShipmentsPageClicked("4"));

        paginationToLeft();
        result.add(isShipmentsPageClicked("3"));

        return !result.contains(false);
    }

    public boolean isPaginationItemPoistionVerified(String item, String poistion) {
        boolean flag;
        flag = item.trim().equals(this.getText(getByusingString(String.format(pageNavigationItem, poistion))).trim());
        return flag;
    }

    public boolean isPageNavEllipsisPoistionVerified() {
        boolean flag;
        flag = "...".equals(this.getText(pageNavEllipsisPosition).trim());
        return flag;
    }

    public int totalShipmentsCount() {
        this.ScrollToTop();
        return Integer.parseInt(this.getText(AllShipmentsCount));
    }

    public int getExpectedShipmentsPageCount() {
        int totalShipments = totalShipmentsCount();
        int shipmentsPerPage = getSelectedShipmentsPerPageValue();
        int pageCount = (totalShipments % shipmentsPerPage) == 0 ? (totalShipments / shipmentsPerPage)
                : (totalShipments / shipmentsPerPage) + 1;
        return pageCount;
    }

    public boolean verifyShipmentsPageNavigationItems() {
        Set<Boolean> result = new HashSet<Boolean>();

        result.add(isPaginationItemPoistionVerified("❮", "1"));
        result.add(isPaginationItemPoistionVerified("1", "2"));
        result.add(isPaginationItemPoistionVerified("2", "3"));
        result.add(isPaginationItemPoistionVerified("3", "4"));
        result.add(isPaginationItemPoistionVerified("4", "5"));
        result.add(isPageNavEllipsisPoistionVerified());
        result.add(isPaginationItemPoistionVerified(String.valueOf(getExpectedShipmentsPageCount()), "7"));
        result.add(isPaginationItemPoistionVerified("❯", "8"));

        return !result.contains(false);
    }

    public void validateGlobalSearchTab(DataTable dataTable) throws InterruptedException {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "SearchPlaceHolder":
                    softly.assertThat(this.elementIsDisplayed(
                                    this.getByusingString(String.format(this.searchInputPlaceHolder, localisedValue))))
                            .isTrue();
                    break;
                case "MultipleTrackingNumber":
                case "shipperNameAdvSearch":
                case "recipientNameAdvSearch":
                case "viewShipmentAdvSearch":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    break;
                case "recipientCityAdvSearch":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    this.enterText(searchinput, "");
                    break;
                case "trackingNumber":
                    this.waitUntilVisible(this.searchinput);
                    this.enterText(searchinput,
                            this.commonHelpers.getValuefromContextStore("FullTrackingNumber").toString());
                    softly.assertThat(this.elementIsDisplayed(
                                    this.getByusingString(String.format(this.trackingNumberValidation, localisedValue))))
                            .isTrue();
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void searchTrackingNumberWithId(String contextStorevariable, String name) throws InterruptedException {
        String trackingId = this.commonHelpers.getValuefromContextStore(contextStorevariable).toString();
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.enterText(searchinput, "");
        this.enterText(searchinput, trackingId);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.thinkTimer(1000);
        this.waitUntilVisible(this.getByusingString(String.format(this.containsPlaceHolder, name)));
        this.JavaScriptClick(this.findElement(this.getByusingString(String.format(this.containsPlaceHolder, name))));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void searchAndValidateTheErrorMessage(String value, String caseType) {
        if (caseType.equalsIgnoreCase("valid")) {
            Assert.assertTrue(this.elementIsDisplayed(this.getByusingString(String.format(this.containsPlaceHolder,
                    this.commonHelpers.getValuefromContextStore("FullTrackingNumber").toString()))));
        } else {
            Assert.assertTrue(
                    this.elementIsDisplayed(this.getByusingString(String.format(this.containsPlaceHolder, value))));
        }

    }

    public void validateMultipleTrackingPage(DataTable dataTable) throws InterruptedException {

        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "singleTrackingNumber":
                case "filterbubble.customSearch":
                case "errorMessages.displayText":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    break;
                case "singleTrackingValidation":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, 1)),
                            this.commonHelpers.getValuefromContextStore("InvalidTrackingID").toString());
                    String localisedValue1 = this.genericFunctionObject.getLocalizedValue("trackButton");
                    By track1 = By.xpath("(//button[contains(text(),'" + localisedValue1 + "')])[last()]");
                    this.JavaScriptClick(this.findElement(track1));
                    break;
                case "multiTrackingField2":
                case "multiTrackingField1":
                    String textVal = getText(headerMultiTrackNumbersPopUpEle);
                    softly.assertThat(textVal.contains(localisedValue)).isTrue();
                    break;
                case "multiTrackingField3":
                case "multiTrackingField4":
                    String textVal2 = getText(headerMultiTrackNumbersMt2);
                    softly.assertThat(textVal2.contains(localisedValue.trim())).isTrue();
                    break;
                case "validationMessage":
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, 1)),
                            this.commonHelpers.getValuefromContextStore("partialInvalidTrackingID").toString());
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    break;
                case "resetButton":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    this.findElement(this.getByusingString(String.format(this.searchMultiTrackNumber, 1)))
                            .sendKeys(Keys.BACK_SPACE);
                    this.findElement(this.getByusingString(String.format(this.searchMultiTrackNumber, 1)))
                            .sendKeys(Keys.BACK_SPACE);
                    this.findElement(this.getByusingString(String.format(this.searchMultiTrackNumber, 1)))
                            .sendKeys(Keys.BACK_SPACE);
                    break;
                case "trackButton":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    By track = By.xpath("(//button[contains(text(),'" + localisedValue + "')])[last()]");
                    this.JavaScriptClick(this.findElement(track));
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void navigateToElement(String navigation) throws InterruptedException {
        String localisedValue;
        switch (navigation.toUpperCase()) {
            case "NAVIGATETOSINGLETRACKINGPAGE":
                this.waitUntilVisible(this.Searchicon);
                this.JavaScriptClick(this.findElement(this.Searchicon));
                break;
            case "MULTIPLETRACKINGNUMBER":
                localisedValue = this.genericFunctionObject.getLocalizedValue(navigation);
                this.waitUntilVisible(this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)));
                this.JavaScriptClick(this
                        .findElement(this.getByusingString(String.format(this.containsPlaceHolder, localisedValue))));
                break;
            default:
                Assertions.fail("There is a value passed which is not expected --> " + navigation);
        }

    }

    public void navigateToElementInSearchScreen(String navigation) throws InterruptedException {
        switch (navigation) {
            case "Multiple Tracking Numbers":
                this.waitUntilVisible(this.getByusingString(String.format(this.containsPlaceHolder, navigation)));
                this.JavaScriptClick(
                        this.findElement(this.getByusingString(String.format(this.containsPlaceHolder, navigation))));
                break;
            case "NavigateToSingleTrackingPage":
                this.waitUntilVisible(this.Searchicon);
                this.JavaScriptClick(this.findElement(this.Searchicon));
                break;
            default:
                Assertions.fail("There is a value passed which is not expected --> " + navigation);
        }
    }

    public void validateInvalidSearchResults(DataTable dataTable) throws InterruptedException {
        this.commonHelpers.AddToContextStore("searchPhrase", "John");
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "MultipleTrackingNumber":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    break;
                case "shipperNameAdvSearch":
                case "recipientNameAdvSearch":
                case "recipientCityAdvSearch":
//                    this.searchTrackingNumberWithId("searchPhrase", localisedValue);
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.containsPlaceHolder, localisedValue)))).isTrue();
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void SearchTrackingNumber(String searchContext, String contextStorevariable) throws InterruptedException {
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.waitUntilVisible(this.Searchicon);
        String randomNumber = "0000000";
        this.enterText(searchinput, randomNumber);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.elementIsDisplayed(By.xpath(String.format(this.zeroTrackingNumxpath, searchContext.split("-")[0])));
        this.SearchTrackingNumber(contextStorevariable);
    }

    public void SearchTrackingNumber(String contextStorevariable) throws InterruptedException {
        String trackingId;
        if (contextStorevariable.contains("Context") || contextStorevariable.contains("Partial")) {
            trackingId = this.commonHelpers.getValuefromContextStore(contextStorevariable).toString();
        } else {
            trackingId = this.commonHelpers.getValuefromContextStore(contextStorevariable).toString();
        }
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.enterText(searchinput, trackingId);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.thinkTimer(3000);
        if (trackingId.length() >= 12) {
            this.JavaScriptClick(this.getByusingString(this.trackingNumberxpath));
            this.waitUntilNotVisible(this.loadingIndicator);
            Boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                this.clickOnElement(this.getByusingString(this.buildXpathForString(trackingId)));
            }
        } else {
            this.JavaScriptClick(resultCount);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public void SearchText(String searchType, String variable) {
        boolean storeCount = false;
        if (variable.contains("ContextStore")) {
            variable = this.commonHelpers.getValuefromContextStore(variable).toString();
        }
        if (searchType.equals("Partial tracking number")) {
            searchType = "Tracking Number";
            storeCount = true;
        }
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.enterText(searchinput, variable.substring(0, 3));
        this.waitUntilNotVisible(this.loadingIndicator, 60);
        if (this.elementIsDisplayed(By.xpath(String.format(searchCountText, searchType)))) {
            if (searchType.equalsIgnoreCase("Recipient City")) {
                this.clickOnElement(By.xpath(String.format(searchExactCountText, searchType)));
                return;
            } else if (storeCount) {
                this.commonHelpers.AddToContextStore("searchCount",
                        this.getText(By.xpath(String.format(searchCountText, searchType))));
            }
            this.clickOnElement(By.xpath(String.format(searchCountText, searchType)));
        } else {
            this.clickOnElement(By.xpath(String.format(searchViewDetailsLink, searchType)));
        }
    }

    public boolean mtsCountValidation() {
        boolean flag = false;
        int currentCount = this.getViewCount();
        int expectedCount = 4;
        if (expectedCount == currentCount) {
            flag = true;
        }
        return flag;
    }

    public void SearchMultiTrackingNumber(String trackNumbers, String inputData) throws InterruptedException {
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.JavaScriptClick(this.findElement(this.searchMultiTrack));
        String trackingId = trackNumbers;
        if (this.commonHelpers.verifyKeyInContextStore(trackNumbers)) {
            trackingId = this.commonHelpers.getValuefromContextStore(trackNumbers).toString().replaceAll("\\[|\\]",
                    "");
        }
        if (trackingId.equals("")) {
            log.error(
                    "**WARNING** There are no trackingid available to proceed with further steps in case of multi tracking");
            this.commonHelpers.AddToContextStore("skipRemainingSteps", true);
            return;
        }
        log.info("Tracking ids --> " + trackingId);
        String trackingIds = trackingId.replaceAll(" ", "");
        List<String> allTrackids = new ArrayList<>(Arrays.asList(trackingIds.split(",")));
        List<String> validTrackingids = new ArrayList<>();
        List<String> inValidTrackingids = new ArrayList<>();
        List<String> specialChars = Arrays.asList("@", "$", "%", "*", "#", " ");
        if (inputData.contains("reset")) {
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
            inputData = inputData.split("-")[1];
        }
        try {
            if (inputData.equalsIgnoreCase("valid")) {
                for (int index = 0; index < allTrackids.size(); ++index) {
                    if (index > 49) {
                        break;
                    }
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index + 1)),
                            allTrackids.get(index));
                    validTrackingids.add(allTrackids.get(index));
                }
                this.commonHelpers.AddToContextStore("Valid TrackingIds", validTrackingids);
            } else if (inputData.equalsIgnoreCase("invalid")) {
                for (int index = 1; index < 6; ++index) {
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index)),
                            allTrackids.get(index));
                    validTrackingids.add(allTrackids.get(index));
                }
                for (int index = 6; index < 11; ++index) {
                    String invalidTrack = RandomStringUtils.randomNumeric(12);
                    if (invalidTrack.startsWith("0")) {
                        invalidTrack = invalidTrack.replace("0", "5");
                    }
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index)),
                            invalidTrack);
                    inValidTrackingids.add(invalidTrack);
                }
                this.commonHelpers.AddToContextStore("Valid TrackingIds", validTrackingids);
                this.commonHelpers.AddToContextStore("InValid TrackingIds", inValidTrackingids);
                log.info("Invalid trackingIds are -->" + inValidTrackingids);
            } else if (inputData.equalsIgnoreCase("invalidChars")) {
                for (int index = 0; index < specialChars.size(); ++index) {
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index + 1)),
                            specialChars.get(index));
                    this.elementIsDisplayed(this.getByusingString(String.format(this.errorSearchMsg, index + 1)));
                }
            } else if (inputData.equalsIgnoreCase("Duplicate")) {
                for (int index = 0; index < 3; ++index) {
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index + 1)),
                            allTrackids.get(index));
                }
                for (int index = 3; index < 5; ++index) {
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index + 1)),
                            allTrackids.get(4));
                }
            } else if (inputData.equalsIgnoreCase("MPS")) {
                for (int index = 1; index < 6; ++index) {
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index)),
                            allTrackids.get(index));
                    validTrackingids.add(allTrackids.get(index));
                }
                this.commonHelpers.AddToContextStore("Valid TrackingIds", validTrackingids);

            } else if (inputData.equals("only invalid")) {
                for (int index = 0; index < 5; ++index) {
                    String invalidTrack = RandomStringUtils.randomNumeric(12);
                    if (invalidTrack.startsWith("0")) {
                        invalidTrack = invalidTrack.replace("0", "5");
                    }
                    this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, index + 1)),
                            invalidTrack);
                    inValidTrackingids.add(invalidTrack);
                }
                this.commonHelpers.AddToContextStore("InValid TrackingIds", inValidTrackingids);
            }
        } catch (Exception e) {
            log.info(String.valueOf(e.getStackTrace()));
        }
        log.info("Tracking ids to be searched are " + trackingIds);

        this.waitUntilNotVisible(this.loadingIndicator);
    }

    /**
     * Click on the Column
     *
     * @param ColumnName
     * @return
     * @throws InterruptedException
     */

    public boolean ClickColumnShipmentList(String ColumnName) throws InterruptedException {
        this.waitUntilNotVisible(this.loadingIndicator);
        boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        // Take Total Column Count //

        // Take Total Column Count //
        int TotalColumnCount = Integer.parseInt(this.findElement(aLLColumnCount, false).getAttribute("aria-colcount"));
        for (int i = 0; i < TotalColumnCount; i++) {
            String AllVisibleColumn = this.findElement(By.xpath(buildXpathForClass(shipmentHeaderContainer)), false)
                    .getText();
            // log.info("getText"+AllVisibleColumn);
            // Take All the Visible Column //
            if (AllVisibleColumn.toLowerCase().contains(ColumnName.toLowerCase())) {
                // If Column found than than Click it //
                this.findElement(By.xpath(buildMultipleXpath(shipmentHeaderCellText, ColumnName)), false).click();
                this.waitUntilNotVisible(this.loadingIndicator);
                flag = true;
                break;
            } else {
                int maxvisible = AllVisibleColumn.split("\n").length - 1;
                String firstvisiblecolumn = AllVisibleColumn.split("\n")[maxvisible].trim();
                firstvisiblecolumn = this.genericFuncObj.convert(firstvisiblecolumn);
                // log.info("first Column"+firstvisiblecolumn);
                this.keyBoardEvent(Keys.ARROW_RIGHT);
                try {
                    this.findElement(By.xpath(buildMultipleXpath(shipmentHeaderCellText, firstvisiblecolumn)), false)
                            .click();
                } catch (Exception e) {
                    this.waitUntilNotVisible(this.loadingIndicator);
                    if (this.elementIsDisplayed(okButton)) {
                        this.clickOnElement(okButton);
                        this.waitUntilNotVisible(this.loadingIndicator);
                    }
                    this.findElement(By.xpath(buildMultipleXpath(shipmentHeaderCellText, firstvisiblecolumn)), false)
                            .click();
                }
                this.waitUntilNotVisible(this.loadingIndicator);
                this.keyBoardEvent(Keys.ARROW_RIGHT);
                flag = false;
            }
        }
        return flag;
    }

    /**
     * Sorting By Column - Click on the Above Function - ClickColumnShipmentList.
     *
     * @param ColumnName
     * @return
     */
    public boolean CheckColumnSort(String SortingType, String ColumnName) throws ParseException {
        boolean flag = false;

        this.waitUntilNotVisible(this.loadingIndicator);
        if (this.elementIsDisplayed(okButton)) {
            this.clickOnElement(okButton);
        }
        // Numeric Sorted //
        List<BigInteger> numRowData = new ArrayList<>();
        List<BigInteger> numSortedData = new ArrayList<>();
        // Alphabetically //
        List<String> stringRowData = new ArrayList<>();
        List<String> stringSortedData = new ArrayList<String>();

        // Date //
        List<String> stringRowDate = new ArrayList<String>();
        List<String> stringSortedDate = new ArrayList<String>();

        String first = genericFuncObj.convert(ColumnName).replaceAll(" ", "");
        ColumnName = first.toLowerCase().charAt(0) + first.substring(1);
        List<WebElement> Rows = this.findElements(By.xpath("//*[contains(@col-id,'" + ColumnName + "')]"));
        for (int i = 1; i < Rows.size(); i++) {
            String Value = Rows.get(i).getText();
            if (SortingType.toLowerCase().contains("numeric")) {
                numRowData.add(new BigInteger(Value));
                numSortedData.add(new BigInteger(Value));
            } else if (SortingType.toLowerCase().contains("alphabetical")) {
                stringRowData.add(Value);
                stringSortedData.add(Value);
            } else {
                String dateinput = "";
                if (Value.contains("T")) {
                    dateinput = Value.substring(0, Value.indexOf('T')).trim();
                    stringRowDate.add(dateinput);
                    stringSortedDate.add(dateinput);
                } else {
                    stringRowDate.add(Value);
                    stringSortedDate.add(Value);
                }
            }
        }

        Collections.sort(numSortedData);
        Collections.sort(stringSortedData);
        Collections.sort(DateSort(stringRowDate));

        flag = (numRowData.equals(numSortedData) && numRowData.size() > 1)
                || (stringRowData.equals(stringSortedData) && stringRowData.size() > 1)
                || (stringRowDate.equals(stringSortedDate) && stringRowDate.size() > 1);

        return flag;
    }

    public List<String> DateSort(List<String> dates) throws ParseException {
        List<String> AllDates = new ArrayList<String>();
        String Case = "";
        String format = "";
        Date d;

        for (int i = 0; i < dates.size(); i++) {
            String CurrentDate = dates.get(i).trim();
            if (CurrentDate.contains("/"))
                Case = "A"; // MM/DD/YYYY
            else if (CurrentDate.split("-")[0].length() > 2)
                Case = "B"; // YYYY-MM-DD
            else if (CurrentDate.split("-")[1].length() == 2)
                Case = "C"; // DD-MM-YYYY
            else
                Case = "D"; // DD-MMM-YYYY

            // log.info("case =" + Case);

            switch (Case) {
                case "A":
                    format = "MM/dd/yyyy";
                    break;

                case "B":
                    format = "yyyy-MM-dd";
                    break;

                case "C":
                    format = "dd-MM-yyyy";
                    break;

                case "D":
                    format = "dd-MMM-yyyy";
                    break;
            }

            d = this.commonHelpers.StringToDate(CurrentDate, format);
            String createdDate = new SimpleDateFormat("MM-dd-yyyy").format(d).trim();
            AllDates.add(createdDate);

        }

        return AllDates;
    }

    /** Begin of test case 19039 */

    /**
     * This method is to search with partial tracking number
     *
     * @return
     * @throws InterruptedException
     */

    public boolean SearchAndValidateRecord(String operation, String trackingNumber) throws InterruptedException {
      //  this.SearchTrackingNumber(trackingNumber);
        boolean flag = false;
        // this.clickOnElement(resultCount);
        if (operation == "search") {
            this.SearchTrackingNumber(trackingNumber);
            //this.clickOnElement(resultCount);
            flag = true;
        } else if (operation.equals("On Time")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("At Risk")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("Moderate Risk")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("Low Risk")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("Expected Wrong Day Late")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("Expected Right Day Late")) {
            flag = ValidatePredictionCode(operation);
        } else if (operation.equals("Early")) {
            flag = ValidatePredictionCode(operation);
        }else if (operation.equals("Past Commit Time")) {
            flag = ValidatePredictionCode(operation);
        }else if (operation.contains("ContextStore-")) {
            operation = this.commonHelpers.getValuefromContextStore(operation).toString();
            flag = ValidatePredictionCode(operation);
        }
        return flag;
    }

    /**
     * This method is to validate whether system is displaying partial tracking
     * number in my shipments page
     *
     * @return
     */

    public boolean ValidateTrackingNumbersInMyShipmentsPage(String trackingType) {
        boolean flag = false;

        this.waitUntilNotVisible(this.loadingIndicator);

        rows = this.findElements(By.xpath(rowXPath));
        for (WebElement row : rows) {
            // if (!row.getText().equals("TRACKING NUMBER")) {
            if (row.getText().contains(this.commonHelpers.getValuefromContextStore(trackingType).toString())) {
                flag = true;
            } else {
                flag = false;
                break;
            }
            // }
        }

        return flag;
    }

    /**
     * This method is to click the tracking number and validate whether system is
     * displaying partial tracking number in shipment details page
     *
     * @return
     */

    public boolean ValidateAndClickTrackingNumberFromTable() throws InterruptedException {
        boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        rows = this.findElements(By.xpath(rowXPath));
        for (WebElement row : rows) {
            if (!row.getText().equals("TRACKING NUMBER")) {
                String rowData = row.getText();
                this.commonHelpers.AddToContextStore("selectedRowValue", row.getText());
                if (rowData.contains(this.commonHelpers.getValuefromContextStore("Tracking Number").toString())) {
                    flag = true;
                }
                if (flag) {
                    row.click();
                    flag = ValidateTrackingNumberInShipmentDetailsPage("Partial Search");
                    if (flag) {
                        break;
                    }
                } else {
                    flag = false;
                }
            }
        }
        return flag;
    }

    /**
     * validate whether system is displaying partial tracking number in shipment
     * details page
     *
     * @return
     */

    public boolean ValidateTrackingNumberInShipmentDetailsPage(String searchType) throws InterruptedException {
        boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator, 120);
        if (searchType.equals("Partial Search")) {
            if (this.commonHelpers.getValuefromContextStore("selectedRowValue").toString()
                    .equals(this.getText(shipDtlPageTrackingNum).substring(17))) {
                flag = true;
            }
        } else if (searchType.equals("Complete Search")) {
            String test = this.getText(shipDtlPageTrackingNum)
                    .substring(this.getText(shipDtlPageTrackingNum).indexOf(":") + 1);
            if (this.commonHelpers.getValuefromContextStore("Tracking Number").toString().equals(test.trim())) {
                flag = true;
            }
        } else {
            flag = false;
        }
        return flag;
    }

    /** End of test case 19039 */

    /**
     * Verify the presence of Search bubble
     *
     * @param
     * @return
     */

    public boolean VerifySearchBubbles() {
        if (this.commonHelpers.verifyKeyinContextStore("Partial Tracking Number")) {
            return this.elementIsDisplayed(this.getByusingString(String.format(searchBubble,
                    this.commonHelpers.getValuefromContextStore("Partial Tracking Number").toString())));
        }
        return this.elementIsDisplayed(this.getByusingString(String.format(searchBubble,
                this.commonHelpers.getValuefromContextStore("Tracking Number").toString())));
    }

    /*** Begin of test case 21070 ***/

    /**
     * validate whether user is able to search with tracking number in my shipments
     * page
     *
     * @param predictionStatus
     * @return
     * @throws InterruptedException
     */

    public boolean SearchWithTrackingNumber(String predictionStatus) throws InterruptedException {
        boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(searchBtn);

        this.enterText(searchTextBx, this.commonHelpers.getValuefromContextStore("DBTrackingNumber").toString());

        if (Integer.valueOf(this.getText(resultCount)) > 0) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.clickOnElement(resultCount);

            switch (predictionStatus) {
                case "On Time":
                    flag = ValidatePredictionCode(predictionStatus);
                    break;

                case "At Risk":
                    flag = ValidatePredictionCode(predictionStatus);
                    break;
            }
        } else {
            flag = false;
        }

        return flag;
    }

    /**
     * validate prediction code in Shipment Details Page for the searched tracking
     * number
     *
     * @param
     * @return
     * @throws InterruptedException
     */

    public boolean ValidatePredictionCode(String status) {
        this.waitUntilNotVisible(this.loadingIndicator);
        boolean flag = false;

        if (this.elementIsDisplayed(predictionHeader)) {
            if (this.getText(this.predictionHeader).contains(status)) {
                flag = true;

                if (this.getText(predictionHeader).equals(delayedStatus)) {
                    if (this.elementIsDisplayed(delayedReason)) {
                        flag = this.getText(this.delayedReason).contains(detailedDelayReason);
                    } else {
                        flag = false;
                    }
                }
            }
        }else if(status.equalsIgnoreCase("")){
            By predictionNone=By.xpath("//*[contains(text(),'PREDICTION')]");
            if(this.elementIsDisplayed(predictionNone)){
                flag=true;
            }
        }
        return flag;
    }

    public boolean verifySortOnColumn(String columnName) {
        return this.findElement(By.xpath(String.format(columnSort, columnName))).getAttribute("class")
                .contains("sorted");
    }

    public boolean ValidateFullScreen() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(By.xpath(String.format(expandIcon, "expand")));
        this.waitUntilNotVisible(By.xpath(String.format(expandIcon, "expand")));
        this.clickOnElement(By.xpath(String.format(expandIcon, "close")));
        return this.elementIsDisplayed(By.xpath(String.format(expandIcon, "expand")));
    }

    /**
     * Search Element in Select All Column if it is 0 than return true means nothing
     * to check
     *
     * @param Element
     * @return - true if element found
     */

    public boolean searchInSelectAll(String Element) {
        List<WebElement> AllRows = this.findElements(By.xpath(
                "//*[contains(@class,'" + gridCellValue + "') and contains(@col-id,'" + trackingColumnidName + "')]"));
        int TotalRows = AllRows.size();
        boolean flag = true;

        int monitoredicon;
        int intervenedicon;
        int allexceptionicon;

        try {
            monitoredicon = this.findElements(monitoredIcon).size();
        } catch (Exception e) {
            monitoredicon = 0;
        }

        try {
            intervenedicon = this.findElements(intervenedIcon).size();
        } catch (Exception e) {
            intervenedicon = 0;
        }

        try {
            allexceptionicon = this.findElements(allExceptionIcon).size();
        } catch (Exception e) {
            allexceptionicon = 0;
        }

        if (TotalRows > 0) {
            if (Element.toLowerCase().contains("monitored or intervened")) {
                int totalEyeCount = monitoredicon + intervenedicon;
                flag = totalEyeCount == AllRows.size();
            }

            if (Element.toLowerCase().contains("monitored") && flag) {
                int TotalToolTip = this.findElements(this.ToolTip).size();
                flag = TotalToolTip >= AllRows.size();
            }

            if (Element.toLowerCase().contains("exceptionicon") && flag) {
                flag = allexceptionicon == AllRows.size();
            }

            return flag;
        } else
            return flag;
    }

    /**
     * Check Status Column - return true if Total Row number is same as Status
     * Column values - Delivered or Exception or In Transit etc.
     *
     * @param columnValue - Expected value
     * @return
     */
    public boolean checkStatusColumn(String columnValue) {
        List<WebElement> StatusColumn = new ArrayList();
        List<WebElement> AllRows = this.findElements(By.xpath(
                "//*[contains(@class,'" + gridCellValue + "') and contains(@col-id,'" + trackingColumnidName + "')]"));
        int TotalRows = AllRows.size();
        boolean flag = true;
        if (columnValue.equalsIgnoreCase("Exception")) {
            StatusColumn = this.findElements(this.ExceptionIcons);
        }
        flag = TotalRows == StatusColumn.size();
        return flag;
    }

    /**
     * Get the Viewing Count using Xpath and return the value
     *
     * @return Viewing Count value (String)
     */

    public String getViewingCount() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String lang = GenericFunction.ReadConfigFile("LANG");
        String viewingCountText = this.getText(viewingCountXpath).replace(lang.equalsIgnoreCase("pt-br") ? "." : ",", "");
        return viewingCountText.split("/")[0].trim();
    }

    public String getTotalRecords() {
        return this.getText(this.TotalRecordsXpath).replace(",", "");
    }

    public void RemoveFiltersinBubble(DataTable filterstable) {
        List<String> filters = filterstable.asList(String.class);
        for (String filter : filters) {
            if (GenericFunction.locale.contains(Constants.EN_US) && !Constants.QuickViewCardNames.contains(filter)) {
                if(!filter.equals("Recipient Country/Territory")){
                    filter = WordUtils.capitalizeFully(filter);
                }
            }
            log.info("Filter to remove is " + filter);
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.cancelFilterBubble, filter))));
            // log.info(this.getByusingString(String.format(this.cancelFilterBubble,
            // filter)));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public void SelectDateFilter(String dateType) {
        String element = this.findElement(filterChevron).getAttribute("class");
        if (!element.contains("active"))
            this.clickOnElement(filterChevron);// Click on Filter
        this.clickOnElement(By.xpath(String.format(filterCategory, "Shipment Information")));
        this.clickOnElement(By.xpath(String.format(filterCategory, dateType)));
    }

    public boolean ValidateFilterValuesInDropDown(DataTable dataTable) throws InterruptedException {
        ArrayList<Boolean> flag = new ArrayList<Boolean>();
        this.commonHelpers.thinkTimer(6000);
        this.clickOnElement(filterChevron);
        List<String> expValues = dataTable.asList(String.class);
        List<WebElement> options = this.findElements(dateDropDown);
        for (WebElement option : options) {
            if (expValues.contains(option.getText().trim())) {
                flag.add(true);
            } else {
                flag.add(false);
            }
        }
        return !flag.contains(false);
    }

    public boolean ValidateCurrentDateIsHighlightedInCalendar() {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString("Shipment Information"))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, "Shipment Information", "Ship Date"))));
        // new code for date range
        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific date range")));
        this.clickOnElement(this.specificDateRangeFrom);
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat simpleformat = new SimpleDateFormat("d MMMM yyyy EEEE");
        String[] toArr = simpleformat.format(cal.getTime()).split(" ");
        String calendarDate = this.getText(currentDate);
        return calendarDate.equals(toArr[0]);
    }

    /**
     * Get the City name from Citybubble using Xpath and return the value
     *
     * @return City value (String)
     */
    public String getCityfromCityBubble() {
        return this.getText(filterCityBubbleXpath);
    }

    /**
     * Get the Selected CompanyName using Xpath and return the value
     *
     * @return Selected CompanyName (String)
     */
    public String getSelectedCompanyName() {
        return getSelectedDropdownValue(shipmentsCountSlection);
    }

    /**
     * Return total company count in dropdown
     *
     * @return
     */
    public int getAllCompanyFromDropdown() {
        List<WebElement> dropdown = new Select(this.findElement(By.xpath("//select"))).getOptions();
        int total = dropdown.size();
        return total;
    }

    /**
     * Store TrackingId w.r.t. Company
     *
     * @param CompanyName
     */
    public void storecompanytrackingnumber(String CompanyName) {
        List<WebElement> alltrackingnumber = this.findElements(TrackingNumResults);
        String allNumber = "";
        for (WebElement e : alltrackingnumber) {
            allNumber = allNumber + e.getText();
        }

        this.commonHelpers.AddToContextStore(CompanyName, allNumber);
    }

    /**
     * This will compare the tracking ids from both the companies
     *
     * @param CompanyName1
     * @param CompanyName2
     * @return true false
     */
    public boolean comparetrackingnumber(String CompanyName1, String CompanyName2) {
        boolean flag = false;
        String allCompany1TN = (String) this.commonHelpers.getValuefromContextStore(CompanyName1);
        String allCompany2TN = (String) this.commonHelpers.getValuefromContextStore(CompanyName2);
        if (!allCompany1TN.contains(allCompany2TN)) {
            flag = true;
        }
        return flag;
    }

    public Boolean ValidateFilterConditions(DataTable dataTable) {
        try {
            List<String> dataFilters = dataTable.asList(String.class);
            commonHelpers.thinkTimer(300);
            this.JavaScriptClick(this.findElement(filterChevron));
            for (String key : dataFilters) {
                this.VerifyValuesinFilter(key);
            }
            this.JavaScriptClick(this.findElement(filterChevron));
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in validation of filter conditions");
            return false;
        }
        return true;
    }

    public void VerifyValuesinFilter(String status) {
        this.clickOnElement(this.getByusingString(this.buildXpathForString(status.split("-")[0])));
        this.clickOnElement(
                this.getByusingString(String.format(this.secndPanexpath, status.split("-")[0], status.split("-")[1])));
        switch (status.split("-")[1]) {
            case "NAK Scan":
                for (String value : Constants.NAKScanFilters) {
                    this.elementIsDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value)));
                }
                break;
            case "Shipment Status":
                for (String value : Constants.ShipmentStatusFilters) {
                    this.elementIsDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value)));
                }
                break;
            case "Latest FXE Event":
                for (String value : Constants.LatestFXEventFilters) {
                    log.info("Comparing value: " + value);
                    if (this.elementIsNotDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value))))
                        break;
                }
                break;
            case "Service Type":
                for (String value : Constants.ServiceTypeFilters) {
                    this.elementIsDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value)));
                }
                break;
            case "CER Number":
                for (String value : Constants.CerNumber) {
                    this.elementIsDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value)));
                }
                break;
            case "Industry Vertical":
                for (String value : Constants.IndustryVerticalFilterOptions) {
                    this.elementIsDisplayed(this.getByusingString(
                            String.format(this.filterValuesxpath, status.split("-")[0], status.split("-")[1], value)));
                }
                break;
            case "Bill To (Transportation)":
                int configToBeLoaded = Integer.parseInt(GenericFunction.ReadConfigFile("lazyLoadAccounts"));
                if (!(this.commonHelpers.BASEPATH.contains("origin"))) {
                    // We have Select All so total configToBeLoaded+1
                    // And we selected a company which is having 10+ accounts under it a step before

                    // for Workgroup level it would be equal for comany level it would be +1 due to
                    // "Select All option
                    Assert.assertTrue("The total results to be shown configured are not lazyLoadAccounts(config)+1",
                            (this.findElements(totalSearchResults).size() == configToBeLoaded + 1)
                                    || (this.findElements(totalSearchResults).size() == configToBeLoaded));

                    // After 1 scroll configToBeLoaded more records should get loaded
                    this.scrollVerticallyInternalScrollBarOnPage("class", "sr-infinite-scroll-panel", "730");
                    commonHelpers.thinkTimer(2000);
                    Assert.assertEquals("The total results to be shown configured are not lazyLoadAccounts(config)*2+1",
                            this.findElements(totalSearchResults).size(), configToBeLoaded * 2);
                } else {
                    Assert.assertTrue("The filters are not empty",
                            (this.findElements(totalSearchResults).size() > 0));
                }

                break;
            case "Accounts":
                configToBeLoaded = Integer.parseInt(GenericFunction.ReadConfigFile("lazyLoadAccounts"));
                if (!(this.commonHelpers.BASEPATH.contains("origin"))) {
                    // We have Select All so total configToBeLoaded+1
                    // And we selected a company which is having 10+ accounts under it a step before

                    // for Workgroup level it would be equal for comany level it would be +1 due to
                    // "Select All option
                    Assert.assertTrue("The total results to be shown configured are not lazyLoadAccounts(config)+1",
                            (this.findElements(totalSearchResults).size() == configToBeLoaded + 1)
                                    || (this.findElements(totalSearchResults).size() == configToBeLoaded));

                    // After 1 scroll configToBeLoaded more records should get loaded
                    this.scrollVerticallyInternalScrollBarOnPage("class", "sr-infinite-scroll-panel", "730");
                    commonHelpers.thinkTimer(2000);
                    Assert.assertEquals("The total results to be shown configured are not lazyLoadAccounts(config)*2+1",
                            this.findElements(totalSearchResults).size(), configToBeLoaded * 2);
                } else {
                    Assert.assertTrue("The filters are not empty",
                            (this.findElements(totalSearchResults).size() > 0));
                }

                break;
            case "Shipper Account Number":
                configToBeLoaded = Integer.parseInt(GenericFunction.ReadConfigFile("lazyLoadAccounts"));
                // We have Select All so total configToBeLoaded+1
                // And we selected a company which is having 10+ accounts under it a step before

                // for Workgroup level it would be equal for comany level it would be +1 due to
                // "Select All option
                if (!(this.commonHelpers.BASEPATH.contains("origin"))) {
                    Assert.assertTrue("The total results to be shown configured are not lazyLoadAccounts(config)+1",
                            (this.findElements(totalSearchResults).size() == configToBeLoaded + 1)
                                    || (this.findElements(totalSearchResults).size() == configToBeLoaded));

                    // After 1 scroll configToBeLoaded more records should get loaded
                    this.scrollVerticallyInternalScrollBarOnPage("class", "sr-infinite-scroll-panel", "730");
                    commonHelpers.thinkTimer(2000);
                    Assert.assertEquals("The total results to be shown configured are not lazyLoadAccounts(config)*2+1",
                            this.findElements(totalSearchResults).size(), configToBeLoaded * 2);
                } else {
                    Assert.assertTrue("The filters are not empty",
                            (this.findElements(totalSearchResults).size() > 0));
                }
                break;
        }
    }

    // to check certain filters are not available
    public Boolean FiltersNonAvailability(DataTable dataTable) {
        Boolean flag = true;
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            if (flag)
                flag = this.ValidateFilterAvailable(key, dataFilters.get(key).split(":"));
        }
        return flag;
    }

    public Boolean ValidateShipmentsIcon(String status) {
        Boolean flag = false;
        if (status.equalsIgnoreCase("Shipment Exception") || status.equalsIgnoreCase("Delivery Exception"))
            flag = this.elementIsDisplayed(this.ExceptionIcon);
        return flag;
    }

    public Boolean Selectfilter(DataTable dataTable) {
        List<String> dataFilters = dataTable.asList(String.class);
        String ParentFilter;
        String ChildFilter;
        Boolean flag = false;
        String searchTextboxText;
        String abbreviationString;
        for (String key : dataFilters) {
            ParentFilter = key.split("-")[0];
            ChildFilter = key.split("-")[1];
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(key.split("-")[0]))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            if (ChildFilter.contains("City")) {
                searchTextboxText = Constants.SearchPlaceHolder;
                abbreviationString = Constants.SuggestTextThreeLetter;
            } else if (ChildFilter.contains("Country")) {
                searchTextboxText = Constants.SearchCountryPlaceHolder;
                abbreviationString = Constants.SuggestTextTwoLetter;
            } else if (ChildFilter.contains("Container ID")) {
                searchTextboxText = Constants.SearchContainerIdDefaultText;
                abbreviationString = Constants.SearchDefaultText;
            } else if (ChildFilter.contains(Constants.SpecialHandling)) {
                searchTextboxText = Constants.SearchSpecialHandlingPlaceHolder;
                abbreviationString = Constants.SearchDefaultText;
            } else if ((ChildFilter.contains("Shipper Reference")) || (ChildFilter.contains("Service Type"))) {
                searchTextboxText = Constants.SearchShipperReferencePlaceHolder;
                abbreviationString = Constants.SuggestTextThreeLetterShipperReference;
            } else if (ChildFilter.contains("Last Known Ramp")) {
                searchTextboxText = Constants.SearchLastKnownRampDefaultText;
                abbreviationString = Constants.SearchDefaultText;
            } else if (ChildFilter.contains("Last Known FedEx Facility")) {
                searchTextboxText = Constants.SearchLastKnownFedExFacilityDefaultText;
                abbreviationString = Constants.SuggestTextThreeCharacters;
            } else {
                searchTextboxText = Constants.SearchStatePlaceHolder;
                abbreviationString = Constants.SuggestTextTwoLetter;
            }
            flag = this.findElement(this.searchWatermark).getAttribute("placeholder").equalsIgnoreCase(
                    searchTextboxText)
                    && this.getText(this.getByusingString(
                            String.format(this.SearchAbbrevation, ParentFilter, ChildFilter)))
                    .equalsIgnoreCase(abbreviationString);
            log.info(String.valueOf(this.findElement(this.searchWatermark).getAttribute("placeholder").equalsIgnoreCase(
                    searchTextboxText)));
            log.info(String.valueOf(this.getText(this.getByusingString(
                            String.format(this.SearchAbbrevation, ParentFilter, ChildFilter)))
                    .equalsIgnoreCase(abbreviationString)));
        }
        return flag;
    }

    public Boolean EnterTextinSearch(String SearchContext, String cancelApply, DataTable dataTable) {
        Map<String, String> filterCriteria = dataTable.asMap(String.class, String.class);
        List<Boolean> validationFlags = new ArrayList();
        for (String filter : filterCriteria.keySet()) {
            String ParentFilter = filter.split("-")[0];
            String ChildFilter = filter.split("-")[1];
            System.out.println("Filter:" + filter);
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
            this.JavaScriptClick(this
                    .findElement(this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            if (Constants.SearchBarFilters.contains(ChildFilter)) {
                String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria.get(filter))
                        ? this.commonHelpers.getValuefromContextStore(filterCriteria.get(filter)).toString()
                        : filterCriteria.get(filter);
                this.JavaScriptClick(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
                if(filter.equals("Shipment Information-Last Known City")){
                    valueToSearch = ChildFilter.contains("City") ? valueToSearch.substring(0, 1).toUpperCase() + valueToSearch.substring(1, 3)
                            : valueToSearch;
                    System.out.println("valueToSearch:" +valueToSearch);
                }else {
                    valueToSearch = ChildFilter.contains("City") ? valueToSearch.substring(0, 3).toUpperCase()
                            : valueToSearch;
                }
                log.info(String.format("Value entered in %s field is ==> %s", ChildFilter, valueToSearch));
                this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)), valueToSearch);
                this.waitUntilNotVisible(this.loadingIndicator);
                log.info("Input for: " + ParentFilter + " > " + ChildFilter + " filter");
                List<WebElement> cities = this.findElements(this.SearchResults);
                for (WebElement city : cities) {
                    log.info(String.format("API Value is : %s and UI Value is : %s",
                            city.getText().toUpperCase(), valueToSearch));
                    validationFlags.add(city.getText().contains(valueToSearch));
                }
                commonHelpers.thinkTimer(300);
                this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, valueToSearch)));
            }
        }
        if (cancelApply.contains(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
        } else {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
        }
        return !validationFlags.contains(false);

    }

    public Boolean SelectFilterforUI(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.clickOnElement(filterChevron);
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
              this.JavaScriptClick(this.findElement(filterChevron));
        }
        if(this.isElementDisplayed(this.filterCancelButton,500,1)) {
            this.Mouse_MoveToElement(this.filterCancelButton);
        }
        for (String key : dataFilters.keySet()) {
            if (key.equalsIgnoreCase("Shipment Information-Industry Vertical")) {
                this.FilterForShipments(key, dataFilters.get(key).split(","));
            } else {
                this.FilterForShipments(key, dataFilters.get(key).split(":"));
            }
        }
        Boolean flag = this.findElements(dotsXpath).size() > 0;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                if (flag && !dataFilters.get(key).contains("Today")
                        && key.equalsIgnoreCase("Shipment Information-Industry Vertical")) {
                    flag = this.VaidateFilterBubble(cancelOrApply, key, dataFilters.get(key).split(","));
                } else if (flag && !dataFilters.get(key).contains("Today")) {
                    flag = this.VaidateFilterBubble(cancelOrApply, key, dataFilters.get(key).split(":"));
                }
            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
//            Actions builder = new Actions(DriverManager.getDrv());
//            builder.moveToElement(this.findElement(this.filterCancelButton));

            this.JavaScriptClick(this.findElement(this.filterCancelButton));

            // Validating if filter bubble is not added
            for (String key : dataFilters.keySet()) {
                if (flag && !dataFilters.get(key).contains("Today")
                        && key.equalsIgnoreCase("Shipment Information-Industry Vertical")) {
                    flag = this.VaidateFilterBubble(cancelOrApply, key, dataFilters.get(key).split(","));
                } else if (flag && !dataFilters.get(key).contains("Today")) {
                    flag = this.VaidateFilterBubble(cancelOrApply, key, dataFilters.get(key).split(":"));
                }
            }
        }
        if (this.getViewCount() == 0)
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        return flag;
    }

    public Boolean SelectFilterforUI_githubCopilot(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        if (this.isElementDisplayed(this.filterCancelButton, 500, 1)) {
            this.Mouse_MoveToElement(this.filterCancelButton);
        }
        dataFilters.forEach((key, value) -> {
            String[] filterValues = key.equalsIgnoreCase("Shipment Information-Industry Vertical") ? value.split(",") : value.split(":");
            this.FilterForShipments(key, filterValues);
        });
        Boolean flag = this.findElements(dotsXpath).size() > 0;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }
        flag = dataFilters.entrySet().stream().allMatch(entry -> {
            String[] filterValues = entry.getKey().equalsIgnoreCase("Shipment Information-Industry Vertical") ? entry.getValue().split(",") : entry.getValue().split(":");
            return this.VaidateFilterBubble(cancelOrApply, entry.getKey(), filterValues);
        });
        if (this.getViewCount() == 0) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        return flag;
    }

    public Boolean VaidateFilterBubble(String cancelOrApply, String status, String[] filterCriteria) {
        String xpath = " ";
        log.info("Inside VaidateFilterBubble Method-->");
        String subFilter = status.split("-")[1];
        log.info("Subfilter is-->" + subFilter);
        if (subFilter.contains("Last Scan Time") || subFilter.contains("Scheduled Delivery Date/Time")
                || subFilter.contains("Standard Transit")) {
            // making it Capital and adding hyphen and colon as it appears in filter bubble
            if (filterCriteria[0].contains("is not within") || filterCriteria[0].contains("Not-Within")) {
                filterCriteria[0] = "Is Not-Within:  ";
            } else if (filterCriteria[0].contains("is within")) {
                filterCriteria[0] = "Is Within: ";
            }
        }
        String temp = subFilter;
        if (subFilter.equalsIgnoreCase("Package Weight") || subFilter.equalsIgnoreCase("Total Weight")
                || subFilter.equalsIgnoreCase("Recipient Country/ Territory")
                ||subFilter.equalsIgnoreCase("Origin Country/Territory")
                ||subFilter.equalsIgnoreCase("Special Handling")){
            temp = filterCriteria[0];
        }
        List<Boolean> validationflags = new ArrayList<>();
        for (int filter = 0; filter < filterCriteria.length; ++filter) {
            if (filter != filterCriteria.length - 1) {
                // xpath = xpath + filterCriteria[filter] + ", ";
                xpath = filterCriteria[filter];
            } else {
                filterCriteria[filter] = filterCriteria[filter].contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(filterCriteria[filter]).toString()
                        : filterCriteria[filter];
                if (filterCriteria[filter].contains("Select All")
                        && (subFilter.contains("Bill To (Duties)") || subFilter.contains("Bill To (Transportation)")
                        || subFilter.contains("Shipper Account Number") || subFilter.contains("Accounts"))) {
                    validationflags.add(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.filterBubbleXpathWithSingleHeading, subFilter))));
                    // Validating atleast few accounts are displayed in filter bubble
                    Assert.assertTrue("Filter bubble is not present with few accounts ", this.findElements(
                                    this.getByusingString(String.format(this.filterBubbleXpathWithSingleHeading, subFilter)))
                            .size() >= 1);

                } else if (filterCriteria[filter].contains("Weather Impacted")
                        || filterCriteria[filter].contains("Select All")) {
                    for (String key : Constants.ExceptionalFilterBubble.keySet()) {
                        if (filterCriteria[filter].equalsIgnoreCase(key)) {
                            filterCriteria[filter] = Constants.ExceptionalFilterBubble.get(key);
                        }
                    }
                }
                // xpath = xpath + filterCriteria[filter];
                xpath = filterCriteria[filter].split("@")[0];
                switch (subFilter) {
                    case "Delivered To":
                        xpath = xpath.toUpperCase();
                        break;
                    case "Recipient City":
                        xpath = xpath.toUpperCase();
                        break;
                    case "Latest FXE Event":
                        xpath = xpath.split("@")[0];
                        break;
                    case "Last Scan Time":
                        // Skipping the checking for first option as that would be the prefix
                        // either is within or is not within but not the actual filter to be checked
                        if (filter == 0)
                            continue;
                        // adding the prefixes that appears in for this filter bubble
                        xpath = "Last Scanned " + filterCriteria[0] + filterCriteria[filter];
                    case "Scheduled Delivery Date/Time":
                        // Skipping the checking for first option as that would be the prefix
                        // either is within or is not within but not the actual filter to be checked
                        if (filter == 0)
                            continue;
                        // adding the prefixes that appears in for this filter bubble
                        xpath = "Scheduled Delivery " + filterCriteria[0] + "Next " + filterCriteria[filter];
                }
            }

            // String temp = status.split("-")[1].equalsIgnoreCase("Latest FXE Event") ?
            // "Latest Event"
            // : status.split("-")[1];
            if (xpath.contains("ContextStore-")) {
                xpath = (String) this.commonHelpers.getValuefromContextStore(xpath);
            }
            if (subFilter.equalsIgnoreCase("Delivered Date")) {
                if (!xpath.contains("In the last")) {
                    xpath = "Delivered In " + xpath;
                } else {
                    xpath = "Delivered Date In the last";
                }
            }

            if (!(xpath.equalsIgnoreCase("Select All") || xpath.equals("Specific Case Number")
                    || xpath.equalsIgnoreCase("Specific RMA")
                    || xpath.equalsIgnoreCase("Specific Personal Note")
                    || xpath.equalsIgnoreCase("Specific POD Exception")
                    || xpath.equalsIgnoreCase("Specific Support Update")
                    || xpath.equalsIgnoreCase("Specific Last Comment")
                    || xpath.equalsIgnoreCase("Specific Commodity Information")
                    || xpath.equalsIgnoreCase("Specific SenseAware #")
                    || xpath.equalsIgnoreCase("Specific Exception Reason")
                    || xpath.equalsIgnoreCase("Special Handling Is")
                    || xpath.equalsIgnoreCase("Special Handling Is Not")
                    || xpath.equalsIgnoreCase("Package Weight (LBS)")
                    || xpath.equalsIgnoreCase("Package Weight (KGS)")
                    || xpath.equalsIgnoreCase("Total Weight (LBS)")
                    || xpath.equalsIgnoreCase("Total Weight (KGS)")
                    || xpath.equalsIgnoreCase("Recipient Country/ Territory Is")
                    || xpath.equalsIgnoreCase("Recipient Country/ Territory Is Not")
                    ||xpath.equalsIgnoreCase("Origin Country/Territory Is")
                    || xpath.equalsIgnoreCase("Controllable Delay"))) {
                validationflags.add(this.elementIsDisplayed(
                        this.getByusingString(String.format(this.filterBubbleXpath, xpath, temp))));
            }
        }
        return cancelOrApply.equalsIgnoreCase("apply") ? !validationflags.contains(false)
                : !validationflags.contains(true);
    }

    public Boolean SelectFilterforUIwithDate(String cancelOrApply, DataTable dataTable, String date) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.SelectFilterForShipments(key, dataFilters.get(key).split(":"), date);
        }
        Boolean checkFilter = false; // = this.findElements(dotsXpath).size() > 0;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "In the last":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split("-")[1], "Last", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Last day filter is not displayed", checkFilter);
                            break;
                        case "In the next":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split("-")[1], "Next", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Next day filter is not displayed", checkFilter);
                            break;
                        case "Today":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.todayBubbleFilter, key.split("-")[1], "Today")))
                                    .isDisplayed();
                            Assert.assertTrue("today filter is not displayed", checkFilter);
                            break;
                        case "In the past":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFiltersHours, key.split("-")[1], "Past", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Past hours filter is not displayed", checkFilter);
                            break;
                        case "Is within":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFiltersDay, key.split("-")[1], "Is within", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Is within filter is not displayed", checkFilter);
                            break;

                    }
                }

            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }
        /*
         * if (this.getViewCount() == 0)
         * this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
         */
        return checkFilter;
    }

    public Boolean SelectUIFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.clickOnElement(filterChevron);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.SelectFilterTodaySpecific(key, dataFilters.get(key).split(":"));
        }
        Boolean flag = this.findElements(dotsXpath).size() > 0;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                // Uncomment below lines for any specific filter that needs handling after click
                // on apply button
                // For now there is no such filter that needs below handling
                // if (dataFilters.get(key).contains("Specific date range")) {
                // this.JavaScriptClick(this.findElement(
                // this.getByusingString(String.format(this.cancelFilterBubble,
                // key.split("-")[1]))));
                // } else
                if (dataFilters.get(key).contains("Date Ranges")
                        || dataFilters.get(key).contains("Specific Date / Time")
                        || dataFilters.get(key).contains("Specific Date")
                        || dataFilters.get(key).contains("Specific date range")) {
                    log.info("No action required");
                }
                // click on isWithin or isNotWithin
                else if (dataFilters.get(key).contains("isWithin") || dataFilters.get(key).contains("isNotWithin")) {
                    this.JavaScriptClick(this.findElement(
                            this.getByusingString(String.format(this.labelFor, key.split(":")[0]))));
                } else {
                    boolean checkFilter = this.findElement(
                                    this.getByusingString(String.format(this.filterBubbleXpath, "Today", key.split("-")[1])))
                            .isDisplayed();
                    this.JavaScriptClick(
                            this.findElement(this.getByusingString(String.format(this.cancelFilterBubble, "Today"))));
                }

            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
            // Validating if filter bubble is not added
            for (String key : dataFilters.keySet()) {
                if (flag && !dataFilters.get(key).contains("Today")) {
                    flag = this.VaidateFilterBubble(cancelOrApply, key, dataFilters.get(key).split(":"));
                }
            }
        }
        if (this.getViewCount() == 0)
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        return flag;
    }

    public void SelectFilterTodaySpecific(String status, String[] filterCriteria) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            // this.clickOnElement(filterChevron);
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(status.split("-")[0]))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, status.split("-")[0], status.split("-")[1]))));
        for (String filter : filterCriteria) {
            switch (filter) {
                case "Specific date range":
                    this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific date range")));
                    if (ChildFilter.equals("Gel Pack Date/Time") || ChildFilter.equals("Dry Ice Added Date/Time")
                            || ChildFilter.equals("Cold Storage Date/Time")) {
                        this.SelectFromandToDatesInCalendarWithOkButton(filterCriteria);
                    } else {
                        this.SelectFromandToDatesInCalendar(filterCriteria);
                    }
                    break;
                case "Date Ranges":
                    this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Date Range")));
                    this.SelectFromandToDatesInCalendarWithOkButton(filterCriteria);
                    break;
                case "Specific Date / Time":
                    this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Date / Time")));
                    this.selectfromDate(filterCriteria);
                    break;
                case "Today":
                    if (filterCriteria[0].contains("Today")) {
                        this.JavaScriptClick(this.findElement(this.getByusingString(
                                String.format(this.filterxpath, status.split("-")[0], status.split("-")[1], filter))));
                    }
                    break;
                case "Specific Date and Time":
                    if (ChildFilter.equals("Scheduled Delivery Date/Time")) {
                        String dateFormatOnUIString = this.commonHelpers
                                .getValuefromContextStore("preferredDateFormat") + " hh:mm a";
                        String scheduledDateTime = (String) this.commonHelpers
                                .getValuefromContextStore("scheduledDeliveryDateDestTZ");
                        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Time")));
                        String dateWithTime = this.dateTimeUtils.changeDateFormat(scheduledDateTime.replace("T", " "),
                                "YYYY-MM-DD hh:mm:ss", dateFormatOnUIString, "DM");
                        this.commonHelpers.AddToContextStore("Specific Date / Time", dateWithTime);
                        String date = this.dateTimeUtils.isDate(scheduledDateTime.replace("T", " "),
                                "YYYY-MM-DD hh:mm:ss", "d MMMM yyyy EEEE");
                        this.selectStaticDate(date, "fromDate");
                        this.selectTime(dateWithTime, "fromTime");
                        String[] time = dateWithTime.split(" ");
                        this.commonHelpers.AddToContextStore("time", String.join(" ", time[1], time[2]));
                    }
                    break;
                case "Specific Date and Time Range":
                    if (ChildFilter.equals("Scheduled Delivery Date/Time")) {
                        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Time")));
                        this.selectDropdown(By.xpath(String.format(this.ampmOptions, "1")), "text", "AM");
                        String fT = this.commonHelpers.getValuefromContextStore("Specific Date / Time")
                                .toString().replace("PM", "AM");
                        this.commonHelpers.AddToContextStore("fromTime", fT);
                        this.selectTime(fT.split(" ")[0] + " " + filterCriteria[1].replace("-", ":"), "toTime");
                        String[] timeValues = filterCriteria[1].split(" ");
                        String tDt = String.join(" ", fT.split(" ")[0], timeValues[0].replace("-", ":"), timeValues[1]);
                        this.commonHelpers.AddToContextStore("toTime", tDt);
                    }
                    break;
                case "Date Ranges and Specific Time":
                    if (ChildFilter.equals("Scheduled Delivery Date/Time")) {
                        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Date")));
                        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Time")));
                        this.selectDatetime(filterCriteria, true, true, false, false);
                        this.selectTime(this.commonHelpers.getValuefromContextStore("Specific Date / Time").toString(),
                                "fromTime");
                        this.commonHelpers.AddToContextStore("toTime",
                                (String) this.commonHelpers.getValuefromContextStore("Specific Date / Time"));
                        this.commonHelpers.removeKeyinContextStore("fromTime");
                    }
                    break;
                case "Date Ranges and Time Range":
                    if (ChildFilter.equals("Scheduled Delivery Date/Time")) {
                        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Time")));
                        this.selectDatetime(filterCriteria, true, true, false, false);
                        this.selectDropdown(By.xpath(String.format(this.ampmOptions, "1")), "text", "AM");
                        // this.selectTime(this.commonHelpers.GetValuefromContextStore("Specific Date /
                        // Time").toString(), "fromTime");
                        String fT = this.commonHelpers.getValuefromContextStore("Specific Date / Time")
                                .toString().replace("PM", "AM");
                        this.commonHelpers.AddToContextStore("fromTime",
                                String.join(" ",
                                        this.dateTimeUtils.isDate(
                                                this.commonHelpers.getValuefromContextStore("FromDate").toString(),
                                                "d MMM YYYY EEEE", "dd-MM-YYYY"),
                                        fT.split(" ")[1], fT.split(" ")[2]));
                        String tDt = String.join(" ", fT.split(" ")[0],
                                this.commonHelpers.getValuefromContextStore(filterCriteria[3]).toString());
                        this.selectTime(tDt, "toTime");
                        this.commonHelpers.AddToContextStore("toTime", tDt);
                    }
                    break;
            }

        }
        /*
         * if (filterCriteria[0].contains("Today")) {
         * this.SelectFromandToDatesInCalendar(filterCriteria); }
         */

    }

    public void navigatesToDateFilter(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            this.SelectFilterTodaySpecific(key, dataFilters.get(key).split(":"));
        }
    }

    public Boolean ValidateFilterAvailable(String status, String[] filterCriteria) {
        List<String> labels = new ArrayList();

        // if filter dropdown is not opened, opening it
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            // this.clickOnElement(filterChevron);
            this.JavaScriptClick(this.findElement(filterChevron));
        }

        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        log.info("Parent Filter = " + ParentFilter);
        log.info("Child Filter  = " + ChildFilter);

        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(status.split("-")[0]))));
        try {
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
        } catch (Exception e) {
            log.info("Child level filter is not found. This could be expected as well");
            return true;
        }
        for (String filter : filterCriteria) {
            if (!filter.contains("Today")) {
                List<WebElement> filterlabels = this
                        .findElements(By.xpath(String.format(this.filterLabels, ParentFilter, ChildFilter)));
                for (WebElement ele : filterlabels) {
                    log.info("Filters Label: " + ele.getText());
                    if (ele.getText().equalsIgnoreCase(filter))
                        labels.add(ele.getText());
                }
            }
        }
        return labels.size() == 0;
    }

    public void FilterForShipments(String status, String[] filterCriteria) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            // this.clickOnElement(filterChevron);
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        log.info("Parent Filter --> " + ParentFilter);
        log.info("Child Filter  --> " + ChildFilter);

        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(status.split("-")[0]))));
        if (ChildFilter.contains("Cold Storage Temp")) {
            ChildFilter = String.join("-", ChildFilter, status.split("-")[2]);
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, status.split("-")[0], ChildFilter))));
        } else {
            this.waitUntilVisible(this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter)));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
        }
        Boolean alreadySearched = true;

        for (String filter : filterCriteria) {
            log.info("Filter: " + filter);
            if (filter.equals("Today checkbox")) {
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Today")));
            }
            if (!filter.contains("Today")) {
                if (ChildFilter.equalsIgnoreCase("Shipper Account Number")) {
                    if (filterCriteria[0].equalsIgnoreCase("Select All")) {
                        // we don't want to use the search box by typing in this case.. so added this
                        // condition to avoid the next one.
                        // this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(filter)));
                    } else {
                        // making sure "Select All" is not visible
                        this.elementIsNotDisplayed(By.xpath(this.getXPathforCheckboxWithText("Select All")));
                    }
                }
                // IF the filters are where we type in search bar
                if (Constants.SearchBarFilters.contains(ChildFilter)
                        && !(filterCriteria[0].equalsIgnoreCase("Select All"))) {
                    InputSearchBarFilter(filter, ParentFilter, ChildFilter);
                } else {
                    if (filter.equalsIgnoreCase("Weather Impacted"))
                        this.JavaScriptClick(this.findElement(this.getByusingString(String
                                .format(this.weatherFilterXpath, ParentFilter, ChildFilter, filter))));
                    else if (filter.equalsIgnoreCase("POD")) {
                        this.JavaScriptClick(this.findElement(this.getByusingString(String
                                .format(this.filterExactMatchXpath, ParentFilter, ChildFilter, filter))));
                    } else if (ChildFilter.equals("Package Dimensions")) {
                        String dimFilter = filter.split("-")[0];
                        String dim = (String) this.commonHelpers
                                .getValuefromContextStore(filter.replace(dimFilter + "-", ""));
                        this.enterText(By.xpath(String.format(this.packageDimesionsInfilter, dimFilter)), dim);
                    } else if (ChildFilter.equalsIgnoreCase("Delivered Date")
                            || ChildFilter.equalsIgnoreCase("Last Scan Time")
                            || ChildFilter.equalsIgnoreCase("Scheduled Delivery Date/Time")
                            || ChildFilter.equalsIgnoreCase("Gel Pack Date/Time")
                            || ChildFilter.equalsIgnoreCase("Dry Ice Added Date/Time")
                            || ChildFilter.equalsIgnoreCase("Cold Storage Date/Time")
                            || ChildFilter.equalsIgnoreCase("Bill To (Transportation)")
                            || ChildFilter.equalsIgnoreCase("Accounts")) {
                        if (filter.contains("In the last")) {
                            String days = filter.split(" ")[filter.split(" ").length - 2];
                            int daysToCount = Integer.parseInt(days) + 1;
                             this.clickOnElement(this.deliveredDateInTheLastOptions);
                            this.selectDropdown(this.deliveredDateInTheLastOptions, "index", days);
                            filter = "In the last";
                            this.commonHelpers.AddToContextStore("FromDate",
                                    GetLastdateFromCurrentDate("Today-" + daysToCount));
                            this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate("Today"));
                        } else if (filter.contains("s Not-Within")) {
                            filter = "is not within";
                        } else if (filter.contains("s Within") || filter.contains("s within")) {
                            filter = "is within";
                        }
                        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(filter)));
                    } else if (((filterCriteria[0].equalsIgnoreCase("Special Handling Is"))
                            || (filterCriteria[0].equalsIgnoreCase("Recipient Country/ Territory Is"))
                            ||(ChildFilter.equalsIgnoreCase("Origin Country/Territory")))
                            && alreadySearched) {
                        String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[1])
                                ? this.commonHelpers.getValuefromContextStore(filterCriteria[1].split("-")[1])
                                .toString()
                                : filterCriteria[1];

                        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Is")));
                        InputSearchBarFilter(valueToSearch, ParentFilter, ChildFilter);
                        alreadySearched = false;
                    } else if (!(filter.equalsIgnoreCase("Specific Case Number") ||

                            filter.equalsIgnoreCase("Specific RMA") || filter.equalsIgnoreCase("Specific Personal Note")
                            || filter.equalsIgnoreCase("Specific POD Exception")
                            || filter.equalsIgnoreCase("Specific Support Update")
                            || filter.equalsIgnoreCase("Specific Last Comment")
                            || filter.equalsIgnoreCase("Specific Commodity Information")
                            || filter.equalsIgnoreCase("Specific SenseAware #")
                            || filter.equalsIgnoreCase("Specific Exception Reason Is")
                            || filter.equalsIgnoreCase("Specific Exception Reason Is Not")
                            || filter.equalsIgnoreCase("Specific Delay Reason Is")
                            || filter.equalsIgnoreCase("Specific Delay Reason Is Not")
                            || ChildFilter.equalsIgnoreCase("Special Handling")
                            || ChildFilter.equalsIgnoreCase("Recipient Country/ Territory")
                            || filter.equalsIgnoreCase("Special Handling Is")
                            || filter.equalsIgnoreCase("Special Handling Is Not")
                            || filter.equalsIgnoreCase("Package Weight (LBS)")
                            || filter.equalsIgnoreCase("Package Weight (KGS)")
                            || filter.equalsIgnoreCase("Total Weight (LBS)")
                            || filter.equalsIgnoreCase("Total Weight (KGS)")
                            || filter.equalsIgnoreCase("Recipient Country/ Territory Is")
                            || filter.equalsIgnoreCase("Recipient Country/ Territory Is Not")
                            || ChildFilter.equalsIgnoreCase("Origin Country/Territory")
                            || filter.contains("ContextStore-"))) {
                        this.JavaScriptClick(this.findElement(this.getByusingString(
                                String.format(this.filterxpath, ParentFilter, ChildFilter,
                                        filter))));

                    }
                }
            }

        }

        if (filterCriteria[0].contains("Specific Exception Reason")) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter,
                            "Specific Exception Reason"))));
        }

        if (filterCriteria[0].contains("Specific Delay Reason")) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter,
                            "Specific Delay Reason"))));
        }


        if (filterCriteria[0].contains("Today")) {
            this.SelectTOandFROMDatesInCalendar(filterCriteria);
        } else if (filterCriteria[0].equalsIgnoreCase("Specific Case Number") ||
                filterCriteria[0].equalsIgnoreCase("Specific RMA")
                || filterCriteria[0].equalsIgnoreCase("Specific POD Exception")
                || filterCriteria[0].equalsIgnoreCase("Specific SenseAware #")
                || filterCriteria[0].equalsIgnoreCase("Specific Support Update")
                || filterCriteria[0].equalsIgnoreCase("Specific Last Comment")
                || filterCriteria[0].equalsIgnoreCase("Specific Commodity Information")

                || filterCriteria[0].equalsIgnoreCase("Specific Personal Note")) {
            String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[1])
                    ? this.commonHelpers.getValuefromContextStore(filterCriteria[1].split("-")[1]).toString()
                    : filterCriteria[1];

            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, status.split("-")[0], status.split("-")[1], filterCriteria[0]))));
            InputSearchBarFilter(valueToSearch, ParentFilter, ChildFilter);
        } else if ((filterCriteria[0].equalsIgnoreCase("Special Handling Is Not"))
                || (filterCriteria[0].equalsIgnoreCase("Specific Exception Reason Is Not"))
                || (filterCriteria[0].equalsIgnoreCase("Specific Delay Reason Is Not"))
                || (filterCriteria[0].equalsIgnoreCase("Recipient Country/ Territory Is Not"))) {
            String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[1])
                    ? this.commonHelpers.getValuefromContextStore(filterCriteria[1].split("-")[1]).toString()
                    : filterCriteria[1];

            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Is not")));

            InputSearchBarFilter(valueToSearch, ParentFilter, ChildFilter);
        } else if (filterCriteria[0].equalsIgnoreCase("Package Weight (LBS)")
                || filterCriteria[0].equalsIgnoreCase("Total Weight (LBS)")) {
            String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[1])
                    ? this.commonHelpers.getValuefromContextStore(filterCriteria[1].split("-")[1]).toString()
                    : filterCriteria[1];

            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("lbs.")));

            inputValueFilter(valueToSearch, ParentFilter, ChildFilter);
        } else if (filterCriteria[0].equalsIgnoreCase("Package Weight (KGS)")
                || filterCriteria[0].equalsIgnoreCase("Total Weight (KGS)")) {
            String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[1])
                    ? this.commonHelpers.getValuefromContextStore(filterCriteria[1].split("-")[1]).toString()
                    : filterCriteria[1];

            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("kgs.")));

            inputValueFilter(valueToSearch, ParentFilter, ChildFilter);
        } else if (filterCriteria[0].equalsIgnoreCase("Specific Temperature")) {
            InputSearchBarFilter(filterCriteria[2], ParentFilter, ChildFilter);
        } else if (filterCriteria[0].equalsIgnoreCase("Specific Quantity")) {
            InputSearchBarFilter(filterCriteria[2], ParentFilter, ChildFilter);
        } else if (filterCriteria[0].equalsIgnoreCase("Specific Amount (KG)")
                || filterCriteria[0].equalsIgnoreCase("Specific Amount (LBS)")) {
            String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filterCriteria[2])
                    ? this.commonHelpers.getValuefromContextStore(filterCriteria[2]).toString()
                    : filterCriteria[2];
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(filterCriteria[1])));
            InputSearchBarFilter(valueToSearch, ParentFilter, ChildFilter);
        }

    }

    /**
     * @param filter
     * @param ParentFilter
     * @param ChildFilter
     */
    public void InputSearchBarFilter(String filter, String ParentFilter, String ChildFilter) {
        String valueToSearch = this.commonHelpers.verifyKeyInContextStore(filter)
                ? this.commonHelpers.getValuefromContextStore(filter).toString()
                : filter;
        if (!this.commonHelpers.verifyKeyinContextStore("DefaultText")) {
            this.commonHelpers.AddToContextStore("DefaultText", this
                    .elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.SearchDefaultText))));

            // Validates the suggestion text based on the child filter
            this.ValidateSuggestionText(ChildFilter);
            this.waitUntilVisible(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
            this.clickOnElement(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
            this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                    "123455678899876545");
            this.waitUntilNotVisible(this.loadingIndicator);
            this.elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.NoResultsFound)));
        }
        this.JavaScriptClick(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
        switch (ChildFilter) {
            case "Delivered To":
                valueToSearch = valueToSearch.toUpperCase();
                break;
            case "Recipient City":
                valueToSearch = valueToSearch.toUpperCase();
                break;
            case "Latest FXE Event":
                valueToSearch = valueToSearch.split("@")[0];
                break;
        }
        if (ChildFilter.equalsIgnoreCase("Special Handling")) {
            String[] values = valueToSearch.split("@");
            for (String key : values) {
                this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                        key);

                try {
                    Thread.sleep(5000);
                } catch (Exception ex) {
                    log.error("Thread sleep fails");
                }
                this.keyBoardEvent(Keys.TAB);
                valueToSearch = valueToSearch.replaceAll("\\s+", " ");
                this.commonHelpers.thinkTimer(3000);
                this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, key.trim())));
            }
        } else {
            this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                    valueToSearch);
            long start = System.currentTimeMillis();
            try {
                Thread.sleep(5000);
            } catch (Exception ex) {
                log.error("Thread sleep fails");
            }

            // Adding more wait time as few of the apis related to shipper and recipient
            // takes a lot of time to return the search resultsfv
            // reuired for single search and multi search
            this.waitUntilNotVisible(this.loadingIndicator);
            // required for checbox search indicator
            this.waitUntilNotVisible(this.quickViewLoading);
            // required if api takes longer time
            String xpathElm = String.format(this.checkboxIndicator, valueToSearch);
            this.waitUntilNotVisible(By.xpath(xpathElm));
            long finish = System.currentTimeMillis();
            log.info("Total Time Elapsed " + (finish - start));
            log.info("Input for: " + ParentFilter + " > " + ChildFilter + " filter." + "Value searched is -->"
                    + valueToSearch);
            if (valueToSearch.equals("FedEx International Priority")
                    || valueToSearch.equals("FedEx First Overnight")
                    || valueToSearch.equals("FedEx 2Day")
                    || ChildFilter.contains("Exception Reason")) {
                this.commonHelpers.thinkTimer(3000);
                this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResultsExactMatch, valueToSearch.trim())));
            } else {
                this.keyBoardEvent(Keys.TAB);
                valueToSearch = valueToSearch.replaceAll("\\s+", " ");
                this.commonHelpers.thinkTimer(3000);
                this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, valueToSearch.trim())));
            }
        }
    }

    public Boolean ValidateSearchBarFiltersInfoText(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        Boolean flag = false;
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            String ParentFilter = key.split("-")[0];
            String ChildFilter = key.split("-")[1];
            String[] inputText = dataFilters.get(key).split(":");
            log.info("Parent Filter --> " + ParentFilter);
            log.info("Child Filter  --> " + ChildFilter);
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(key.split("-")[0]))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            this.JavaScriptClick(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
            for (String input : inputText) {
                this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                        input);
                this.waitUntilNotVisible(this.loadingIndicator);
                log.info("Input for: " + ParentFilter + " > " + ChildFilter + " filter." + "Value searched is -->"
                        + input);
                if ((input.equalsIgnoreCase("FE")) || (input.equalsIgnoreCase("TNT"))) {
                    this.elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.NoResultsFound)));
                    flag = true;
                } else if (input.equalsIgnoreCase("?!@")) {
                    this.elementIsDisplayed(
                            By.xpath(this.buildXpathForString(Constants.ConsecutiveSpecialCharactersNotAllowed)));
                    flag = true;
                }
            }
        }

        return flag;
    }

    public void ValidateSuggestionText(String childFilter) {
        if (Constants.SuggestTextTwoLetterFilters.contains(childFilter)) {
            Assert.assertTrue("Suggestion text is wrong for " + childFilter,
                    this.elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.SuggestTextTwoLetter))));
        } else if (Constants.SuggestTextThreeLetterFilters.contains(childFilter)) {
            Assert.assertTrue("Suggestion text is wrong for " + childFilter,
                    this.elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.SuggestTextThreeLetter))));
        } else if (Constants.SuggestTextThreeLetterCERTypeFilter.contains(childFilter)) {
            Assert.assertTrue("Suggestion text is wrong for " + childFilter,
                    this.elementIsDisplayed(
                            By.xpath(this.buildXpathForString(Constants.SuggestTextThreeLetterCERType))));
        } else if (Constants.SuggestTextThreeCharacterFilters.contains(childFilter)) {
            Assert.assertTrue("Suggestion text is wrong for " + childFilter,
                    this.elementIsDisplayed(By.xpath(this.buildXpathForString(Constants.SuggestTextThreeCharacters))));
        }

    }

    public Boolean validateDefaultFilterSelection(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.findElement(filterChevron));
        String ParentFilter = "";
        String ChildFilter = "";
        Boolean flag = true;
        for (String key : dataFilters.keySet()) {
            ParentFilter = key.split("-")[0];
            ChildFilter = key.split("-")[1];
            String labelText = dataFilters.get(key);
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(key.split("-")[0]))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            if ((ChildFilter.equalsIgnoreCase("Special Handling"))
                    || (ChildFilter.equalsIgnoreCase("Recipient Country/ Territory"))
                    ||(ChildFilter.equalsIgnoreCase("Origin Country/Territory"))){
                String attributeValue = this.getAttributeValue(By.xpath(this.getXPathforCheckboxWithText(labelText)),
                        "for");
                flag = attributeValue.equals("in");
            } else {
                String[] filterValues = labelText.split(";");
                for (String filterValue : filterValues) {
                    String condn = filterValue.split("-")[0];
                    Object expValue = null;
                    if (condn.equals("checked")) {
                        expValue = true;
                    } else if (condn.equals("unchecked")) {
                        expValue = false;
                    }
                    String[] filterDefaultValues = filterValue.split("-")[1].split(",");
                    for (String filterDefaultValue : filterDefaultValues) {
                        Object actValue = this.getElementPropertyValueUsingJS(
                                By.xpath(this.getXPathforAnyElementWithText(filterDefaultValue) + "/../input"),
                                "checked");
                        if (!expValue.equals(actValue)) {
                            flag = false;
                        }
                    }
                }
            }
        }
        return flag;
    }

    public Boolean validateFilterTitle(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.findElement(filterChevron));
        String ParentFilter = "";
        String ChildFilter = "";
        String valueToSearch = "";
        Boolean flag = false;
        for (String key : dataFilters.keySet()) {
            ParentFilter = key.split("-")[0];
            ChildFilter = key.split("-")[1];
            String expectedFilterTitle = dataFilters.get(key);
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(key.split("-")[0]))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            this.JavaScriptClick(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
            switch (ChildFilter) {
                case "Recipient Country/ Territory":
                    valueToSearch = "US";
                    this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                            valueToSearch);
                    this.waitUntilNotVisible(this.loadingIndicator);
                    break;
                case "Last Known Country/ Territory":
                    valueToSearch = "US";
                    this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                            valueToSearch);
                    this.waitUntilNotVisible(this.loadingIndicator);
                    break;
                case "Service Type":
                    valueToSearch = "FEDEX";
                    this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                            valueToSearch);
                    this.waitUntilNotVisible(this.loadingIndicator);
                    break;
                default:
                    break;
            }
            String actualFilterTitle = this.findElement(subFilterTitle).getText();
            if (expectedFilterTitle.equals(actualFilterTitle)) {
                flag = true;
            }
        }
        return flag;
    }

    public void inputValueFilter(String filter, String ParentFilter, String ChildFilter) {
        String valueToInput = this.commonHelpers.verifyKeyInContextStore(filter)
                ? this.commonHelpers.getValuefromContextStore(filter).toString()
                : filter;
        this.JavaScriptClick(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)));
        this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)),
                valueToInput);
        log.info("Input for: " + ParentFilter + " > " + ChildFilter + " filter");
    }

    public void selectOrDeselectFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.clickOnElement(filterChevron);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.FilterForShipments(key, dataFilters.get(key).split(":"));
        }
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }
        // Skipping view count condition for some filters as
        // Data Dependency is expected and we just want to test filter bubbles and not
        // the data
        if (!(dataFilters.keySet().toString().contains("Gel Pack Date/Time")
                || dataFilters.keySet().toString().contains("Dry Ice Added Date/Time")
                || dataFilters.keySet().toString().contains("Cold Storage Date/Time"))) {
            if (this.getViewCount() == 0)
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }

    }

    /**
     * Take the Column Value and compare with the table values.
     */
    public boolean checkvalueinColumn(String ColumnName, DataTable table) {
        boolean flag = false;
        List<String> attributesToSearch = table.asList(String.class);
        String tablevalue = "";
        for (int counter = 0; counter < attributesToSearch.size(); counter++) {
            tablevalue = tablevalue + attributesToSearch.get(counter);
        }
        List<WebElement> columnValues = null;

        switch (ColumnName) {
            case "Tracking Number":
                columnValues = this.findElements(TrackingNumResults);
                break;

            case "Delay Status":
                columnValues = this.findElements(packageDelayStatus);
                break;

        }

        for (int counter = 1; counter < columnValues.size(); counter++) {
            String colval = columnValues.get(counter).getText();
            if (tablevalue.contains(colval))
                flag = true;
            else {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public void SelectCompanyAccountDD(String CompanyName) throws Exception {
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, CompanyName);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, CompanyName)));
        // this.elementIsNotDisplayed(
        // By.xpath(String.format(this.defaultMessageCompanyDD,
        // Constants.noAccountSelectedMsg)));
        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.api.SetCompanyContext(CompanyName);
    }

    public void selectNextComapnyfromDropDown(String selection, String recordsCount) throws Exception {
        this.selectDropdown(shipmentsCountSlection, selection, recordsCount);
        if (this.elementIsDisplayed(loadingIndicator))
            this.waitUntilNotVisible(loadingIndicator);
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Dashboard");
        List<CEdashboard> companieslist = new ArrayList<CEdashboard>();
        List<CEdashboard> companies = this.commonHelpers.unMarshall(resp, CEdashboard[].class);
        for (CEdashboard board : companies) {
            if (board.getCompanyName().equalsIgnoreCase(recordsCount)) {
                companieslist.add(board);
            }
        }
        int index = this.commonHelpers.GenerateRandomNumber(companieslist.size());
        CEdashboard randomCompany = companieslist.get(index);
        log.info("Company Selected is --> " + randomCompany.getCompanyName());
        this.commonHelpers.AddToContextStore("CompanyName", randomCompany.getCompanyName());
        this.commonHelpers.AddToContextStore("CompanyCode", randomCompany.getCompanyCode());
    }

    public boolean CompareBothCompanyNames(String companyName) {
        String ComanyNameinContextStore = this.commonHelpers.getValuefromContextStore(companyName).toString();
        log.info("Context Store Company: " + ComanyNameinContextStore);
        String UICompany = this.getText(this.SelectedCompanies);
        log.info("UI Company: " + this.getSelectedCompanyName());
        return ComanyNameinContextStore.contains(UICompany);
    }

    public void SearchPartialTrackingNumber(String digit, String contextStorevariable) throws InterruptedException {
        String partialTrackingNum = this.commonHelpers.getValuefromContextStore(contextStorevariable).toString()
                .substring(0, Integer.parseInt(digit));
        this.commonHelpers.AddToContextStore("Partial Tracking Number", partialTrackingNum);
        this.JavaScriptClick(this.findElement(this.Searchicon));
        // if ( this.commonHelpers.GetValuefromContextStore("UserContext").equals("CE"))
        // {
        // this.enterText(searchinputCE, partialTrackingNum);
        // }
        // else
        // {
        this.enterText(searchinput, partialTrackingNum);
        // }

        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.thinkTimer(2000);
        this.commonHelpers.AddToContextStore("searchresultCount", this.getText(resultCount));
        this.JavaScriptClick(this.resultCount);
    }

    public boolean VerifyAllTrackinNumsContainsGivenPartialTrackingNumOnly(int searchresultCountInt) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(resultCount);
        this.waitUntilNotVisible(this.loadingIndicator);
        int TrackingIDsCount = Integer.parseInt(this.getViewingCount());
        return TrackingIDsCount == searchresultCountInt;
    }

    public boolean isNoSearchDisplayedforTwoDigitTrackingNumber(int digit) throws InterruptedException {
        String twodigitTrackingNum = this.commonHelpers.getValuefromContextStore("Tracking Number").toString()
                .substring(0, digit);
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.enterText(searchinput, twodigitTrackingNum);
        this.waitUntilNotVisible(this.loadingIndicator);
        return this.elementIsDisplayed(resultCount);
    }

    public boolean isInvalidTrackingNumberDisplayed(String trackingNum, String textString) throws InterruptedException {
        this.enterText(searchinput, trackingNum);
        this.waitUntilNotVisible(this.loadingIndicator);
        return this.elementIsDisplayed(this.getByusingString(String.format(trackingNumberxpath, textString)));
    }

    public String GetLastdateFromCurrentDate(String dateValue) {
        DateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy EEEE");
        Date myDate = new Date(System.currentTimeMillis());
        Calendar cal = Calendar.getInstance();
        if (dateValue.contains("-")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt("-" + dateValue.split("-")[1]));
        } else if (dateValue.equalsIgnoreCase("Today")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, 0);
        } else if (dateValue.contains("+")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt(dateValue.split("\\+")[1]));
        } else {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt("-" + dateValue));
        }
        return dateFormat.format(cal.getTime());
    }

    public String GetLastDateFromCalendar(String daysPrior) {
        String uiDate = "";
        while (this.elementIsDisplayed(calenderLeftArrow)) {
            this.clickOnElement(calenderLeftArrow);
        }
        uiDate = this.getText(dateFieldText);
        String month = this.getText(monthField);
        return uiDate + " " + month;
    }

    public boolean ValidateCalendarDisplaysDatesFromPreviousDays(String daysPrior) {
        String a = GetLastdateFromCurrentDate(daysPrior);
        String day = a.substring(0, a.lastIndexOf(" "));
        String dateCalendar = GetLastDateFromCalendar(daysPrior);
        // this.clickOnElement(clearCalendar);
        return day.equals(dateCalendar);
    }

    public void SelectShipmentQuickView() {
        this.waitUntilNotVisible(this.loadingIndicator);
        HashMap<String, String> quickViews = new HashMap<>();
        for (int index = 0; index < this.findElements(By.xpath(this.quickViewtitlesValueXpath)).size(); ++index) {
            quickViews.put(this.findElements(By.xpath(this.quickViewtitlesValueXpath)).get(index).getText(),
                    this.findElements(By.xpath(this.quickViewtitlesXpath)).get(index).getText());
        }
        Map<String, String> treeMap2 = new TreeMap<>(quickViews);
        Map<Integer, String> treeMap1 = new TreeMap<>();
        for (Map.Entry<String, String> entry : treeMap2.entrySet()) {
            log.info("Key: " + entry.getKey() + " Value: " + entry.getValue());
            treeMap1.put(Integer.parseInt(entry.getKey().replace(",", "")), entry.getValue());
        }
        log.info("-------------------------");
        Map.Entry<Integer, String> min = null;
        for (Map.Entry<Integer, String> entry : treeMap1.entrySet()) {
            log.info("Key: " + entry.getKey() + " Value: " + entry.getValue());
            if (entry.getKey() != 0) {
                if (min == null || min.getKey() > entry.getKey()) {
                    min = entry;
                }
            }
        }
        String minQucikView = min.getValue().toLowerCase();
        char[] charArray = minQucikView.toCharArray();
        boolean foundSpace = true;
        for (int i = 0; i < charArray.length; i++) {
            if (Character.isLetter(charArray[i])) {
                if (foundSpace) {
                    charArray[i] = Character.toUpperCase(charArray[i]);
                    foundSpace = false;
                }
            } else {
                foundSpace = true;
            }
        }
        minQucikView = String.valueOf(charArray);
        log.info("Input to click: " + minQucikView);
        if (minQucikView.equals("Senseaware Id")) {
            this.clickOnElement(By.xpath(String.format(this.clilckQuickView, "SenseAware ID")));
        } else if (minQucikView.equals("No Commit")) {
            this.clickOnElement(By.xpath(String.format(this.clilckQuickView, "No commit")));
        } else {
            this.JavaScriptClick(By.xpath(String.format(this.clilckQuickView, minQucikView)));
        }

    }

    public Boolean validateButtonStateinCalender(String button, String state) {
        String actualState = this.findElement(this.getByusingString(String.format(this.buttonStateinCalander, button)))
                .getAttribute(state);
        return Boolean.parseBoolean(actualState);
    }

    public void SelectTOandFROMDatesInCalendar(String[] filter) {
        boolean flag = true;

        if (filter[0].contains("Today")) {
            // new code for date range
            try {
                this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific date range")));
            } catch (Exception e) {
                // if its just today then only select Specific date
                // as in data range also we can have the word Today
                if (filter.length == 1) {
                    this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Date")));
                }
            }
            /////////////////

            this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(filter[0]));
            String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
            this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate(filter[1]));
            String[] toArr = this.commonHelpers.getValuefromContextStore("ToDate").toString().split(" ");

            // new code for date range
            this.clickOnElement(this.specificDateRangeFrom);
            /////////////////

            while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
               // if (this.elementIsDisplayed(calenderRightArrow) && flag) {
                if(this.elementIsDisplayed(calenderLeftArrowNext) && flag) {
                    flag = false;
                 //   this.clickOnElement(calenderRightArrow);
                    this.clickOnElement(calenderLeftArrowNext);
                } else {
                //    this.clickOnElement(calenderLeftArrow);
                    this.clickOnElement(calenderLeftArrowPrev);
                }
            }
            this.clickOnElement(By.xpath(String.format(dateXpath, fromArr[0])));
            if (elementIsDisplayed(specificDateOk)) {
                this.clickOnElement(this.specificDateOk);
            }
            // new code for date range
            this.clickOnElement(this.specificDateRangeTo);
            /////////////////
            flag = true;
            while (!this.getText(monthField).split(" ")[0].equals(toArr[1])) {
              //  if (this.elementIsDisplayed(calenderRightArrow) && flag) {
                if (this.elementIsDisplayed(calenderLeftArrowNext) && flag){
                    flag = false;
                  //  this.clickOnElement(calenderRightArrow);
                    this.clickOnElement(calenderLeftArrowNext);
                } else {
                    this.clickOnElement(calenderLeftArrow);
                }
            }
            this.clickOnElement(By.xpath(String.format(dateXpath, toArr[0])));
            if (elementIsDisplayed(specificDateOk)) {
                this.clickOnElement(this.specificDateOk);
            }
        }
    }

    public String getLastUpdatedDate() {
        WebElement UpdatedAt = this.findElement(lastUpdatedAtTime);
        String dateTime = UpdatedAt.getText();
        // removing the timezone part as well as we need just date and not even time
        // 02:46 PM, 4/17/2023 IST
        String date = dateTime.split(" ")[2];

        // if the system has 24 hours system then it comes at 1st place as AM , PM does
        // not come
        // 14:43, 4/17/2023 IST
        if (!(date.contains("/") || date.contains("-"))) {
            date = dateTime.split(" ")[1];
        }
        return date;
    }

    public void VerifyFileNameInFileDownloadDialogue(String preOrPostDownloadInfo, String prefixText,
                                                     String fileFormat) {
        String downloadDate = this.getLastUpdatedDate();
        WebElement actualFileNameField = null;
        String actualFileName = "";
        if (preOrPostDownloadInfo.equalsIgnoreCase("Pre")) {
            if (!this.findElement(savedFilename).isDisplayed()) {
                actualFileName = this.findElements(savedFilename).get(1).getText();
            } else {
                actualFileNameField = this.findElement(savedFilename);
                actualFileName = actualFileNameField.getText();
            }
        } else if (preOrPostDownloadInfo.equalsIgnoreCase("Post")) {
            actualFileNameField = this.findElement(downloadFileNamePostDownload);
            actualFileName = actualFileNameField.getText();
        }

        switch (fileFormat) {
            case "DOWNLOAD CSV":
                if (!prefixText.equalsIgnoreCase("")) {
                    Assert.assertTrue(Pattern.matches(prefixText + "_" + downloadDate +".*"+ ".csv", actualFileName));
                   // Assert.assertEquals(prefixText + "_" + downloadDate + ".csv", actualFileName);
                    break;
                } else {
                    Assert.assertTrue(Pattern.matches("FedEx_Surround_" + downloadDate +".*"+ ".csv", actualFileName));
                    //Assert.assertEquals("FedEx_Surround_" + downloadDate + ".csv", actualFileName);
                    break;
                }

            case "DOWNLOAD EXCEL":
                if (!prefixText.equalsIgnoreCase("")) {
                    Assert.assertTrue(Pattern.matches(prefixText + "_" + downloadDate +".*"+ ".xlsx", actualFileName));
                    //Assert.assertEquals(prefixText + "_" + downloadDate + ".xlsx", actualFileName);
                    break;
                } else {
                    Assert.assertTrue(Pattern.matches("FedEx_Surround_" + downloadDate +".*"+ ".xlsx", actualFileName));
                    //Assert.assertEquals("FedEx_Surround_" + downloadDate + ".xlsx", actualFileName);
                }
        }
        this.commonHelpers.AddToContextStore("dfileName", actualFileName);
        this.commonHelpers.AddToContextStore("userDateFormat", downloadDate);
    }

    public void enterDownloadFileName(String givenFileName, String saveFileFormat) {
        int popupAvailCount = 0;
        By fileNameTextbox = this.exportPrefixCompanyTextbox;
        String dcpopupTitle = this.findElement(dcPopupTitle).getText();
        WebElement saveAsFilename = this.findElement(savedFilename);
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        waitUntilVisible(this.getByusingString(this.buildXpathForString("Loading Available")));
        waitUntilNotVisible(this.getByusingString(this.buildXpathForString("Loading Available")));

        if (!dcpopupTitle.equals("Large File Download")) {

            String saveUptoDownloadFiles = this.findElement(saveUptoDownloads).getText();
            if (saveFileFormat.contains("Combined Files")) {
                saveUptoDownloadFiles = this.findElements(saveUptoDownloads).get(1).getText();
                fileNameTextbox = this.exportPrefixCompanyCombinedFilesTextbox;
                saveFileFormat = saveFileFormat.split("-")[0];
                saveAsFilename = this.findElements(savedFilename).get(1);
            }

            if (user.equalsIgnoreCase("CE")) {
                assertThat(saveUptoDownloadFiles)
                        .matches("Save up to 100 downloads \\(\\d+ Available\\)");
            } else {
                Assert.assertTrue("Save message on download popup is not coming correctly",
                        saveUptoDownloadFiles.matches("Save up to 50 downloads \\(\\d+ Available\\)"));
            }
            // saveUptoDownloadFiles = saveUptoDownloadFiles.substring(25, 27).trim();
            saveUptoDownloadFiles = saveUptoDownloadFiles.split("\\(")[1].split(" ")[0];
            popupAvailCount = Integer.parseInt(saveUptoDownloadFiles);
            this.commonHelpers.AddToContextStore("popupAvailableCount", popupAvailCount);
        }

        if (user.equalsIgnoreCase("CE")) {
            if (this.getText(fileNameTextbox).equalsIgnoreCase(""))
                this.enterText(fileNameTextbox, givenFileName);
        } else {
            if (this.getText(this.enterFilename).equalsIgnoreCase(""))
                this.enterText(this.enterFilename, givenFileName);
        }

        if (givenFileName.equals("") && user.equalsIgnoreCase("CE")) {
            givenFileName = this.commonHelpers.getValuefromContextStore("ContextStore-CompanyName")
                    + "_FedEx_Surround";
        }
        // waiting for enter text to be visible sometimes from automation it is delaying
        this.commonHelpers.thinkTimer(8000);
        WebElement UpdatedAt = this.findElement(lastUpdatedAtTime);
        String actualTime = UpdatedAt.getText();
        String formatTime = actualTime.split(",")[0].replace(":","_").replace(" ","_");
        // // WebElement saveAsFilename = this.findElement(savedFilename);
        String downLoadFilename = saveAsFilename.getText();
        // String[] date = actualTime.split(",");
        String dateFormat = getLastUpdatedDate();
        switch (saveFileFormat) {
            case "DOWNLOAD CSV":
                if (!givenFileName.equalsIgnoreCase("")) {
                    Assert.assertEquals(givenFileName + "_" + dateFormat + ".csv", downLoadFilename);
                    break;
                } else {
                    Assert.assertEquals("FedEx_Surround_" + dateFormat + "_"+formatTime+".csv", downLoadFilename);
                    break;
                }

            case "DOWNLOAD EXCEL":
                if (!givenFileName.equalsIgnoreCase("")) {
                    Assert.assertEquals(givenFileName + "_" + dateFormat + ".xlsx", downLoadFilename);
                    break;
                } else {
                    Assert.assertEquals("FedEx_Surround_" + dateFormat + "_" + formatTime + ".xlsx", downLoadFilename);
                }
        }

        boolean checkFormat = actualTime.contains(dateFormat);
        Assert.assertTrue("The date format is not matched", checkFormat);
        this.commonHelpers.AddToContextStore("dfileName", downLoadFilename);
        this.commonHelpers.AddToContextStore("userDateFormat", dateFormat);
        List<WebElement> elements = DriverManager.getDrv().findElements(this.fileDetails);
        String actMsg = elements.get(0).getText().replace("\n", " ");
        //this.getText(this.fileDetails).replace("\n", " ");
        String expMsg = "File will be saved as " + downLoadFilename;
        Assert.assertEquals("File Download Message", expMsg, actMsg);
    }

    public boolean verifyDownloadFileName(String fileName) {
        boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator, 60);
        this.commonHelpers.thinkTimer(8000);
        // this.waitUntilClickable(by)
        // Handling for CE
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE")) {
            try{
                if(this.findElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                        this.commonHelpers.getValuefromContextStore("CompanyName")))).isDisplayed())
                {
                    this.clickOnElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                            this.commonHelpers.getValuefromContextStore("CompanyName"))));
                }
            }
            catch(Exception ex)
            {
                log.info("Combined files is open");
            }
        }
        this.findElement(this.getByusingString(String.format(this.downloaddFileButton, fileName))).isDisplayed();
        WebElement downloadFileName = this
                .findElement(this.getByusingString(String.format(this.downLoadPageFileName, fileName))); // this.findElement(downLoadPageFileName);
        if (downloadFileName.isDisplayed()) {
            String fileNameDownloadPage = downloadFileName.getText();
            if (fileName.equals(fileNameDownloadPage)) {
                flag = true;
            }
        }
        return flag;
    }

    public boolean verifyDownloadFileNameIsDisplayed(String fileName) {
        boolean flag = false;
        this.commonHelpers.thinkTimer(8000);
        // Handling for CE
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE")
                && (this.commonHelpers.getValuefromContextStore("DownloadType").toString().contains("BY COMPANY"))) {
            this.clickOnElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                    this.commonHelpers.getValuefromContextStore("CompanyName"))));
        }
        try {
            flag = this
                    .findElement(this.getByusingString(String.format(this.downLoadPageFileName, fileName)))
                    .isDisplayed();
        } catch (Exception e) {
            log.error("**EXCEPTION** Downloaded file name is not displayed on download center page");
            flag = false;
        }
        return flag;
    }

    public boolean verifyAvailCount(String count, String downLoadFilename) {
        boolean flag = false;
        int verifyCount, countFromPopup;
        this.waitUntilNotVisible(this.loadingIndicator);
        boolean checkDownloadButton = this
                .findElement(this.getByusingString(String.format(this.downloaddFileButton, downLoadFilename)))
                .isDisplayed();
        Assert.assertTrue("The download button is not activated", checkDownloadButton);
        countFromPopup = Integer.parseInt(count);
        String availCountOnPage = this.findElement(displayedAvailableReports).getText();
        availCountOnPage = availCountOnPage.length() > 2 ? availCountOnPage.substring(availCountOnPage.length() - 2)
                : availCountOnPage;
        int displayedCountPage = Integer.parseInt(availCountOnPage);
        verifyCount = 50 - countFromPopup + 1;
        if (displayedCountPage == verifyCount) {
            flag = true;
        }
        return flag;
    }

    public boolean verifyReportDateColumnValue(String fileName) {
        String currentTime = this.getText(lastUpdatedAtTime);
        Boolean flag = true;
        WebElement reportDate;
        this.commonHelpers.thinkTimer(30000);
        // Handling for CE
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE")) {
            this.clickOnElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                    this.commonHelpers.getValuefromContextStore("CompanyName"))));
            reportDate = this.findElement(reportDateValueCE);

        } else {
            commonHelpers.thinkTimer(700);
            this.findElement(this.getByusingString(String.format(this.downloaddFileButton, fileName))).isDisplayed();
            reportDate = this
                    .findElement(this.getByusingString(String.format(this.reportDateValue, fileName)));

        }
        String reportDateValue = reportDate.getText();

        log.info("ReportDateValue from the UI = " + reportDateValue + "\n Current time now is " + currentTime);

        // Validating except time part as there could be difference of a minute
        if (!(reportDateValue.substring(5).equals(currentTime.substring(5)))) {
            flag = false;
        }
        // validating the hour part in the time
        if (!(reportDateValue.substring(0, 2).equals(currentTime.substring(0, 2)))) {
            flag = false;
        }
        return flag;
    }

    public String getCurrentLocalTime() {
        this.currentLocalTime = new SimpleDateFormat("hh:mm z, MMM d, yyyy")
                .format(new Date(System.currentTimeMillis()));
        return this.currentLocalTime;
    }

    public void deleteFileFromPage(String downLoadFilename) {
        // Handling for CE
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE")) {
            if(this.findElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                    this.commonHelpers.getValuefromContextStore("CompanyName")))).isDisplayed()) {
                String company = (String) this.commonHelpers.getValuefromContextStore("CompanyName");
                String expand = this
                        .getAttributeValue(this.getByusingString(String.format(this.expandCollapseReportDownloadCentre,
                                company)), "class");
                if (expand.contains("plus")) {
                    this.clickOnElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                            company)));
                }
            }
        }
        this.waitUntilNotVisible(this.dcfileloadingIndicator, 150);
        commonHelpers.thinkTimer(200);
        boolean checkDownloadButton = this
                .findElement(this.getByusingString(String.format(this.downloaddFileButton, downLoadFilename)))
                .isEnabled();
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue("The download button is not activated", checkDownloadButton);
        this.JavaScriptClick(
                this.findElement(this.getByusingString(String.format(this.downloaddFileButton, downLoadFilename))));
        DriverManager.getDrv().navigate().refresh();
        this.waitUntilNotVisible(this.loadingIndicator);
        if((this.elementIsDisplayed(this.Errorpage)))
        {
            log.info("Error page occured"+this.findElement(this.Errorpage).getText());
        }
        boolean checkLastDownload = this
                .findElement(this.getByusingString(String.format(this.lastdownloadTime, downLoadFilename)))
                .isDisplayed();
        Assert.assertTrue("The last download time is not displayed", checkLastDownload);
        this.JavaScriptClick(
                this.findElement(this.getByusingString(String.format(this.deleteDownloadFile, downLoadFilename))));
        this.JavaScriptClick(
                this.findElement(By.xpath(this.getXPathforAnyElementWithText("Delete"))));
    }

    public void clickOnIconOnDownloadPage(String icon, String downLoadFilename) {
        // Handling for CE
        if ((this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE"))
                && (this.commonHelpers.getValuefromContextStore("DownloadType").toString().contains("BY COMPANY"))) {
            this.clickOnElement(this.getByusingString(String.format(this.expandReportInDownloadCentre,
                    this.commonHelpers.getValuefromContextStore("CompanyName"))));
        }
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(
                this.findElement(this.getByusingString(String.format(this.deleteDownloadFile, downLoadFilename))));
    }

    public void SelectFromandToDatesInCalendar(String[] filter) {

        this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(filter[1]));
        String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
        this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate(filter[2]));
        String[] toArr = this.commonHelpers.getValuefromContextStore("ToDate").toString().split(" ");

        // new code for date range
        this.clickOnElement(this.specificDateRangeFrom);
        /////////////////

        while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
            this.clickOnElement(calenderLeftArrow);
        }
        this.clickOnElement(By.xpath(String.format(dateXpath, fromArr[0])));

        // new code for date range
        this.clickOnElement(this.specificDateRangeTo);
        /////////////////

        while (!this.getText(monthField).split(" ")[0].equals(toArr[1])) {
//            this.clickOnElement(calenderRightArrow);
            this.clickOnElement(calenderLeftArrowNext);
        }
        this.clickOnElement(By.xpath(String.format(dateXpath, toArr[0])));

    }

    public void clickOnSaveButton(String link) {
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(link))));
    }

    public boolean VerifyFilterBubbleIsShownWithValues(String preferredDateFormat, String DateType)
            throws ParseException {
        String dataToBeChecked = "";
        String userFormat = commonHelpers.getValuefromContextStore(preferredDateFormat).toString().replace("DD", "d")
                .replace("MM", "M");
        DateFormat originalFormat = new SimpleDateFormat("d MMMM yyyy EEEE");
        DateFormat targetFormat = new SimpleDateFormat(userFormat);
        String formattedToDate = targetFormat
                .format(originalFormat.parse(this.commonHelpers.getValuefromContextStore("ToDate").toString()));
        String formattedFromDate = targetFormat
                .format(originalFormat.parse(this.commonHelpers.getValuefromContextStore("FromDate").toString()));
        // dataToBeChecked = formattedFromDate.equals(formattedToDate)
        // ? dataToBeChecked = DateType.toUpperCase() + ": " + formattedFromDate
        // : DateType.toUpperCase() + ": " + formattedFromDate + " - " +
        // formattedToDate;
        dataToBeChecked = DateType.toUpperCase() + ": " + formattedFromDate + " - " + formattedToDate;
        log.info("Expected Date Range: " + dataToBeChecked.split(":")[1].trim());
        log.info("Actual Date Range from UI : " + this.getText(dateFilterXpath));
        return dataToBeChecked.split(":")[1].trim().equals(this.getText(dateFilterXpath));
    }

    public String GetTrackingNumberFromShipmentList(String trackingNum) throws InterruptedException {
        String trackinNumber = "";
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToLeft(this.findElement(ScrollBar));
        if (trackingNum.equalsIgnoreCase("random")) {
            int randomtrackingnum = this.commonHelpers
                    .GenerateRandomNumber(this.findElements(TrackingNumResults).size());
            randomtrackingnum = (randomtrackingnum <= 1) ? 2 : randomtrackingnum;
            trackinNumber = this
                    .getText(this.getByusingString(String.format(TrackingNumxpath, randomtrackingnum)));
        }
        this.waitUntilNotVisible(this.loadingIndicator);
        return trackinNumber;
    }

    /**
     * Gets view count from shipment list
     *
     * @return
     */
    public int getViewCount() {
        commonHelpers.thinkTimer(3000);
        this.waitUntilVisible(getViewCount, 30);
        // 5,000 / 7,500 getting the viewing count i.e. 5,000
        // Since the space is a special character and not a normal space
        String firstCount = this.getText(getViewCount).split("/")[0].replaceAll(",", "").replaceAll("\\u202F", "");
        // Replacing the comma and spaces(localization) from the number
        return Integer.parseInt(firstCount);
    }

    public boolean verifyToggleSelection(String toggle) {
        return this.findElement(By.xpath(String.format(toggleSwitchStatus, toggle))).getAttribute("class")
                .contains("active");
    }

    public void selectToggle(String toggle) {
        if (!this.findElement(By.xpath(String.format(toggleSwitchStatus, toggle))).getAttribute("class")
                .contains("active")) {
            this.clickOnElement(By.xpath(String.format(toggleSwitch, toggle)));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public Map<String, String> GetUiField(List<String> fields, String trkNbr) {
        Map<String, String> gridData = new HashMap<>();
        trkNbr = this.commonHelpers.getValuefromContextStore(trkNbr).toString();
        // field = this.commonHelpers.GetValuefromContextStore(field).toString();
        gridData.put("Tracking Number", trkNbr);
        // gridData.put("Status", this.getText(By.xpath(String.format(statusTrkNbr,
        // trkNbr))).trim());
        for (String field : fields) {
            String uiFieldName = Character.toLowerCase(field.charAt(0)) + field.substring(1);
            String value = this.getText(By.xpath(String.format(fieldTrkNbr, trkNbr, uiFieldName.replace(" ", ""))));
            if (value.contains("hr")) {
                gridData.put(field, value.split("r")[0]);
            } else {
                gridData.put(field, value);
            }
        }
        return gridData;
    }

    public void selectToggle(String toggle, String flag) {
        if (verifyToggleSelection(toggle) && flag.equalsIgnoreCase("OFF")) {
            this.clickOnElement(By.xpath(String.format(toggleSwitch, toggle)));
            this.waitUntilNotVisible(this.loadingIndicator);
        } else if (!verifyToggleSelection(toggle) && flag.equalsIgnoreCase("ON")) {
            this.clickOnElement(By.xpath(String.format(toggleSwitch, toggle)));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public void watchOrUnwatchShipment(String watchOrUnwatch) {
        if (watchOrUnwatch.equalsIgnoreCase("watch")) {
            this.clickOnElement(firstStarIcon);
            this.waitUntilNotVisible(this.loadingIndicator);
        } else if (watchOrUnwatch.equalsIgnoreCase("unwatch")) {
            this.clickOnElement(firstFilledStarIcon);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public int getWatchOrUnwatchShipmentsCount(String watchedOrUnwatched) {
        int count = 0;
        if (watchedOrUnwatched.equalsIgnoreCase("watched")) {
            count = DriverManager.getDrv().findElements(watchedList).size();
        } else if (watchedOrUnwatched.equalsIgnoreCase("unwatched")) {
            count = DriverManager.getDrv().findElements(unwatchedList).size();
        }
        return count;
    }

    public boolean validateWatchedListCount(String flag) {
        boolean status = false;
        int previousCount = (int) this.commonHelpers.getValuefromContextStore("previousShipmentsCount");
        int currentCount = this.getViewCount();

        if (flag.equalsIgnoreCase("increased")) {
            status = (previousCount < currentCount);
        } else if (flag.equalsIgnoreCase("decreased")) {
            status = (previousCount > currentCount);
        } else if (flag.equalsIgnoreCase("same")) {
            status = (this.commonHelpers.AssertCountswithCorrection(previousCount, currentCount));
        }

        return status;
    }

    public Map<String, String> GetUiFieldData(List<String> fields, String trkNbr) {
        Map<String, String> gridData = new HashMap<>();
        trkNbr = this.commonHelpers.getValuefromContextStore(trkNbr).toString();
        gridData.put("Tracking Number", trkNbr);
        for (String field : fields) {
            String uiFieldName = Character.toLowerCase(field.charAt(0)) + field.substring(1);
            String xpath = String.format(trkNbrFieldData, trkNbr, uiFieldName.replace(" ", ""));
            log.info(xpath);
            String value = this.getText(By.xpath(String.format(trkNbrFieldData, trkNbr, uiFieldName.replace(" ", ""))));
            if (value.contains("hr")) {
                gridData.put(field, value.split("r")[0]);
            } else {
                gridData.put(field, value);
            }
        }
        return gridData;
    }

    public Boolean ValidateFilterBubble(DataTable dataTable) {
        boolean flag = true;
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).contains("Today")) {
                flag = this.VaidateFilterBubble(key, dataFilters.get(key).split(":"));
            }
            if (!flag)
                break;
        }
        return flag;
    }

    public Boolean ValidateFilterBubbleForLocalization(DataTable dataTable) {
        boolean flag = true;
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).contains("Today")) {
                flag = this.VaidateFilterBubbleForLocalization(key, dataFilters.get(key).split(":"));
            }
            if (!flag)
                break;
        }
        return flag;
    }

    public Boolean VaidateFilterBubbleForLocalization(String status, String[] filterCriteria) {
        String xpath = " ";
        List<Boolean> validationflags = new ArrayList<Boolean>();
        for (int filter = 0; filter < filterCriteria.length; ++filter) {
            if (filter != filterCriteria.length - 1) {
                // xpath = xpath + filterCriteria[filter] + ", ";
                // xpath = xpath + filterCriteria[filter];
                xpath = filterCriteria[filter];
            } else {
                filterCriteria[filter] = filterCriteria[filter].contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(filterCriteria[filter]).toString().split(",")[0]
                        : filterCriteria[filter];
                // xpath = xpath + filterCriteria[filter];
                xpath = filterCriteria[filter];
            }
            xpath=this.genericFuncObj.getLocalizedValue(xpath);
            status=this.genericFuncObj.getLocalizedValue(status.split("-")[1].trim());
            validationflags.add(this.elementIsDisplayed(
                    this.getByusingString(String.format(this.filterBubbleXpath, xpath, status))));
        }
        return !validationflags.contains(false);
    }


    public Boolean VaidateFilterBubble(String status, String[] filterCriteria) {
        String xpath = " ";
        List<Boolean> validationflags = new ArrayList<Boolean>();
        for (int filter = 0; filter < filterCriteria.length; ++filter) {
            if (filter != filterCriteria.length - 1) {
                // xpath = xpath + filterCriteria[filter] + ", ";
                // xpath = xpath + filterCriteria[filter];
                xpath = filterCriteria[filter];
            } else {
                filterCriteria[filter] = filterCriteria[filter].contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(filterCriteria[filter]).toString().split(",")[0]
                        : filterCriteria[filter];
                // xpath = xpath + filterCriteria[filter];
                xpath = filterCriteria[filter];
            }
            validationflags.add(this.elementIsDisplayed(
                    this.getByusingString(String.format(this.filterBubbleXpath, xpath, status.split("-")[1].trim()))));
        }
        return !validationflags.contains(false);
    }

    public void clickOnBackButton(String link) {
        this.ScrollIntoView(this.findElement(By.xpath(String.format(editColBackBtn, link))));
        this.clickOnElement(By.xpath(String.format(editColBackBtn, link)));
    }

    public Boolean SaveAView(String viewName) {
        Boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        // this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString("Save
        // This View"))));
        commonHelpers.thinkTimer(3000);
        JavaScriptClick(saveThisViewIcon);

        if (!GenericFunction.locale.equalsIgnoreCase(Constants.EN_US)) {
            By viewname = this.getByusingString(
                    String.format(this.viewNameInputLocalized, this.genericFuncObj.getLocalizedValue("View Name")));
            this.waitUntilVisible(viewname);
            this.enterText(this.getByusingString(
                            String.format(this.viewNameInputLocalized, this.genericFuncObj.getLocalizedValue("View Name"))),
                    viewName);
            this.clickOnElement(this.getByusingString(
                    String.format(this.viewSaveButtonLocalized, this.genericFuncObj.getLocalizedValue("Save"))));
            flag = this.elementIsDisplayed(By.xpath(String.format(this.viewSuccessfulMessageLocalized, viewName,
                    this.genericFuncObj.getLocalizedValue("successfully created."))));
            this.clickOnElement(this.getByusingString(String.format(this.viewSuccessfulMsgCloseButtonLocalized,
                    this.genericFuncObj.getLocalizedValue("Close"))));
        } else {
            this.waitUntilVisible(this.viewNameInput);
            this.enterText(this.viewNameInput, viewName);
            this.clickOnElement(this.viewSaveButton);
            flag = this.elementIsDisplayed(By.xpath(String.format(this.viewSuccessfulMessage, viewName)),
                    true);
            this.JavaScriptClick(this.viewSuccessfulMsgCloseButton);
        }
        return flag;
    }

    public Boolean SaveAViewAsDefault(String viewName) {
        Boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        // this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString("Save
        // This View"))));
        this.clickOnElement(saveThisViewIcon);
        this.enterText(this.viewNameInput, viewName);
        this.clickSetAsDefaultOnViewPopup();
        this.clickOnElement(this.viewSaveButton);
        flag = this.elementIsDisplayed(By.xpath(String.format(this.viewSuccessfulMessage, viewName.toUpperCase())),
                true);
        this.waitUntilVisible(this.viewSuccessfulMsgCloseButton);
        this.clickOnElement(this.viewSuccessfulMsgCloseButton);
        return flag;
    }

    public void clickMyView() {
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        if (user.equalsIgnoreCase("CE")) {
            if (!this.getAttributeValue(By.xpath(this.MyViewChevronOpen), "class").contains("open"))
                this.JavaScriptClick(By.xpath(this.MyViewChevron));
        }
    }

    public void clickStandardView() {
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        if (user.equalsIgnoreCase("CE")) {
            if (!this.getAttributeValue(By.xpath(this.StandardViewsChevronOpen), "class").contains("open"))
                this.clickOnElement(By.xpath(this.StandardViewsChevron));
        }
    }

    public void clickSharedView() {
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        if (user.equalsIgnoreCase("CE")) {
            if (!this.getAttributeValue(By.xpath(this.SharedViewsChevronOpen), "class").contains("open"))
                this.clickOnElement(By.xpath(this.SharedViewsChevron));
        }
    }

    public void validateViewAvailable(DataTable dataTable) {
        List<String> views = dataTable.asList(String.class);
        for (String view : views) {
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(this.ViewsChevron, view))));
        }
    }

    public boolean VerifySearchBubble(String view, String state) {
        Boolean flag = false;
        if (!view.equalsIgnoreCase("Multiple Tracking Numbers")) {
            this.clickMyView();
        }

        if (state.equalsIgnoreCase("visible")) {
            flag = this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubbleValue, view)), true)
                    && this.elementIsDisplayed(By.xpath(String.format(this.verifySearchBubble)), true);
        } else if (state.equalsIgnoreCase("invisible")) {
            flag = !(this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubbleValue, view)), true)
                    || this.elementIsDisplayed(By.xpath(String.format(this.verifySearchBubble)), true));
        }
        return flag;
    }

    public boolean VerifyErrormsg(String state) {
        Boolean flag = false;
        String errorMsg;
        this.waitUntilNotVisible(this.loadingIndicator);
        this.waitUntilVisible(verifyErrorMsg);
        if (state.equalsIgnoreCase("invalidTracks")) {
            errorMsg = this.findElement(verifyErrorMsg).getText();
            flag = errorMsg.equals(
                    "5 tracking numbers did not produce any data or were invalid. Verify tracking numbers and resubmit custom search.");// this.elementIsDisplayed(verifyErrorMsg);
        }
        return flag;
    }

    public boolean verifyDeleteConfirmationPopUpMessageDC(String fileName) {
        Boolean flag = false;
        String expectedPopUpMessage = "You are about to delete “" + fileName + "” are you sure?";
        String actualPopUpMessage = this.findElement(deleteMessagePopUpDC).getText();
        if (actualPopUpMessage.equals(expectedPopUpMessage)) {
            flag = true;
        }
        return flag;
    }

    public Boolean verifyViewInList(Map<String, String> columns) {
        boolean flag = false;
        for (String column : columns.keySet()) {
            if (columns.get(column).equalsIgnoreCase("visible")) {
                column = column.contains("Delay Reports") || column.contains("Working List") ? column
                        : column.toUpperCase();
                flag = this.elementIsDisplayed(By.xpath(String.format(this.verifyViewInList, column)),
                        true);
            } else if (columns.get(column).equalsIgnoreCase("invisible")) {
                flag = this.elementIsNotDisplayed(By.xpath(String.format(this.verifyViewInList, column.toUpperCase())));
            }
        }
        return flag;
    }

    public void SelectView(String viewName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickMyView();
        this.JavaScriptClick(By.xpath(String.format(this.verifyViewInList, viewName)));
    }

    public void ClickOnCloseButtonOnViewSuccessPopup() {
        this.clickOnElement(this.viewSuccessfulMsgCloseButton);
    }

    public void ClickOnRenameIconOfView(String viewName) {
        this.clickOnElement(By.xpath(String.format(rename_Icon, viewName)));
    }

    public void ClickOnShareIconOfView(String viewName) {
        this.clickOnElement(By.xpath(String.format(shareViewIconShipmentPage, viewName)));
    }

    public void ClickOnRenameOrSaveViewConfirmSaveCancel(String button) {

        switch (button) {
            case "Cancel":
                this.JavaScriptClick(renameOrSaveViewPopupCancel);
                break;
            case "Save":
                this.JavaScriptClick(renameOrSaveViewPopupSave);
                break;
            case "Share":
                this.JavaScriptClick(shareViewPopup);
                break;
        }
    }

    public void ClickOnSaveThisView(String button) {
        this.clickOnElement(saveThisViewIcon);
    }

    public void EnterViewNameToCreateView(String viewName) {
        this.enterText(viewNameInputText, viewName);
    }

    public void ClickRenameViewIconToRename(Map<String, String> table) {
        for (String expkey : table.keySet()) {
            this.clickOnElement(By.xpath(String.format(rename_Icon, table.get(expkey).toUpperCase())));
        }
    }

    public boolean ValidateMessageOnViewRenamePopup(String key, String message) {
        boolean flag = true;
        switch (key) {
            case "UniqueNameErrorMessage":
                String actualError = this.getText(viewUniqueNameErrorMessage).trim();
                flag = actualError.contains(message);
                break;
            case "Header":
                String actualHeader = this.getText(By.xpath(String.format(viewRenamePopupMessage, "1").trim()));
                log.info(actualHeader);
                flag = actualHeader.contains(message);
                break;
            case "UniqueNameText":
                String actualUniqueNameText = this.getText(By.xpath(String.format(viewRenamePopupMessage, "2").trim()));
                flag = actualUniqueNameText.contains(message);
                break;
            case "UniqueRenameText":
                String actualUniqueRenameText = this.getText(By.xpath(viewRenamePopupLowerMessage)).trim();
                flag = actualUniqueRenameText.contains(message);
                break;
            case "CharLenghtText":
                String actualCharLenghtText = this.getText(By.xpath(String.format(viewRenamePopupMessage, "3").trim()));
                flag = actualCharLenghtText.contains(message);
                break;
            case "ViewName Label":
                String actualViewNameLabel = this.getText(viewNameLabelInPopup);
                flag = actualViewNameLabel.contains(message);
                break;
            case "MaxLenght":
                String actualMaxLen = this.getText(viewNameMaxLenght);
                flag = actualMaxLen.contains(message);
                break;
        }
        // }
        return flag;
    }

    public boolean RenameSuccessMessageValidation(String oldName, String newName) {
        boolean flag = false;
        flag = this.elementIsDisplayed(
                By.xpath(String.format(this.renameViewSuccessMessage, oldName.toUpperCase(), newName)));
        return flag;
    }

    public void ClickOnXButtonOnViewSuccessPopup() {
        this.clickOnElement(this.viewSuccessDailogXButton);
    }

    public boolean IsSaveThisViewEnabled(String visibility) {
        boolean flag = false;
        if (visibility.equalsIgnoreCase("enabled"))
            flag = this.IsElementEnabled(By.xpath(String.format(saveThisViewIconEnablement, "active")));
        else
            flag = this.IsElementEnabled(By.xpath(String.format(saveThisViewIconVisibility, visibility.toLowerCase())));
        return flag;
    }

    public boolean VerifyViewBubble(String view, String state) {
        Boolean flag = false;
        if (state.equalsIgnoreCase("visible")) {
            flag = this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubbleValue, view)), true)
                    && this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubble)), true);
        } else if (state.equalsIgnoreCase("invisible")) {
            flag = !(this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubbleValue, view)), true)
                    || this.elementIsDisplayed(By.xpath(String.format(this.verifyViewBubble)), true));
        }
        return flag;
    }

    public void DeleteView(String option, List<String> table) {
        for (String view : table) {
            if (this.elementIsDisplayed(By.xpath(String.format(this.views, view)))) {
                this.JavaScriptClick(By.xpath(String.format(this.viewDeleteIcon, view)));
                if (option.equalsIgnoreCase("delete")) {
                    this.JavaScriptClick(this.viewDelete_DeleteButton);
                    this.waitUntilNotVisible(this.loadingIndicator);
                } else if (option.equalsIgnoreCase("cancel")) {
                    this.JavaScriptClick(this.viewDelete_CancelButton);
                }
            }
        }
    }

    public void DeleteDefaultView(String option, List<String> table) {
        for (String view : table) {
            if (this.elementIsDisplayed(By.xpath(String.format(this.defaultViews, view)))) {
                this.clickOnElement(By.xpath(String.format(this.viewDeleteIcon, view)));
                if (option.equalsIgnoreCase("delete")) {
                    this.clickOnElement(this.viewDelete_DeleteButton);
                    this.waitUntilNotVisible(this.loadingIndicator);
                } else if (option.equalsIgnoreCase("cancel")) {
                    this.clickOnElement(this.viewDelete_CancelButton);
                }
            }
        }
    }

    public Boolean VerifyDefaultColumns() {
        return this.elementIsDisplayed(this.defaultShipmentColumns, true)
                && this.elementIsDisplayed(this.defaultShipperColumns, true)
                && this.elementIsDisplayed(this.defaultRecipientColumns, true);
    }

    public Boolean VerifyCEDefaultColumns() {
        return this.elementIsDisplayed(this.defaultCEShipmentColumns, true)
                && this.elementIsDisplayed(this.defaultCEShipperColumns, true)
                && this.elementIsDisplayed(this.defaultCERecipientColumns, true);
    }

    public Boolean VerifyViewIsActive(String view) {
        this.clickMyView();
        String lang  = GenericFunction.ReadConfigFile("LANG");
        if(!lang.equalsIgnoreCase("en-us")){
            view=this.genericFuncObj.getLocalizedValue(view).toUpperCase();

        }
        return this.elementIsDisplayed(By.xpath(String.format(this.activeView, view)), true);
    }

    public Boolean VerifyViewHasDefaultTextDisplayed(String view) {
        this.clickMyView();
        return this.elementIsDisplayed(By.xpath(String.format(this.defaultViewText, view)), true);
    }

    public Boolean VerifyViewsListIsSorted() {
        List<String> views = new ArrayList<String>();
        List<WebElement> elements = this.findElements(this.inactiveViewsList);
        for (WebElement element : elements) {
            views.add(element.getText());
        }
        List<String> viewsActual = views;
        Collections.sort(views);
        return views.equals(viewsActual);
    }

    public Boolean VerifyColumnsInShipmentsGrid(String shipment, String shipper, String recipient) {
        return this.elementIsDisplayed(By.xpath(String.format(this.shipmentColumns, shipment)), true)
                && this.elementIsDisplayed(By.xpath(String.format(this.shipperColumns, shipper)), true)
                && this.elementIsDisplayed(By.xpath(String.format(this.recipientColumns, recipient)), true);
    }

    public Boolean ValidateColumnswithExpected(String section) {
        List<String> columns = new ArrayList();
        Boolean flag = true;
        List<WebElement> checkedColumns = this
                .findElements(CheckedColumns);
        for (WebElement ele : checkedColumns) {
            log.info("Section: " + section + " column: " + ele.getAttribute("value"));
            columns.add(ele.getAttribute("value"));
        }
        switch (section) {
            case "ALL SHIPMENTS":
                flag = columns.size() == Constants.AllShipmentsColumns.size();
                if (flag) {
                    for (String str : columns) {
                        flag = Constants.AllShipmentsColumns.contains(str);
                    }
                } else {
                    break;
                }
                break;
            case "Delay Reports":
                flag = columns.size() == Constants.DelayReportsColumns.size();
                if (flag) {
                    for (String str : columns) {
                        flag = Constants.DelayReportsColumns.contains(str);
                    }
                } else {
                    break;
                }
                break;
            case "Working List":
                flag = columns.size() == Constants.WorkingListColumns.size();
                if (flag) {
                    for (String str : columns) {
                        flag = Constants.WorkingListColumns.contains(str);
                    }
                } else {
                    break;
                }
                break;
        }
        return flag;
    }

    public Boolean verifyViewIsInTopOfTheList(String view) {
        return this.elementIsDisplayed(By.xpath(String.format(this.topView, view)), true);
    }

    public Boolean verifyViewEditAndDeleteIcons(String state, String view) {
        Boolean flag = false;
        if (state.equalsIgnoreCase("visible")) {
            flag = this.elementIsDisplayed(By.xpath(String.format(this.viewEditIcon, view)), true)
                    && this.elementIsDisplayed(By.xpath(String.format(this.viewDeleteIcon, view)), true);
        } else if (state.equalsIgnoreCase("invisible")) {
            if (view.equalsIgnoreCase("All Shipments")) {
                flag = (this.elementIsDisplayed(By.xpath(String.format(this.viewEditIcon, view)), true)
                        && this.elementIsNotDisplayed(By.xpath(String.format(this.viewDeleteIcon, view))));
            } else
                flag = (this.elementIsNotDisplayed(By.xpath(String.format(this.viewEditIcon, view)))
                        || this.elementIsDisplayed(By.xpath(String.format(this.viewDeleteIcon, view)), true));
        }
        return flag;
    }

    public boolean ValidateEditColumCheckedState(String key, String attributeName, String checkedState) {
        boolean flag = true;
        String actualCheckedState = this.getAttributeValue(By.xpath(String.format(editColumnCheckbox, key)),
                attributeName);
        flag = checkedState.equals(actualCheckedState);
        return flag;
    }

    public Boolean VerifyColumnDataasHyperlink(String columnName, String columnValue) {
        Boolean flag = false;
        switch (columnName) {
            case "Vessel CONS":
                String hrefXpath = "";
                hrefXpath = String.format(Constants.VesselConsLink,
                        this.commonHelpers.getValuefromContextStore(columnValue).toString());
                flag = this.elementIsDisplayed(By.xpath(hrefXpath));
                break;
        }
        return flag;
    }

    /**
     * This method verifies specified columns data
     *
     * @param
     * @return
     */
    public Boolean verifyColumnData(Map<String, String> columnTable) {
        this.commonHelpers.thinkTimer(4000);
        this.waitUntilNotVisible(this.loadingIndicator);
        Boolean flag = false;
        String columnId = "";
        HashSet<String> values = new HashSet<>();
        for (String columnName : columnTable.keySet()) {
            switch (columnName) {
                case "Delay Status":
                    columnId = "packageDelayStatus";
                    break;
                case "Status":
                    columnId = "status";
                    break;
                case "Shipper Account Number":
                    columnId = "shipperAccountNumber";
                    break;
                case "Bill To Account":
                    columnId = "billToAccount";
                    break;
                case "Bill To (Transportation)":
                    columnId = "billToAccount";
                    break;
                case "Bill To (Duties)":
                    columnId = "billToDutiesAccount";
                    break;
                case "Department Number":
                    columnId = "departmentNumber";
                    break;
                case "Vessel CONS":
                    columnId = "latestVesselCONS";
                    break;
                case "Invoice Number":
                    columnId = "invoiceNumber";
                    break;
                case "Purchase Order Number":
                    columnId = "purchaseOrderNumber";
                    break;
                case "Flight Number":
                    columnId = "latestFlightNumber";
                    break;
                case "Latest FXE Event":
                    columnId = "latestEvent";
                    break;
                case "Last Known FedEx Facility":
                    columnId = "lastKnownFedexFacility";
                    break;
                case "NAK Scan":
                    columnId = "nakScan";
                    break;
                case "Service Type":
                    columnId = "serviceType";
                    break;
                case "Reference":
                    columnId = "reference";
                    break;
                case "Delivery Prediction":
                    columnId = "finalPackageDelayStatus";
                    break;
            }
            List<WebElement> elements = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
            log.info("Number of columns: " + elements.size());
            for (WebElement element : elements) {
                values.add(columnName.equalsIgnoreCase("Latest FXE Event") ? element.getText().split("@")[0]
                        : element.getText());
            }
            columnName = columnName.contains("ContextStore")
                    ? this.commonHelpers.getValuefromContextStore(columnName).toString()
                    : columnName;
            // flag = values.size() == 1 &&
            // values.toString().contains(columnTable.get(columnName).contains("ContextStore")
            // ?
            // this.commonHelpers.GetValuefromContextStore(columnTable.get(columnName)).toString()
            // : columnTable.get(columnName)) ? true : false;

            // flag = values.size() == 1 &&
            // (columnTable.get(columnName).contains("ContextStore")
            // ?
            // this.commonHelpers.GetValuefromContextStore(columnTable.get(columnName)).toString()
            // : columnTable.get(columnName)).contains(values.toString()) ? true : false;

           /* flag = values.size() == 1 && (values.toString()
                    .contains(columnTable.get(columnName).contains("ContextStore")
                            ? (columnName.equalsIgnoreCase("Latest FXE Event")
                            ? this.commonHelpers.getValuefromContextStore(columnTable.get(columnName))
                            .toString().split("@")[0]
                            : this.commonHelpers.getValuefromContextStore(columnTable.get(columnName))
                            .toString())
                            : columnTable.get(columnName)));*/

            if((values.size() == 1 && (
                    values.toString()
                            .contains(columnTable.get(columnName).contains("ContextStore")
                                    ? (columnName.equalsIgnoreCase("Latest FXE Event")
                                    ? this.commonHelpers.getValuefromContextStore(columnTable.get(columnName))
                                    .toString().split("@")[0]
                                    : this.commonHelpers.getValuefromContextStore(columnTable.get(columnName))
                                    .toString())
                                    : columnTable.get(columnName)))) ||
                    (values.toString().contains(columnTable.get(columnName)))

            )
            {flag= true;}

            if (!flag) {
                return false;
            }
        }
        return flag;
    }

    public boolean VerifyColumnsVisibleOnShipmentListGrid(DataTable dataTable) {
        boolean flag = true;
        List<String> columns = dataTable.asList(String.class);
        for (String col : columns) {
            if (this.elementIsDisplayed(By.xpath(String.format(SpecificColumnxpath, col)))) {
                flag = true;
            }
            else if (this.elementIsNotDisplayed(By.xpath(String.format(SpecificColumnxpath, col)))) {
                this.scrollHorizontalBarOnPage("900");
                this.elementIsDisplayed(By.xpath(String.format(SpecificColumnxpath, col)));
                flag = true;
            }
            else{
                flag = false;
                log.error(" This columns is not Visible --> " + col);
                break;
            }
        }
        return flag;
    }

    public boolean VerifyColumnsNotVisibleOnShipmentListGrid(DataTable dataTable) {
        boolean flag = true;
        List<String> columns = dataTable.asList(String.class);
        for (String col : columns) {
            if (this.elementIsNotDisplayed(By.xpath(String.format(SpecificColumnxpath, col)))) {
                flag = true;
            } else {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public String GetColumnValueFromShipmentsPage(String columnName) {
        String trackNumber = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        By ColumnValue = By.xpath(String.format(columnFromShipmentList, trackNumber, columnName));
        return this.getText(ColumnValue);
    }

    public Boolean VerifyElipsisForCommentColumn() {
        Boolean flag = false;
        By commentColumn = By.xpath(String.format(this.commentColumn,
                this.commonHelpers.getValuefromContextStore("Tracking Number").toString()));
        this.clickOnElement(commentColumn);
        String classValue = this.getAttributeValue(commentColumn, "class");
        if (classValue.contains("ag-column-hover"))
            flag = true;
        return flag;
    }

    public String getShipmentTypeCheckedState(String shipmentType) {
        By shipmentTypeSelection = By.xpath(String.format(this.shipmetTypeCheckedState, shipmentType));
        return this.getAttributeValue(shipmentTypeSelection, Constants.EditColumnsCheckboxAttribute);
    }

    public String getShipmentTypeBadgeCount() {
        return this.getText(this.shipmentTypeBadge);
    }

    public Boolean ValidateModulesinBar(String module, DataTable table) {
        Boolean flag = true;
        String Xpath = "";
        List<String> subModules = table.asList(String.class);
        if (module.equalsIgnoreCase("Action bar")) {
            for (String mod : subModules) {
                if (flag) {
                    // if (mod.equalsIgnoreCase("Viewing")) {
                    // flag = this.elementIsDisplayed(By.xpath(String.format(this.LeftActionBar,
                    // mod)));
                    // } else {
                    // flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionBar,
                    // mod)));
                    // }
                    switch (mod) {
                        case "Viewing":
                            this.waitUntilVisible(By.xpath(String.format(this.LeftActionBar, mod)));
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.LeftActionBar, mod)));
                            break;
                        case "FILTERS":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionBar, mod)));
                            break;
                        case "columns":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionBar, mod)));
                            break;
                        case "VIEWS":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionBar, mod)));
                            break;
                        case "Types":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionBar, mod)));
                            break;
                        case "Save View":
                            Xpath = "save-view-icn";
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionIconBar, Xpath)));
                            break;
                        case "Reset":
                            Xpath = "reset-icn";
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionIconBar, Xpath)));
                            break;
                        case "Export List":
                            Xpath = "download-icn";
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.RightActionIconBar, Xpath)));
                            break;
                    }
                    log.info("Test - Verifying: " + mod + "-" + flag);
                }

            }
        }
        return flag;
    }

    public Boolean ValidateWebElement(String module, DataTable table) {
        Boolean flag = true;
        List<String> subModules = table.asList(String.class);
        for (String mod : subModules) {
            if (flag) {
                flag = this.elementIsDisplayed(By.xpath(String.format(this.ChevronXpath, mod)));
            }
        }
        return flag;
    }

    public Boolean ChevronState(String module, String state) {
        Boolean flag = false;
        if (module.equalsIgnoreCase("EDIT COLUMNS")) {
            flag = this.elementIsDisplayed(By.xpath(String.format(this.ChevronState, "COLUMNS", state)));
        }
        return flag;
    }

    public void StoreQuickViewsinContextStore(String contextStoreKey) {
        HashMap<String, Integer> quickViews = new HashMap<String, Integer>();
        if (!contextStoreKey.equalsIgnoreCase("NoQuickViews")) {
            for (int index = 0; index < this.findElements(By.xpath(this.quickViewtitlesXpath)).size(); ++index) {
                quickViews.put(this.findElements(By.xpath(this.quickViewtitlesXpath)).get(index).getText(), index);
            }
        }
        this.commonHelpers.AddToContextStore(contextStoreKey, quickViews);
    }

    /**
     * This method accepts the reset popup in shipments overview page
     *
     * @param
     * @return
     */
    public void AcceptResetPopup() {
        String lang = GenericFunction.ReadConfigFile("LANG");
        String resetText = lang.equalsIgnoreCase("en-us") ? "Reset" : this.genericFuncObj.getLocalizedValue("Reset");
        By resetPopup1 = By.xpath("//button[contains(text(),'" + resetText + "')]");
        commonHelpers.thinkTimer(300);
        this.JavaScriptClick(resetPopup1);
    }

    /**
     * This method verifies whether the quick view card is active or inactive
     *
     * @param cardName
     * @return Boolean
     */
    public boolean ValidateWhetherQuickViewCardISHighlighted(String cardName) {
        Boolean flag = false;
        String filteredRecords = this.commonHelpers.getValuefromContextStore(cardName).toString();
        cardName = cardName.toUpperCase();
        if (Integer.parseInt(filteredRecords) > 0) {
            String cardhighlight = "";
            switch (cardName) {
                case "ON THE WAY":
                    cardhighlight = Constants.inprogressQChighlght;
                    break;
                case "OUT FOR DELIVERY":
                    cardhighlight = Constants.outfordeliveryQChighlght;
                    break;
                case "MONITORED":
                    cardhighlight = Constants.monitoredQChighlght;
                    break;
                case "ALL EXCEPTIONS":
                    cardhighlight = Constants.allexceptionsQChighlght;
                    break;
                case "DELIVERY EXCEPTION":
                    cardhighlight = Constants.deliveryExceptionsQChighlght;
                    break;
                case "AT RISK":
                    cardhighlight = Constants.atRiskQChighlght;
                    break;
                case "INTERVENED":
                    cardhighlight = Constants.intervenedQCHighlight;
                    break;
                case "RETURNING TO SHIPPER":
                    cardhighlight = Constants.returningToShipperQCHighlight;
                    break;
            }
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                if(cardName.equalsIgnoreCase("RETURNING TO SHIPPER")){
                    cardName="Returning to Shipper";
                }else {
                    cardName = WordUtils.capitalizeFully(cardName);
                }
            }
            flag = this.elementIsDisplayed(this.getByusingString(String.format(QCHighlight, cardName, cardhighlight)));
        } else {
            this.carouselNav(cardName, "Yes");
            flag = this.elementIsDisplayed(this.getByusingString(String.format(disabledQCards, cardName)));
        }

        return flag;
    }

    public Boolean ValidateColumnPositionwithAnother(String column1, String position, String column2) {
        Boolean flag = false;
        String colIndex2 = "";
        String colIndex1 = this.findElement(By.xpath(String.format(this.ColumnIdXpath, column1)))
                .getAttribute("aria-colindex");
        if (column2.equalsIgnoreCase("Shipment Type")) {
            colIndex2 = this.findElement(ShipmentTypeIdXpath).getAttribute("aria-colindex");
        } else {
            colIndex2 = this.findElement(By.xpath(String.format(this.ColumnIdXpath, column2)))
                    .getAttribute("aria-colindex");
        }
        if (position.equalsIgnoreCase("left")) {
            flag = Integer.parseInt(colIndex2) > Integer.parseInt(colIndex1);
        } else {
            flag = Integer.parseInt(colIndex2) < Integer.parseInt(colIndex1);
        }
        return flag;
    }

    public Boolean ValidateColumnHoverState(String columnName, String state) {
        Boolean flag = false;
        WebElement ele = this.findElement(By.xpath(this.buildXpathForString(columnName)));
        this.mouseHoverJScript(ele);
        String HoverState = this.findElement(By.xpath(String.format(this.ColumnHeaderState, columnName)), false)
                .getAttribute("class");
        log.info("Hover state: " + HoverState);
        if (state.equalsIgnoreCase("highlighted")) {
            flag = HoverState.contains(Constants.HoverStateAttribute);
        }
        return flag;
    }

    public Boolean ValidateRowHighlightOnSelect(String contextStoreVariable) {
        log.info("Random Tracking Number selected: " + contextStoreVariable);
        this.clickOnElement(By.xpath(String.format(this.TrackingNumStatus, contextStoreVariable)));
        log.info("Row is selected");
        this.commonHelpers.thinkTimer(2000);
        return this.elementIsDisplayed(By.xpath(String.format(this.Rowhighlight, contextStoreVariable)));
    }

    public void DoubleClickRowForDetails(String ContextStoreVariable) {
        this.DoubleClickElement(
                this.findElement(By.xpath(String.format(this.TrackingNumStatus, ContextStoreVariable))));
        log.info("User entered into details by double click operation on row");
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void UIDragAndDrop(String FromElement, String ToElement) {
        WebElement FromEle = this.findElement(By.xpath(String.format(this.columnheaderXpath, FromElement)), false);
        WebElement ToEle = this.findElement(By.xpath(String.format(this.columnheaderXpath, ToElement)), false);
        log.info("Index Before drag and drop: " + this
                .findElement(By.xpath(String.format(this.ColumnIdXpath, FromElement))).getAttribute("aria-colindex"));
        this.commonHelpers.AddToContextStore(String.format("%s BeforeIndex", FromElement),
                this.findElement(By.xpath(String.format(this.ColumnIdXpath, FromElement)))
                        .getAttribute("aria-colindex"));
        this.DragAndDrop(FromEle, ToEle);
        log.info("Index After drag and drop: " + this
                .findElement(By.xpath(String.format(this.ColumnIdXpath, FromElement))).getAttribute("aria-colindex"));
        this.commonHelpers.AddToContextStore(String.format("%s AfterIndex", FromElement),
                this.findElement(By.xpath(String.format(this.ColumnIdXpath, FromElement)))
                        .getAttribute("aria-colindex"));
    }

    public void StoreColumnPositionIndex(String element) {
        log.info("Index After drag and drop: "
                + this.findElement(By.xpath(String.format(this.ColumnIdXpath, element))).getAttribute("aria-colindex"));
        this.commonHelpers.AddToContextStore(String.format("%s AfterIndex", element),
                this.findElement(By.xpath(String.format(this.ColumnIdXpath, element))).getAttribute("aria-colindex"));
    }

    public Boolean ValidateColumnPosition(String ColumnName, String ContextStoreVariable) {
        String PresentColIndex = this.findElement(By.xpath(String.format(this.ColumnIdXpath, ColumnName)))
                .getAttribute("aria-colindex");
        log.info("Present Column Index: " + PresentColIndex);
        String PreviousColIndex = this.commonHelpers.getValuefromContextStore(ContextStoreVariable).toString();
        log.info("Previous Column Index: " + PreviousColIndex);
        return Integer.parseInt(PresentColIndex) == Integer.parseInt(PreviousColIndex);
    }

    public boolean verifyIfShipmentStatusFilterIsPresentOrNot(String filter) {
        String element = this.findElement(filterChevron).getAttribute("class");
        if (!element.contains("active"))
            this.clickOnElement(filterChevron);// Click on Filter
        this.clickOnElement(By.xpath(String.format(filterCategory, "Shipment Status")));
        return this.elementIsDisplayed(By.xpath(String.format(filterCategory, filter)));
    }

    public boolean verifyIfShipmentTypesIsPresentOrNot(String type) {
        Boolean flag = true;
        this.JavaScriptClick(this.findElement(filterType));
        if (flag) {
            // this.findElement(this.getByusingString(String.format(this.typeCategory,type)));
            // flag = this.elementIsDisplayed(By.xpath(String.format(this.typeCategory,
            // type)));
            flag = !this.elementIsNotDisplayed(By.xpath(String.format(this.TypesOptionsCBXpath, type)));
            // this.elementIsDisplayed(By.xpath(String.format(this.typeCategory,type)));
        }
        return flag;
    }

    public boolean ValidateMessageOnResetPopup(String key, String message) {
        boolean flag = true;
        switch (key) {
            case "Header":
                String actualHeader = this.getText(resetPopupHeader).trim();
                flag = actualHeader.contains(message);
                break;
            case "HeaderTextOne":
                String actualHeaderTextOne = this.getText(resetpopupSubtitleOne).trim();
                flag = actualHeaderTextOne.contains(message);
                break;
            case "HeaderTextTwo":
                String actualHeaderTextTwo = this.getText(resetpopupSubtitleTwo).trim();
                flag = actualHeaderTextTwo.contains(message);
                break;
            case "HeaderTextThree":
                String actualHeaderTextThree = this.getText(resetpopupSubtitleThree).trim();
                flag = actualHeaderTextThree.contains(message);
                break;
            case "ResetButtonColor":
                String actualResetButtonColor = Color
                        .fromString(this.findElement(resetPopup).getCssValue("background-color")).asHex();
                flag = actualResetButtonColor.contains(message);
                break;
            case "CancelButtonTextColor":
                String actualCancelButtonTextColor = Color
                        .fromString(this.findElement(resetpopupCancelButton).getCssValue("color")).asHex();
                flag = actualCancelButtonTextColor.contains(message);
                break;
        }
        return flag;
    }

    public boolean ValidateOrderOfShipmentListHeader(DataTable dataTable) {
        boolean flag = true;
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        for (String expkey : messageTable.keySet()) {
            flag = this.getAttributeValue(By.xpath(String.format(this.shipmentListColumnHeader, expkey)),
                    Constants.ShipmentHeaderColIndex).equals(messageTable.get(expkey));
        }
        return flag;
    }

    public boolean ValidateShipmentCountIsCommaSeperated(String count) {
        boolean flag = false;
        switch (count) {
            case "View Count":
                String[] viewCounter = this.getText(getViewCount).split("/");
                String tempViewStr = viewCounter[0].replace(",", "");
                if ((tempViewStr.length() > 3 && viewCounter[0].contains(","))
                        || (tempViewStr.length() <= 3) && !viewCounter[0].contains(",")) {
                    flag = true;
                }
                break;
            case "Total Count":
                String totalCount = this.getText(TotalRecordsXpath);
                String tempTotalStr = totalCount.replace(",", "");
                if ((tempTotalStr.length() > 3 && totalCount.contains(","))
                        || tempTotalStr.length() <= 3 && !totalCount.contains(",")) {
                    flag = true;
                }
                break;
        }
        return flag;
    }

    public Boolean verifyShipmentsIcon(String icon, String check) {
        Boolean flag = false;
        String xpath = "";
        int iconCount = 0;
        int totalRowsCount = 0;
        switch (icon) {
            case "Payer":
                xpath = "payer-icn";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                break;
            case "SenseAware":
                xpath = "senseawareid-icn";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                break;
            case "Monitored":
                xpath = "monitored-icn";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                break;
            case "Digital":
                xpath = "digital-icn";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                break;
            case "Intervened":
                xpath = "intervened-icn";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyShipmentsIcon, xpath))).size();
                break;

        }
        if (check.equalsIgnoreCase("Visible")) {
            flag = totalRowsCount == iconCount;
        } else if (check.equalsIgnoreCase("Invisible")) {
            flag = iconCount == 0;
        }

        return flag;
    }

    public void RemoveSpecificOneFilterinBubble(DataTable filterstable) {
        List<String> filters = filterstable.asList(String.class);
        for (String filter : filters) {
            if (!Constants.QuickViewCardNames.contains(filter)) {
                filter = WordUtils.capitalizeFully(filter);
            }
            this.JavaScriptClick(
                    this.findElement(
                            this.getByusingString(String.format(this.cancelSpecificFilterItemFromBubble, filter))));
            log.info(String
                    .valueOf(this.getByusingString(String.format(this.cancelSpecificFilterItemFromBubble, filter))));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public Boolean SelectFilterAndVerifyConditionOnUI(String filterCondition, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        boolean flag = false;
        // this.JavaScriptClick(this.findElement(filterChevron));
        String ParentFilter = filterCondition.split("-")[0];
        String ChildFilter = filterCondition.split("-")[1];
        String filterCriteria = filterCondition.split("-")[2];
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
        this.JavaScriptClick(this.findElement(this.getByusingString(
                String.format(this.filterxpath, ParentFilter, ChildFilter,
                        filterCriteria))));
        for (String key : dataFilters.keySet()) {
            if (key.equalsIgnoreCase("searchField")) {
                flag = this.elementIsDisplayed(filterSearchInput);
                if (dataFilters.get(key).equalsIgnoreCase("visible")) {
                    Assert.assertTrue("Search field is not visible for " + ParentFilter + " > " + ChildFilter +
                            " > " + filterCriteria, flag);
                } else if (dataFilters.get(key).equalsIgnoreCase("invisible")) {
                    Assert.assertFalse("Search field is visible for " + ParentFilter + " > " + ChildFilter +
                            " > " + filterCriteria, flag);
                }
            } else {
                flag = IsElementEnabled(By.xpath(String.format(this.filterxpath, ParentFilter, ChildFilter, key)));
                if (dataFilters.get(key).equalsIgnoreCase("disabled")) {
                    Assert.assertFalse("Filter: " + ParentFilter + " > " + ChildFilter +
                            " > " + filterCriteria + " is enabled", flag);
                    flag = true;
                } else if (dataFilters.get(key).equalsIgnoreCase("enabled")) {
                    Assert.assertTrue("Filter: " + ParentFilter + " > " + ChildFilter +
                            " > " + filterCriteria + " is disabled", flag);
                }
            }

        }
        // this.JavaScriptClick(this.findElement(this.filterCancelButton));
        return flag;
    }

    public void ClickOnButtonApplyOrCancel(String button) {
        if (button.contains(this.apply)) {
            this.JavaScriptClick(this.getByusingString(String.format(this.applyButton, this.applyUpperCase)));
        } else if (button.contains("Cancel"))
            this.JavaScriptClick(filterCancelButton);
    }

    public void ClickOnFilterButton() {
        this.JavaScriptClick(this.findElement(filterChevron));
    }

    public Boolean ValidateSelectedRowHighlighted(String contextStoreVariable) {
        log.info("Random Tracking Number selected: " + contextStoreVariable);
        return this.elementIsDisplayed(By.xpath(String.format(this.TrackingIDRowhighlight, contextStoreVariable)));
    }

    public void ValidateAccountDetails(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.CompanyAccddXpath);

        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).isEmpty()) {
                this.elementIsDisplayed(
                        By.xpath(String.format(this.CompanyAccountSelected, key, dataFilters.get(key))));
            } else
                this.elementIsDisplayed(By.xpath(String.format(this.companyNameinDD, key)));
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public boolean validateSenseawareIdHyperLink(String trackingNumber) {
        String hrefLink = this.getAttributeValue(By.xpath(String.format(this.CompanySenseawareIdLink, trackingNumber)),
                "href");
        return hrefLink.equalsIgnoreCase(String.format(Constants.SenseawareLinkUrl, trackingNumber));

    }

    public boolean validateHyperLink(String column) {
        if (this.getViewCount() == 0) {
            log.info("**WARNING** There is no data on my shipments page, hence skipping the rest of the validation ");
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            return true;
        }
        String columnId = "";
        switch (column) {
            case "SenseAware Mobile":
                columnId = "senseAwareJourneyId";
                break;
        }

        if (this.elementIsDisplayed(this.getByusingString(String.format(this.cancelFilterBubble, column)))) {
            log.info("Since filter is applied we should see the link on journeyid");
            List<WebElement> elements = this.findElements(By.xpath(String.format(this.hreflink, columnId)));
            elements.forEach(s -> s.getAttribute("href")
                    .equals(String.format(Constants.SenseawareJourneyIdLinkUrl, s.getText())));
            // Storing the first journeyid
            this.commonHelpers.AddToContextStore("senseAwareJourneyId",
                    this.findElement(By.xpath(String.format(this.hreflink, columnId))).getText());
        } else {
            log.info("As senseaware mobile journey id filter is not applied, so no hyperlink or journey id");
            List<WebElement> elements = this.findElements(By.xpath(String.format(this.colValues, columnId)));
            elements.forEach(s -> s.getText().isEmpty());
        }
        return true;
    }

    public boolean validateSenseawareIdHyperLinkUnderTooling(String subHeading, String trackingNumber) {
        String hrefLink = this.getAttributeValue(By.xpath(String.format(this.ExternalLinksUnderTooling, subHeading)),
                "href");
        String target = this.getAttributeValue(By.xpath(String.format(this.ExternalLinksUnderTooling, subHeading)),
                "target");
        return hrefLink.equalsIgnoreCase(String.format(Constants.SenseawareLinkUrl, trackingNumber))
                // to validate it would be opened on a new page
                && target.equals("_blank");
    }

    public boolean validateStaticHyperLinkUnderTooling(String subHeading, String linktype) {
        String hrefLink = this.getAttributeValue(By.xpath(String.format(this.ExternalLinksUnderTooling, subHeading)),
                "href");
        String target = this.getAttributeValue(By.xpath(String.format(this.ExternalLinksUnderTooling, subHeading)),
                "target");
        String expectedLink = null;
        if (subHeading.equals("SenseAware.com")) {
            if (linktype.equals("SenseawareJourneyIdLinkUrl")
                    && !this.commonHelpers.getValuefromContextStore("UserContext").toString().equals("CE"))
                expectedLink = String.format(Constants.SenseawareJourneyIdLinkUrl,
                        this.commonHelpers.getValuefromContextStore("senseAwareJourneyId").toString());
            else if (linktype.equals("SenseawareJourneyIdLinkUrl")
                    && this.commonHelpers.getValuefromContextStore("UserContext").toString().equals("CE"))
                expectedLink = Constants.SenseawareJourneyIdLinkUrlWithoutJourneyId;
            else if (linktype.equals("SenseawareURL")) {
                expectedLink = Constants.SenseawareURL;
            }
        }
        return hrefLink.contains(expectedLink)
                // to validate it would be opened on a new page
                && target.equals("_blank");
    }

    public boolean validateDamagePackageValue(String trackingNumber, String actualDamagedPackageValue) {
        String damagedPackageActualValue = this.getText(
                By.xpath(String.format(this.DamagedPackageColumnValue, trackingNumber)));
        return actualDamagedPackageValue.equalsIgnoreCase(damagedPackageActualValue);
    }

    public String GetShipmentComment(String comment) {
        String ShipmentComment = "";
        switch (comment) {
            case "DELAY IN TRANSIT":
                ShipmentComment = Constants.ShipmentCommentDelayInTransit;
                break;
            case "EXPECT DELIVERY TODAY":
                ShipmentComment = Constants.ShipmentCommentExpectDeliveryToday;
                break;
            case "EXPECT DELIVERY NEXT":
                ShipmentComment = Constants.ShipmentCommentExpectDeliveryNext;
                break;
            case "INTERVENTION EXPECT DELIVERY TODAY":
                ShipmentComment = Constants.ShipmentCommentInterventionExpectDeliveryToday;
                break;
            case "INTERVENTION EXPECT NEXT BUSINESS":
                ShipmentComment = Constants.ShipmentCommentInterventionExpectNextBusiness;
                break;
            case "MONITORING FOR UPDATES":
                ShipmentComment = Constants.ShipmentCommentMonitoringForUpdates;
                break;
            case "NATIONAL SERVICE DISRUPTION":
                ShipmentComment = Constants.ShipmentCommentNationalServiceDisruption;
                break;
            case "REQUEST REATTEMPT":
                ShipmentComment = Constants.ShipmentCommentRequestReattempt;
                break;
            case "SERVICE UPGRADE REQUESTED":
                ShipmentComment = Constants.ShipmentCommentServiceUpgradeRequested;
                break;
        }
        return ShipmentComment;
    }

    public Boolean validateFilterSubmenu(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        String ParentFilter = "";
        String ChildFilter = "";
        Boolean flag = false;
        List<String> submenuTexts = new ArrayList();
        String abbreviationString = "";
        String submenuText = "";
        List<Boolean> flags = new ArrayList<Boolean>();
        for (String key : dataFilters.keySet()) {
            ParentFilter = key.split("-")[0];
            ChildFilter = key.split("-")[1];
            submenuTexts = Arrays.asList(dataFilters.get(key).split(":"));
            this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(key.split("-")[0]))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
            if (ChildFilter.contains("Last Comment")) {
                submenuText = submenuTexts.get(0);
                if (submenuText.equals("Specific Last Comment")) {
                    this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(submenuText)));
                    String text = "";
                    if (submenuTexts.get(1).contains("ContextStore-")) {
                        text = (String) this.commonHelpers.getValuefromContextStore(submenuTexts.get(1));
                    }
                    this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)), text);
                    this.waitUntilNotVisible(this.loadingIndicator);
                    flags.add(this.elementIsDisplayed(By.xpath(String.format(this.submenuText, text))));
                } else {
                    for (String text : submenuTexts) {
                        submenuText = this.GetShipmentComment(text);
                        flags.add(this.elementIsDisplayed(By.xpath(String.format(this.submenuText, submenuText))));
                    }
                }

            }

            if (ChildFilter.contains("Recipient Postal")) {
                for (String text : submenuTexts) {
                    if (text.contains("ContextStore-")) {
                        text = (String) this.commonHelpers.getValuefromContextStore(text.split("-")[1]);
                    }
                    this.enterText(By.xpath(String.format(this.filterSearchBar, ParentFilter, ChildFilter)), text);
                    this.waitUntilNotVisible(this.loadingIndicator);
                    String postal = this.getText(By.xpath(this.getXPathforCheckboxWithText(text)));
                    flags.add(postal.contains(",") && postal.split(", ")[1]
                            .equals(this.commonHelpers.getValuefromContextStore("recipCountryOrTerritory")));
                }
            }

        }
        return !flags.contains(false);
    }

    public void validateAccountDropdownCheckbox(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        List<String> companies = new ArrayList<String>();
        List<String> checkboxStatus = new ArrayList<String>();
        this.JavaScriptClick(this.CompanyAccddXpath);
        for (String key : dataFilters.keySet()) {
            companies = Arrays.asList(key.split(":"));
            checkboxStatus = Arrays.asList(dataFilters.get(key).split(":"));
            String companyExp = companies.get(0);
            if (companies.get(0).contains("ContextStore-")) {
                companyExp = (String) this.commonHelpers.getValuefromContextStore(companyExp.split("-")[1]);
            }
            this.JavaScriptClick(By.xpath(String.format(this.companyAccountInDD, companyExp)));
            for (String company : companies) {
                String companyToCheck = company;
                if (company.contains("ContextStore-")) {
                    companyToCheck = (String) this.commonHelpers.getValuefromContextStore(company.split("-")[1]);
                }
                if (checkboxStatus.get(companies.indexOf(company)).equalsIgnoreCase("checked")) {
                    Assert.assertTrue("Company:" + key + " is unchecked",
                            this.getAttributeValue(By.xpath(String.format(this.companyNameinDD, companyToCheck)),
                                    "aria-checked").equalsIgnoreCase("true"));
                } else if (checkboxStatus.get(companies.indexOf(company)).equalsIgnoreCase("unchecked")) {
                    Assert.assertTrue("Company:" + key + " is checked",
                            this.getAttributeValue(By.xpath(String.format(this.companyNameinDD, companyToCheck)),
                                    "aria-checked").equalsIgnoreCase("false"));
                }
            }

        }
        this.JavaScriptClick(this.CompanyAccddXpath);

    }

    public boolean validateShipmentColumnValue(String columnName, String trackingNumber, String expectedValue) {
        String columnValue = this.commonHelpers.verifyKeyInContextStore(expectedValue)
                ? this.commonHelpers.getValuefromContextStore(expectedValue).toString()
                : expectedValue;

        String trckNumber = this.commonHelpers.verifyKeyInContextStore(trackingNumber)
                ? this.commonHelpers.getValuefromContextStore(trackingNumber).toString()
                : trackingNumber;

        String columnId = "";

        Boolean flag = this.elementIsDisplayed(By.xpath(String.format(this.columnHeader, columnName)));
        switch (columnName) {
            case "Damaged Package":
                columnId = "damagedPackage";
                break;
            case "Latest Primary Event FX":
                columnId = "latestPrimaryEvent";
                break;
        }
        String ActualColumnValue = this.getText(
                By.xpath(String.format(this.ShipmentColumnValue, trckNumber, columnId)));
        return columnValue.equalsIgnoreCase(ActualColumnValue) && flag;
    }

    public boolean validateColumnPresent(String columnName) {
        return (this.elementIsDisplayed(By.xpath(String.format(this.columnHeader, columnName))));
    }

    public void clickOnFirstList() {
        this.clickOnElement(firstStatusCol);
    }

    public Boolean validateValueInShipmentType(String DropDownType, DataTable table) {
        List<String> options = table.asList(String.class);
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType)));
        for (String option : options) {
            if (option.equalsIgnoreCase("Watched")) {
                return this.elementIsDisplayed(
                        By.xpath(String.format(this.WatchedTypesOptionsCBXpath, DropDownType, option)));
            } else {
                return this.elementIsDisplayed(By.xpath(String.format(this.TypesOptionsCBXpath, DropDownType, option)));
            }
        }
        return false;
    }

    public Boolean validateShipmentTypeIconNotPresent(String icon) {
        if (icon.equalsIgnoreCase("monitored"))
            return this.elementIsDisplayed(this.monitoredIcon);

        return false;
    }

    public void clickUpdateViewOnViewPopup() {
        this.clickOnElement(By.xpath(this.updateView));
    }

    public void clickSetAsDefaultOnViewPopup() {
        this.clickOnElement(By.xpath(this.setAsDefaultView));
    }

    public boolean validateViewSaveButtonStatus(String state) {
        if (state.equalsIgnoreCase("disabled"))
            return this.elementIsDisplayed(By.xpath(this.viewSaveDisabled));
        else if (state.equalsIgnoreCase("enabled"))
            return this.elementIsDisplayed(By.xpath(this.viewSaveEnabled));
        return false;
    }

    public boolean validateViewCancelButtonEnabled() {
        return this.elementIsDisplayed(this.renameOrSaveViewPopupCancel);
    }

    public void validateEditIconRemovedFromViewBubbleFilter(DataTable dataTable) {
        Map<String, String> views = dataTable.asMap(String.class, String.class);
        for (String view : views.keySet()) {
            if (views.get(view).equalsIgnoreCase("visible")) {
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(String.format(this.renameViewIconShipmentPage, view))));
            } else if (views.get(view).equalsIgnoreCase("invisible")) {
                Assert.assertFalse(
                        this.elementIsDisplayed(By.xpath(String.format(this.renameViewIconShipmentPage, view))));
            }
        }
    }

    public void clickViewFilterBubbleEditIcon(String viewName) {
        this.ScrollByOffset("0","500");
//        boolean successFlag = this.clickOnElementEvent(By.xpath(String.format(this.renameViewIconShipmentPage, viewName)));
        this.commonHelpers.thinkTimer(2000);
        this.waitUntilVisible(By.xpath(String.format(this.renameViewIconShipmentPage, viewName)));
        boolean successFlag = this.javaScriptClickOnElementEvent(By.xpath(String.format(this.renameViewIconShipmentPage, viewName)));
        if(!successFlag){
            this.clickOnElementEvent(By.xpath(String.format(this.renameViewIconShipmentPage1, viewName)));
        }


    }

    public void clickOnEditView(String viewType, String viewName) {
        if (viewType.equalsIgnoreCase("standard views"))
            this.clickStandardView();
        else if (viewType.equalsIgnoreCase("shared views"))
            this.clickSharedView();
        else if (viewType.equalsIgnoreCase("my views"))
            this.clickMyView();
        this.ClickOnRenameIconOfView(viewName);
    }

    public void clickOnShareIconView(String viewName) {
        this.ClickOnShareIconOfView(viewName);
    }

    public boolean verifyStandardViewPopUpMessage(String viewName) {
        return this.elementIsDisplayed(By.xpath(String.format(this.StandardViewPopUpMessage, viewName)));
    }

    public void clickonFirstTrackingNumber() {
        this.waitUntilNotVisible(this.loadingIndicator, 30);
        rows = this.findElements(By.xpath(rowXPath));
        String trackingNum = "";
        for (WebElement row : rows) {
            trackingNum = row.getText();
            if (!trackingNum.equals("TRACKING NUMBER")) {
                row.findElement(By.tagName("a")).click();
                this.waitUntilNotVisible(this.loadingIndicator, 30);
                // row.click();
                this.commonHelpers.AddToContextStore("Tracking Number", trackingNum);
                break;
            }
        }
        this.waitUntilNotVisible(this.loadingIndicator, 30);

    }

    public String getDateFromLeftPanel() {
        return this.getText(updateAtTimeFormat);
    }

    public void SelectFromandToDatesInCalendarWithOkButton(String[] filter) {
        boolean toDate = true;
        this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(filter[1]));
        String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
        try {
            this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate(filter[2]));
        } catch (Exception e) {
            log.info("To Date is not available");
            toDate = false;
        }

        this.JavaScriptClick(this.specificDateRangeFrom);
        while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
            this.JavaScriptClick(calenderLeftArrow);
        }
        this.JavaScriptClick(By.xpath(String.format(dateXpath, fromArr[0])));
        this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        if (toDate) {
            String[] toArr = this.commonHelpers.getValuefromContextStore("ToDate").toString().split(" ");
            this.JavaScriptClick(this.specificDateRangeTo);
            while (!this.getText(monthField).split(" ")[0].equals(toArr[1])) {
                this.JavaScriptClick(calenderRightArrow);
            }
            this.JavaScriptClick(By.xpath(String.format(dateXpath, toArr[0])));
            this.setTimeHoursMins(0, 0, 0);
            this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        }

    }



    public boolean ValidateCalnderDetailsforFilter(String filterButton) {
        boolean check = false;
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        if (filterButton.equalsIgnoreCase("Standard Transit") || filterButton.equalsIgnoreCase("Delivered Date")
                || filterButton.equalsIgnoreCase("Last Scan Time")) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(this.buildXpathForString("Shipment Information"))));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, "Shipment Information", filterButton))));
            this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Date Range")));
            this.clickOnElement(this.specificDateRangeFrom);
            check = CalendarVerification();
            this.JavaScriptClick(By.xpath(this.CalenderOKButton));
            this.clickOnElement(this.specificDateRangeTo);
            check = CalendarVerification();
            this.JavaScriptClick(By.xpath(this.CalenderOKButton));
            this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Date Range")));
            this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, "Specific Date / Time")));
            this.clickOnLastElement(this.specificDateRangeFromLast);
            check = CalendarVerification();
            this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        }
        return check;
    }

    private boolean CalendarVerification() {

        boolean check;

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat simpleformat = new SimpleDateFormat("d MMMM yyyy EEEE");
        String[] toArr = simpleformat.format(cal.getTime()).split(" ");
        String calendarDate = this.getText(currentDate);
        this.commonHelpers.thinkTimer(1000);
        if (calendarDate.equals(toArr[0])) {
            log.info("Date Range is picking today date by default");
            check = true;
        } else {
            log.info("Date Range is not picking today date by default");
            check = false;
        }
        if (this.IsElementEnabled(By.xpath(this.CalenderTimeOption))
                && this.elementIsDisplayed(By.xpath(this.CalenderTimeOption))) {
            log.info("Time option is available for filter");
            check = true;
        } else {
            log.info("Time option is not available for filter");
            check = false;
        }
        if (this.commonHelpers.verifyKeyinContextStore("preferredTimeFormat")) {
            String timeFormat = (String) this.commonHelpers.getValuefromContextStore("preferredTimeFormat");
            List<WebElement> hoursOptions = this.findElements(By.xpath("//*[contains(@class,'hourselect')]/option"));
//            hoursOptions.get(hoursOptions.size() - 1).click()
//             this.clickOnElement(this.timeHourDrodown);
            if (timeFormat.equalsIgnoreCase("12-Hour")) {
                // this.clickOnElement(this.timeAmPmDrodown);
                //String ampmId = this.getAttributeValue(this.timeAmPmDrodown, "id");
                List<WebElement> amPmOptions = this
                        .findElements(By.xpath("//select[contains(@class,'ampmselect')]/option"));
                int hours = hoursOptions.size();
                if (!(hours == 12 && amPmOptions.get(1).getText().equalsIgnoreCase("PM")
                        && amPmOptions.get(0).getText().equalsIgnoreCase("AM"))) {
                    check = false;
                }

            }

            // if (timeFormat.equalsIgnoreCase("24-Hour")) {
            // if (!(hours == 24 && amPmOptions.size() == 0)) {
            // check = false;
            // }
            // }
        }
        return check;
    }


    public boolean validateSearchForFilter(DataTable filterList, boolean specialCharacters) {
        boolean returnFlag = false;
        List<String> filterTextList = filterList.asList(String.class);
        String expInfotext = "The following combinations are not allowed: []{};'^~:`\"\\|,.<>?";
        String filterResult = "", expFilterResult = "";
        for (String filterText : filterTextList) {
            this.enterText(this.searchForfilterInput, filterText);
            // Validate Information text is displayed on top of txtbox
            String infotext = this.getText(this.searchForfilterInfoText);
            // Validate Result is displayed matching search text
            if (specialCharacters) {
                this.commonHelpers.thinkTimer(1000);
                filterResult = this.getText(this.searchBoxmessage);
                if (filterText.equals("<>") || filterText.equals("%$%^&^"))
                    expFilterResult = "Consecutive special characters are not allowed";
                else
                    expFilterResult = String.format(
                            "The following combination is not allowed: %s please remove this from your search",
                            filterText);
            } else {
                filterResult = this
                        .getText(this.getByusingString(String.format(this.searchForFilterResultText, filterText)));
                expFilterResult = filterText;
            }
            log.info("Search for filter is verifing for:" + filterText);
            assertThat(infotext).isEqualTo(expInfotext);
            assertThat(filterResult).isEqualTo(expFilterResult);
            returnFlag = true;
            // if (infotext.equals(expInfotext) && filterResult.equals(expFilterResult)) {
            // returnFlag = true;
            // log.info("Search for filter is verified for:" + filterText);
            // } else {
            // log.info("Search for filter is Failing for:" + filterText);
            // return false;
            // }
        }
        return returnFlag;
    }

    public boolean validateSearchForColumn(DataTable columnList, boolean specialCharacters)
            throws InterruptedException {
        boolean returnFlag = false;
        List<String> columnTextList = columnList.asList(String.class);
        String expInfotext = "The following combinations are not allowed: []{};'^~:`\"\\|,.<>?";
        String columnResult = "", expColumnResult = "";
        for (String columnText : columnTextList) {
            this.enterText(this.searchForColumnInput, columnText);
            // Validate Information text is displayed on top of txtbox
            String infotext = this.getText(this.searchForColumnInfoText);
            // Validate Result is displayed matching search text
            if (specialCharacters) {
                // to give time to search for special characters message to change
                Thread.sleep(2000);
                columnResult = this.getText(this.searchBoxmessage);
                if (columnText.equals("<>") || columnText.equals("%$%^&^"))
                    expColumnResult = "Consecutive special characters are not allowed";
                else
                    expColumnResult = String.format(
                            "The following combination is not allowed: %s please remove this from your search",
                            columnText);
            } else {
                columnResult = this
                        .getText(this.getByusingString(String.format(this.searchForFilterResultText, columnText)));
                expColumnResult = columnText;
            }
            assertThat(infotext).isEqualTo(expInfotext);
            assertThat(columnResult).isEqualTo(expColumnResult);
            // if (infotext.equals(expInfotext) && columnResult.equals(expColumnResult)) {
            returnFlag = true;
            // log.info("Search for filter is verified for:" + columnText);
            // log.info("Search for filter is verified for:" + columnText);
            // } else {
            // log.info("Search for filter is Failing for:" + columnText);
            // return false;
            // }
        }
        return returnFlag;
    }

    public boolean validateLegacyFilterSearchTextAndIcon(String expectedPlaceholderText) {
        boolean flag = false;
        if (expectedPlaceholderText.equals("Search for Columns")) {
            String actualPlaceholderText = this.getAttributeValue(searchForColumnInput,
                    "placeholder");
            if ((this.elementIsDisplayed(this.columnSearchIcon))
                    && (this.elementIsDisplayed(this.searchForColumnInput))
                    && actualPlaceholderText.equals(expectedPlaceholderText)) {
                log.info("Placeholder text and search icon is displayed");
                flag = true;
            }
        } else{
            String actualPlaceholderText = this.getAttributeValue(searchForfilterInput,
                    "placeholder");
            if ((this.elementIsDisplayed(this.legacyFilterSearchIcon))
                    && (this.elementIsDisplayed(this.searchForfilterInput))
                    && actualPlaceholderText.equals(expectedPlaceholderText)) {
                log.info("Placeholder text and search icon is displayed");
                flag = true;
            }
        }
        return flag;
    }

    public boolean validateLegacyFilterSearchAndResult(String filterType, DataTable table) throws InterruptedException {
        boolean returnFlag = false, parentFlag = false, childFlag = false;
        List<String> filterList = table.asList(String.class);
        String expectedMessage = "No results found.";
        String actualfilterResult = "", expectedFilterResult = "";

        for (String filter : filterList) {
            if (filterType.equals("Parent Filter")) {
                this.enterText(this.searchForfilterInput, filter);
                Thread.sleep(2000);
                actualfilterResult = this.getText(this.searchBoxmessage);
                if (actualfilterResult.equals(expectedMessage)) {
                    returnFlag = true;
                }
            } else {
                String parentFilter = filter.split("-")[0];
                String childFilter = filter.split("-")[1];
                this.enterText(this.searchForfilterInput, childFilter);
                expectedFilterResult = childFilter;
                actualfilterResult = this
                        .getText(this.getByusingString(String.format(this.searchForFilterResultText, childFilter)));
                JavaScriptClick(this
                        .findElement(
                                this.getByusingString(String.format(this.searchForFilterResultText, childFilter))));
                parentFlag = (this.findElement(this.getByusingString(String.format(this.filterAncestor, parentFilter)))
                        .getAttribute("class")).contains("active");
                childFlag = (this.findElement(this.getByusingString(String.format(this.filterAncestor, childFilter)))
                        .getAttribute("class")).contains("active");

                if (actualfilterResult.equals(expectedFilterResult) && parentFlag && childFlag) {
                    returnFlag = true;
                    log.info("Search and result for filter is verified for:" + childFilter);
                } else {
                    log.info("Search or result validation for filter is failing for:" + childFilter);
                    returnFlag = false;
                }
            }

        }

        return returnFlag;
    }

    public boolean validateColumnSearchAndResult(String columnNameType, DataTable table) throws InterruptedException {
        boolean returnFlag = false, columnFlag = false;
        List<String> columnNameList = table.asList(String.class);
        String expectedMessage = "No results found.";
        String actualSearchResult = "", expectedSearchResult = "";
        for (String columnName : columnNameList) {
            if (GenericFunction.locale != Constants.EN_US)
                columnName = this.genericFunctionObject.getLocalizedValue(columnName);

            if (columnNameType.equals("Invalid Column Name")) {
                this.enterText(this.searchForColumnInput, columnName);
                Thread.sleep(2000);
                actualSearchResult = this.getText(this.searchBoxmessage);
                if (actualSearchResult.equals(expectedMessage)) {
                    returnFlag = true;
                }
            } else {
                this.enterText(this.searchForColumnInput, columnName);
                expectedSearchResult = columnName;
                actualSearchResult = this
                        .getText(this.getByusingString(String.format(this.searchForFilterResultText, columnName)));
                JavaScriptClick(this
                        .findElement(
                                this.getByusingString(String.format(this.searchForFilterResultText, columnName))));
                String columnColour = (this
                        .findElement(this.getByusingString(String.format(this.columnAncestor, columnName)))
                        .getCssValue("color"));
                String columnBackgroundColour = (this
                        .findElement(this.getByusingString(String.format(this.columnAncestor, columnName)))
                        .getCssValue("background-color"));
                if (!columnColour.equals(columnBackgroundColour)) {
                    columnFlag = true;
                }
                if (actualSearchResult.equals(expectedSearchResult) && columnFlag) {
                    returnFlag = true;
                    log.info("Search and result for filter is verified for:" + columnName);
                } else {
                    log.info("Search or result validation for filter is failing for:" + columnName);
                    returnFlag = false;
                }
            }

        }

        return returnFlag;
    }

    public boolean validateIconsFromUiAndFile() throws IOException {
        List<WebElement> isWatched = this.findElements(watchList);
        List<WebElement> typeColumnValuesList1 = this.findElements(this.typesColumnValues);
        List<WebElement> typeColumnValuesList = this.findElements(By.xpath(String
                .format(this.columnValuesXpath + "//app-shipment-specifications//span[@class!='m-l-1']", "isPayer")));
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        Map<String, String> fileData = this.genericFuncObj.getColumnDataFromFile("Types");
        boolean returnflag = true;
        int typeColumnIterator = 0;
        if (isWatched.size() != trackingNumbersList.size()) {
            return false;
        }
        for (int i = 0; i < trackingNumbersList.size(); i++) {
            String actualtypeIconOnUi = "";
            // Check if type column is not empty
            int typeElmCount = typeColumnValuesList1.get(i).findElements(By.xpath(".//span")).size();
            int actualElementCount = typeElmCount / 2;
            String watchedIcon = isWatched.get(i).getAttribute("class");
            String trackingNumber = trackingNumbersList.get(i).getText();
            String typeIcon = typeColumnValuesList.get(typeColumnIterator).getAttribute("class");
            // Handling for records that dont have any type or having multiple types
            typeColumnIterator++;
            if (typeElmCount == 0) {
                typeIcon = "";
                typeColumnIterator = typeColumnIterator - 1;
            } else if (actualElementCount == 2) {
                typeIcon = typeIcon + "," + typeColumnValuesList.get(typeColumnIterator).getAttribute("class");
                typeColumnIterator = typeColumnIterator + 1;
            } else if (actualElementCount == 3) {
                typeIcon = typeIcon + "," + typeColumnValuesList.get(typeColumnIterator).getAttribute("class")
                        + "," + typeColumnValuesList.get(typeColumnIterator + 1).getAttribute("class");
                typeColumnIterator = typeColumnIterator + 2;
            } else if (actualElementCount == 4) {
                typeIcon = typeIcon + "," + typeColumnValuesList.get(typeColumnIterator).getAttribute("class")
                        + "," + typeColumnValuesList.get(typeColumnIterator + 1).getAttribute("class")
                        + "," + typeColumnValuesList.get(typeColumnIterator + 2).getAttribute("class");
                typeColumnIterator = typeColumnIterator + 3;
            }

            // Get the type for tracking Number from csv file
            String typeForTrackinNumInFile = fileData.get(trackingNumber);
            if (watchedIcon.equals("star-icn filled") && typeIcon.equals("")) {
                actualtypeIconOnUi = "watched";
            } else if (watchedIcon.equals("star-icn filled") && typeIcon != "") {
                actualtypeIconOnUi = typeIcon.replace("-icn", "") + "," + "watched";
            } else {
                actualtypeIconOnUi = typeIcon.replace("-icn", "");
            }
            typeForTrackinNumInFile = typeForTrackinNumInFile.replace(" ", "");
            typeForTrackinNumInFile = typeForTrackinNumInFile.replace("SurroundSelect", "digital");
            assertThat(actualtypeIconOnUi).isEqualToIgnoringCase(typeForTrackinNumInFile);
            commonHelpers.thinkTimer(2000);
            // .replace(" ", "").replace("digital","SurroundSelect")
        }

        return returnflag;
    }

    public void validateDataInColumn(String data,String rowsToValidate,String columnName, String validation) throws IOException {

        int totalCount = 0;
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));

        int rowCount = Integer.parseInt(rowsToValidate);
        if (trackingNumbersList.size() < 1 ){
            Assert.assertTrue("The records are less than Zero",false);
        }else if(trackingNumbersList.size() < rowCount) {
            totalCount = trackingNumbersList.size();
        }else{
            totalCount =rowCount;
        }
        String defaultXpath = columnValuesXpath;
        String uiColumnName ="";
        switch (columnName.toUpperCase()){
            case "DELIVERY ADDRESS VARIANCE" :
                uiColumnName = "deliveryAddressVariance";
                break;
            case "MONITORING AND INTERVESIONS OPTIONS" :
                uiColumnName = "monitoringAndInterventionsCode";
                break;
            case "SPECIAL HANDLING" :
                uiColumnName = "specialHandling";
                break;
            case "EDTW" :
                uiColumnName = "edtWindowStart";
                defaultXpath =defaultXpath + "/app-text//span";
                break;
            case "SDD" :
                uiColumnName = "scheduledDeliveryDateDestTZ";
                break;
            case "STDT":
                uiColumnName = "standardTransitTimeBy";
                break;

        }

        List<WebElement> uiColumnNameValue = this
                .findElements(By.xpath(String.format(defaultXpath, uiColumnName)));


        for (int intCnt = 0; intCnt < totalCount; intCnt++) {
            String value = uiColumnNameValue.get(intCnt).getText();
            if(validation.equalsIgnoreCase("equals")) {
                Assert.assertEquals(columnName + ":  Expected : "+data+ " but found : "+ value  ,data,value);
            } else if(validation.equalsIgnoreCase("CONTAINS")){
                Assert.assertTrue("Matches: ",value.contains(data));
            }
            else{ Assert.fail("No condition matches: ");
            }
        }
    }



    public int extractcountforpopup(String popup) {
        return this.getCount(this.enterFilename);
    }

    public int validateDownloadCountDecOnEachDownload(String caseFilter) {
        int returnCount = 0;
        this.commonHelpers.thinkTimer(10000);
        String saveUptoDownloadFiles = this.findElement(saveUptoDownloads).getText();
        if (caseFilter.contains("Combined Files")) {
            saveUptoDownloadFiles = this.findElements(saveUptoDownloads).get(1).getText();
            caseFilter = caseFilter.split("-")[0];
        }
        if (caseFilter.equalsIgnoreCase("post first")) {
            String previousCount = this.commonHelpers.getValuefromContextStore("popupAvailableCount").toString();
            int count = Integer.parseInt(previousCount);
            String dcpopupTitle = this.findElement(dcPopupTitle).getText();
            if (!dcpopupTitle.equals("Large File Download")) {
                // String saveUptoDownloadFiles = this.findElement(saveUptoDownloads).getText();
                saveUptoDownloadFiles = saveUptoDownloadFiles.split("\\(")[1].split(" ")[0].trim();
                this.commonHelpers.thinkTimer(5000);
                int popupAvailCountonredownload = Integer.parseInt(saveUptoDownloadFiles);
                this.commonHelpers.AddToContextStore("popupAvailableCount2", popupAvailCountonredownload);
                returnCount = count - popupAvailCountonredownload;
            }
        } else if (caseFilter.equalsIgnoreCase("post delete")) {
            String previousCount = this.commonHelpers.getValuefromContextStore("popupAvailableCount").toString();
            int count = Integer.parseInt(previousCount);
            String dcpopupTitle = this.findElement(dcPopupTitle).getText();
            if (!dcpopupTitle.equals("Large File Download")) {
                // String saveUptoDownloadFiles = this.findElement(saveUptoDownloads).getText();
                saveUptoDownloadFiles = saveUptoDownloadFiles.split("\\(")[1].split(" ")[0].trim();
                int popupAvailCountOnPostDeleteDownload = Integer.parseInt(saveUptoDownloadFiles);
                this.commonHelpers.AddToContextStore("popupAvailableCountpostdelete",
                        popupAvailCountOnPostDeleteDownload);
                returnCount = popupAvailCountOnPostDeleteDownload - count;
            }
        }
        return returnCount;
    }

    public void clickOnDeleteElementofDownloadCenter() {
        this.clickOnElement(By.xpath(deleteFileFromDC));
    }

    public void clickOnCancelOrDeleteElementofDeletePopUpInDownloadCenter(String button) {

        switch (button) {
            case "Cancel":
                this.clickOnElement(By.xpath(cancelButtonPopUpDC));
                break;
            case "Delete":
                this.clickOnElement(By.xpath(deleteFileFromDC));
                break;
        }
    }

    public String verifyDownloadFilecheckbox(String fileName) {
        String flag = "";
        if (this.findElement(this.getByusingString(String.format(this.downloadFileChecboxButtonDownloaded, fileName)))
                .isDisplayed()) {
            flag = "File is downlaoded in DC and checkbox is enabled";
        } else if (this
                .findElement(this
                        .getByusingString(String.format(this.downloadFileChecboxButtonDownloadInProgress, fileName)))
                .isDisplayed()) {
            flag = "File download is in progress and checkbox is not shown";
        }
        return flag;
    }

    public void selectMultipleShipmentsFromUI(int shipmentscount) throws InterruptedException {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.scrollHorizontalBarOnPage("-4000");
        List<WebElement> watchlist = this.findElements(this.watchList);
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        Map<String, String> watchedShipments = new HashMap<>();
        if (shipmentscount < 100) {
            if (trackingNumbersList.size() < shipmentscount) {
                shipmentscount = trackingNumbersList.size();
            }
        }

        this.keyBoardEventHoldKey(Keys.LEFT_CONTROL);
        for (int i = 0; i < shipmentscount; i++) {
            List<WebElement> shipmentList = this.findElements(By.xpath("//div[@row-id=" + i + "]"));
            try {
                shipmentList.get(1).click();
                commonHelpers.thinkTimer(1000);
                String isWatched = watchlist.get(i).getAttribute("class");
                String trackingNumber = trackingNumbersList.get(i).getText();
                if (isWatched.equals("star-icn")) {
                    watchedShipments.put(trackingNumber, "un-watched");
                } else {
                    watchedShipments.put(trackingNumber, "watched");
                }
            } catch (Exception e) {
                log.info("Unable to select row");
                // this.scrollInternalScrollBarOnPage("-200");
            }

            if (i != 0 && i % 12 == 0) {
                this.scrollInternalScrollBarOnPage("530");
                commonHelpers.thinkTimer(3000);
            }
        }
        this.keyBoardEventReleaseKey(Keys.LEFT_CONTROL);
        this.commonHelpers.AddToContextStore("watchedShipments", watchedShipments);
    }

    public boolean verifySelectedShipmentsDownloaded(int shipmentCount) throws IOException {
        boolean returnFlag = true;
        Map<String, String> fileData = this.genericFuncObj.getColumnDataFromFile("Types");
        assertThat(shipmentCount).isEqualTo(fileData.size());
        for (Map.Entry<String, String> shipments : fileData.entrySet()) {
            String trackingNumber = shipments.getKey();
            String isSelected = this.getAttributeValue(By.xpath(String.format(this.shipmentRow, trackingNumber)),
                    "aria-selected");
            if (!isSelected.equals("true")) {
                returnFlag = false;
            }
        }
        return returnFlag;
    }

    public void watchMultipleShipments(int shipmentCount) {
        List<WebElement> watchlist = this.findElements(this.watchList);
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        Map<String, String> watchedShipments = new HashMap<>();
        for (int i = 0; i < shipmentCount; i++) {
            String isWatched = watchlist.get(i).getAttribute("class");
            String trackingNumber = trackingNumbersList.get(i).getText();
            if (isWatched.equals("star-icn")) {
                watchlist.get(i).click();
            }
            watchedShipments.put(trackingNumber, "watched");
        }
        this.commonHelpers.AddToContextStore("watchedShipments", watchedShipments);
    }

    public boolean verifyMultipleShipmentsWatchedUnwatched(String shipmentType) {
        boolean returnFlag = true;
        String shipType = "star-icn";
        if (shipmentType.equals("watched")) {
            shipType = "star-icn filled";
        }
        if (this.commonHelpers.verifyKeyinContextStore("watchedShipments")) {
            Map<String, String> shipments = (Map<String, String>) this.commonHelpers
                    .getValuefromContextStore("watchedShipments");
            for (Map.Entry shipment : shipments.entrySet()) {
                String trackingNumber = (String) shipment.getKey();
                String isWatchedBefore = (String) shipment.getValue();
                String isWatchedAfter = this.getAttributeValue(By.xpath(String.format(this.watchIcon, trackingNumber)),
                        "class");
                if (!(isWatchedAfter.equals(shipType)
                        && (isWatchedBefore.equals("watched") || isWatchedBefore.equals("un-watched")))) {
                    returnFlag = false;
                }
            }
        } else {
            List<WebElement> watchlist = this.findElements(this.watchList);
            for (WebElement element : watchlist) {
                if (!element.getAttribute("class").equals(shipType)) {
                    returnFlag = false;
                }
            }
        }
        return returnFlag;
    }

    public String getTypeIcon(String shipmentType) {
        return this.getAttributeValue(By.xpath(String.format(this.typesIcon, shipmentType)), "class");
    }

    public boolean verifyOnlyUnwatchedShipmentsDisplayed(String shipmentType) {
        boolean flag = true;
        String icon = "star-icn";
        if (shipmentType.equals("watched")) {
            icon = "star-icn filled";
        }
        List<WebElement> watchlist = this.findElements(this.watchList);
        for (int i = 0; i < watchlist.size(); i++) {
            String isWatched = watchlist.get(i).getAttribute("class");
            if (!isWatched.equals(icon)) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public boolean verifyBulkTab(String tab1, String tab2) {
        List<WebElement> tabList = this.findElements(this.tabList);
        int tab1Index = 0, tab2index = 0;
        for (int i = 0; i < tabList.size(); i++) {
            String tabName = tabList.get(i).getText();
            if (tabName.equalsIgnoreCase(tab1)) {
                tab1Index = i;
            }
            if (tabName.equalsIgnoreCase(tab2)) {
                tab2index = i;
            }
        }
        return tab1Index > tab2index;
    }

    public boolean verifyDateTime(String columnId, String range) {
        String columnName = "";
        switch (columnId) {
            case "Date Delivered":
                columnName = "dateDelivered";
                break;
            case "Last Scan Time":
                columnName = "latestScanDatetimeFusion";
                break;
            case "Scheduled Delivery Date/Time":
                columnName = "scheduledDeliveryDateTimeBy";
                break;
            case "Gel Pack Date/Time":
                columnName = "gelPackDateTime";
                break;
            case "Dry Ice Added Date/Time":
                columnName = "dryIceAddedDateTime";
                break;
            case "Standard Transit":
                columnName = "standardTransit";
                break;
            case "Cold Storage Date/Time":
                columnName = "coldStorageTemperatureDateTime";
                break;
            default:
                break;
        }
        List<WebElement> dateColumn = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnName)));
        // String dateFormatOnUIString = "dd-MM-yyyy hh:mm";
        // String dateFormatOnUIString = (String)
        // this.commonHelpers.GetValuefromContextStore("preferredDateFormat") + " " +
        // (String) this.commonHelpers.GetValuefromContextStore("preferredTimeFormat");
        String dateFormatOnUIString = this.commonHelpers.getValuefromContextStore("preferredDateFormat") + " hh:mm a";
        if (this.commonHelpers.verifyKeyinContextStore("preferredTimeFormat")) {
            if (this.commonHelpers.getValuefromContextStore("preferredTimeFormat").toString().equals("24-Hour")) {
                dateFormatOnUIString = this.commonHelpers.getValuefromContextStore("preferredDateFormat") + " hh:mm";
            }
        }
        String dateFormatForCompariosn = "MM/dd/yyyy";
        boolean isDateflag = true, dateRange = true;
        Date fromDateExp = null, toDateExp = null;
        if (columnName.equals("scheduledDeliveryDateTimeBy")) {
            dateFormatForCompariosn = "MM/dd/yyyy hh:mm a";
        }
        if (this.commonHelpers.verifyKeyinContextStore("FromDate")) {
            String fromDate = this.dateTimeUtils.isDate(
                    (String) this.commonHelpers.getValuefromContextStore("FromDate"), "dd MMM yyyy",
                    dateFormatForCompariosn);
            fromDateExp = this.dateTimeUtils.stringToDate(fromDate, dateFormatForCompariosn);
            if (this.commonHelpers.verifyKeyinContextStore("fromTime")) {
                String date = this.dateTimeUtils.isDate(
                        this.commonHelpers.getValuefromContextStore("fromTime").toString(), dateFormatOnUIString,
                        dateFormatForCompariosn);
                fromDateExp = this.dateTimeUtils.stringToDate(date, dateFormatForCompariosn);
            }

            if (this.commonHelpers.verifyKeyinContextStore("ToDate")) {
                String toDate = this.dateTimeUtils.isDate(
                        (String) this.commonHelpers.getValuefromContextStore("ToDate"),
                        "dd MMM yyyy", dateFormatForCompariosn);
                toDateExp = this.dateTimeUtils.stringToDate(toDate, dateFormatForCompariosn);
            }

            if (this.commonHelpers.verifyKeyinContextStore("toTime")) {
                String date = this.dateTimeUtils.isDate(
                        this.commonHelpers.getValuefromContextStore("toTime").toString(), dateFormatOnUIString,
                        dateFormatForCompariosn);
                toDateExp = this.dateTimeUtils.stringToDate(date, dateFormatForCompariosn);
            }

        }

        if (columnName.equals("latestScanDatetimeFusion")) {
            dateFormatOnUIString = "MMMM d, yyyy hh:mm";
        }

        for (WebElement date : dateColumn) {
            String dateVal = date.getText();
            if (!dateVal.equals("")) {
                String isDate = this.dateTimeUtils.isDate(dateVal, dateFormatOnUIString, dateFormatForCompariosn);
                Date actualDate = this.dateTimeUtils.stringToDate(isDate, dateFormatForCompariosn);
                if (isDate == null) {
                    isDateflag = false;
                }

                if (range.equalsIgnoreCase("Date Range") || range.contains("In the last")
                        || range.contains("Time Range")) {
                    if ((actualDate.compareTo(fromDateExp) == 0 || actualDate.compareTo(toDateExp) == 0)) {
                        log.info("Delivered date is equal to from/to Date");
                    } else if (!(actualDate.after(fromDateExp) && actualDate.before(toDateExp))) {
                        dateRange = false;
                    }
                }

                if (range.equalsIgnoreCase("Specific Date / Time")) {
                    if (!(actualDate.compareTo(fromDateExp) == 0)) {
                        dateRange = false;
                    }
                }
                if (range.equalsIgnoreCase("Specific Time")) {
                    String actTime = String.join(" ", dateVal.split(" ")[1], dateVal.split(" ")[2]);
                    if (!actTime.equals(this.commonHelpers.getValuefromContextStore("time"))) {
                        dateRange = false;
                    }

                }

            }

        }
        return isDateflag && dateRange;
    }

    public boolean verifyDeliveredDateOptions(String filterName) {
        String userContext = "";
        if (this.commonHelpers.verifyKeyInContextStore("UserContext")) {
            userContext = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        }

        String inpt = "/../input";
        // verify if options are mutually exclusive
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Date Range")));
        // Validate Specific Date / Time and Delivered in options are disabled on
        // selecting Date Range
        Assert.assertFalse(
                this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Specific Date / Time") + inpt)));
        if (userContext.equalsIgnoreCase("CE")) {
            Assert.assertFalse(
                    this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("No delivered date") + inpt)));
        }
        Assert.assertFalse(
                this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Less than 4 hours") + inpt)));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("4-8 hours") + inpt)));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("8-24 hours") + inpt)));
        if (filterName.equals("Last Scan Time")) {
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("1 day") + inpt)));
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("2 days") + inpt)));
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("3+ days") + inpt)));
        } else {
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("In the last") + inpt)));
        }
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Date Range")));
        // Validate Date Range and Delivered in options are disabled on selecting
        // Specific Date / Time
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific Date / Time")));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Date Range") + inpt)));
        if (userContext.equalsIgnoreCase("CE")) {
            Assert.assertFalse(
                    this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("No delivered date") + inpt)));
        }
        Assert.assertFalse(
                this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Less than 4 hours") + inpt)));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("4-8 hours") + inpt)));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("8-24 hours") + inpt)));
        if (filterName.equals("Last Scan Time")) {
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("1 day") + inpt)));
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("2 days") + inpt)));
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("3+ days") + inpt)));
        } else {
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("In the last") + inpt)));
        }
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific Date / Time")));
        // Validate Date Range and Specific Date / Time are disabled on selecting
        // Delivered in options
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Less than 4 hours")));
        Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Date Range") + inpt)));
        Assert.assertFalse(
                this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Specific Date / Time") + inpt)));
        if (userContext.equalsIgnoreCase("CE")) {
            Assert.assertTrue(
                    this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("No delivered date") + inpt)));
        }
        Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("4-8 hours") + inpt)));
        Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("8-24 hours") + inpt)));
        if (filterName.equals("Last Scan Time")) {
            Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("1 day") + inpt)));
            Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("2 days") + inpt)));
            Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("3+ days") + inpt)));
        } else {
            Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("In the last") + inpt)));
        }

        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Less than 4 hours")));

        // Verify Delivered In options are displayed as lid
        if (filterName.equals("Last Scan Time")) {
            filterName = "Last Scanned";
        }
        List<WebElement> deliveredInOptions = this
                .findElements(By.xpath(String.format(this.deliveredDateOptions, filterName)));
        int optionIndex = 0;
        if (!filterName.equals("Last Scanned")) {
            if (userContext.equalsIgnoreCase("CE")) {
                Assert.assertEquals(deliveredInOptions.get(optionIndex).getText(), "No delivered date");
                optionIndex = optionIndex + 1;
            }
            Assert.assertEquals(deliveredInOptions.get(optionIndex).getText(), "Less than 4 hours");
            Assert.assertEquals(deliveredInOptions.get(optionIndex + 1).getText(), "4-8 hours");
            Assert.assertEquals(deliveredInOptions.get(optionIndex + 2).getText(), "8-24 hours");
        }
        if (filterName.equals("Last Scanned")) {
            Assert.assertEquals(deliveredInOptions.get(0).getText(), "is within");
            Assert.assertEquals(deliveredInOptions.get(1).getText(), "is not within");
            Assert.assertEquals(deliveredInOptions.get(2).getText(), "Less than 4 hours");
            Assert.assertEquals(deliveredInOptions.get(3).getText(), "4-8 hours");
            Assert.assertEquals(deliveredInOptions.get(4).getText(), "8-24 hours");
            Assert.assertEquals(deliveredInOptions.get(5).getText(), "1 day");
            Assert.assertEquals(deliveredInOptions.get(6).getText(), "2 days");
            Assert.assertEquals(deliveredInOptions.get(7).getText(), "3+ days");
        } else {
            Assert.assertTrue(deliveredInOptions.get(optionIndex + 3).getText().contains("In the last"));
            // Verify In the last dropdown values
            Assert.assertEquals(this.getDropdownOptions(this.deliveredDateInTheLastOptions).size(), 14);
        }
        return true;
    }

    public void selectfromDate(String[] filter) {
        this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(filter[1]));
        String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
        this.clickOnLastElement(this.specificDateRangeFromLast);
        while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
            this.clickOnElement(calenderLeftArrow);
        }

        this.clickOnElement(By.xpath(String.format(dateXpath, fromArr[0])));
        this.setTimeHoursMins(0, 0, 0);
        if (this.elementIsDisplayed(By.xpath(this.CalenderOKButton))) {
            this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        }

    }

    public boolean validateDateFlter(String filterame, String dateCriteria) {
        String fromDate, toDate, filterCriteria = "";
        String outputDateFormat = "DD-MM-yyyy";
        if (this.commonHelpers.verifyKeyInContextStore("preferredDateFormat")) {
            outputDateFormat = (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat");
        }
        if (dateCriteria.equalsIgnoreCase("Date Range")) {
            fromDate = this.dateTimeUtils.changeDateFormat(
                    (String) this.commonHelpers.getValuefromContextStore("FromDate"), "dd MMM yyyy", outputDateFormat,
                    "DM")
                    + " 00:00";
            toDate = this.dateTimeUtils.changeDateFormat(
                    (String) this.commonHelpers.getValuefromContextStore("ToDate"), "dd MMM yyyy", outputDateFormat,
                    "DM")
                    + " 00:00";
            // Adding extra space in filter between from and To dates
            if (filterame.equalsIgnoreCase("Gel Pack Date/Time")
                    || filterame.equalsIgnoreCase("Dry Ice Added Date/Time")
                    || filterame.equalsIgnoreCase("Cold Storage Date/Time")
                    || filterame.equalsIgnoreCase("Standard Transit")) {
                filterCriteria = fromDate + " - " + toDate;
            } else {
                filterCriteria = fromDate + " - " + toDate;
            }
        } else if (dateCriteria.equalsIgnoreCase("Specific Date / Time")) {
            filterCriteria = this.dateTimeUtils.changeDateFormat(
                    (String) this.commonHelpers.getValuefromContextStore("FromDate"), "dd MMM yyyy", outputDateFormat,
                    "DM")
                    + " 00:00";
            // filterCriteria = fromDate;
        } else if (dateCriteria.equalsIgnoreCase("Specific Date and Time Range")) {
            String fromTime = (String) this.commonHelpers.getValuefromContextStore("fromTime");
            String toTime = (String) this.commonHelpers.getValuefromContextStore("toTime");
            filterCriteria = String.join(" ", fromTime.replaceFirst(" ", " : "), "-", toTime.split(" ")[1],
                    toTime.split(" ")[2]);
        } else if (dateCriteria.equalsIgnoreCase("Date Range and Specific Time")) {
            String fromTime = this.dateTimeUtils.changeDateFormat(
                    (String) this.commonHelpers.getValuefromContextStore("FromDate"), "dd MMM yyyy", outputDateFormat,
                    "DM");
            String toTime = (String) this.commonHelpers.getValuefromContextStore("toTime");
            filterCriteria = String.join(" ", fromTime.split(" ")[0], "-", toTime.replaceFirst(" ", " : "));
        } else if (dateCriteria.equalsIgnoreCase("Date Range and Specific Time")) {
            String fromTime = this.dateTimeUtils.changeDateFormat(
                    (String) this.commonHelpers.getValuefromContextStore("FromDate"), "dd MMM yyyy", outputDateFormat,
                    "DM");
            String toTime = (String) this.commonHelpers.getValuefromContextStore("toTime");
            filterCriteria = String.join(" ", fromTime.split(" ")[0], "-", toTime.replaceFirst(" ", " : "));
        } else if (dateCriteria.equalsIgnoreCase("Date Range and Time Range")) {
            String[] fromTime = ((String) this.commonHelpers.getValuefromContextStore("fromTime")).split(" ");
            String[] toTime = ((String) this.commonHelpers.getValuefromContextStore("toTime")).split(" ");
            filterCriteria = String.join(" ", fromTime[0], "-", toTime[0], ":", fromTime[1], fromTime[2], "-",
                    toTime[1], toTime[2]);
        }

        String timeformat = "24-Hour";
        if (this.commonHelpers.verifyKeyInContextStore("preferredTimeFormat")) {
            timeformat = (String) this.commonHelpers.getValuefromContextStore("preferredTimeFormat");
        }
        if (timeformat.equals(("12-Hour"))) {
            if (this.commonHelpers.verifyKeyInContextStore("time")) {
                filterCriteria = filterCriteria.replace("00:00",
                        ": " + this.commonHelpers.getValuefromContextStore("time"));
            } else {
                filterCriteria = filterCriteria.replace("00:00", "12:00 AM");
            }

        }
        if (filterame.equalsIgnoreCase("Last Scan Time")) {
            String actFilter = this.getText(this.filterValue);
            return actFilter.equalsIgnoreCase(filterCriteria);

        } else if (filterame.equalsIgnoreCase("Scheduled Delivery Date/Time")) {
            String year = filterCriteria.substring(6, 10);
            // Only validating the filter bubble with year part
            return this.findElement(
                            this.getByusingString(String.format(this.filterBubbleXpath, year, filterame)))
                    .isDisplayed();
        } else {
            return this.findElement(
                            this.getByusingString(String.format(this.filterBubbleXpath, filterCriteria, filterame)))
                    .isDisplayed();
        }

    }

    public boolean verifyDataOnUIAndDownloadedFile(String columnName) throws IOException {
        String columnId = "";
        String dateFormat = "dd-MM-yyyy hh:mm";
        boolean excelData = false;
        Map<String, List<String>> columnListDataExcel;
        List<String> columnData = new ArrayList<>();
        Map<String, String> fileData = new HashMap<>();
        if (columnName.contains("Excel")) {
            columnName = columnName.split("-")[1];
            columnListDataExcel = this.genericFuncObj.getCompleteColumnData("Shipments");
            columnData = columnListDataExcel.get(columnName);
            excelData = true;
        } else {
            fileData = this.genericFuncObj.getColumnDataFromFile(columnName);
        }

        switch (columnName) {
            case "Delivered Date/Time":
                columnId = "dateDelivered";
                break;
            case "Last Comment":
                columnId = "lastComment";
                break;
            case "Industry Vertical":
                columnId = "industryVerticalName";
                break;
            case "At Risk Since":
                columnId = "atRiskSince";
                break;
            case "Master Tracking Number":
                columnId = "masterTrackingNumber";
                break;
            case "Sub-status":
                columnId = "subStatus";
                break;
            case "Recipient Country/ Territory":
                columnId = "recipCountryOrTerritory";
                break;
            case "Types":
                columnId = "isPayer";
                break;
            case "Package Weight (Lbs)":
                columnId = "pkgWtLbs";
                break;
            case "Package Weight (Kgs)":
                columnId = "pkgWtKg";
                break;
            case "Total Weight (Lbs)":
                columnId = "totalWtLbs";
                break;
            case "Total Weight (Kgs)":
                columnId = "totalWtKg";
                break;
            case "CER Number":
                columnId = "cerNumbers";
                break;
            case "Recipient Postal":
                columnId = "recipPostal";
            case "CER Count":
                columnId = "cerCount";
                break;
            case "Scheduled Delivery Date/Time":
                columnId = "scheduledDeliveryDateTimeBy";
                break;
            case "Dry Ice Added (Kg)":
                columnId = "dryIceAddedKgs";
                break;
            case "Dry Ice Added (Lbs)":
                columnId = "dryIceAddedLbs";
                break;
            case "SenseAware Mobile":
                columnId = "senseAwareJourneyId";
                break;
            case "Dry Ice Added Date/Time":
                columnId = "dryIceAddedDateTime";
                break;
            case "Cold Storage Date/Time":
                columnId = "coldStorageTemperatureDateTime";
                break;
            case "Cold Storage Temp - Min (°C)":
                columnId = "coldStorageTemperatureMinC";
                break;
            case "Cold Storage Temp - Max (°C)":
                columnId = "coldStorageTemperatureMaxC";
                break;
            case "Gel Pack Quantity":
                columnId = "gelPackQuantity";
                break;
            case "Gel Pack Date/Time":
                columnId = "gelPackDateTime";
                break;
            case "Estimated Delivery Date/Time":
                columnId = "edtWindowStart";
                break;
            case "Service Type":
                columnId = "serviceType";
                break;
            case "Healthcare Identifier":
                columnId = "healthcareIdentifier";
                break;
            case "Delivery Address Variance" :
                columnId = "deliveryAddressVariance";
                break;
            case "Monitoring And Intervention Options" :
                columnId = "monitoringAndInterventionsCode";
                break;
            case "Délai de livraison standard au plus tard à":
                columnId = "standardTransitTimeBy";
                break;
            case "Actual Delivery Address":
                columnId = "deliveryAddress";
                break;
            case "Latest Delivery Attempt Date/Time":
                columnId="dateAttemptedDelivery";
                break;
            case "Time In Network":
                columnId="timeSincePickup";
                break;
            case "Controllable Delay":
                columnId="controllableDelay";
                break;
            case "Delivery Prediction":
                columnId="finalPackageDelayStatus";
                break;
            case "Priority Alert Options":
                columnId="priorityAlertOptions";
                break;
            case "Workgroup":
                columnId="workgroups";
                break;
            case "International Shipments":
                columnId="internationalShipments";
                break;
        }
        // this.waitUntilVisible(this.loadingIndicator);
        this.waitUntillEleInvisible(this.loadingIndicator, 60);
        List<WebElement> actColumnValues = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
        log.info("Total Values for column =  " + columnName + " are  = " + actColumnValues.size());

        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));

        boolean returnflag = true;
        int counter = trackingNumbersList.size();
        log.info("Tracking Number list has total numbers --> " + counter);
        if (this.commonHelpers.verifyKeyInContextStore("watchedShipments")) {
            Map<String, String> shipments = (Map<String, String>) this.commonHelpers
                    .getValuefromContextStore("watchedShipments");
            counter = shipments.size();
        }

        if (columnName.equals("Tracking Number")) {
            actColumnValues = trackingNumbersList;
        }
        if (this.commonHelpers.verifyKeyInContextStore("preferredDateFormat")) {
            dateFormat = (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat");
        }
        List<String> typesData = new ArrayList<>();
        if (this.commonHelpers.verifyKeyInContextStore("Types")) {
            typesData = (List<String>) this.commonHelpers.getValuefromContextStore("Types");
        }

        for (int i = 0; i < counter; i++) {
            String trackingNumber = trackingNumbersList.get(i).getText();
            String actColumnValue = actColumnValues.get(i).getText();
            if (this.commonHelpers.verifyKeyInContextStore("Types")) {
                actColumnValue = typesData.get(i);
            }
            // Get the data for tracking Number from csv/Excel file
            String expColumnValue = "";
            if (excelData) {
                expColumnValue = columnData.get(i);
            } else {
                expColumnValue = fileData.get(trackingNumber);
            }

            if (columnName.equals("Delivered Date")) {
                if (expColumnValue.equals("")) {
                    if (!actColumnValue.equals("")) {
                        returnflag = false;
                        break;
                    }
                } else {
                    Date expDate = this.dateTimeUtils.stringToDate(expColumnValue, dateFormat);
                    Date actDate = this.dateTimeUtils.stringToDate(actColumnValue, dateFormat);
                    if (!(expDate.compareTo(actDate) == 0)) {
                        returnflag = false;
                        break;
                    }
                }
            } else if (columnName.equals("CER Number")) {
                String actValue = "";
                if (actColumnValue.contains(",")) {
                    String[] cerList = actColumnValue.split(", ");
                    // There is bug once its fixed will swap 0 and 1 in below line
                    actValue = cerList[0] + ", " + cerList[1];
                } else {
                    // actValue = Constants.CERLink + " " + actColumnValue;
                    actValue = actColumnValue;
                }

                if (!actValue.equals(expColumnValue)) {
                    returnflag = false;
                    break;
                }
            } else if (columnName.equals("SenseAware Mobile")) {
                String url = actColumnValues.get(i).findElement(By.tagName("a")).getAttribute("href");
                if (!url.equals(expColumnValue) && expColumnValue.contains(actColumnValue)) {
                    returnflag = false;
                    break;
                }
            } else if (columnName.equals("Types")) {
                if (actColumnValue.contains(",")) {
                    String[] typesList = actColumnValue.split(",");
                    for (String types : typesList) {
                        // Since watched icon does not appear under Types but still appears in csv
                        if (!(types.equalsIgnoreCase(expColumnValue) || types.equalsIgnoreCase("Watched"))) {
                            returnflag = false;
                            break;
                        }
                    }
                }
            }else if (columnName.equals("Estimated Delivery Date/Time")) {

                String expectedValidCol[] = expColumnValue.split("-");
                String actualValidCol[] = actColumnValue.split("-");

                if(!(expectedValidCol[0].trim().equalsIgnoreCase(actualValidCol[0].trim()) && expectedValidCol[1].trim().equalsIgnoreCase(actualValidCol[1].trim()) )){
                    returnflag = false;
                    break;
                }
            }
            else {
                if (!expColumnValue.contains(actColumnValue)) {
                    returnflag = false;
                    System.out.println("failed at "+i);
                    break;
                }
            }

        }
        return returnflag;
    }

    public boolean verifyShipmentsInsidePopUp(String header) {
        boolean returnFlag = true;
        Map<String, String> commentsMap = new HashMap<String, String>();
        Map<String, String> shipments = (Map<String, String>) this.commonHelpers
                .getValuefromContextStore("watchedShipments");
        for (Map.Entry shipment : shipments.entrySet()) {
            String trackingNumber = (String) shipment.getKey();
            boolean flag = this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(trackingNumber)), true);
            String comment = this.getText(
                    this.getByusingString(String.format(this.commentsInRepeatLastCommentPopUp, trackingNumber)));
            if (!flag) {
                returnFlag = false;
            }
            commentsMap.put(trackingNumber, comment);
        }

        this.commonHelpers.AddToContextStore("CommentedShipments", commentsMap);
        return returnFlag;
    }

    public boolean verifyLastCommenstForShipments() {
        boolean flag = true;
        this.waitUntilNotVisible(this.loadingIndicator);
        Map<String, String> shipments = (Map<String, String>) this.commonHelpers
                .getValuefromContextStore("CommentedShipments");
        List<WebElement> comments = this.findElements(By.xpath(String.format(this.columnValuesXpath, "lastComment")));
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        List<WebElement> lastCommentDateTime = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "lastCommentOn")));
        String timeStamp = new SimpleDateFormat("dd-MM-yyyy HH:mm z").format(new Date(System.currentTimeMillis()));
        String actTimeStamp = this.dateTimeUtils.changeDateFormat(timeStamp, "dd-MM-yyyy HH:mm z",
                "d-M-yyyy HH:mm z", "DM");
        if (!this.commonHelpers.verifyKeyInContextStore("lastCommentTimeStamp")) {
            this.commonHelpers.AddToContextStore("lastCommentTimeStamp", actTimeStamp);
        } else {
            actTimeStamp = (String) this.commonHelpers.getValuefromContextStore("lastCommentTimeStamp");
        }
        String lastComment = "";
        if (this.commonHelpers.verifyKeyInContextStore("lastComment")) {
            lastComment = (String) this.commonHelpers.getValuefromContextStore("lastComment");
        }
        for (int i = 0; i < shipments.size(); i++) {
            String trackingNumber = trackingNumbersList.get(i).getText();
            String commentAct = comments.get(i).getText();
            String commentExp = shipments.get(trackingNumber);

            log.info(commentAct + "*******" + commentExp);

            if (!lastComment.equals("")) {
                commentExp = lastComment;
            }

            String lastCommentDt = lastCommentDateTime.get(i).getText();
            if (!(commentAct.equalsIgnoreCase(commentExp)
                    && lastCommentDt.replace(",", "").equalsIgnoreCase(actTimeStamp))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public boolean verifyMasterTrackingNumberFilter(DataTable table) {
        List<String> options = table.asList(String.class);
        boolean noResult = true;
        boolean flag = true;
        boolean infoText = this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(options.get(0))), true);

        for (int i = 1; i < options.size(); i++) {
            if (options.get(i).contains("ContextStore-")) {
                this.enterText(this.filterSearchInput, this.commonHelpers
                        .getValuefromContextStore("masterTrackingNumber0").toString().substring(0, 3));
            } else {
                this.enterText(this.filterSearchInput, options.get(i));
            }

            this.waitUntilNotVisible(this.loadingIndicator);
            commonHelpers.thinkTimer(3000);
            noResult = this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(Constants.NoResultsFound)),
                    true);

            if (i == options.size() - 2) {
                String maxCharInSearchBox = this.getAttributeValue(this.filterSearchInput, "value");
                int len = maxCharInSearchBox.length();
                if (len > 12) {
                    flag = false;
                    break;
                }
            }
            if (i == options.size() - 1) {
                if (noResult) {
                    flag = false;
                    break;
                }
            } else {
                if (!noResult) {
                    flag = false;
                    break;
                }
            }
        }

        return flag && infoText;
    }

    public boolean verifySummarySheet() {
        log.info("Inside VerifySummary Sheet function");
        String currentTime = new SimpleDateFormat("HH:mm z, MMM d, yyyy").format(new Date(System.currentTimeMillis()));
        log.info("Current time is " + currentTime);
        String reportField = this.genericFuncObj.getValueFromExcel("Summary", 1, 0);
        log.info(" *Report Field* Value is " + reportField);
        String reportTime = this.genericFuncObj.getValueFromExcel("Summary", 1, 1);
        log.info(" *Report Time* Value is " + reportTime);
        assertThat(reportField).isEqualTo("Report created on:");
        assertThat(reportTime).isEqualTo(this.getText(lastUpdatedAtTime));
        return true;
    }

    /**
     * This method Sets time as per inputs
     *
     * @param hours      = Hour to set; 1 to 24
     * @param mins       = Minutes to set;00 to 59
     * @param timeoption = time option; 0-AM, 1-PM
     */
    public void setTimeHoursMins(int hours, int mins, int timeoption) {
        try {
            if (this.elementIsDisplayed(this.timeHourDrodown)) {
                String timeFormat = (String) this.commonHelpers.getValuefromContextStore("preferredTimeFormat");
                this.clickOnElement(this.timeHourDrodown);
                String hoursid = this.getAttributeValue(this.timeHourDrodown, "id");
                List<WebElement> hoursOptions = this
                        .findElements(By.xpath("//*[@id='" + hoursid + "-panel']//mat-option"));
                if (timeFormat.equals(("12-Hour"))) {
                    if (hours == 0) {
                        hoursOptions.get(hoursOptions.size() - 1).click();
                    } else {
                        hoursOptions.get(hours - 1).click();
                    }
                    this.clickOnElement(this.timeAmPmDrodown);
                    String ampmId = this.getAttributeValue(this.timeAmPmDrodown, "id");
                    List<WebElement> amPmOptions = this
                            .findElements(By.xpath("//*[@id='" + ampmId + "-panel']//mat-option"));
                    amPmOptions.get(timeoption).click();
                } else {
                    hoursOptions.get(hours - 1).click();
                }
                this.clickOnElement(this.minutesDropdown);
                String minsId = this.getAttributeValue(this.minutesDropdown, "id");
                List<WebElement> minsOptions = this
                        .findElements(By.xpath("//*[@id='" + minsId + "-panel']//mat-option"));
                if (mins == 0) {
                    minsOptions.get(0).click();
                }
            } else {
                log.info("Time options not displayed");
            }
        } catch (Exception e) {
            log.info("Can not set time");
        }

    }

    public boolean verifyRightClickOptions(String menuItem, List<String> expOptions) {
        log.info("Validating for the option --> " + menuItem);
        boolean flag = true;
        List<String> actOptions = this.getRightClickOptions(this.shipmentOverviewFirstRow, this.bulkMenuList);
        // List<String> expOptions = table.asList(String.class);
        for (int i = 0; i < expOptions.size(); i++) {
            String actValue = actOptions.get(i);
            String expOption = expOptions.get(i);
            if (!actValue.equalsIgnoreCase(expOption)) {
                flag = false;
            }
        }
        return flag;
    }

    public void addComment(String comment) {
        if (comment.contains("ContextStore-")) {
            comment = (String) this.commonHelpers.getValuefromContextStore("lastComment");
        }
        if (comment.equals("")) {
            this.selectDropdown(this.addCommentsDropdown, "index", "1");
        } else {
            this.selectDropdown(this.addCommentsDropdown, "text", comment);
        }
    }

    public boolean verifyFieldValue(String fieldName, String dataState) {
        boolean flag = true;
        List<String> expTrackingIds = new ArrayList<String>();
        List<WebElement> elems = this.findElements(this.searchMultiInput);
        int counter = elems.size();
        if (this.commonHelpers.verifyKeyInContextStore("Valid TrackingIds")) {
            expTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
            counter = expTrackingIds.size();
        }
        if (this.commonHelpers.verifyKeyInContextStore("InValid TrackingIds")) {
            expTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("InValid TrackingIds");
            counter = expTrackingIds.size();
        }

        if (dataState.equals("empty")) {
            counter = counter - 1;
        }
        for (int i = 0; i < counter; i++) {
            String value = elems.get(i).getAttribute("value");
            if (!dataState.equals("empty")) {
                if (value.equals("")) {
                    flag = false;
                }
            } else {
                if (!value.equals("")) {
                    flag = false;
                }
            }
        }

        return flag;
    }

    public boolean verifyTrackingNumberOrderForMts() {
        boolean flag = true;
        List<String> expTrackingNumbers = (List<String>) this.commonHelpers
                .getValuefromContextStore("Valid TrackingIds");
        int expViewCount = expTrackingNumbers.size();
        List<String> inValidTrackingNumbers = (List<String>) this.commonHelpers
                .getValuefromContextStore("InValid TrackingIds");
        if (this.commonHelpers.verifyKeyInContextStore("InValid TrackingIds")) {
            expTrackingNumbers.addAll(inValidTrackingNumbers);
        }

        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        for (int i = 0; i < expTrackingNumbers.size(); i++) {
            String expValue = expTrackingNumbers.get(i);
            String actValue = trackingNumbersList.get(i).getText();
            if (!expValue.equals(actValue)) {
                flag = false;
                break;
            }
        }
        int viewCount = this.getViewCount();
        return flag && viewCount == expViewCount;
    }

    public boolean verifyDataInColumnsMts() {
        boolean flag = true;
        this.clickOnElement(By.xpath(String.format(this.expandIcon, "expand")));
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        List<WebElement> statusList = this.findElements(By.xpath(String.format(this.columnValuesXpath, "status")));
        this.scrollHorizontalBarOnPage("1500");
        List<WebElement> companyList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "recipCompany")));
        List<WebElement> dateTimeList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "scheduledDeliveryDateTimeBy")));
        List<WebElement> shipperList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "shipperName")));
        List<WebElement> shipperAccountNoList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "shipperAccountNumber")));
        Map<String, Map<String, String>> uiData = new HashedMap<>();
        List<String> validTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        for (int i = 0; i < trackingNumbersList.size(); i++) {
            Map<String, String> columnsData = new HashedMap<>();
            columnsData.put("status", statusList.get(i).getText());
            columnsData.put("company", companyList.get(i).getText());
            try {
                columnsData.put("scheduledDatTime", dateTimeList.get(i).getText());
            }catch(Exception e){
                columnsData.put("scheduledDatTime", "");
            }
            if (!user.equals("CE")) {
                columnsData.put("shipper", shipperList.get(i).getText());
            }

            try {
                columnsData.put("shipperAccountNo", shipperAccountNoList.get(i).getText());
            }catch(Exception e){
                columnsData.put("shipperAccountNo", "");
            }
            uiData.put(trackingNumbersList.get(i).getText(), columnsData);
        }

        for (int i = 0; i < validTrackingIds.size() - 5; i++) {
            String trackingId = validTrackingIds.get(i);
            Map<String, String> trackingIdData = uiData.get(trackingId);
            for (Map.Entry m : trackingIdData.entrySet()) {
                if (m.getValue().equals("")) {
                    flag = false;
                    break;
                }
            }
            if (!flag) {
                break;
            }
        }
        if (this.commonHelpers.verifyKeyInContextStore("InValid TrackingIds")) {
            List<String> inValidTrackingIds = (List<String>) this.commonHelpers
                    .getValuefromContextStore("InValid TrackingIds");
            for (int i = 0; i < inValidTrackingIds.size(); i++) {
                String trackingId = inValidTrackingIds.get(i);
                Map<String, String> trackingIdData = uiData.get(trackingId);
                for (Map.Entry m : trackingIdData.entrySet()) {
                    if (!m.getKey().equals("status")) {
                        if (!m.getValue().equals("")) {
                            flag = false;
                            break;
                        }
                    }
                }
                if (!flag) {
                    break;
                }
            }
        }

        return flag;

    }

    public boolean clickOnWatchIconAndVerifyStatus(int shipmentCount, String action) {
        boolean flag = true;
        String expStatusAfterAction = "", actStatusAfterAction = "";
        List<WebElement> watchlist = this.findElements(this.watchList);
        for (int i = 0; i < shipmentCount; i++) {
            String isWatched = watchlist.get(i).getAttribute("class");
            if (isWatched.equals("star-icn")) {
                expStatusAfterAction = "watched";
            } else {
                expStatusAfterAction = "un-watched";
            }
            watchlist.get(i).click();
            isWatched = watchlist.get(i).getAttribute("class");
            if (isWatched.equals("star-icn filled")) {
                actStatusAfterAction = "watched";
            } else {
                actStatusAfterAction = "un-watched";
            }
            if (!expStatusAfterAction.equals(actStatusAfterAction)) {
                flag = false;
                break;
            }
        }

        return flag;

    }

    public boolean verifyMtsTrackingIds() {
        boolean flag = true;
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        List<String> validTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
        for (int i = 0; i < trackingNumbersList.size(); i++) {
            if (validTrackingIds.indexOf(trackingNumbersList.get(i).getText()) == -1) {
                flag = false;
                break;
            }

        }
        return flag;
    }

    public void clickSearchedAccountORWorkgroup() {
        this.clickOnElement(this.searchAccount);
        // this.useSpecialKeys(this.searchAccount, "enter");
        // this.useSpecialKeys(this.searchAccount, "space");
    }

    public void clickAccountClearorApplyButton(String button) {
        this.clickOnElement(this.getByusingString(String.format(this.pageNumberXpath, button)));
    }

    public void clickSerachMultiTackingNumbers() {
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.JavaScriptClick(this.findElement(this.searchMultiTrack));
    }

    public boolean verifyQvcSequenceInPanel(List<String> qvcListExp) {
        boolean flag = true;
        List<WebElement> qvcList = this.findElements(By.xpath(this.quickViewtitlesXpath));
        for (int i = 0; i < qvcList.size(); i++) {
            String expQVC = qvcListExp.get(i);
            String actQVC = qvcList.get(i).getText();
            if (!expQVC.equalsIgnoreCase(actQVC)) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public boolean validateDuplicateTrackingIds() {
        boolean flag = true;
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        for (int i = 0; i < trackingNumbersList.size(); i++) {
            String id1 = trackingNumbersList.get(i).getText();
            for (int j = i + 1; j < trackingNumbersList.size(); j++) {
                String id2 = trackingNumbersList.get(j).getText();
                if (id1.equals(id2)) {
                    flag = false;
                    break;
                }
            }

        }

        return flag;
    }

    public boolean verifyTrackingIdsAreDisplayedForSelectedCompanies() {
        List<String> wgRegions = new ArrayList<>();
        wgRegions.add("US");
        wgRegions.add("EU");
        wgRegions.add("AMEA");
        wgRegions.add("LAC");
        wgRegions.add("CA");
        boolean flag = true;
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(this.CompanyAccddXpath);
        List<WebElement> companies = this.findElements(this.selectedCompanies);
        List<String> compnyIds = new ArrayList<>();
        List<String> compnyNameList = new ArrayList<>();
        for (int i = 0; i < companies.size(); i++) {
            String companyName = companies.get(i).getAttribute("aria-label");
            if (companyName != null) {
                if (wgRegions.indexOf(companyName.replace("toggle ", "")) == -1) {
                    compnyNameList.add(companyName.replace("toggle ", ""));
                    companies.get(i).click();
                    List<WebElement> companyIdList = this.findElements(this.companyId);
                    for (int j = 0; j < companyIdList.size(); j++) {
                        String companyId = companyIdList.get(j).getAttribute("id");
                        compnyIds.add(companyId);
                    }
                    companies.get(i).click();
                }

            }

        }
        this.commonHelpers.AddToContextStore("selectedCompanies", compnyNameList);
        this.JavaScriptClick(this.CompanyAccddXpath);
        List<WebElement> shipperAccountNumberList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "shipperAccountNumber")));
        List<WebElement> trackingNumbersList = this
                .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));
        for (int i = 0; i < trackingNumbersList.size(); i++) {
            String shipperId = shipperAccountNumberList.get(i).getText();
            int index = compnyIds.indexOf(shipperId);
            if (index == -1) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public void exportList() {
        this.waitUntilNotVisible(this.loadingIndicator, 60);
        int viewCount = this.getViewCount();
        if (viewCount > 1000) {
            try {
                this.selectMultipleShipmentsFromUI(5);
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString("BULK")));
                this.JavaScriptClick(By.xpath(String.format(this.filterCategory, "EXPORT SELECTED")));
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EXPORT LIST")));
        }
    }

    public String selectCompanyFromDownloadFilePopUp() {
        List<String> companyList = new ArrayList<>();
        companyList = (List<String>) this.commonHelpers.getValuefromContextStore("selectedCompanies");
        return companyList.get(0);
    }

    public void getAccountIds() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        List<WebElement> companyList = this.findElements(getByusingString(this.accountIds));
        List<WebElement> accountIds = this.findElements(getByusingString(this.accountIds + "/../div"));
        Map<String, List<String>> accountIdForUser = new HashMap<>();
        for (int i = 0; i < accountIds.size(); i++) {
            List<String> compnyIds = new ArrayList<>();
            String companyName = companyList.get(i).getAttribute("id");
            accountIds.get(i).click();
            List<WebElement> companyIdList = this.findElements(this.companyId);
            for (int j = 0; j < companyIdList.size(); j++) {
                String companyId = companyIdList.get(j).getAttribute("id");
                compnyIds.add(companyId);
            }
            accountIds.get(i).click();
            accountIdForUser.put(companyName, compnyIds);
        }
        this.commonHelpers.AddToContextStore("CompanyAccountIds", accountIdForUser);
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public boolean verifyDateFormat(List<String> columnNameList, String format) {
        String columnId = "";
        String dateFormatOnUIString = format;
        String dateFormatForCompariosn = "MM/dd/yyyy";
        boolean isDateflag = true;
        for (String columnName : columnNameList) {
            switch (columnName) {
                case "Delivered Date/Time":
                    columnId = "dateDelivered";
                    break;
                case "Scheduled Delivery Date/Time":
                    columnId = "scheduledDeliveryDateTimeBy";
                    break;
                case "Last Scan Time":
                    columnId = "latestScanDatetimeFusion";
                    break;
                case "Ship Date":
                    columnId = "shipDate";
                    break;
                default:
                    break;
            }
            List<WebElement> dateColumn = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));

            if (columnName.equals("latestScanDatetimeFusion")) {
                dateFormatOnUIString = "MMMM d, yyyy hh:mm";
            }

            for (WebElement date : dateColumn) {
                String dateVal = date.getText();
                String isDate = this.dateTimeUtils.isDate(dateVal, dateFormatOnUIString, dateFormatForCompariosn);
                if (isDate == null) {
                    isDateflag = false;
                }
            }
            if (!isDateflag) {
                break;
            }
        }

        return isDateflag;
    }

    public boolean dateFormatOnFilterBubble(String filterName) {
        boolean dateValidation = true;
        String filterValue = this.getText(this.getByusingString(String.format(this.filterBubleValue, filterName)));
        switch (filterName) {
            case "Delivered Date":
                String fromDate = filterValue.split(" - ")[0];
                String toDate = filterValue.split(" - ")[1];
                String date1 = this.dateTimeUtils.isDate(fromDate,
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "MM/dd/yyyy");
                String date2 = this.dateTimeUtils.isDate(toDate,
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "MM/dd/yyyy");
                if ((date1 == null) || (date2 == null)) {
                    dateValidation = false;
                }
                break;
            default:
                break;
        }
        return dateValidation;
    }

    public void filterLessThanThousandRecords() {
        boolean filtered = false;
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
//        String[] types = { "Intervened", "Payer", "Select" };
        String[] types = { "Intervened", "Payer" };
        for (int i = 0; i < types.length; i++) {
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Types")));
            this.JavaScriptClick(By.xpath(String.format(this.TypesOptionsCBXpath, types[i])));
            // this.JavaScriptClick(this.ShipmentTypeApply);
            // Localized Chages
            this.JavaScriptClick(By.xpath(String.format(this.ShipmentTypeApply, this.apply)));

            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            int viewCount = this.getViewCount();
//            String export = this.getAttributeValue(
//                    this.getByusingString(this.getXPathforAnyElementWithText("Export List") + "/../.."), "class");
            if (viewCount < 1000 ) {
                filtered = true;
                break;
            }
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.cancelFilterBubble, "Shipment Type"))));
            this.waitUntilNotVisible(this.loadingIndicator);
        }

        if (!filtered) {
            // this.FilterForShipments("Shipment Information-Appointment Delivery",
            // ["Yes"]);
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }
    public boolean verifyMtsbulkSearch(String trackNumbers, int dataCount, String inputData, String cellIndex){
        // this.JavaScriptClick(this.findElement(this.Searchicon));
        // this.JavaScriptClick(this.findElement(this.searchMultiTrack));
        boolean flag = true;
        String trackingId = this.commonHelpers.getValuefromContextStore(trackNumbers).toString().replaceAll("\\[|\\]",
                "");
        String trackingIds = trackingId.replaceAll(" ", "");
        List<String> allTrackids = new ArrayList<String>(Arrays.asList(trackingIds.split(",")));

        String updatedTrackingIds = allTrackids.get(0);
        for (int i = 1; i < dataCount; i++) {
            updatedTrackingIds = updatedTrackingIds + "," + allTrackids.get(i);
        }
        this.commonHelpers.AddToContextStore("updatedTrackingIds", updatedTrackingIds);
        //this.copyPasteText(this.getByusingString(String.format(this.searchMultiTrackNumber, cellIndex)),
        //          updatedTrackingIds);
        //modified code
        int startIndex= Integer.parseInt(cellIndex);
        if(startIndex>1){
            dataCount=dataCount+(startIndex-1);
        }
        if (dataCount > 50) {
            dataCount = 50;
        }
        for(int i=startIndex-1;i< dataCount;i++){
            this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber, i+1)),allTrackids.get(i));

        }
        //this.enterText(this.getByusingString(String.format(this.searchMultiTrackNumber,
        //  cellIndex)),
        // updatedTrackingIds);
        List<WebElement> elms = this.findElements(this.searchMultiInput);
        for (int i = 0; i < dataCount; i++) {
            String actTrackingId = elms.get(i).getAttribute("value");
            String expTrackingId = allTrackids.get(i);
            if (!actTrackingId.equals(expTrackingId)) {
                flag = false;
                break;
            }
        }
        if (inputData.contains("RESET")) {
            this.JavaScriptClick(By.xpath(this.getXPathforAnyElementWithText("RESET")));
            Assert.assertTrue(this.verifyFieldValue("Multiple Tracking Number", "empty"));
        }
        return flag;
    }



    public boolean verifyNewRowsInMtsForm(String dataRowCount, String action) {
        int rows = Integer.parseInt(dataRowCount);
        int totalRows = this.findElements(this.searchMultiInput).size();
        if (action.contains("RESET")) {
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
            Assert.assertTrue(this.verifyFieldValue("Multiple Tracking Number", "empty"));
            Assert.assertEquals(this.findElements(this.searchMultiInput).size(), 9);
        }
        if (rows >= 50) {
            return totalRows == 50;
        } else {
            return totalRows - rows == 3;
        }

    }

    public void verifySingleTrackingSearch(String action) {
        Assert.assertEquals(this.getAttributeValue(this.searchinput, "value"),
                ((String) this.commonHelpers.getValuefromContextStore("updatedTrackingIds")).split(",")[0]);
        Assert.assertTrue(this.elementIsDisplayed(this.searchMultiTrack, true));
        if (action.equals("RESET")) {
            this.JavaScriptClick(this.findElement(this.searchMultiTrack));
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
        }
    }

    public void verifyMTsThroughSingleTrackingIdSearch(String trackingId) {
        this.enterText(searchinput, trackingId);
        Assert.assertEquals(this.getAttributeValue(this.searchinput, "value"), trackingId);
        this.JavaScriptClick(this.findElement(this.searchMultiTrack));
        Assert.assertEquals(this.getAttributeValue(this.searchMultiInput, "value"), trackingId);
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
        Assert.assertTrue(this.verifyFieldValue("Multiple Tracking Number", "empty"));
        Assert.assertEquals(this.findElements(this.searchMultiInput).size(), 9);
    }

    public String SaveViewGetMsg(String viewName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(saveThisViewIcon);
        this.enterText(this.viewNameInput, viewName);
        this.clickOnElement(this.viewSaveButton);
        String msg = this.getText(this.viewLimitMsg);
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
        return msg;
    }

    public String shareView(String viewName, int viewCount) {
        String msg = "";
        this.clickMyView();
        for (int i = 0; i < viewCount; i++) {
            this.clickOnShareIconView(viewName);
            this.clickOnElement(By.xpath(this.getXPathforButton(" Share ")));
            if (i == 30) {
                msg = this.getText(this.viewLimitMsg);
                this.clickOnLastElement(this.getXPathforAnyElementWithText("Cancel"));
            } else {
                this.ValidateMessageOnResetPopup("HEADER", " VIEW successfully shared.");
                this.clickOnElement(this.viewSuccessfulMsgCloseButton);
                msg = " VIEW successfully shared.";
            }

        }
        return msg;
    }

    public boolean getSheetData(String sheetName, int columnInd, String fileType) throws IOException {
        String currentTime = new SimpleDateFormat("HH:mm z, MMM d, yyyy").format(new Date(System.currentTimeMillis()));
        switch (sheetName) {
            case "Summary":
                Map<String, String> actData = this.genericFuncObj.getValuesFromExcel(sheetName, columnInd);
                Assert.assertNotNull(actData.get("Report requested by:"));
                Assert.assertEquals(actData.get("Report created on:"), currentTime);
                Assert.assertEquals(actData.get("Note:"),
                        "Any secured content like account numbers is either masked or excluded.");
                // this.getText(this.filterApplied);
                Assert.assertNull(actData.get("Filters Applied"));
                Assert.assertEquals(actData.get("Shipment Status:"), "Delivered");
                break;
            case "Shipments":
                if (fileType.equals("CSV")) {
                    Map<String, String> Data = this.genericFuncObj.getColumnDataFromFile("Shipper Account Number");
                    Assert.assertFalse(Data.containsKey("Bill To (Duties)"));
                    Assert.assertFalse(Data.containsKey("Bill To (Transportation)"));
                    for (String columnValue : Data.values()) {
                        Assert.assertTrue(this.checkMaskedString(columnValue, 4));
                    }
                } else {
                    Map<String, List<String>> columnListData = this.genericFunctionObject
                            .getCompleteColumnData(sheetName);
                    Assert.assertFalse(columnListData.containsKey("Bill To (Duties)"));
                    Assert.assertFalse(columnListData.containsKey("Bill To (Transportation)"));
                    List<String> columnData = columnListData.get("Shipper Account Number");
                    if (columnData != null) {
                        for (String columnValue : columnData) {
                            Assert.assertTrue(this.checkMaskedString(columnValue, 4));
                        }
                    }
                }
                break;
            default:
                Assert.fail("You have passed a sheetName which is not valid for getSheetData function");
                break;
        }

        return true;
    }

    public boolean checkMaskedString(String str, int maskedChr) {
        boolean flag = true;
        String str1 = str.substring(0, maskedChr);
        for (int i = 0; i < maskedChr; i++) {
            if (str1.charAt(i) != '*') {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public Map<String, List<String>> getSelectedCompanies() {
        boolean flag = true;
        this.JavaScriptClick(this.CompanyAccddXpath);
        List<WebElement> companies = this.findElements(this.selectedCompanies);
        List<String> compnyIds = new ArrayList<>();
        // List<String> compnyNameList = new ArrayList<>();
        Map<String, List<String>> companyNameId = new HashMap<>();
        for (int i = 0; i < companies.size(); i++) {
            String companyName = companies.get(i).getAttribute("aria-label").replace("toggle ", "");
            // compnyNameList.add(companyName.replace("toggle ", ""));
            companies.get(i).click();
            List<WebElement> companyIdList = this.findElements(this.companyId);
            for (int j = 0; j < companyIdList.size(); j++) {
                String companyId = companyIdList.get(j).getAttribute("id");
                compnyIds.add(companyId);
            }
            companies.get(i).click();
            companyNameId.put(companyName, compnyIds);
        }
        this.commonHelpers.AddToContextStore("selectedCompanies", companyNameId);
        this.JavaScriptClick(this.CompanyAccddXpath);
        return companyNameId;
    }

    public void verifyCompanyAccountsDropdown() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(this.CompanyAccddXpath);
        Assert.assertEquals(this.getAttributeValue(this.companySearchInput, "placeholder"), "Search");
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        List<WebElement> options = this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span"));
        Assert.assertEquals(options.get(0).getText(), "COMPANY");
        Assert.assertEquals(options.get(1).getText(), "WORK GROUPS");
        this.findElements(this.getByusingString(this.companyWorkgroupChevron)).get(0).click();
        String expanded = this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/.."))
                .get(0).getAttribute("aria-expanded");
        Assert.assertEquals(expanded, "false");
        this.findElements(this.getByusingString(this.companyWorkgroupChevron)).get(1).click();
        expanded = this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/.."))
                .get(1).getAttribute("aria-expanded");
        Assert.assertEquals(expanded, "false");
        this.findElements(this.getByusingString(this.companyWorkgroupChevron)).get(0).click();
        expanded = this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/.."))
                .get(0).getAttribute("aria-expanded");
        Assert.assertEquals(expanded, "true");
        this.findElements(this.getByusingString(this.companyWorkgroupChevron)).get(1).click();
        expanded = this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/.."))
                .get(1).getAttribute("aria-expanded");
        Assert.assertEquals(expanded, "true");
        // Select companies and verify Work groups are disabled
        List<WebElement> accountIds = this
                .findElements(getByusingString(String.format(this.companyWorkgroupList, "Company")));
        for (int i = 0; i < accountIds.size(); i++) {
            this.ScrollIntoView(accountIds.get(i));
            accountIds.get(i).click();
        }
        Assert.assertTrue(this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                .get(1).getAttribute("class").contains("selection-not-allowed"));
        // Select workgroups and verify companies are disabled
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        List<WebElement> workGroups = this
                .findElements(getByusingString(String.format(this.companyWorkgroupList, "Work Groups")));
        String wg = workGroups.get(0).getText();
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(wg) + "/../div"));
        this.clickOnElement(By.xpath(String.format(this.workgroupAccountIds, wg)));
        Assert.assertTrue(this
                .findElements(this.getByusingString(this.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                .get(0).getAttribute("class").contains("selection-not-allowed"));

    }

    public void selectmultipleCompaniesWorkGroups(String accountType, DataTable companyMap) {
        Map<String, String> cmpMap = companyMap.asMap(String.class, String.class);
        this.clickOnElement(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        if (cmpMap.containsKey("all")) {
            this.ScrollIntoView(
                    this.findElements(getByusingString(String.format(this.companyWorkgroupList, accountType))).get(0));
            List<WebElement> accountIds = this
                    .findElements(getByusingString(String.format(this.companyWorkgroupList, accountType)));
            for (int i = 0; i < accountIds.size(); i++) {
                if(i%19==0)
                {
                    this.commonHelpers.thinkTimer(15000);
                }
                accountIds.get(i).click();
                DriverManager.getDrv().switchTo().activeElement().sendKeys(Keys.TAB);
                // accountIds.get(i).sendKeys(Keys.TAB);
            }
            // Verify Multiple Selected is displayed
            Assert.assertTrue(
                    this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("Multiple Selected")), true));
        } else {
            for (String company : cmpMap.keySet()) {
                String accountId = cmpMap.get(company);
                String[] idList = accountId.split(",");
                if (accountId.equals("all")) {
                    this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(company)));
                    Assert.assertTrue(
                            this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(company)), true));
                } else {
                    this.clickOnElement(this.getByusingString(String.format(this.companyChevronString, company)));
                    for (String id : idList) {
                        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(id)));
                    }
                    // Verify Company Name is displayed at top
                    Assert.assertTrue(this.elementIsDisplayed(By.xpath(this
                                    .getXPathforAnyElementWithText(company + "  (+" + Integer.valueOf(idList.length) + ")")),
                            true));
                }

            }
        }

        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
    }

    public boolean verifyCompanyAccountsSorting() {
        this.JavaScriptClick(this.CompanyAccddXpath);
        List<WebElement> companies = this.findElements(this.selectedCompanies);
        List<String> compnyNameList = new ArrayList<>();
        Map<String, List<String>> companyAccountIdMap = new HashMap<>();
        for (int i = 0; i < companies.size(); i++) {
            String companyName = companies.get(i).getAttribute("aria-label").replace("toggle ", "");
            compnyNameList.add(companyName);
            companies.get(i).click();
            List<WebElement> companyIdList = this.findElements(this.companyId);
            List<String> compnyIds = new ArrayList<>();
            for (int j = 0; j < companyIdList.size(); j++) {
                String checked = companyIdList.get(j).getAttribute("aria-checked");
                if (checked.equals("true")) {
                    String companyId = companyIdList.get(j).getAttribute("id");
                    compnyIds.add(companyId);
                }
            }
            companies.get(i).click();
            companyAccountIdMap.put(companyName, compnyIds);
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
        // Check company name sorting
        String previous = "";
        boolean CompnayNameSortingflag = true;
        for (String company : compnyNameList) {
            final String current = company;
            if (current.compareToIgnoreCase(previous) < 0) {
                CompnayNameSortingflag = false;
            }
            previous = current;
        }

        boolean CompnayIdSortingflag = true;
        for (String companyName : companyAccountIdMap.keySet()) {
            String previousS = "";
            List<String> idList = companyAccountIdMap.get(companyName);
            for (String id : idList) {
                final String current = id;
                if (current.compareTo(previousS) < 0) {
                    CompnayIdSortingflag = false;
                }
                previousS = current;
            }

        }

        return CompnayNameSortingflag && CompnayIdSortingflag;
    }

    public void verifyAppliedFilterCondition(DataTable filtrs) {
        Map<String, String> filters = filtrs.asMap(String.class, String.class);
        for (String filter : filters.keySet()) {
            List<String> expFilterValues = new ArrayList<>();
            for (String filt : filters.get(filter).split(",")) {
                String newValue = filt;
                if (filt.contains("ContextStore-")) {
                    if (filter.contains("Package Dimensions")) {
                        String[] arr = filt.split(":");
                        newValue = arr[0] + ": " + this.commonHelpers.getValuefromContextStore(arr[1]) + " "
                                + arr[2];
                        if (expFilterValues.size() > 0) {
                            expFilterValues.set(0, expFilterValues.get(0).replace(" (in.)", "") + " " + newValue);
                        }

                    } else {
                        newValue = (String) this.commonHelpers.getValuefromContextStore(filt);
                    }
                }
                expFilterValues.add(newValue.trim());
            }

            List<WebElement> filterCondns = this
                    .findElements(this.getByusingString(String.format(this.appliedFilterCoindition, filter)));
            for (WebElement elmnt : filterCondns) {
                String actFilterValue = elmnt.getText();
                Assert.assertTrue(expFilterValues.indexOf(actFilterValue) >= 0);
            }
        }
    }

    public void SearchAndSelectCompanyAccountDD(String CompanyName) throws Exception {
        if (CompanyName.contains("ContextStore-")) {
            CompanyName = (String) this.commonHelpers.getValuefromContextStore(CompanyName.split("-")[1]);
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, CompanyName);
        this.JavaScriptClick(By.xpath(String.format(this.companyNameinDD, CompanyName)));
        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        // this.api.SetCompanyContext(CompanyName);
    }

    public void SearchAndSelectCompanyWorkGroupDD(String WorkGroupName) throws Exception {
        if (WorkGroupName.contains("ContextStore-")) {
            WorkGroupName = (String) this.commonHelpers.getValuefromContextStore(WorkGroupName.split("-")[1]);
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, WorkGroupName);
        this.JavaScriptClick(By.xpath(String.format(this.workgroupNameinDD, WorkGroupName)));
        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        // this.api.SetCompanyContext(CompanyName);
    }

    public void verifyAccountsDropdownBtnStatus(DataTable table) throws Exception {
        this.JavaScriptClick(this.CompanyAccddXpath);
        Map<String, String> btnsMap = table.asMap(String.class, String.class);
        for (String btn : btnsMap.keySet()) {
            String valExp = btnsMap.get(btn);
            if (btn.contains("ContextStore-")) {
                btn = (String) this.commonHelpers.getValuefromContextStore(btn.split("-")[1]);
            }
            boolean actVal = valExp.equals("enabled") || valExp.equals("checked");
            if (btn.equals("RESET")) {
                Assert.assertEquals("RESET button", actVal, this.IsElementEnabled(this.resetCompaniesBy));
            } else if (valExp.contains("checked")) {
                Assert.assertEquals(btn, actVal, this
                        .findElement(By.xpath(this.getXPathforCheckboxWithText(btn) + "/../input"), true).isSelected());
            } else {
                Assert.assertEquals(btn, actVal,
                        this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText(btn))));
            }
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public String validateFutureDateInDateField(String dateCriteria, String filter) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString("Shipment Information"))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, "Shipment Information", filter))));
        this.JavaScriptClick(By.xpath(String.format(this.SelectSearchResults, dateCriteria)));
        this.clickOnLastElement(this.specificDateRangeFromLast);
        String flag = this.getAttributeValue(this.futureDate, "class");
        return flag.split(" ")[0];
    }

    public void verifyDefaultColumns() {
        Set<String> columns = new HashSet<>();
        List<WebElement> list1 = this.findElements(this.allColumns);
        for (WebElement column : list1) {
            String val = column.getText();
            if (!val.equals("")) {
                columns.add(column.getText());
            }
        }
        this.scrollHorizontalBarOnPage("900");
        List<WebElement> list2 = this.findElements(this.allColumns);
        for (WebElement column : list2) {
            String val = column.getText();
            if (!val.equals("")) {
                columns.add(column.getText());
            }
        }
        this.scrollHorizontalBarOnPage("900");
        List<WebElement> list3 = this.findElements(this.allColumns);
        for (WebElement column : list3) {
            String val = column.getText();
            if (!val.equals("")) {
                columns.add(column.getText());
            }
        }
        // columns.add(list3.get(list3.size()-1).getText());
        this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EDIT COLUMNS")));
        int shipment = Integer.valueOf(
                this.getText(this.getByusingString(this.getXPathforAnyElementWithText("Shipment ("))).split("\\(")[1]
                        .replace(")", ""));
        int shipper = Integer.valueOf(
                this.getText(this.getByusingString(this.getXPathforAnyElementWithText("Shipper ("))).split("\\(")[1]
                        .replace(")", ""));
        int receipient = Integer.valueOf(
                this.getText(this.getByusingString(this.getXPathforAnyElementWithText("Recipient ("))).split("\\(")[1]
                        .replace(")", ""));
        int totalColumnsExp = shipment + shipper + receipient;
        Assert.assertEquals("Default Columns Count", columns.size() - 1, totalColumnsExp);
        List<WebElement> selectedColumns = this.findElements(this.CheckedColumns);
        for (WebElement element : selectedColumns) {
            String expColumnName = element.findElement(this.getByusingString("./following-sibling::label")).getText();
            if (!expColumnName.equals("")) {
                Assert.assertTrue("Default Selected Columns", columns.contains(expColumnName.toUpperCase()));
            }

        }
    }

    public void iScrollToBringVisibleInView(String label) throws Throwable {
        ScrollToLabel(label);
    }

    public String verifyCompanyWorkGroupInAccountsDropdown(String company) {
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, company);
        String flag = this.getText(By.xpath(this.getXPathforCheckboxWithText(company)));
        this.JavaScriptClick(this.CompanyAccddXpath);
        return flag;
    }

    public void verifyWorkGroupRegion(String workgroup, String region) {
        this.JavaScriptClick(this.CompanyAccddXpath);
        Assert.assertEquals("true", this
                .getAttributeValue(By.xpath(String.format(this.selectedWorkGroupInRegion, workgroup)), "aria-checked"));
        Assert.assertEquals("true",
                this.getAttributeValue(By.xpath(String.format(this.selectedRegion, region)), "aria-expanded"));
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public void verifyWorkGroupCategories(List<String> regions) {
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        List<WebElement> regionsList = this.findElements(this.workGroupCategoriesRegion);
        for (WebElement webElement : regionsList) {
            String regn = this.getAttributeValue(webElement, "aria-label").replace("toggle ", "");
            Assert.assertTrue(regions.indexOf(regn) >= 0);
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    public void searchAndGetWorkGroupRegion(String workgroup, String region) {
        List<String> expRegionsList = Arrays.asList(region.split(","));
        this.JavaScriptClick(this.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.buildXpathForString("Clear")));
        this.enterText(this.companySearchInput, workgroup);
        List<WebElement> regionsList = this.findElements(this.workGroupCategoriesRegion);
        for (WebElement webElement : regionsList) {
            String regn = this.getAttributeValue(webElement, "aria-label").replace("toggle ", "");
            Assert.assertTrue(expRegionsList.indexOf(regn) >= 0);
        }
        this.JavaScriptClick(this.CompanyAccddXpath);
    }

    /**
     * Mouse hover any element and then get the text. please note text might come
     * over another elemen so we have used 2 xpaths
     *
     * @param element you can pass a name and then construct the xpath based on the
     *                name passed
     * @param text    the text which should appear when we hover over
     * @return boolean true if after hover over the text matches
     * @author Gaurav Khurana
     */
    public void mouseHoverAndValueValidation(String element, String text) {

        String xpathElm = null;
        String xpathElmHoverText = null;
        String icn = null;
        switch (element) {
            case "Select":
                icn = "digital-icn";
                break;
            case "Shipper":
                icn = "shipper-icn";
                break;
            case "Intervened":
                icn = "intervened-icn";
                break;
            case "SenseAware ID":
                icn = "senseawareid-icn";
                break;
            case "Payer":
                icn = "payer-icn";
                break;
        }
        if (this.getViewCount() == 0) {
            log.info("**WARNING** - Since the view count is 0, so hovering over is not possible hence skipping");
            return;
        }
        xpathElm = String.format(this.typesColIcon, icn);
        xpathElmHoverText = String.format(this.typesColIconHoverText, icn);
        this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
        assertThat(this.findElement(By.xpath(xpathElmHoverText)).getText()).contains(text);
        // moving the cursor elsewhere so it does not cause any problem
        this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
    }

    /**
     * Match the data in CER Number and CER Count columns
     *
     * @return boolean true if the data matches
     * @author Abhipriya De
     */

    public Boolean CompareCERNumberAndCountValues() {
        String cerNumberColumnId = "cerNumbers";
        String cerCountColumnId = "cerCount";
        int i = 0;
        HashSet<Boolean> flag = new HashSet<Boolean>();
        List<WebElement> cerNumberColumnValues;
        List<WebElement> cerCountColumnValues;
        boolean cerNumberFlag = this.elementIsDisplayed(By.xpath(String.format(this.columnHeader, "Case Number")));
        boolean cerCountFlag = this.elementIsDisplayed(By.xpath(String.format(this.columnHeader, "Case Count")));
        cerNumberColumnValues = this.findElements(By.xpath(String.format(this.columnValuesXpath, cerNumberColumnId)));
        cerCountColumnValues = this.findElements(By.xpath(String.format(this.columnValuesXpath, cerCountColumnId)));

        for (WebElement ele : cerNumberColumnValues) {
            String cerNumberValueCount = Integer.toString((Arrays.asList(ele.getText().split(","))).size());
            String cerCountValue = cerCountColumnValues.get(i).getText();
            if (cerCountValue.equals(cerNumberValueCount))
                flag.add(true);
            i++;
        }
        return cerNumberFlag && cerCountFlag && !flag.contains(false);
    }

    public void verifySearchOptions(DataTable table) {
        List<String> options = table.asList(String.class);
        this.JavaScriptClick(this.findElement(this.Searchicon));
        for (String option : options) {
            Assert.assertTrue("Global Search option on Shipment Overview Page is not displayed with : " + option,
                    this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(option))));
        }
    }

    public void SearchWithOptions(DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        boolean storeCount = false;
        String searchData = data.get("searchData");
        String searchType = data.get("searchType");
        String option = data.get("searchOption");

        if (searchData.contains("ContextStore")) {
            searchData = this.commonHelpers.getValuefromContextStore(searchData).toString();
        }
        if (searchType.equals("Partial tracking number")) {
            searchType = "Tracking Number";
            storeCount = true;
        }
        this.JavaScriptClick(this.findElement(this.Searchicon));
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(option)));
        if (storeCount) {
            this.enterText(searchinput, searchData.substring(0, 4));
        } else {
            this.enterText(searchinput, searchData);
        }
        this.waitUntilNotVisible(this.loadingIndicator);
        if (option.equalsIgnoreCase("Within Selected Accounts")) {
            if (searchType.equals("Exact tracking number")) {
                searchType = "Tracking Number";
                if (data.containsKey("resultCount")) {
                    if (data.get("resultCount").equals("0")) {
                        Assert.assertTrue(
                                this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Tracking Number"))));
                    }
                } else {
                    Assert.assertTrue(
                            this.elementIsDisplayed(By.xpath(String.format(searchViewDetailsLink, searchType))));
                }
            } else {
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Tracking Number"))));
            }
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Shipper Name"))));
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Recipient Name"))));
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Recipient City"))));
        } else {
            if (searchType.equals("Exact tracking number")) {
                searchType = "Tracking Number";
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchViewDetailsLink, searchType))));
            } else {
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(searchCountText, "Tracking Number"))));
            }
        }
        if (storeCount || data.containsKey("resultCount")) {
            this.commonHelpers.AddToContextStore("searchCount",
                    this.getText(By.xpath(String.format(searchCountText + "/span", "Tracking Number"))));
        }
        if (data.containsKey("resultCount")) {
            Assert.assertEquals(data.get("resultCount"), this.commonHelpers.getValuefromContextStore("searchCount"));
        }

        if (this.elementIsDisplayed(By.xpath(String.format(searchCountText, searchType)))) {
            if (searchType.equalsIgnoreCase("Recipient City"))
                this.clickOnElement(By.xpath(String.format(searchExactCountText, searchType)));
            else if (storeCount) {
                this.commonHelpers.AddToContextStore("searchCount",
                        this.getText(By.xpath(String.format(searchCountText, searchType))));
            }
            if (storeCount && option.equalsIgnoreCase("Within All Enabled Accounts")) {
                Assert.assertEquals("0", this.commonHelpers.getValuefromContextStore("searchCount"));
            }
            this.clickOnElement(By.xpath(String.format(searchCountText, searchType)));
        } else {
            this.clickOnElement(By.xpath(String.format(searchViewDetailsLink, searchType)));
        }
    }

    public boolean verifyColumnDataInFile(String columnName, DataTable table) throws IOException {
        boolean flag = false;
        Map<String, String> data = table.asMap(String.class, String.class);
        String fileFormat = data.get("fileType");
        Map<String, List<String>> columnListDataExcel = new HashMap<>();
        List<String> columnData = new ArrayList<>();
        Map<String, String> fileData = new HashMap<>();
        String trackingid = (String) this.commonHelpers.getValuefromContextStore("Tracking Number");
        String actColumnValue = "";
        String expValue = data.get("ContextStore-Tracking Number");
        if (fileFormat.equals("Excel")) {
            columnListDataExcel = this.genericFuncObj.getCompleteColumnData("Shipments");
            columnData = columnListDataExcel.get(columnName);
            actColumnValue = columnData.get(Integer.valueOf(data.get("columnIndex")));
        } else {
            fileData = this.genericFuncObj.getColumnDataFromFile(columnName);
            actColumnValue = fileData.get(trackingid);
        }
        if (expValue.equals("unwatched")) {
            if (!actColumnValue.contains("watched")) {
                flag = true;
            }
        } else {
            if (actColumnValue.contains(expValue)) {
                flag = true;
            }
        }
        return flag;
    }

    public void clickOnWatchUnwatchShipments(int shipmentCount, String action) {
        List<WebElement> watchlist = this.findElements(this.watchList);
        for (int i = 0; i < shipmentCount; i++) {
            String isWatched = watchlist.get(i).getAttribute("class");
            if (action.equals("watch") && isWatched.equals("star-icn")) {
                watchlist.get(i).click();
            } else if (action.equals("un-watch") && isWatched.equals("star-icn filled")) {
                watchlist.get(i).click();
            }
        }
    }

    public void selectDatetime(String[] dateCriteria, boolean fromDate, boolean toDate, boolean time,
                               boolean okBtnInCalendar) {
        if (fromDate) {
            log.info("Validating fromDate for " + dateCriteria[1]);
            if (dateCriteria[1].contains("Today")) {
                this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(dateCriteria[1]));
            } else {
                if (dateCriteria[1].contains("ContextStore")) {
                    this.commonHelpers.AddToContextStore("FromDate",
                            this.commonHelpers.getValuefromContextStore(dateCriteria[1]).toString());
                } else {
                    this.commonHelpers.AddToContextStore("FromDate", dateCriteria[1]);
                }
            }

            String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
            this.clickOnLastElement(this.specificDateRangeFromLast);
            while (!(this.getText(monthField).split(" ")[0].equals(fromArr[1])) && dateCriteria[1].contains("-")) {
                log.info("Month on calendar is " + this.getText(monthField).split(" ")[0]);
                log.info("Month we are matching with is " + fromArr[1]);
                this.clickOnElement(calenderLeftArrowPrev);
            }
            while (!(this.getText(monthField).split(" ")[0].equals(fromArr[1])) && dateCriteria[1].contains("+")) {
                log.info("Month on calendar is " + this.getText(monthField).split(" ")[0]);
                log.info("Month we are matching with is " + fromArr[1]);
                this.clickOnElement(calenderLeftArrowNext);
            }
            this.clickOnElement(By.xpath(String.format(dateXpath, fromArr[0])));
            if (time) {
                this.setTimeHoursMins(0, 0, 0);
            }
            if (okBtnInCalendar) {
                this.JavaScriptClick(By.xpath(this.CalenderOKButton));
            }
        }

        if (toDate) {
            log.info("Validating toDate for " + dateCriteria[2]);
            if (dateCriteria[2].contains("Today")) {
                this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate(dateCriteria[2]));
            } else {
                if (dateCriteria[2].contains("ContextStore")) {
                    this.commonHelpers.AddToContextStore("ToDate",
                            this.commonHelpers.getValuefromContextStore(dateCriteria[2]).toString());
                } else {
                    this.commonHelpers.AddToContextStore("ToDate", dateCriteria[2]);
                }
            }
            String[] toArr = this.commonHelpers.getValuefromContextStore("ToDate").toString().split(" ");
            if (toArr[0].contains("T")) {
                String date = this.dateTimeUtils.isDate(toArr[0].replace("T", " "), "YYYY-MM-DD hh:mm:ss",
                        "d MMMM yyyy EEEE");
                toArr = date.split(" ");
                this.commonHelpers.AddToContextStore("ToDate", date);
            }
            this.clickOnElement(this.specificDateRangeTo);
            while (!this.getText(monthField).split(" ")[0].equals(toArr[1])) {
                log.info("** Month on calendar is " + this.getText(monthField).split(" ")[0]);
                log.info("** Month we are matching with is " + toArr[1]);
                // if not plus then move left side in calendar otherwise right side if plus
                if (this.elementIsDisplayed(calenderLeftArrowPrev) && !dateCriteria[2].contains("+")) {
                    this.clickOnElement(calenderLeftArrowPrev);
                } else if (this.elementIsDisplayed(calenderLeftArrowNext) && dateCriteria[2].contains("+")) {
                    this.clickOnElement(calenderLeftArrowNext);
                }
            }
            this.clickOnElement(By.xpath(String.format(dateXpath, toArr[0])));
            if (time) {
                this.setTimeHoursMins(0, 0, 0);
            }
            if (okBtnInCalendar) {
                this.JavaScriptClick(By.xpath(this.CalenderOKButton));
            }
        }
    }
    /**
     * Select static date as per the string passed in d MMM yyyy EEEE format
     *
     * @return boolean true if the data matches
     * @author Mahendra Selukar
     */
    public void selectStaticDate(String dateStr, String dateType) {
        if (dateType.equals("fromDate")) {
            this.clickOnLastElement(this.specificDateRangeFromLast);
            this.commonHelpers.AddToContextStore("FromDate", dateStr);
        } else {
            this.clickOnElement(this.specificDateRangeTo);
            this.commonHelpers.AddToContextStore("ToDate", dateStr);
        }
        String[] fromArr = dateStr.split(" ");
        while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
            if (this.elementIsDisplayed(calenderLeftArrow)) {
                this.clickOnElement(calenderLeftArrow);
            }
        }
        this.clickOnElement(By.xpath(String.format(dateXpath, fromArr[0])));
    }

    public boolean verifyIfColumDataIsUpdated(DataTable table) {
        boolean returnflag = true;
        String columnId = "";
        Map<String, String> columns = table.asMap(String.class, String.class);
        this.waitUntilNotVisible(this.loadingIndicator, 10);
        for (String columnName : columns.keySet()) {
            String expColumnValue = columns.get(columnName);
            switch (columnName) {
                case "Cold Storage Temp - Min (°C)":
                    columnId = "coldStorageTemperatureMinC";
                    break;
                case "Cold Storage Temp - Max (°C)":
                    columnId = "coldStorageTemperatureMaxC";
                    break;
                case "Delivered Date":
                    columnId = "dateDelivered";
                    break;
                case "Dry Ice Added (Kg)":
                    columnId = "dryIceAddedKgs";
                    break;
                case "Dry Ice Added (Lbs)":
                    columnId = "dryIceAddedLbs";
                    break;
                case "Exception Reason":
                    columnId = "exceptionReason";
                    break;
                case "Gel Pack Quantity":
                    columnId = "gelPackQuantity";
                    break;
                case "Workgroup":
                    columnId = "workgroups";
                    break;
                case "Delay Reason":
                    columnId = "delayedExceptionReason";
                    break;
            }
            List<WebElement> actColumnValues = this
                    .findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
            List<WebElement> trackingNumbersList = this
                    .findElements(By.xpath(String.format(this.columnValuesXpath, "trackingNumber")));

            int counter = trackingNumbersList.size();
            for (int i = 0; i < counter; i++) {
                String actColumnValue = actColumnValues.get(i).getText();
                if (!(expColumnValue == null)) {
                    if (expColumnValue.equals("")) {
                        if (!actColumnValue.equals("") && actColumnValue.contains("Unspecified Reason")) {
                            returnflag = false;
                            break;
                        }
                    }
                } else {
                    if (actColumnValue.equals("")) {
                        returnflag = false;
                        break;
                    }
                }
            }
        }
        return returnflag;

    }

    public boolean verifyFilterOptions(String filterName, DataTable table) {
        List<String> options = table.asList(String.class);
        String inpt = "/../input";
        for (int i = 0; i < options.size(); i++) {
            // verify if options are mutually exclusive
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(options.get(i))));
            // Validate other options are disabled
            for (int j = 0; j < options.size(); j++) {
                if (i != j) {
                    if (options.get(i).equals("Yes") || options.get(i).equals("No")) {
                        Assert.assertFalse(this
                                .IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText(options.get(j)) + inpt)));
                    } else {
                        if (options.get(j).equals("Yes") || options.get(j).equals("No")) {
                            Assert.assertFalse(this.IsElementEnabled(
                                    By.xpath(this.getXPathforCheckboxWithText(options.get(j)) + inpt)));
                        } else {
                            Assert.assertTrue(this.IsElementEnabled(
                                    By.xpath(this.getXPathforCheckboxWithText(options.get(j)) + inpt)));
                        }
                    }
                }
            }
            if (options.get(i).equals("Yes") || options.get(i).equals("No")) {
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(options.get(i))));
            }
        }
        // Verify Placeholder on search box
        if (filterName.equals("Gel Pack Quantity")) {
            Assert.assertEquals("Search Value in filter", "e.g. 10, 1 etc..",
                    this.getAttributeValue(
                            By.xpath(String.format(this.filterSearchBar, "Shipment Information", filterName)),
                            "placeholder"));
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific Quantity")));
        } else if (!(filterName.equals("Exception Reason") || filterName.equals("Workgroup"))) {
            Assert.assertEquals("Search Value in filter", "e.g. 10.00, 1.00 etc..",
                    this.getAttributeValue(
                            By.xpath(String.format(this.filterSearchBar, "Shipment Information", filterName)),
                            "placeholder"));
            if (filterName.equals("Dry Ice Added")) {
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific Amount (LBS)")));
            } else {
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific Temperature")));
            }
        } else {
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(options.get(2))));
        }
        return true;
    }

    /**
     * This will take the column Name and would save the first row value
     * in the context store from the shipment overview page
     *
     * @param table List of columns whose value we want to store
     * @author Gaurav Khurana
     */
    public void saveValueFromFirstShipmentRecord(DataTable table) {
        this.waitUntilNotVisible(this.loadingIndicator);
        List<String> columns = table.asList(String.class);
        for (String col : columns) {
            String elmValue = this.findElement(this.getByusingString(String.format(firstRowShipment, col))).getText();
            this.commonHelpers.AddToContextStore(col, elmValue);
        }
    }

    public void selectParentChildFilters(String filter) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = filter.split("-")[0];
        String ChildFilter = filter.split("-")[1];
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
    }

    public void verifySenseAwareMobileIdNavigation(String id) {
        String sensewareId = id;
        if (this.commonHelpers.verifyKeyInContextStore("senseAwareJourneyId")) {
            sensewareId = (String) this.commonHelpers.getValuefromContextStore("senseAwareJourneyId");
        }
        this.clickOnElement(By.xpath(this.getXPathforlink(sensewareId)));
        assertThat(this.switchToTabAndGetPageTitle(this.senseAwareLoginPage))
                .withFailMessage("SenseAware Login page not dispalyed")
                .isEqualToIgnoringCase("Login");
    }

    public void validateColumnBasicsValidation(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "COLUMNS":
                    this.waitUntilVisible(this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)))).isTrue();
                    break;
                case "The following combinations are not allowed":
                    this.waitUntilVisible(this.searchForColumnInfoText);
                    localisedValue = localisedValue.replace(" ", " ");
                    softly.assertThat(this.getText(this.searchForColumnInfoText)).isEqualTo(localisedValue);
                    break;
                case "Search for Columns":
                    softly.assertThat(this.getAttributeValue(searchForColumnInput, "placeholder"))
                            .isEqualTo(localisedValue);
                    break;
                case "Shipment":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.tabsUnderColumns, localisedValue)))).isTrue();
                    break;
                case "Shipper":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.tabsUnderColumns, localisedValue)))).isTrue();
                    break;
                case "Recipient":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.tabsUnderColumns, localisedValue)))).isTrue();
                    break;
                case "My Shipments":
                    softly.assertThat(this.elementIsDisplayed(
                                    this.getByusingString(String.format(this.homePage.topNavigation, localisedValue))))
                            .isTrue();
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public boolean validateBulkOption(String option, DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        List<String> localisedValues = new ArrayList<>();
        String localised;
        for (String value : allValues) {
            localised = this.genericFunctionObject.getLocalizedValue(value);
            localisedValues.add(localised);
        }
        return this.verifyRightClickOptions(option, localisedValues);
    }

    public void validateHoverOverMenuMyShipmentsLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue, xpathElm, bulkLocalisedValue = null;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "BULK":
                    bulkLocalisedValue = localisedValue;
                    String BulkValue = this.getText(By.xpath(String.format(this.KBulk,bulkLocalisedValue)));
                    Assert.assertEquals(bulkLocalisedValue,BulkValue);
                    break;
                case "Custom View":
                    xpathElm = String.format(this.hoverOverMenuIcon, "save-view-icn");
                    this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.hoverOverMenuText, localisedValue)))).isTrue();
                    // moving the cursor elsewhere so it does not cause any problem
                    this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
                    break;
                case "Reset":
                    xpathElm = String.format(this.hoverOverMenuIcon, "reset-icn");
                    this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.hoverOverMenuText, localisedValue)))).isTrue();
                    // moving the cursor elsewhere so it does not cause any problem
                    this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
                    break;
                case "EXPORT LIST":
                    xpathElm = String.format(this.hoverOverMenuIcon, "download-icn");
                    this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.hoverOverMenuText, localisedValue)))).isTrue();
                    // moving the cursor elsewhere so it does not cause any problem
                    this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
                    break;
                case "Filter shipments to {0} or less to enable Export List":
                    localisedValue = localisedValue.replace("{0}", "60,000");
                    xpathElm = String.format(this.hoverOverMenuIcon, "download-icn");
                    this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.hoverOverMenuText, localisedValue)))).isTrue();
                    // moving the cursor elsewhere so it does not cause any problem
                    this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
                    break;
                case "Please select at least one shipment.":
                    xpathElm = String.format(this.bulkChevronText, bulkLocalisedValue);
                    this.Mouse_MoveToElement(this.findElement(By.xpath(xpathElm)));
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.hoverOverMenuText, localisedValue)))).isTrue();
                    // moving the cursor elsewhere so it does not cause any problem
                    this.Mouse_MoveToElement(this.findElement(By.xpath(rowXPath)));
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public void saveValueInContextstore(String valueToBeSaved, String variable) {
        int count = 0;
        if (valueToBeSaved.equalsIgnoreCase("Viewing Count")) {
            count = Integer.parseInt(this.getViewingCount());
        } else if (valueToBeSaved.equalsIgnoreCase("SHIPMENTS IN PROGRESS")) {
            count = this.homePage.getNumberFromPurpleBarHomePage(valueToBeSaved);
        }
        log.info("The Value for " + valueToBeSaved + " is " + count);
        this.commonHelpers.AddToContextStore(variable, count);
    }

    public void validateFedexAndTNTCount(DataTable dataTable) {
        List<String> data = dataTable.asList(String.class);
        //Adding + or -1 buffer to the count due to Streaming Data
        assertThat(Integer.parseInt(this.commonHelpers.getValuefromContextStore(data.get(2)).toString()))
                .withFailMessage("Individual Count for Fedex + TNT != combined count")
                .isBetween(Integer.parseInt(this.commonHelpers.getValuefromContextStore(data.get(0)).toString())
                        + Integer.parseInt(this.commonHelpers.getValuefromContextStore(data.get(1)).toString()) -1,Integer.parseInt(this.commonHelpers.getValuefromContextStore(data.get(0)).toString())
                        + Integer.parseInt(this.commonHelpers.getValuefromContextStore(data.get(1)).toString())+1);
    }

    public void typesOptionsValidation(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();

        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            softly.assertThat(
                            this.elementIsPresent(this.getByusingString(String.format(TypesOptionsCBXpath, localisedValue))))
                    .isTrue();
        }
        softly.assertAll();

    }

    public void filterBubbleValidation(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // separating filter and its values
        for (String key : dataFilters.keySet()) {
            filterBubbleVisible(key, dataFilters.get(key).split(","));
        }
    }

    public void filterBubbleValidationWithUserChoice(String condition,DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // separating filter and its values
        for (String key : dataFilters.keySet()) {
            filterBubbleValidationForLocalization(key, dataFilters.get(key).split(","),condition);
        }
    }



    public void validateColumnNamesTranslationinShipmentsList(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            this.scrollHorizontalBarOnPage("-4000");
            if (this.elementIsDisplayed(By.xpath(String.format(columnHeader, localisedValue)))) {
                softly.assertThat(
                                this.elementIsPresent(
                                        this.getByusingString(String.format(columnHeader, localisedValue))))
                        .isTrue();
            } else {
                while (!waitUntilVisible(By.xpath(String.format(columnHeader, localisedValue))))
                    this.scrollHorizontalBarOnPage("700");
                softly.assertThat(
                                this.elementIsPresent(
                                        this.getByusingString(String.format(columnHeader, localisedValue))))
                        .isTrue();
            }
        }
        softly.assertAll();
    }

    public void validateColumnNamesTranslationinColumnsMenu(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();

        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            if (this.elementIsDisplayed(By.xpath(String.format(columnLabelXpath, localisedValue)))) {
                softly.assertThat(
                                this.elementIsPresent(
                                        this.getByusingString(String.format(columnLabelXpath, localisedValue))))
                        .isTrue();
            } else {
                this.ScrollIntoView(this.findElement(By.xpath(String.format(columnLabelXpath, localisedValue))));
                softly.assertThat(
                                this.elementIsPresent(
                                        this.getByusingString(String.format(columnLabelXpath, localisedValue))))
                        .isTrue();
            }
        }
        softly.assertAll();
    }

    public void filterBubbleVisible(String filter, String[] filteredValues) {
        String localizedFilterValue = "";
        // localizing the filter and its values before doing the validation
        String localizedFilter = this.genericFuncObj.getLocalizedValue(filter);
        for (String value : filteredValues) {
            localizedFilterValue = this.genericFuncObj.getLocalizedValue(value);
            assertThat(this.elementIsDisplayed(this
                            .getByusingString(String.format(filterBubbleXpath, localizedFilterValue, localizedFilter))))
                    .isTrue();
        }
    }

    public void filterBubbleValidationForLocalization(String filter, String[] filteredValues,String condition) {
        String localizedFilterValue = "";
        // localizing the filter and its values before doing the validation
        String localizedFilter = this.genericFuncObj.getLocalizedValue(filter);
        for (String value : filteredValues) {
            if(!condition.equals("No")){
                localizedFilterValue = this.genericFuncObj.getLocalizedValue(value);
            }
            assertThat(this.elementIsDisplayed(this
                    .getByusingString(String.format(filterBubbleXpath, localizedFilterValue, localizedFilter))))
                    .isTrue();
        }
    }

    public void validateRecipientAddressText(String value) {

        String recipientPostal = this.fetchRecipientPostalText();
        this.scrollHorizontalBarOnPage("900");
        String recipientStateProvince = this.fetchRecipientStateProvinceText();
        this.scrollHorizontalBarOnPage("900");
        String recipientStreet = this.fetchRecipientStreetText();
        String recipientCity = this.fetchRecipientCityText();
        String recipientCountryTerritory = this.fetchRecipientCountryTerritotyText();
        String recipientFullAddress = this.fetchRecipientFullAddressText(value);

        String[] address = recipientFullAddress.split(recipientCity);

        String city = address[0].toString().concat(recipientCity);
        boolean cityExists = recipientFullAddress.contains(city);

        Assert.assertTrue("Recipient city exists in address",cityExists);
        Assert.assertTrue("Recipient street exists in address",address[0].contains(recipientStreet));
        Assert.assertTrue("Postal code exists in Address",address[1].contains(recipientPostal));

//        String concatedValue;
//        if(recipientCountryTerritory.equals("GB"))
//        {
//            recipientCountryTerritory="UNITED KINGDOM";
//            concatedValue=recipientStreet+","+" "+recipientCity+","+" "+recipientCountryTerritory+","+" "+recipientPostal;
//        }
//        else if (recipientCountryTerritory.equals("US"))
//        {
//            recipientCountryTerritory="UNITED STATES OF AMERICA";
//            concatedValue=recipientStreet+","+" "+recipientCity+","+" "+recipientCountryTerritory+","+" "+recipientPostal;
//        }
//        else
//        {
//            concatedValue = recipientStreet + "," + " " + recipientCity + "," + " " + recipientCountryTerritory + "," + " " + recipientPostal;
//        }
//        Assert.assertEquals(concatedValue,recipientFullAddress);

    }


    public String fetchRecipientFullAddressText(String value) {
        return this.findElement(By.xpath(String.format(recipientFullAddress, value))).getText();
    }

    public String fetchRecipientStreetText() {
        return this.findElement(By.xpath(recipientStreet)).getText();
    }

    public String fetchRecipientCityText() {
        return this.findElement(By.xpath(recipientCity)).getText();
    }

    public String fetchRecipientStateProvinceText() {
        return this.findElement(By.xpath(recipientStateProvince)).getText();
    }

    public String fetchRecipientCountryTerritotyText() {
        return this.findElement(By.xpath(recipientCountryTerritory)).getText();
    }

    public String fetchRecipientPostalText() {
        return this.findElement(By.xpath(recipientPostal)).getText();
    }

    public String fetchTimeInNetworkText() {
        return this.findElement(By.xpath(timeInNetwork)).getText();
    }

    public void SelectFilterForShipments(String status, String[] filterCriteria, String inputDate) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));

        for (String filter : filterCriteria) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter, filter))));
            switch (status.split("-")[1]) {
                case "Delivered Date":
                    this.selectDropdown(By.xpath(
                                    String.format(selectDaysDateTimeBox, ParentFilter, ChildFilter, filter)),
                            "text", inputDate);
                    boolean checkSpecificdateflag = this.findElement(By.xpath(String.format(specificDate)))
                            .isSelected();// this.IsElementEnabled(By.xpath(String.format(specificDate)));
                    if (checkSpecificdateflag) {
                        Assert.assertTrue("Specific date is Enabled", checkSpecificdateflag);
                    }
                    break;
                case "Commit Time":
                    this.selectDropdown(
                            By.xpath(String.format(selectDays, ParentFilter, ChildFilter, filter)),
                            "text", inputDate);
                    break;
                case "Ship Date":
                    if (!inputDate.equals("1")) {
                        WebElement dropdownElement = this.findElement(By.xpath(this.shipDateDropdownFilter));
                        dropdownElement.sendKeys(inputDate);
                    }
                    break;
                case "Label Created Date":
                    if (!inputDate.equals("1")) {
                        By dropdownElement = By.xpath(this.shipDateDropdownFilter);
                        selectDropdown(dropdownElement, "text", inputDate);
                    }
                    break;
                case "Time In Network":
                    if (!inputDate.equals("1")) {
                        WebElement dropdownElement = this.findElement(By.xpath(this.timeInNetworkDropdownFilter));
                        dropdownElement.sendKeys(inputDate);
                    }
                    break;

            }
        }

    }

    public Boolean SelectFilterforUIwithHour(String cancelOrApply, DataTable dataTable, String date) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.SelectTimeInNetworkValues(key, dataFilters.get(key).split(":"), date);
        }
        Boolean checkFilter = false; // = this.findElements(dotsXpath).size() > 0;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "Is within":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFiltersHour, key.split("-")[1], "Is within", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Is within filter is not displayed", checkFilter);
                            break;
                    }
                }

            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }
        /*
         * if (this.getViewCount() == 0)
         * this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
         */
        return checkFilter;
    }

    public void SelectTimeInNetworkValues(String status, String[] filterCriteria, String inputDate) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
        this.JavaScriptClick(this.findElement(
                this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));

        for (String filter : filterCriteria) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.durationxpath, ParentFilter, ChildFilter, filter))));
            switch (status.split("-")[1]) {
                case "Time In Network":
                    if (!inputDate.equals("1")) {
                        WebElement dropdownElement = this.findElement(By.xpath(this.durationInNetworkDropdownFilter));
                        dropdownElement.sendKeys(inputDate);
                    }
                    break;
            }
        }
    }

    public void validateTimeInNetworkText(String value) {
        String timeInNetworkText = this.fetchTimeInNetworkText();
        if(timeInNetworkText.equals(""))
        {
            Assert.assertTrue("None exists: ", timeInNetworkText.equals(""));
        }
        else
        {
            String[] timeInNetwork = timeInNetworkText.split(" ");
            Assert.assertTrue("Days  exists: ",timeInNetwork[0].contains("d"));
            Assert.assertTrue("Hour exists: ",timeInNetwork[1].contains("hr"));
            Assert.assertTrue("Mins exists: ",timeInNetwork[2].contains("min"));
        }
    }

    public void clickCountryOrTerritoryDropdown() {
        this.JavaScriptClick(this.countryOrTerritoryDropdown);
    }

    public void validateCountryOrTerritoryDropdownCheckbox(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        List<String> companies = new ArrayList<String>();
        List<String> checkboxStatus = new ArrayList<String>();
        //this.JavaScriptClick(this.countryOrTerritoryDropdown);
        for (String key : dataFilters.keySet()) {
            companies = Arrays.asList(key.split(":"));
            checkboxStatus = Arrays.asList(dataFilters.get(key).split(":"));
            String companyExp = companies.get(0);
            if (companies.get(0).contains("ContextStore-")) {
                companyExp = (String) this.commonHelpers.getValuefromContextStore(companyExp.split("-")[1]);
            }
            //this.JavaScriptClick(By.xpath(String.format(this.countryOrTerritoryLabelInDD, companyExp)));
            for (String company : companies) {
                String companyToCheck = company;
                if (company.contains("ContextStore-")) {
                    companyToCheck = (String) this.commonHelpers.getValuefromContextStore(company.split("-")[1]);
                }
                if (checkboxStatus.get(companies.indexOf(company)).equalsIgnoreCase("checked")) {
                    Assert.assertTrue("Company:" + key + " is unchecked",
                            this.getAttributeValue(By.xpath(String.format(this.countryOrTerritoryCheckboxinDD, companyToCheck)),
                                    "aria-checked").equalsIgnoreCase("true"));
                } else if (checkboxStatus.get(companies.indexOf(company)).equalsIgnoreCase("unchecked")) {
                    Assert.assertTrue("Company:" + key + " is checked",
                            this.getAttributeValue(By.xpath(String.format(this.countryOrTerritoryCheckboxinDD, companyToCheck)),
                                    "aria-checked").equalsIgnoreCase("false"));
                }
            }

        }
        //this.JavaScriptClick(this.CompanyAccddXpath);

    }


    public boolean VerifyDropdownValuesVisible(DataTable dataTable) {
        boolean flag = true;
        List<String> values = dataTable.asList(String.class);
        for (String val : values) {
            if (this.elementIsDisplayed(By.xpath(String.format(countryOrTerritoryLabelInDD, val)))) {
                flag = true;
            } else {
                flag = false;
                log.error(" This dropdown value is not Visible --> " + val);
                break;
            }
        }
        return flag;
    }

    public boolean validateDropdownSearchBoxTextAndIcon(String expectedPlaceholderText) {
        boolean flag = false;

        String actualPlaceholderText = this.getAttributeValue(searchForPlaceholderText,
                "placeholder");
        if ((this.elementIsDisplayed(this.dropdownSearchIcon))
                && (this.elementIsDisplayed(this.searchForPlaceholderText))
                && actualPlaceholderText.equals(expectedPlaceholderText)) {
            log.info("Placeholder text and search icon is displayed");
            flag = true;
        }

        return flag;
    }

    public void selectMultipleValuesFromDD(DataTable dataTable) throws Exception {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        this.JavaScriptClick(this.clear);
        // Clearing if any companies are already selected

        for (String key : dataFilters.keySet()) {
            // Searching the company, so it appears at the top and becomes clickable
            this.enterText(companySearchInput, key);
            this.JavaScriptClick(By.xpath(String.format(this.countryOrTerritoryCheckboxinDD, key)));
        }
    }

    public boolean isCountryTerritoryValuePresent(DataTable dataTable) {
        Set<Boolean> result = new HashSet<>();
        List<String> filters = dataTable.asList(String.class);
        String value = "";
        for (String filter : filters) {
            switch (filter) {
                case "CHINA":
                    value = "CN";
                    break;
                case "INDIA":
                    value = "IN";
                    break;
                case "UNITED STATES OF AMERICA":
                    value = "US";
                    break;
                case "ITALY":
                    value = "IT";
                    break;
                case "MEXICO":
                    value = "MX";
                    break;

            }
            result.add(this.elementIsDisplayed(By.xpath(String.format(this.countryTerritoryShipmentXpath, value))));
        }
        return !result.contains(false);
    }

    public void clickAccountDropdowninRR() {
        this.JavaScriptClick(this.CompanyAccddXpathRR);
    }

    public void SelectMultipleCompanyAccountDDRR(DataTable dataTable) throws Exception {
        List<String> dataOptions = dataTable.asList(String.class);
        this.JavaScriptClick(this.CompanyAccddXpathRR);
        for (String key : dataOptions) {
            this.enterText(companySearchInput, key);
            this.JavaScriptClick(By.xpath(String.format(this.companyNameinDDRR, key)));
        }

        // Clearing if any companies are already selected
        int number = this.getCompanyCountFromDropdownText(this.getCompanyDropdownText());
        log.info("The total number of accounts under company selected are " + number);

        // cannot click on apply if accounts are more than 250
        if (number > 250) {
            // Then the below button should be disabled
            Assert.assertFalse(" 'Apply' button is enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Apply "))));
            Assert.assertFalse(" 'Set As default' button is enabled ",
                    this.IsElementEnabled(By.xpath(this.getXPathforButton("Set As Default "))));

            // Also validating the message for maximum accounts
            Assert.assertEquals(this.getText(this.CompanyAccDefaultMessage), Constants.maxAccountErrorMsg);

            // Since in this condition we should not try to click on apply button as its
            // disabled as expected
            return;
        }

        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
    }

    public void verifyAccountsDropdownBtnStatusRR(DataTable table) throws Exception {
        Map<String, String> btnsMap = table.asMap(String.class, String.class);
        for (String btn : btnsMap.keySet()) {
            String valExp = btnsMap.get(btn);
            if (btn.contains("ContextStore-")) {
                btn = (String) this.commonHelpers.getValuefromContextStore(btn.split("-")[1]);
            }
            boolean actVal = valExp.equals("enabled") || valExp.equals("checked");
            if (btn.equals("RESET")) {
                Assert.assertEquals("RESET button", actVal, this.IsElementEnabled(this.resetCompaniesBy));
            } else if (valExp.contains("checked")) {
                Assert.assertEquals(btn, actVal, this
                        .findElement(By.xpath(this.getXPathforCheckboxWithText(btn) + "/../input"), true).isSelected());
            } else {
                Assert.assertEquals(btn, actVal,
                        this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText(btn))));
            }
        }
    }
    public void verifySearchedResultsOfContainerColumns(List<String>listOfValuesToBeSearched){
        for(String string:listOfValuesToBeSearched){
            this.enterText(By.xpath(String.format(containerConsInputTextSearchBox,"Search e.g. 12345678")),string);
            this.commonHelpers.thinkTimer(6000);
            if(getCount(noResultsFoundText)>=1){
                continue;
            }
            else{
                List<WebElement>listOfSearchedValues=this.findElements(dropDownCheckBoxes);
                for(WebElement element:listOfSearchedValues){
                    String value=getAttributeValue(element,"value");
                    Assert.assertEquals(true,value.contains(string));
                }
            }
        }
    }


    public Boolean SelectFilter(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.clickOnElement(filterChevron);
        this.JavaScriptClick(this.findElement(filterChevron));
        this.Mouse_MoveToElement(this.filterCancelButton);
        boolean status = false;
        for (String key : dataFilters.keySet()) {
            if (key.equalsIgnoreCase("Shipment Information-Industry Vertical")) {
                this.FilterForShipment(key, dataFilters.get(key).split(","));
                return status = true;
            } else {
                this.FilterForShipment(key, dataFilters.get(key).split(":"));
                return status = true;
            }
        }
        return status;
    }

    public void FilterForShipment(String status, String[] filterCriteria) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            // this.clickOnElement(filterChevron);
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        log.info("Parent Filter --> " + ParentFilter);
        log.info("Child Filter  --> " + ChildFilter);

        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(status.split("-")[0]))));
        if (ChildFilter.contains("Cold Storage Temp")) {
            ChildFilter = String.join("-", ChildFilter, status.split("-")[2]);
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, status.split("-")[0], ChildFilter))));
        } else {
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
        }
    }

    public void findRecordsForExportIcnEnabled(String filter_option){
        this.selectFilterOptions(filter_option);
        int countOfCheckBoxes=getCount(accountAlias.accountAliasCheckBox);
        List<WebElement>listOfElements=this.findElements(accountAlias.accountAliasCheckBox);
        JavaScriptClick(filterCancelButton);
        int iterator=1;
        for(WebElement element:listOfElements){
            if(iterator==1) {
                iterator++;
                continue;
            }
            this.selectFilterOptions(filter_option);
            String accountNumber=getAttributeValue(By.xpath(String.format(checkBoxIndex,iterator)),"value");

            String text="";
            if(!getText(By.xpath(String.format(aliasNameWRTAccNum,accountNumber))).contains("Add Alias")){
                text=accountNumber+" | "+getText(By.xpath(String.format(aliasNameWRTAccNum,accountNumber)));
            }
            else{
                text=accountNumber;
            }
            JavaScriptClick(By.xpath(String.format(checkBoxIndex,iterator)));
            JavaScriptClick(By.xpath(String.format(applyButton,"APPLY")));
            this.Mouse_MoveToElement(exportArrowBtn);
            if(getCount(exportIcnBtn)>0){
                this.commonHelpers.AddToContextStore("AccountNumExport",text);
                break;
            }
            JavaScriptClick(resetBtn);
            JavaScriptClick(resetPopup);
            iterator++;
        }
        if(!this.commonHelpers.verifyKeyinContextStore("AccountNumExport")){
            this.commonHelpers.AddToContextStore(Constants.skipSteps,true);
        }
    }
    public String[][] getCSVData(String sheetname,int index) throws IOException, CsvException {
        File filpath = advisoryPage.getLastModified(System.getProperty("user.home") + "\\Downloads");
        FileReader fileReader = new FileReader(filpath.toString());
        CSVReader csvReader = new CSVReaderBuilder(fileReader).withSkipLines(0).build();
        List<String[]> allData = csvReader.readAll();
        String[][] data = new String[allData.size()][];
        allData.toArray(data);
        return data;
    }
    public String[][] getExcelData(String sheetname,int index) throws IOException {
        File filpath = advisoryPage.getLastModified(System.getProperty("user.home") + "\\Downloads");
        FileInputStream fs = null;
        XSSFWorkbook wb;
        fs = new FileInputStream(filpath.toString());
        wb = new XSSFWorkbook(fs);
        XSSFSheet sheet;
        if(sheetname !="")
            sheet = wb.getSheet(sheetname);
        else sheet = wb.getSheetAt(index);
        int lastrow = sheet.getLastRowNum();
        int lastcol = sheet.getRow(0).getLastCellNum();
        log.info("Last row : " + lastrow);
        String[][] excelData = new String[lastrow + 1][lastcol];

        for (int erow = 0; erow <= lastrow; erow++) {
            Row rb = sheet.getRow(erow);
            for (int ecolumn = 0; ecolumn < lastcol; ecolumn++) {
                Cell cb = rb.getCell(ecolumn);
                excelData[erow][ecolumn] = cb.getStringCellValue();

            }
        }
        return excelData;
    }
    public void validateExcelColumn(String columnNumber,String sheetName) throws IOException {
        int colnum=Integer.parseInt(columnNumber);
        String colValue=(String) this.commonHelpers.getValuefromContextStore("AccountNumExport");
        StringBuilder sb=new StringBuilder(colValue);
        for(int iterator=0;iterator<4;iterator++){
            sb.setCharAt(iterator,'*');
        }
        String[][] excelData=getExcelData(sheetName,1);
        int lrow=excelData.length;
        for(int iterator=1;iterator<lrow-1;iterator++){
            Assert.assertEquals(true,sb.toString().contains(excelData[iterator][colnum]));
        }
    }
    public void validateCSVDataColumn(String columnNumber) throws IOException, CsvException {
        int colnum=Integer.parseInt(columnNumber);
        String colValue=(String) this.commonHelpers.getValuefromContextStore("AccountNumExport");
        StringBuilder sb=new StringBuilder(colValue);
        for(int iterator=0;iterator<4;iterator++){
            sb.setCharAt(iterator,'*');
        }
        String[][] CSVData=getCSVData("",1);
        int lrow=CSVData.length;
        for(int iterator=1;iterator<lrow-1;iterator++){
            Assert.assertEquals(true,sb.toString().contains(CSVData[iterator][colnum]));
        }
    }
    public void modifyAliasName(String aliasName){
        String []info=this.commonHelpers.getValuefromContextStore("TrackingNum").toString().split("[|,?.@]+");
        if(info[2].contains("Add Alias")){
            this.commonHelpers.thinkTimer(2000);
            JavaScriptClick(By.xpath(String.format(accountAlias.addAliasBtnWRTAccNum,info[1].trim())));
            this.enterText(accountAlias.inputAddAliasName,aliasName);
        }
        else{
            JavaScriptClick(By.xpath(String.format(accountAlias.editIcnBesideSingleAccountAccountNumber,info[1].trim())));
            this.enterText(accountAlias.inputAddAliasName,aliasName);
        }
        info[2]=aliasName;
        String modified="";
        for(int iterator=0;iterator<3;iterator++){
            if(iterator==2){
                modified+=info[iterator];
            }
            else{
                modified+=info[iterator]+"|";
            }
        }
        this.commonHelpers.AddToContextStore("TrackingNumNew",modified);
        JavaScriptClick(accountAlias.applyBtnAddAllias);
    }
    public void checkAndApplyFilters(String filterOption,DataTable table){
        String num=getText(this.viewingNumber).split("/")[0];
        if(num.equals("0") || num.length()>3){
            this.commonHelpers.AddToContextStore(Constants.skipSteps,true);
        }
        else if(Integer.parseInt(num)>500){
            this.SelectFilterforUI(filterOption, table);
            String num2=getText(this.viewingNumber).split("/")[0];
            if(num2.equals("0") || num2.length()>3){
                this.commonHelpers.AddToContextStore(Constants.skipSteps,true);
            }
        }
    }
    public void validateTimeInColumn(){
        List<WebElement>listOfElement=this.findElements(this.estimatedDeliveryColDates);
        Iterator<WebElement> it = listOfElement.iterator();
        for(int iter=0;iter<Math.min(10,listOfElement.size());iter++){
            String text = getText(it.next());
            if(text.length()>1) {
                this.validateStartDateIsLessThanEndDate(text);
            }
        }
    }
    public void  validateStartDateIsLessThanEndDate(String dateTime){
            String StartTime = dateTime.split(" ")[1].split("-")[0];
            String EndTime = dateTime.split(" ")[2].split("-")[0];
            if(dateTime.length()>0) {
            int start_date_hrs =  Integer.parseInt(StartTime.split(":")[0]);
            int start_date_min = Integer.parseInt(StartTime.split(":")[1]);
            int end_date_hrs = Integer.parseInt(EndTime.split(":")[0]);
            int end_date_min = Integer.parseInt(EndTime.split(":")[1]);
            if(end_date_hrs>start_date_hrs){
                Assert.assertTrue("Validation of "+end_date_hrs+"greater than "+start_date_hrs+"is "+(start_date_hrs>end_date_hrs?"passed":"failed"),end_date_hrs>start_date_hrs);
            }
            else if(start_date_hrs==end_date_hrs){
                if(end_date_min>start_date_min) {
                    Assert.assertTrue("Validation of "+end_date_min+"is greater than "+start_date_min+"is "+(start_date_min>end_date_min?"passed":"failed"),end_date_min>start_date_min);
                }
                else {
                    Assert.assertTrue("Validation of "+end_date_min+"is greater than "+start_date_min+"is "+(start_date_min>end_date_min?"passed":"failed"),end_date_min>start_date_min);
                }
            }
            else{
                Assert.assertFalse("Valiadtion is failed as"+end_date_hrs+"is less than"+start_date_hrs,start_date_hrs<=end_date_hrs);
            }
        }
    }
    public void storeFirstTrackingNumberDetails(){
        if(elementIsDisplayed(firstEstimatedDelivery)) {
            if (getText(this.firstEstimatedDelivery).length() > 2)
                this.commonHelpers.AddToContextStore("DateTrackingNum", getText(this.firstEstimatedDelivery).substring(0, 10));
            else {
                this.commonHelpers.AddToContextStore("DateTrackingNum", "");
            }
        }

    }

    public void getColumnNames(String ColumnNames) throws InterruptedException {
        this.ScrollToTop();
        this.clickOnElement(By.xpath(String.format(expandIcon, "expand")));
        this.waitUntilNotVisible(By.xpath(String.format(expandIcon, "expand")));
        Thread.sleep(2000);
        List<WebElement> columns = this.findElements(getColumnNames);
        List<String> headerNamesList = new ArrayList<>();
        for (WebElement name : columns) {
            headerNamesList.add(name.getText().toString().toLowerCase());
        }
        String[] ActColumnNames = ColumnNames.split(",");
        String[] array = headerNamesList.toArray(new String[0]);

        for (int i = 0; i < ActColumnNames.length; i++) {
            Assert.assertTrue(array[i].trim().toLowerCase().contains(ActColumnNames[i].trim().toLowerCase()));
        }
    }

    public void RecipientAddressValidation() throws InterruptedException {
        String value = this.getText(recipientAddress);
        String[] Data = value.split(",");
        Assert.assertTrue(Data[0].matches("^[a-zA-Z0-9_ ]*$"));
        Assert.assertTrue(Data[1].matches("^[a-zA-Z0-9_ ]*$"));
        Assert.assertTrue(Data[2].matches("^[a-zA-Z0-9_ ]*$"));
        Assert.assertTrue(Data[3].matches("^[a-zA-Z0-9_ ]*$"));
        Assert.assertTrue(Data[4].matches("^[a-zA-Z0-9_ ]*$"));
        Assert.assertTrue(Data[5].matches("^[0-9_ ]*$"));
    }

    public void SelectValuesFromRegionDD(String Region) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(By.xpath(String.format(this.DropDownRegion)));
        this.ScrollToBottom();
        this.selectDropdown(By.xpath(DropDownRegion),"text", Region);
    }

    public void clickOnEditIconView(String viewName) {
        this.ClickOnEditIconOfView(viewName);
    }

    public void ClickOnEditIconOfView(String viewName) {
        this.clickOnElement(By.xpath(String.format(editViewIconShipmentPage, viewName)));
    }
    public void verifyAlphabeticallyOrdersInColumnsInGrid(){
        List<WebElement>listOfSortedElementsGrid1=this.findElements(By.xpath(String.format(gridColumnNamesList,1)));
        List<WebElement>listOfUnSortedElementsGrid2=this.findElements(By.xpath(String.format(gridColumnNamesList,2)));
        verifySortingAlphabeticallyOfList(listOfSortedElementsGrid1);
        verifySortingAlphabeticallyOfList(listOfUnSortedElementsGrid2);
    }
    public void verifySortingAlphabeticallyOfList(List<WebElement>list1){
        List<String>listOfStringsSorted=new ArrayList<>();
        List<String>listOfStringsUmSorted=new ArrayList<>();
        for(WebElement element:list1){
            listOfStringsUmSorted.add(getText(element).trim());
            listOfStringsSorted.add(getText(element).trim());
        }
        Collections.sort(listOfStringsSorted);
        for(int iter=0;iter<listOfStringsSorted.size();iter++){
            Assert.assertTrue(listOfStringsSorted.get(iter).toString().equals(listOfStringsUmSorted.get(iter).toString()));
        }
    }

    public void SearchBarValidation(){
        Assert.assertTrue("SearchBar is not available",this.getCount(this.SearchBarValidation)==1);
    }

    public void validatetheButtonStatus(String state,String ButtonName) {
        if (state.equalsIgnoreCase("disabled"))
            Assert.assertTrue(this.getCount(By.xpath(String.format(this.ButtonDisabled,ButtonName)))==1);
        else if (state.equalsIgnoreCase("enabled"))
            Assert.assertTrue(this.getCount(By.xpath(String.format(this.ButtonEnabled,ButtonName)))==1);
    }

    public void SearchResultsValidation(String SearchText) {
        this.enterText(this.SearchBarValidation,SearchText);
        this.waitUntilNotVisible(this.loadingIndicator);
        List<String> ActualContent = new ArrayList<String>();
        for (WebElement element : this.findElements(this.FilterResult)) {
            ActualContent.add(element.getAttribute("value").trim());
        }
        for(String value :ActualContent){
            Assert.assertTrue(value.toLowerCase().contains(SearchText.toLowerCase()));
        }
    }

    public void LastEventFilterValidation(String FilterName, String SearchText) {
        List<String> ActualContent = new ArrayList<String>();
        this.waitUntilNotVisible(this.loadingIndicator);

        Assert.assertEquals(this.getText(this.FilterName).trim().toLowerCase(),
                FilterName.toLowerCase().trim());

        for (WebElement element : this.findElements(this.FilterItemResult)) {
            ActualContent.add(element.getText().trim());
        }
        for(String value :ActualContent){
            Assert.assertTrue(value.toLowerCase().contains(SearchText.toLowerCase()));
        }
    }
    public void verifyTheIsDisplayedForEachColumn(String ColumnName) throws ParseException {
        switch (ColumnName) {
            case "At Risk Since":
                List<WebElement> AtRiskSince = this.findElements(By.xpath(String.format(this.shipment_ColumnName,"atRiskSince")));
                break;
            case "Controllable Delay":
                this.scrollHorizontalBarOnPage("4000");
                commonHelpers.thinkTimer(1000);
                List<WebElement> controllableDelay = this.findElements(By.xpath(String.format(this.shipment_ColumnName,"controllableDelay")));
                break;
        }
    }

    public void OverViewPageLinksValidation() {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(this.elementIsDisplayed(DashboardLink));
        Assert.assertTrue(this.elementIsDisplayed(ActSummaryLink));
        Assert.assertTrue(this.elementIsDisplayed(MyShipmentLink));
    }

    public void validationofCountWrtOverViewpage_otherPage(String Name) {
        switch (Name) {
            case "Dashboard":
                String Dashvalue = this.getText(this.DashboardCountLink).trim();
                int DashFinalvalue = Integer.parseInt(Dashvalue.replace(",", "").replace("%", "").replace(".", ""));
                int roundoff = (int) (DashFinalvalue * (90 / 100.0f));
                Assert.assertTrue(Integer.parseInt(Dashvalue) <= roundoff);
                break;
            case "Account Summary":
                String ActSvalue = this.getText(this.ActSummaryCountLink).trim();
                int ActSFinalvalue = Integer.parseInt(ActSvalue.replace(",", "").replace("%", "").replace(".", ""));
                int roundoff1 = (int) (ActSFinalvalue * (90 / 100.0f));
                Assert.assertTrue(Integer.parseInt(ActSvalue) <= roundoff1);
                break;
            case "My Shipment":
                String MyShipvalue = this.getText(this.MyShipmentCountLink).trim();
                int MyShipFinalvalue = Integer.parseInt(MyShipvalue.replace(",", "").replace("%", "").replace(".", ""));
                int roundoff2 = (int) (MyShipFinalvalue * (90 / 100.0f));
                Assert.assertTrue(Integer.parseInt(MyShipvalue) <= roundoff2);
                break;
        }
    }

    public void searchBoxValidation(String substring,int sizeOfSearchList) {
        if (substring.length() <= 2) {
            Assert.assertTrue(sizeOfSearchList == 0);
        } else {
            Assert.assertTrue(sizeOfSearchList > 0);

        }
    }
    public void validateColumnFilterDataInShipmentPage(String columnName,DataTable expectedValues) {
        List<String> expectedList = expectedValues.asList(String.class);
        if(columnName.equalsIgnoreCase("FedEx Destination Location") || columnName.equalsIgnoreCase("FedEx Origin Location")) {
            for (String value : expectedList) {
                this.elementClear(By.xpath(String.format(this.filterSearchBar, "Shipment Information", columnName)));
                this.enterText(By.xpath(String.format(this.filterSearchBar, "Shipment Information", columnName)),
                        value);
                long start = System.currentTimeMillis();
                try {
                    Thread.sleep(5000);
                } catch (Exception ex) {
                    log.error("Thread sleep fails");
                }

                // Adding more wait time as few of the apis related to shipper and recipient
                // takes a lot of time to return the search resultsfv
                // reuired for single search and multi search
                this.waitUntilNotVisible(this.loadingIndicator);
                // required for checbox search indicator
                this.waitUntilNotVisible(this.quickViewLoading);
                // required if api takes longer time
                String xpathElm = String.format(this.checkboxIndicator, value);
                this.waitUntilNotVisible(By.xpath(xpathElm));
                long finish = System.currentTimeMillis();
                log.info("Total Time Elapsed " + (finish - start));
                log.info("Input for:  filter." + "Value searched is -->"
                        + value);
                Assert.assertTrue("The value : " + value + " Doesnot matches ", this.elementIsDisplayed(By.xpath(xpathElm)));

            }
        }else {
            for (String value : expectedList) {
                value = " " + value + " ";
                // return this.getText(By.xpath(String.format(this.addInOrOutPrefLocation, "Settings"))).contains(secondarylink);
                Assert.assertTrue("The value : " + value + " Doesnot matches ", this.elementIsDisplayed(By.xpath(String.format(this.FilterOptions, columnName, value))));
            }
        }
    }

    public void validateNoFiltersAvailableInMyshipmentPage(){
           Assert.assertTrue("Filters/Views are available",this.elementIsNotDisplayed(filterValues));
    }



    public boolean ValidateQuickViewCardColor(String cardName) {
        Boolean flag = false;

        String filteredRecords = this.commonHelpers.getValuefromContextStore(cardName).toString();
        //cardName = cardName.toUpperCase();
        String cardhighlight = "";
        switch (cardName) {
            case "Returning to Shipper":
                cardhighlight = Constants.returningToShipperQCHighlight;
                break;
        }
        By locator=this.getByusingString(String.format(QCHighlight, cardName, cardhighlight));
        if (Integer.parseInt(filteredRecords) > 0) {
            //this.getElementCssProperty(locator, "border-bottom-color");
            Assert.assertEquals("Element is not Highlighted in "+Constants.redColor+" color", this.getElementCssProperty(locator, "border-bottom-color"), Constants.redColor);
        } else {
            log.info("Element is greyed out");

        }

        return flag;
    }

    public boolean validateColumnDataFormatInShipmentPage(String columnId,String fedExCompany){
        this.commonHelpers.thinkTimer(4000);
        this.waitUntilNotVisible(this.loadingIndicator);
        boolean flag = false;
        if(columnId.equalsIgnoreCase("Delivered Past Commit")){
            columnId="deliveredPastCommitTimer";
        }
        List<WebElement> elements = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
        log.info("Number of columns: " + elements.size());

        for(WebElement element:elements){
            String elementText=element.getText().trim();
            if(fedExCompany.equalsIgnoreCase("FedEx Ground")){
                flag = Pattern.matches(
                        "[0-9]*[a-z]*[\" \"][0]*[a-z]*[\" \"][0]*[a-z]*", elementText);
            }else{
                flag = Pattern.matches(
                        "[0-9]*[a-z]*[\" \"][0-9]*[a-z]*[\" \"][0-9]*[a-z]*", elementText);
            }
            if(!flag)
                break;
        }
        return flag;
    }



    public void validateDelayReasonFilter(String filterValue){
        //if filter=yes/no/specific delay reason, all options should be disabled
        boolean flag=false;
        ArrayList<String> list=new ArrayList<String>(Arrays.asList("Yes","No","Specific Delay Reason"));
        this.JavaScriptClick(By.xpath(String.format(this.FilterOptions, "Delay Reason", filterValue)));
        for(String str:list) {
               if(!str.equalsIgnoreCase(filterValue)) {
                   flag = this.isAttributePresent(this.findElement(By.xpath(String.format(this.FilterOptionCheckbox, "Delay Reason", str))), "disabled");
                    Assert.assertTrue("option is not disabled",flag);
               }
        }
/*
        if(filterValue.equalsIgnoreCase("Specific Delay Reason")){
            //verify is and isnot dropdowns above search bar
            String isOption="// li[@class='sr-multinav-subchild__list']/ div[contains(text(),'Delay Reason')]/ following-sibling::ul// label[text()=\"%s\"]";
           Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(isOption,"Is"))));
           Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(isOption,"Is not"))));
           if(!this.findElement(By.xpath(String.format(isOption,"Is"))).isSelected()){
               this.findElement(By.xpath(String.format(isOption,"Is not"))).isSelected();
           }else if(!this.findElement(By.xpath(String.format(isOption,"Is"))).isSelected()){
               this.findElement(By.xpath(String.format(isOption,"Is not"))).isSelected();
           }
             //enter invalid text
            this.elementClear(By.xpath(String.format(this.searchBox,"Shipment Status","Delay Reason")));
            this.enterText(By.xpath(String.format(this.searchBox,"Shipment Status","Delay Reason")),"aaaaaa");
            commonHelpers.thinkTimer(2000);
            this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("No results found")));

            //enter special characters
            this.elementClear(By.xpath(String.format(this.searchBox,"Shipment Status","Delay Reason")));
            this.enterText(By.xpath(String.format(this.searchBox,"Shipment Status","Delay Reason")),"#@#$%");
            commonHelpers.thinkTimer(2000);
            this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("The following combination is not allowed")));
        }
*/
    }

    public void validateFilterUIForSpecificDelayReason(String filterValue,DataTable dataTable){
        List<String> filterUIValidations = dataTable.asList(String.class);

        if(filterValue.equalsIgnoreCase("Specific Delay Reason")) {
            //verify is and isnot dropdowns above search bar
            String isOption = "// li[@class='sr-multinav-subchild__list']/ div[contains(text(),'Delay Reason')]/ following-sibling::ul// label[text()=\"%s\"]";
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(isOption, "Is"))));
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(isOption, "Is not"))));
            if (!this.findElement(By.xpath(String.format(isOption, "Is"))).isSelected()) {
                this.findElement(By.xpath(String.format(isOption, "Is not"))).isSelected();
            } else if (!this.findElement(By.xpath(String.format(isOption, "Is"))).isSelected()) {
                this.findElement(By.xpath(String.format(isOption, "Is not"))).isSelected();
            }

            for (String value : filterUIValidations) {
                this.elementClear(By.xpath(String.format(this.searchBox, "Shipment Status", "Delay Reason")));
                this.enterText(By.xpath(String.format(this.searchBox, "Shipment Status", "Delay Reason")), value);
                commonHelpers.thinkTimer(2000);

                if (GenericFunction.containsConsecutiveSpecialCharacters(value)) {
                    this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("The following combination is not allowed")));
                } else {
                    this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("No results found")));

                }
            }
        }

    }



    public void FilterForDelayReason(String status, String[] filterCriteria) {
        if (!this.findElement(filterChevron).getAttribute("class").contains("active")) {
            // this.clickOnElement(filterChevron);
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        String ParentFilter = status.split("-")[0];
        String ChildFilter = status.split("-")[1];
        log.info("Parent Filter --> " + ParentFilter);
        log.info("Child Filter  --> " + ChildFilter);

        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(status.split("-")[0]))));
        if (ChildFilter.contains("Cold Storage Temp")) {
            ChildFilter = String.join("-", ChildFilter, status.split("-")[2]);
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, status.split("-")[0], ChildFilter))));
        } else {
            this.waitUntilVisible(this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter)));
            this.JavaScriptClick(this.findElement(
                    this.getByusingString(String.format(this.secndPanexpath, ParentFilter, ChildFilter))));
        }

        if (filterCriteria[0].contains("Specific Delay Reason")) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter,
                            "Specific Delay Reason"))));
        }

        if (filterCriteria[0].contains("Specific Exception Reason")) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter,
                            "Specific Exception Reason"))));
        }


        if(filterCriteria[0].contains("Is Not")){
                this.JavaScriptClick(this.findElement(this.getByusingString(
                        String.format(this.filterxpath, ParentFilter, ChildFilter,
                                "Is not"))));
        }
        if (filterCriteria[0].contains("Specific Delay Reason") || filterCriteria[0].contains("Specific Exception Reason")) {
            this.elementClear(By.xpath(String.format(this.searchBox, ParentFilter, ChildFilter)));
            this.enterText(By.xpath(String.format(this.searchBox, ParentFilter, ChildFilter)), filterCriteria[1]);
            commonHelpers.thinkTimer(5000);
            List<WebElement> Searchlist = this.findElements(By.xpath(String.format(this.searchOptions, filterCriteria[1])));
            for (WebElement element : Searchlist) {
                this.JavaScriptClick(element);
            }
        }else if(filterCriteria[0].equalsIgnoreCase("Delay Reason") || filterCriteria[0].equalsIgnoreCase("Exception Reason")){
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.filterxpath, ParentFilter, ChildFilter,
                            filterCriteria[1]))));
        }

    }

    public void selectOrDeselectDelayReasonFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.clickOnElement(filterChevron);
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.FilterForDelayReason(key, dataFilters.get(key).split(":"));
        }
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }


    }
    public void validateDelayReasonColumnFilterBubble(String delayReason,String filter){
        StringBuilder str = new StringBuilder();
        List<WebElement> filterList = this.findElements(FilterBubbleValues);
        for (WebElement w : filterList) {
            str.append(w.getText() + " ");
        }
        Assert.assertTrue("Filter bubble value doesn't match",(str.toString().contains(delayReason)&&str.toString().contains(filter)));


    }


    public boolean validateColumnDataForFilter(String columnId,String expectedValue,String isDisplayed){
        this.commonHelpers.thinkTimer(4000);
        this.waitUntilNotVisible(this.loadingIndicator);
        List<WebElement> elements = this.findElements(By.xpath(String.format(this.columnValuesXpath, columnId)));
        log.info("Number of columns: " + elements.size());
        boolean flag=false;
        for(WebElement element:elements){
            flag=element.getText().contains(expectedValue);
            if(isDisplayed.equalsIgnoreCase("False")) {
                if (flag)
                    break;
            }else {
                if(!flag)
                    break;
            }

        }
        return flag;
    }
    public  void getcoloumndata(String sheetname,String columnName,String value) throws IOException {


            Map<String, String> fileData = new HashMap<>();
            Map<String, List<String>> columnListData = this.genericFunctionObject
                    .getCompleteColumnData(sheetname);
            List<String> columnData = columnListData.get(columnName);
            if (columnData != null) {
                for (String columnValue : columnData) {
                    Assert.assertTrue(columnValue.equalsIgnoreCase(value));
                }
            }
        }
    public void selectFilterOption(String search,String filterOptions,DataTable table){

        String[] filters=filterOptions.split("-");
        String ParentFilter=filters[0];
        String ChildFilter=filters[1];
        search=this.genericFuncObj.getLocalizedValue(search);
        ParentFilter = this.genericFuncObj.getLocalizedValue(ParentFilter);
        ChildFilter = this.genericFuncObj.getLocalizedValue(ChildFilter);
        List<String> dataFilters = table.asList(String.class);
        for(String s:dataFilters) {
            this.elementClear(By.xpath(String.format(this.searchBox1, ParentFilter, ChildFilter,search)));
            this.enterText(By.xpath(String.format(this.searchBox1, ParentFilter, ChildFilter,search)), s);
            commonHelpers.thinkTimer(15000);
            List<WebElement> Searchlist = this.findElements(By.xpath(String.format(this.searchOptions1, s)));
            for (WebElement element : Searchlist) {
                this.JavaScriptClick(element);
            }
        }
        //click on apply
        this.JavaScriptClick(
                this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
    }


    public void filterLessThanThousandRecordsForLocalization() {
        boolean filtered = false;
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
//        String[] types = { "Intervened", "Payer", "Select" };
        String[] types = { "Intervened", "Payer" };
        for (int i = 0; i < types.length; i++) {
            String localizedTypeItem = this.genericFuncObj.getLocalizedValue(types[i]);
            String localizedType = this.genericFuncObj.getLocalizedValue("Types");
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(localizedType)));
            this.JavaScriptClick(By.xpath(String.format(this.TypesOptionsCBXpath, localizedTypeItem)));
            // this.JavaScriptClick(this.ShipmentTypeApply);
            // Localized Chages
            this.JavaScriptClick(By.xpath(String.format(this.ShipmentTypeApply, this.apply)));

            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            int viewCount = this.getViewCount();
//            String export = this.getAttributeValue(
//                    this.getByusingString(this.getXPathforAnyElementWithText("Export List") + "/../.."), "class");
            if (viewCount < 1000 ) {
                filtered = true;
                break;
            }
            String localizedShipmentType = this.genericFuncObj.getLocalizedValue("Shipment Type");
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.cancelFilterBubble,localizedShipmentType ))));
            this.waitUntilNotVisible(this.loadingIndicator);
        }

        if (!filtered) {
            // this.FilterForShipments("Shipment Information-Appointment Delivery",
            // ["Yes"]);
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    public void sortaliasAccount()
    {
        this.Refresh_Page(1);
        this.waitUntilClickable(getByusingString(this.account));
        this.clickOnElement(getByusingString(this.account));
        this.clickOnElement(getByusingString(this.account));
    }

        public String addingZeroBeforeDate(String input) {

            // Define input and output date formats
            DateTimeFormatter dateFormatterInput = DateTimeFormatter.ofPattern("d-M-yyyy", Locale.ENGLISH);
            DateTimeFormatter dateFormatterOutput = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH);

            // Split the input into date and time parts
            String[] parts = input.split(" : ");
            String datePart = parts[0];
            String timePart = parts[1];

            // Split the date part into start and end dates
            String[] dateRange = datePart.split(" - ");
            String startDateStr = dateRange[0];
            String endDateStr = dateRange[1];

            // Parse and format start date
            LocalDate startDate = LocalDate.parse(startDateStr, dateFormatterInput);
            String formattedStartDate = startDate.format(dateFormatterOutput);

            // Parse and format end date
            LocalDate endDate = LocalDate.parse(endDateStr, dateFormatterInput);
            String formattedEndDate = endDate.format(dateFormatterOutput);

            // Combine formatted dates and time part into desired output format
            String output = formattedStartDate + " - " + formattedEndDate + " : " + timePart;
             return output;
        }

    public void validateFilterBubbleValue(){
        String FilterBubbleDateValue = this.findElement(FilterBubbleVerifyValues).getText();
        String ValidateFilterBubbleDateValue = addingZeroBeforeDate(FilterBubbleDateValue);
        this.commonHelpers.AddToContextStore("ValidateFilterBubbleDate", ValidateFilterBubbleDateValue);
        System.out.println("ValidateFilterBubbleDateValue: " + ValidateFilterBubbleDateValue);
    }


   public void  verifyFullScreen(){
       Assert.assertTrue("Full screen is visible",this.elementIsDisplayed(closeFulLScreen)&&this.elementIsNotDisplayed(expandButton));
   }

   public void closeFullScreen(){
         this.JavaScriptClick(closeFulLScreen);
   }

   public boolean validatePageIsDisplayed(String page){
        boolean flag=false;
        try{
            if(!this.elementIsDisplayed(By.xpath(String.format(homePage.menu, page)))){
                flag=true;
            }
        }catch(Exception e) {
            log.info("Element is not visible as expected");
        }
        return flag;
   }
    public String getColumnContentByColumnName(String columnName){
       String colId=null;
       String flag="false";
        switch(columnName){
            case "Prediction Details":
                colId="packageRiskReason";
                break;
        }
        List<WebElement> colList=DriverManager.getDrv().findElements(By.xpath(String.format(columnValuesXpath,colId)));
        for(WebElement e:colList){
            if(!e.getText().isEmpty()){
               flag="true";
               break;
            }
        }
        return flag;
    }
    public void verifyFilterOptionDisabled(String filterName) {
//        String actualLink = this.findElement(this.getByusingString(this.buildXpathForString(filterName)))
//                .getAttribute("disabled");
//        System.out.println(actualLink);
        String filterEle = String.valueOf(By.xpath((String.format(String.valueOf(this.filterIsNotDisplayed), filterName))));
        System.out.println(this.findElement(By.xpath(filterEle)).getAttribute("disabled"));
//        if (this.findElement(By.xpath(filterEle)).getAttribute("disabled").contains("active")) {
//            // this.clickOnElement(filterChevron);
//
//        }
    }
    public String getTotalCount() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String lang = GenericFunction.ReadConfigFile("LANG");
        String viewingCountText = this.getText(viewingCountXpath).replace(lang.equalsIgnoreCase("pt-br") ? "." : ",", "");
        return viewingCountText.split("/")[1].trim();
    }

    public boolean isShipmentColumnPresentWithOffset(String offset,DataTable dataTable) {
        Set<Boolean> result = new HashSet<>();
        List<String> filters = dataTable.asList(String.class);
        String columnId = "";
        int count=0;
        for (String filter : filters) {
            switch (filter) {
                case "Weather Impacted":
                    columnId = "weatherImpacted";
                    break;
                case "Commit Time":
                    columnId = "commitTimer";
                    break;
                case "Nak Scan":
                    columnId = "nakScan";
                    break;
                case "Delivery Prediction":
                    columnId = "finalPackageDelayStatus";
                    break;
                case "CER Number":
                    columnId = "cerNumbers";
                    break;
                case "Container ID":
                    columnId = "latestContainerId";
                    break;
                case "Last Known Ramp":
                    columnId = "lastKnownRamp";
                    break;
                case "Industry Vertical":
                    columnId = "industryVerticalName";
                    break;
                case "Service Type":
                    columnId = "serviceType";
                    break;
                case "Flight Number":
                    columnId = "latestFlightNumber";
                    break;
                case "Delivered Date":
                    columnId = "dateDelivered";
                    break;
                case "Special Handling":
                    columnId = "specialHandling";
                    break;
                case "Package Weight (LBS)":
                    columnId = "pkgWtLbs";
                    break;
                case "Package Weight (KGS)":
                    columnId = "pkgWtKg";
                    break;
                case "Total Weight (LBS)":
                    columnId = "totalWtLbs";
                    break;
                case "Total Weight (KGS)":
                    columnId = "totalWtKg";
                    break;
                case "Intervention Date/Time":
                    columnId = "latestInterventionDateTime";
                    break;
                case "Address Correction":
                    columnId = "addressCorrection";
                    break;
                case "Address Classification":
                    columnId = "recipientAddressClassification";
                    break;
                case "Case Count":
                    columnId = "cerCount";
                    break;
                case "Case Number":
                    columnId = "cerNumbers";
                    break;
                case "Tracking Number":
                    columnId = "trackingNumber";
                    break;
                case "Types":
                    columnId = "isPayer";
                    break;
                case "Status":
                    columnId = "status";
                    break;
                case "Sub-Status":
                    columnId = "subStatus";
                    break;
                case "Case Type":
                    columnId = "cerCodes";
                    break;
                case "Exception Reason":
                    columnId = "exceptionReason";
                    break;
                case "Standard Transit Date":
                    columnId = "standardTransitDate";
                    break;
                case "Standard Transit Time By":
                    columnId = "standardTransitTimeBy";
                    break;
                case "Scheduled Delivery Date/Time":
                    columnId = "scheduledDeliveryDateDestTZ";
                    break;
                case "Estimated Delivery Date/Time":
                    columnId = "edtWindowStart";
                    break;
                case "Time in Network":
                    columnId = "timeSincePickup";
                    break;
                case "Ship Date":
                    columnId = "shipDate";
                    break;
                case "Last Comment":
                    columnId = "lastComment";
                    break;
                case "Last Comment Date/Time":
                    columnId = "lastCommentOn";
                    break;
                case "Weather Advisory":
                    columnId = "weatherImpacted";
                    break;
                case "FedEx Origin Location":
                    columnId = "fedExOriginLocation";
                    break;
                case "FedEx Destination Location":
                    columnId = "fedExDestinationLocation";
                    break;
                case "Recipient Postal":
                    columnId = "recipPostal";
                    break;
                case "Recipient State/Province":
                    columnId = "recipState";
                    break;
                case "Case Status":
                    columnId = "cerStatus";
                    break;
                case "Dry Ice Added (Kgs)":
                    columnId = "dryIceAddedKgs";
                    break;
                case "Dry Ice Added (Lbs)":
                    columnId = "dryIceAddedLbs";
                    break;
                case "Dry Ice Added Date/time":
                    columnId = "dryIceAddedDateTime";
                    break;
                case "Get Pack Quantity":
                    columnId = "gelPackQuantity";
                    break;
                case "Gel Pack Date/Time":
                    columnId = "gelPackDateTime";
                    break;
                case "Cold Storage Temp - Min (C)":
                    columnId = "coldStorageTemperatureMinC";
                    break;
                case "Cold Storage Temp - Max (C)":
                    columnId = "coldStorageTemperatureMaxC";
                    break;
                case "Cold Storage Date/Time":
                    columnId = "coldStorageTemperatureDateTime";
                    break;
                case "Shipper company":
                    columnId = "shipperCompany";
                    break;
                case "Shipper Name":
                    columnId = "shipperName";
                    break;
                case "Shipper Account Number":
                    columnId = "shipperAccountNumber";
                    break;
                case "Reference":
                    columnId = "reference";
                    break;
                case "Recipient Company":
                    columnId = "recipCompany";
                    break;
                case "Recipient Contact Name":
                    columnId = "recipContactName";
                    break;
                case "Healthcare Identifier":
                    columnId = "healthcareIdentifier";
                    break;
                case "Monitoring and Intervention Options":
                    columnId = "monitoringAndInterventionsCode";
                    break;
                case "Last Known Location":
                    columnId = "lastKnownLocation";
                    break;
                case "Recipient Country/ Territory":
                    columnId = "recipCountryOrTerritory";
                    break;
                case "Shipper Country/ Territory":
                    columnId = "shipperCountryOrTerritory";
                    break;
                case "Shipper State/Province":
                    columnId = "shipperState";
                    break;
                case "Origin State/Province":
                    columnId = "originStateOrProvince";
                    break;
                case "Origin Country/Territory":
                    columnId = "originCountryOrTerritory";
                    break;
                case "Support Update":
                    columnId="supportUpdate";
                    break;
                case "Prediction Details":
                    columnId="packageRiskReason";
                    break;
            }
            if(count==1){
                this.JavaScriptClick(By.xpath("(//div[@class='ag-center-cols-container']//div[@row-id=\"1\"]/div)[3]"));
            }
            if(count>1){
                this.keyBoardEvent(Keys.ARROW_RIGHT);
            }


            this.commonHelpers.thinkTimer(3000);
            // this.ScrollIntoView(this.findElement(By.xpath(String.format(this.shipmentColumnHeaderXpath, columnId))));
            Boolean val=this.elementIsDisplayed(By.xpath(String.format(this.shipmentColumnHeaderXpath, columnId)));
            if(!val){
                System.out.println("column not displayed is "+columnId);
                Assert.fail();
            }
            result.add(this.elementIsPresent(By.xpath(String.format(this.shipmentColumnHeaderXpath, columnId))));
           count++;
        }
        return !result.contains(false);
    }
}
