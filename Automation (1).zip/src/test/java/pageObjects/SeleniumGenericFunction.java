package pageObjects;

import common.CommonHelpers;
import common.DriverManager;
import constants.EnvConstants;
import genericfunctions.Constants;
import genericfunctions.DateTimeUtils;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;

/**
 * All Selenium related functions with wrappers are present here
 */
@Slf4j
public class SeleniumGenericFunction {
    public DateTimeUtils dateTimeUtils = new DateTimeUtils();
    public static WebDriver driver = null;
    public By loginLinksurround = By.xpath("//a[@aria-label='Log In ']");
    public By loginIconSurround = By.xpath(".//*[contains(@class,'fdx-sjson-c-icon-signin')]");
    public By virtualizedPage = By.xpath(".//*[contains(text(),'Login to Virtualized APIs')]");
    public By CEloginLink = By.xpath(".//*[@class='fdx-u-hidden fs-14 fdx-u-pr--2']");
    public By CEsignOutLink = By.xpath(".//*[contains(text(),'Sign Out')]");
    public By CEuserIdTB = By.xpath(".//*[@name='identifier']");
    public By CEpwdTB = By.xpath(".//*[@name='credentials.passcode']");
    public By CELoginButton = By.xpath(".//*[@type='submit']");
    public By CESendPush = By.xpath(".//a[contains(text(),'Push notification sent')]");
    public By CESelectPush = By.xpath(".//div[@data-se='okta_verify-push']//a[contains(text(),'Select')]");
    public By userIdTB = By.xpath(".//input[@id='NavLoginUserId']");
    public By userIdStressPage = By.xpath("//input[@id='userId']");
    public By passwordTB = By.xpath(".//input[@id='NavLoginPassword']");
    public By passwordStressPage = By.xpath("//input[@id='password']");
    public By LoginButtonStressPage = By.xpath("//button[@id='login-btn']");
    public By remindMelater = By.xpath("//button[@id='cancelBtn']");
    public By loadingIndicator = By.xpath(".//div[@class='fdx-c-loading-indicator']");
    public By loadingIndicatorContains = By.xpath("//*[contains(@class,'fdx-c-loading-indicator']");

    public String favname = "//div[@class='sr-caro']//*[contains(text(),\"Favorite\")]/span";
    public String viewname = "//div[@class='sr-caro']//div[contains(text(),'View')]/span";
    public String purplebarxpath = "//div[@class='sr-caro']//*[contains(text(),\"%s\")]";
    public String audittablexpath = "//div[@class='ag-root ag-unselectable ag-layout-auto-height']//*[contains(text(),\"%s\")]";
    public String labelContainsText = "//*[contains(text(),\"%s\")]";
    public String labelForText = "//*[text()=\"%s\"]";
    public By currentDate = By.xpath("//td[contains(@class,'end-date start-date')]//span");
    public String hours = "(//select[@id='hours'])[%s]";
    public String minutes = "(//select[@id='minutes'])[%s]";
    public String ampmOptions = "(//select[@id='dateTimeFormat'])[%s]";
    public String dateXpath = "//tr//span[text()=\"%s\"]//parent::td[not(contains(@class,'disabled'))][not(contains(@class,'off'))]";

    public By LoadingMoreData = By.xpath("//div[@class='fdx-c-loading-indicator']//..//span[.='Loading More Data...']");
    public By MaxRows = By.xpath("//div[@ref='eCenterContainer']//div[@row-index='12']");
    public By countOfRows=By.xpath("//div[@ref='eCenterContainer']");
    public String rowAtIndex ="(//div[@ref='eCenterContainer'])[%s]";
    public By CSVRadioBox = By.xpath("(//input[@name='lastScanRadio'])[1]");
    public By ExcelRadioBox = By.xpath("(//input[@name='lastScanRadio'])[2]");
    public By Errorpage= By.xpath("//a[text()=\"breadCrumb.fedex\"]");
    public By CloseUpdateTerms= By.xpath("//button[text()=' GOT IT ']");
    public String containsFilterValue="(//div[@class='sr-multinav']//*[contains(text(),\"%s\")])[1]";

    // protected KeyVaultHelpers keyVaultHelpers;
    // protected KeyVaultClient client;
    EnvConstants envObject;
    GenericFunction genericFunctionObject;
    CommonHelpers commonHelpers;

    public SeleniumGenericFunction(CommonHelpers commonHelpers) {
        this.commonHelpers = commonHelpers;
        // this.keyVaultHelpers = new KeyVaultHelpers();
        // this.client = this.getkeyVaultClient();
        genericFunctionObject = new GenericFunction();
    }

    /**
     * GetDriver method will create a driver instance based on the tags present over
     * the scenario
     *
     * @param scenario = Instance of the scenario
     */
    public static void getDriver(Scenario scenario) throws MalformedURLException {
        Collection<String> tags = scenario.getSourceTagNames();
        for (String tag : tags) {
            if (tag.substring(1).equalsIgnoreCase("UI")) {
                DriverManager.getDrv();
                break;
            }
        }
    }
    /**
     * This method will create a client for fetching values from keyVault
     *
     * @return = Client for accessing keyVault
     */
    // public KeyVaultClient getkeyVaultClient() {
    // return this.keyVaultHelpers.SetAppConfigKeys();
    // }

    /**
     * This method will create a driver instance which is shared across the scenario
     * execution
     */
    public static void driverInstance() throws MalformedURLException {
        String Browser = GenericFunction.ReadConfigFile("BROWSER");
        String CurrentDir = GenericFunction.userDir;
        // String OS = System.getProperty("os.name");
        switch (Browser) {
            case "CHROME":
                ChromeOptions options = new ChromeOptions();
                options.setPageLoadStrategy(PageLoadStrategy.NONE);
                // Uncomment this if you want to point this to a browser you have started on
                // 9222 port via the command
                // replace the {{user}} with your alias
                // C:\Program Files\Google\Chrome\Application>chrome.exe
                // --remote-debugging-port=9222 --no-first-run --no-default-browser-check
                // --user-data-dir="C:\Users\{{youruser}}\AppData\Local\Google\Chrome\User Data"

                // options.setExperimentalOption("debuggerAddress","localhost:9222");
                if (GenericFunction.OS.contains("Window")) {
                    log.info(" We are running the build in the windows environment");
                    // options.addArguments("--disable-dev-shm-usage");
                    // options.addArguments("--no-sandbox");
                    // options.addArguments("--remote-debugging-port=9222");
                    // options.addArguments("--headless=new");
                    // options.addArguments("--window-size=1920,1080");

                } else {
                    // Check that Bash should run to set this value //
                    // CurrentDir = "/usr/bin/chromedriver";
                    log.info(" We are running the build in the linux environment");
                    Map<String, Object> prefs = new HashMap<>();
                    prefs.put("download.default_directory", "/root/Downloads");
                    options.setExperimentalOption("prefs", prefs);
                    options.addArguments("--disable-dev-shm-usage");
                    options.addArguments("--no-sandbox");
                    options.addArguments("--remote-debugging-port=9222");
                    options.addArguments("--headless=new");
                    // options.addArguments("--kiosk");
                    options.addArguments("--lang=" + GenericFunction.locale);

                }
                options.addArguments("--window-size=1920,1080");
                options.addArguments("--incognito");
                options.addArguments("--start-maximized");

                if (DriverManager.getDrv() == null) {
                    driver = new ChromeDriver(options);
                    DriverManager.getDrv().manage().window().maximize();
                    // For running in selenium grid use below
                    // driver = new RemoteWebDriver(new URL("http://localhost:4444/"), options);

                }

                break;
            case "EDGE":
                log.info("Driver setting is pending to add");
                break;
            case "IE":
                log.info("Driver setting is pending to add");
                break;
            case "FF":
                if (GenericFunction.OS.contains("Window")) {
                    // CurrentDir = CurrentDir + "\\driver\\geckodriver.exe";
                } else {
                    // Check that Bash should run to set this value //
                    // CurrentDir = "/usr/bin/geckodriver";
                }
                // System.setProperty("webdriver.gecko.driver", CurrentDir);
                driver = new FirefoxDriver();
                break;
            default:
                log.info("Invalid Choice");
                Assertions.fail("Wrong browser is passed in the config file");
                break;
        }
        // driver.manage().window().maximize();
        // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
    }

    /**
     * This method will build xpath for a class - div , span , img etc
     *
     * @param classtext
     * @return
     */
    public static String buildXpathForClass(String classtext) {
        return ".//*[contains(@class,'" + classtext + "')]";
    }

    public static void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                String testCaseId = "";
                byte[] screenshot = ((TakesScreenshot) DriverManager.getDrv()).getScreenshotAs(OutputType.BYTES);
                File screenshot_with_scenario_name = ((TakesScreenshot) DriverManager.getDrv()).getScreenshotAs(OutputType.FILE);
                for (String tag : scenario.getSourceTagNames()) {
                    if (tag.contains("TESTCASE")) {
                        testCaseId = tag.split("=")[1];
                        break;
                    }
                }
                log.info(scenario.getName() + " Execution is Failed");

                String FileName = "TestCaseID_" + testCaseId + ".png";
                String OS = GenericFunction.OS.toLowerCase();
                if (OS.contains("window"))
                    FileName = GenericFunction.userDir + "..\\artifacts\\Screenshot\\" + FileName;
                else
                    FileName = GenericFunction.userDir + "../artifacts/Screenshot/" + FileName;
                log.info("Filename " + FileName);
                File file = new File(FileName);
                file.getParentFile().mkdirs(); // Will create parent directories if not exists
                file.createNewFile();
                FileOutputStream s = new FileOutputStream(file, false);
                FileUtils.copyFile(screenshot_with_scenario_name, new File(FileName));
                scenario.embed(screenshot, "image/png", FileName);
                s.close();
                // this.AddScreenShottoReport(FileName);
                SeleniumGenericFunction.AddScreenShottoReport(FileName);
            } else {
                log.info(scenario.getName() + " Execution is passed");

            }
            log.info(
                    "\n---------------------------------------End of Scenario---------------------------------------\n");

        } catch (Exception e) {
            log.error(
                    "Not Able to take screenshot May be a case of API where driver can give exception as " + e);
        }
    }

    /**
     * This method will add the screen shot file in the extent report for failure
     * scenarios
     *
     * @param FileName
     */
    public static void AddScreenShottoReport(String FileName) {
        try {
            // will update this later for adding screenshot
            // Reporter.addScreenCaptureFromPath(FileName);
            log.info("Adding screenshot to report, need to be fixed " + FileName);
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in AddScreenShottoReport method" + e.getMessage());
            e.printStackTrace();
        }
    }

    // With version 5 of cucumber asMap was not working
    // This wrapper uses asMaps and then return the first from the list
    // as passing an empty table was causing issue
    // This same function is there even in TestAPI so whenever there is change it
    // should be at both places
    public Map<String, String> getFirstValueOfDataTableifNotEmpty(DataTable dataTable) {
        try {
            Map<String, String> expectedKV = dataTable.asMap(String.class, String.class);
            return expectedKV;
        } catch (Exception e) {
            log.info("Looks like there is an empty datatable was sent. So handling it differently");
            List<Map<String, String>> expectedKVList = dataTable.asMaps();
            if (expectedKVList.size() == 0) {
                return null;
            }
            return expectedKVList.get(0);
        }
    }

    /**
     * This method will fetch the userId when loginId is passed as a parameter to
     * the method
     *
     * @param loginId = It should be the user1 or 2 from feature file
     * @return = login Id of the user
     */
    public String getUserId(String loginId) {
        this.envObject = new EnvConstants();
        loginId = this.envObject.GetUser(loginId);
        boolean virtualizationFlag;
        String virtualization = System.getProperty("VIRTUALIZATION");
        virtualizationFlag = virtualization == null
                ? Boolean.parseBoolean(GenericFunction.ReadConfigFile("VIRTUALIZATION"))
                : Boolean.parseBoolean(virtualization);
        this.commonHelpers.AddToContextStore("VIRTUALIZATION", virtualizationFlag);
        return loginId;
    }

    public String getCEPassword() {
        String CEPassword = System.getProperty("CEpwd");
        CEPassword = CEPassword == null ? GenericFunction.ReadConfigFile("CEpwd") : CEPassword;
        return CEPassword;
    }

    public String getCustomerPassword() {
        String CustPassword = System.getProperty("CustPassword");
        CustPassword = CustPassword == null ? GenericFunction.ReadConfigFile("CustPassword") : CustPassword;
        return CustPassword;
    }

    public String getUserRole(String loginId) {

        if (this.envObject == null) {
            loginId = this.getUserId(loginId);
        }

        return this.envObject.GetUserRole();

    }

    /**
     * This method will navigate the browser to previous page
     */
    public void NavigateToPreviousPageOfBrowser() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            DriverManager.getDrv().navigate().back();
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public String GetxpathForLink(String text) {
        return String.format("//a[text()=\"%s\"]", text);
    }

    public boolean elementIsDisplayed(By by, boolean... highlight) {
        try {
            return this.findElement(by, highlight).isDisplayed();
        } catch (Exception ex) {
            log.error(by.toString() + " Element is not displayed [this can be expected too] check TC for more details "
                    + ex);
            return false;
        }
    }

    public boolean elementIsNotDisplayed(By by) {
        try {
            return !DriverManager.getDrv().findElement(by).isDisplayed();
            // to save time not using the customised one as it adds 15 seconds wait
            // return this.findElement(by).isDisplayed();
        } catch (Exception ex) {
            log.info(by.toString() + " Element is not displayed as expected ");
            return true;
        }
    }

    public boolean isElementDisplayed(By by,int timer,int retries) {
        boolean isElementFound=false;
        for(int cnt=1;cnt<=retries;cnt++) {
           isElementFound=false;
            try {
                isElementFound = DriverManager.getDrv().findElement(by).isDisplayed();
                log.info(by.toString() + " Succesful after attempt : "+ cnt);
                break;
            } catch (Exception ex) {
                this.commonHelpers.thinkTimer(timer);
                log.info(by.toString() + " Element is not displayed for attempt : "+cnt);

            }
        }
        return isElementFound;
    }

    public boolean elementIsPresent(By by) {
        try {
            return this.findElement(by) != null;
        } catch (Exception ex) {
            log.error(by.toString() + " Error while finding the element " + ex);
            return false;
        }
    }

    public void elementIsPresentWithIndex(String text,String index){
        this.elementIsPresent(this.getByusingString(this.buildGenericXpathForString(text,index)));
    }

    /**
     * This function will highlight and unhighlight the webElement
     *
     * @param element = webelement
     */
    public void ElementHighlighter(WebElement element) {

        if (GenericFunction.ElementHighlighter) {
            try {
                JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
                js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", element);
                this.commonHelpers.thinkTimer(100);
                js.executeScript("arguments[0].setAttribute('style', '');", element);
            } catch (Exception e) {
                log.error("**EXCEPTION** - Failed to highlight the element " + element);
                e.printStackTrace();
            }
        }

    }

    /**
     * This function is for generating the xpath with multiple conditions
     *
     * @param Text
     * @param classText
     * @return
     */
    public String buildMultipleXpath(String classText, String Text) {
        return "//*[contains(@class,'" + classText + "') and contains(text(),\"" + Text + "\")]";
    }

    /**
     * KeyBoard Key press
     *
     * @param KeyToPress
     */
    public void keyBoardEvent(Keys KeyToPress) {
        Actions actions = new Actions(DriverManager.getDrv());
        Action act = actions.sendKeys(KeyToPress).build();
        act.perform();
        this.commonHelpers.thinkTimer(1000);
    }

    /**
     * Function - Wait for a certain time period for element to get invisible Case -
     * Shipment Load Progress indicator
     *
     * @param by           - Element
     * @param timeinsecond - tell DriverManager.getDrv() how much second he should wait
     * @return false means element is not visible now and true means still visible.
     */
    public boolean waitUntillEleInvisible(By by, int timeinsecond) {
        boolean flag = true;
        while (flag && timeinsecond != 0) {
            try {
                waitForDriver(DriverManager.getDrv()).until(ExpectedConditions.visibilityOfElementLocated(by));
                this.commonHelpers.thinkTimer(1000);
                timeinsecond--;
            } catch (Exception ex) {
                log.error("**EXCEPTION** Element is not visible (could be expected too) " + ex);
                flag = false;
                break;
            }
        }
        return !flag;
    }

    /**
     * Return element with Link Text
     *
     * @param driver
     * @param linkText
     * @return true/false
     * @author shmarala
     */
    public WebElement elementByLinkTextCheck(WebDriver driver, String linkText) {
        return this.findElement(By.linkText(linkText));
    }

    /**
     * Mouse Action Move to element for taking screenshot more to that particular
     * Element is necessary
     * Mouse hover
     *
     * @param element
     */
    public void Mouse_MoveToElement(WebElement element) {
        Actions actions = new Actions(DriverManager.getDrv());
        actions.moveToElement(element);
        actions.build().perform();
    }

    public void Mouse_MoveToElement(By by) {
        Actions actions = new Actions(DriverManager.getDrv());
        actions.moveToElement(this.findElement(by, false));
        actions.build().perform();
    }

    public void Mouse_MoveToElementClick(By by) {
        Actions actions = new Actions(DriverManager.getDrv());
        WebElement wb = this.findElement(by);
        actions.moveToElement(wb);
        actions.click().build().perform();
    }

    public void DoubleClickElement(WebElement element) {
        Actions actions = new Actions(DriverManager.getDrv());
        actions.doubleClick(element).perform();
    }

    public void mouseHoverJScript(WebElement HoverElement) {
        String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);}else if(document.createEventObject)	{ arguments[0].fireEvent('onmouseover');}";
        ((JavascriptExecutor) DriverManager.getDrv()).executeScript(mouseOverScript, HoverElement);
    }

    public void DragAndDrop(WebElement Fromelement, WebElement ToElement) {
        Actions builder = new Actions(DriverManager.getDrv());
        builder.moveToElement(Fromelement).clickAndHold(Fromelement).perform();
        this.commonHelpers.thinkTimer(1000);
        builder.moveToElement(Fromelement).clickAndHold(Fromelement).moveToElement(ToElement).perform();
        this.commonHelpers.thinkTimer(1000);
        builder.moveToElement(Fromelement).clickAndHold(Fromelement).moveToElement(ToElement).release().build()
                .perform();
    }

    /**
     * Return element with Div Class
     *
     * @param DivClassText
     * @return
     */
    public By elementByDivClass(String DivClassText) {
        return By.xpath(buildXpathForClass(DivClassText));
    }

    /**
     * Return element with Img class
     *
     * @param ImgClassText
     * @return
     */
    public WebElement elementByImgClass(String ImgClassText) {
        return this.findElement(By.xpath(buildXpathForClass(ImgClassText)));
    }

    /**
     * Return Element with id passed
     *
     * @param idText
     * @return
     */
    public WebElement elementById(String idText) {
        return this.findElement(By.id(idText));
    }

    /**
     * This method will build xpath for a href
     *
     * @param aHreftext
     * @return
     */
    public String buildXpathForHref(String aHreftext) {
        return ".//*[contains(@href,'" + aHreftext + "')]";
    }

    /**
     * This method will build xpath for a string when text is passed as a parameter
     *
     * @param text
     * @return
     */
    public String buildXpathForString(String text) {
        String xpath = String.format("//*[contains(text(),\"%s\")]", text);
        switch (text.toUpperCase()) {
            case "EDIT COLUMNS":
                xpath = "//a[contains(@class,'sr-tabs__nav-lnk') and @aria-controls='COLUMNS']";
                break;
            case "RESET":
                xpath = "//a/span[contains(@class,'reset-icn active')]";
                break;
            case "EXPORT":
                xpath = ".//span[contains(@class,'download-icn active')]";
                break;
            case "EXPORT LIST":
                xpath = "//a/span[contains(@class,'download-icn active')]";
                break;
            case "EXPORT LIST POPUP":
                xpath = "//span[contains(@class,'download-icn d-inline-block active')]";
                break;
            case "TYPES":
                xpath = "//a[contains(@class,'sr-tabs__nav-lnk')]/span[contains(text(),'TYPES')]";
                break;
            case "BULK":
                xpath = "//a[contains(@class,'sr-tabs__nav-lnk')]/span[contains(text(),'BULK')]";
                break;
            case "DOWNLOAD CSV":
                xpath = "//input[@id='csv']";
                break;
            case "DOWNLOAD EXCEL":
                xpath = ".//input[@id='xlsx']";
                break;
            case "WHAT'S NEW":
                xpath = "//*[contains(text()," + '"' + "What's New" + '"' + ")]";
                break;
            case "WHAT FORMAT WOULD YOU LIKE TO DOWNLOAD?":
                xpath = "//div[@class='fdx-c-modal__description']/div[contains(text(),'What format would you')]";
                break;
            case "YOUR FILE IS BEING GENERATED":
                xpath = "//div[@class='fdx-c-modal__description']/div [1]";
                break;
            case "DOWNLOAD WILL BEGIN AUTOMATICALLY WHEN PROCESSING HAS FINISHED":
                xpath = "//div[@class='fdx-c-modal__description']/div [2]";
                break;
            case "CLOSE BUTTON POST DOWNLOAD":
                xpath = "//div[contains(@class,'sr-modal-btns')]/button";
                break;
            case "CLOSE CROSS BUTTON":
                xpath = "//div[@class='close-icn bk']";
                break;
            case "BY COMPANY":
                xpath = "//span[contains(text(),\"BY COMPANY\")]";
                break;
            case "COMBINED FILES":
                xpath = "//span[contains(text(),\"COMBINED FILES\")]";
                break;
            case "SHIPMENT DATA":
                xpath = String.format("//a[@role='tab']//*[contains(text(),\"%s\")]", text);
                break;
            // by default the preferred locations click goes to the one under Advisories tab
             case "PREFERRED LOCATIONS":
               xpath = String.format("//span[text()=\"%s\"]",text);
               break;
            case "FedEx Surround":
                xpath = String.format("//div[@class='sr-data'][contains(.,\"%s\")]",text);
                break;
            case "SPECIAL HANDLING":
                xpath = String.format("//label[@class='sr-label'][contains(.,\"%s\")]",text);
                break;
            case "SAVE":
                xpath = String.format("//button[@type='button'][contains(.,\"%s\")]",text);
                break;
        }
        return xpath;
    }


    public String buildGenericXpathForString(String text,String index) {
        {
            if (!(index.equalsIgnoreCase(""))) {
                return String.format("(//*[contains(text(),\"%s\")])[" + Integer.parseInt(index) + "]", text);
            }
            return String.format("//*[contains(text(),\"%s\")]", text);
        }
    }

    /**
     * This method will return the current date in the format provided as argument
     *
     * @param format - Date format should be passed as parameter
     * @return = current date in the provided format
     */
    public String getCurrentDateinFormat(String format) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        StringBuilder sb = new StringBuilder();
        sb.append(now.format(dtf).split(",")[0]).append(" IST, ").append(now.format(dtf).split(",")[1]);
        return sb.toString();
    }

    public String getDateinFormat(String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);// , new Locale(GenericFunction.language,
                                                                         // GenericFunction.country));
        String date = simpleDateFormat.format(new Date());
        return date;
    }

    /**
     * This method wil wait until the document is in ready state
     *
     * @param driver
     */
    public void waitForDOMToLoad(WebDriver driver) {
        waitForDriver(driver).until(d -> (JavascriptExecutor) d).executeScript("return document.readyState")
                .equals("complete");
    }

    /**
     * This method will wait even if we get No Such element exception for 30 seconds
     *
     * @param driver
     * @return webdriver wait
     */
    private WebDriverWait waitForDriver(WebDriver driver) {
        int waitTime = GenericFunction.TIMEOUT;
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
        wait.ignoring(NoSuchElementException.class);
        return wait;
    }

    // This method you can pass a specific time,
    // if some page (Example login) takes more than the normal wait time
    public WebDriverWait waitForDriver(WebDriver driver, int waitTime) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
        wait.ignoring(NoSuchElementException.class);
        return wait;
    }

    /**
     * This method will scroll in view of element
     *
     * @param element to be scrolled to
     */
    public void ScrollIntoView(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("arguments[0].scrollIntoView()", element);
    }

    public void ScrollToLabel(String label) {
        WebElement element = this.findElement(By.xpath(String.format(this.labelForText, label)));
        this.ScrollIntoView(element);
    }

    public void ScrollToTop() {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("window.scrollTo(0,0)");
    }

    /**
     * Scroll to bottom with 0 , document.body coordinates
     */
    public void ScrollToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    public void ScrollByOffset(String offsetX,String offsetY) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("window.scrollBy("+offsetX+", "+offsetY+")","");
    }

    public void JavaScriptClick(WebElement element) {

        try {
            Mouse_MoveToElement(element);
        }catch(Exception e){
            log.error(" ** EXCEPTION ** Unable to Move to Element element : " + e.getMessage());
        }

        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("arguments[0].click()", element);
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void JavaScriptClick(By by) {

        try {
            Mouse_MoveToElement(by);
        }catch(Exception e){
            log.error(" ** EXCEPTION ** Unable to Move to Element element : " + e.getMessage());
        }

        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        commonHelpers.thinkTimer(200);
        js.executeScript("arguments[0].click()", this.findElement(by, false));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    /**
     * This method will find the webelement - @param highlight - false means it will
     * not highlight or true to highlight
     *
     * @param by reference of the webElement
     * @return webelement
     */
    public WebElement findElement(By by, boolean... highlight) {
        waitForDOMToLoad(DriverManager.getDrv());
        WebElement element = null;
        try {
            element = waitForDriver(DriverManager.getDrv()).until(d -> d.findElement(by));
            if (highlight != null && highlight.length > 0) {
                if (highlight[0]) {
                    this.ElementHighlighter(element);
                }
            } else {
                this.ElementHighlighter(element);
            }
        } catch (Exception ex) {
            log.error(" **EXCEPTION** Could not find the element with " + ex + " - locator: " + by);
        }

        return element;
    }


    public void ScrollIntoViewInfinite() {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
            int countR=this.findElements(countOfRows).size();
            WebElement maxRowelement = this.findElement(By.xpath(String.format(rowAtIndex,countR)));
            js.executeScript("arguments[0].scrollIntoView(true);",maxRowelement);
        for (int count = 1; count < 3; count++) {
            WebElement Loadingelement = this.findElement(this.LoadingMoreData);
            if(elementIsDisplayed(LoadingMoreData)) {
                js.executeScript("arguments[0].scrollIntoView(true);", Loadingelement);
            }
            else{
                break;
            }
        }
    }


    public void ScrollIntoViewColumnwise(String ColumnName) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        WebElement maxRowelement = this.findElement(By.xpath("//span[@class='ag-header-cell-text' and text()='"+ColumnName+"']"));
        js.executeScript("arguments[0].scrollIntoView(true);",maxRowelement);
    }

    /**
     * This method will return the webelements when locator is passed
     *
     * @param by
     * @return List of webelements
     */
    public List<WebElement> findElements(By by) {
        waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> elements = null;
        try {
            elements = waitForDriver(DriverManager.getDrv()).until(d -> d.findElements(by));
        } catch (Exception ex) {
            log.error("**EXCEPTION** Could not find the element with " + ex);
        }
        return elements;
    }

    /**
     * Return the list of tabs opened in the browser
     *
     * @return List of tabs in a browser as ArrayList<String>
     */
    public ArrayList<String> GetWindowHandles() {
        return new ArrayList<>(DriverManager.getDrv().getWindowHandles());
    }

    /**
     * This methid wil wait for 30sec until the element is clickable
     *
     * @param by reference of the element
     * @return true/false based on the element clickable
     */
    public boolean waitUntilClickable(By by) {
        try {
            waitForDriver(DriverManager.getDrv()).until(ExpectedConditions.elementToBeClickable(by));
            return true;
        } catch (Exception ex) {
            try {
                this.commonHelpers.thinkTimer(10000);
                waitForDriver(DriverManager.getDrv()).until(ExpectedConditions.elementToBeClickable(by));
                return true;
            } catch (Exception ex1) {
                return false;
            }
        }

    }

    /**
     * This method will wait for 30sec till the provided element is not visible,
     * used extensively for loader in an application.
     *
     * @param by reference of the element
     * @return true/false based on the element visibility
     */
    public boolean waitUntilNotVisible(By by) {
        try {
            waitForDriver(DriverManager.getDrv()).until(ExpectedConditions.invisibilityOfElementLocated(by));
            return true;
        } catch (Exception ex) {
            // log.info("Element is still visible " + ex);
            return false;
        }
    }

    // here we pass the time based on our need. Specially desiged for login
    // but can be used anywhere else where we want to override the time from config
    public boolean waitUntilNotVisible(By by, int waitTime) {
        try {
            waitForDriver(DriverManager.getDrv(), waitTime).until(ExpectedConditions.invisibilityOfElementLocated(by));
            return true;
        } catch (Exception ex) {
            // log.info("Element is still visible " + ex);
            return false;
        }
    }

    /**
     * This method will wait for 30sec till the provided element is visible
     *
     * @param by reference of the element
     * @return true/false based on the element visibility
     */
    public boolean waitUntilVisible(By by) {
        try {
            waitForDriver(DriverManager.getDrv()).until(ExpectedConditions.visibilityOfElementLocated(by));
            return true;
        } catch (Exception ex) {
            log.error("**EXCEPTION** Element is not visible (could be expected too)" + ex);
            return false;
        }
    }

    public boolean waitUntilVisible(By by, int waitTime) {
        try {
            waitForDriver(DriverManager.getDrv(), waitTime).until(ExpectedConditions.visibilityOfElementLocated(by));
            return true;
        } catch (Exception ex) {
            log.error("**EXCEPTION** Element is not visible (could be expected too)" + ex);
            return false;
        }
    }

    /**
     * This method will enter text into text box by clearing the existing text in
     * text box
     *
     * @param by   = webElement reference
     * @param text = Text to enter in textbox
     */
    public void enterText(By by, String text) {
        try {
            WebElement element = this.findElement(by);

            try {
                Mouse_MoveToElement(element);
            }catch(Exception e){
                log.error(" ** EXCEPTION ** Unable to Move to Element element : " + e.getMessage());
            }

            this.ElementHighlighter(element);
            if (element.getTagName() == "input") {
                element.click();
                element.sendKeys(Keys.BACK_SPACE);
                element.sendKeys("");
            }
            element.clear();
            element.sendKeys(text);
            this.waitUntilNotVisible(this.loadingIndicator);
        } catch (Exception ex) {
            log.error(" **EXCEPTION** Failed to Enter Text :" + text + " = with message: " + ex.getMessage());
        }
    }

    public void elementClear(By by) {
        try {
            WebElement element = this.findElement(by);
            element.click();
            element.sendKeys(Keys.CONTROL, "a");
            element.sendKeys(Keys.BACK_SPACE);
        } catch (Exception ex) {
        }
    }

    /**
     * This method is used to click on any provided webElement
     *
     * @param by reference of the webElement
     */
    public void clickOnElement(By by) {

        try {
            Mouse_MoveToElement(by);
        }catch(Exception e){
            log.error(" ** EXCEPTION ** Unable to Move to Element element : " + e.getMessage());
        }

        try {
            this.waitUntilNotVisible(this.loadingIndicator,200);
            this.findElement(by).click();
            this.waitUntilNotVisible(this.loadingIndicator);
        } catch (Exception e) {
            log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
            Assert.fail("Element is not clickable --> " + by.toString());
        }

    }

   public boolean clickOnElementEvent(By by){
        boolean booleanClickFlag = false;
       try {
           this.waitUntilNotVisible(this.loadingIndicator,200);
           Mouse_MoveToElement(by);
           this.findElement(by).click();
           this.waitUntilNotVisible(this.loadingIndicator);
           booleanClickFlag = true;
       } catch (Exception e) {
           log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
//           Assert.fail("Element is not clickable --> " + by.toString());
           booleanClickFlag = false;
       }
       return booleanClickFlag;
   }

    public boolean clickOnElementEvent(WebElement webElement){
        boolean booleanClickFlag = false;
        try {
            this.waitUntilNotVisible(this.loadingIndicator,200);
            Mouse_MoveToElement(webElement);
            webElement.click();
            this.waitUntilNotVisible(this.loadingIndicator);
            booleanClickFlag = true;
        } catch (Exception e) {
            log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
            Assert.fail("Element is not clickable --> " + webElement.toString());

        }
        return booleanClickFlag;
    }

    public void clickOnElement(WebElement webElement) {

        try {
            Mouse_MoveToElement(webElement);
        }catch(Exception e){
            log.error(" ** EXCEPTION ** Unable to Move to Element element : " + e.getMessage());
        }

        try {
            this.waitUntilNotVisible(this.loadingIndicator);
            webElement.click();
            this.waitUntilNotVisible(this.loadingIndicator);
        } catch (Exception e) {
            log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
            Assert.fail("Element is not clickable --> " + webElement.toString());
        }

    }

    public void clickOnElementAtMiddle(WebElement webElement) {
        try {
            // get the button size
            int width = webElement.getSize().getWidth();
            int height = webElement.getSize().getHeight();
            // calculate the center point of the button
            int center_x = webElement.getLocation().getX() + width / 2;
            int center_y = webElement.getLocation().getY() + height / 2;

            // create an Actions object
            Actions actions = new Actions(DriverManager.getDrv());

            // move the mouse to the center of the button and click
            actions.moveToElement(webElement, center_x, center_y).click().perform();

            // this.waitUntilNotVisible(this.loadingIndicator);
            // webElement.click();
            // this.waitUntilNotVisible(this.loadingIndicator);
        } catch (Exception e) {
            log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
            Assert.fail("Element is not clickable --> " + webElement.toString());
        }

    }

    /**
     * This method is used to click on last webElement of elements list
     *
     * @param by reference of the webElement
     */
    public void clickOnLastElement(String by) {
        try {
            List<WebElement> elements = this.findElements(By.xpath(by));
            int count = elements.size();
            elements.get(count - 1).click();
            this.waitUntilNotVisible(this.loadingIndicator);
        } catch (Exception e) {
            log.error(
                    "Unable to click the element : " + e.getMessage() + " Element " + this.findElement(By.xpath(by)));
        }
    }

    /**
     * This method is to fetch the xpath of the button when button name is provided
     * to method
     *
     * @param text = Name of the button
     * @return Xpath of the button
     */
    public String getXPathforButton(String text, boolean... space) {
        if (space.length > 0 && space[0] == true) {
            return ".//button[contains(text(),\"" + text + "\")]";
        }
        return ".//button[text()= \"" + text + "\"]";
    }

    public String getXPathforlink(String text) {
        return ".//a[contains(text(),\"" + text + "\")]";
    }

    public String getXPathforAnyElementWithText(String text) {
        return ".//*[contains(text(), \"" + text + "\")]";
    }

    public String getXPathforCheckboxWithText(String text) {
        if (text.contains("ContextStore-")) {
            text = (String) this.commonHelpers.getValuefromContextStore(text.split("-")[1]);
        }
        return ".//label[contains(text(), \"" + text + "\")]";
    }

    public String getNthInstanceOfXPathForAnyElementWithText(String text, int n) {
        return "(.//*[contains(text(), \"" + text + "\")])[" + n + "]";
    }

    /**
     * This method will return By when String text is passed to method
     *
     * @param text
     * @return
     */
    public By getByusingString(String text) {
        return By.xpath(text);
    }

    /**
     * This method will return the text present in the webElement
     *
     * @param by reference for the WebElement
     * @return
     */
    public String getText(By by) {
        return this.findElement(by).getText();
    }

    public String getText(WebElement element) {
        return element.getText();
    }

    public int getCount(By by) {
        List<WebElement> elements = this.findElements(by);
        int count = elements.size();
        return count;
    }

    /**
     * This method will select the dropdown with given value
     *
     * @param by        reference for the WebElement
     * @param inputType type of the input to select
     * @param input     value to select
     */
    public void selectDropdown(By by, String inputType, String input) {
        try {
            waitUntilVisible(by);
            WebElement element = this.findElement(by);
            this.ElementHighlighter(element);
            Select dropdown = new Select(element);
            switch (inputType) {
                case "text":
                    dropdown.selectByVisibleText(input);
                    break;
                case "value":
                    dropdown.selectByValue(input);
                    break;
                case "index":
                    dropdown.selectByIndex(Integer.parseInt(input));
                    break;
            }
        } catch (Exception ex) {
            log.error("**EXCEPTION** Failed to select dropdown with " + input + " " + inputType);
        }
    }

    public String getSelectedDropdownValue(By by) {
        String text = "";
        try {
            waitUntilVisible(by);
            WebElement element = this.findElement(by);
            this.ElementHighlighter(element);
            Select dropdown = new Select(element);
            text = dropdown.getFirstSelectedOption().getText();
        } catch (Exception ex) {
            log.error("**EXCEPTION** Failed to get selected dropdown option with the locator: " + by);
        }
        return text;
    }

    /**
     * This method gets all the dropdown options in the dropdown
     *
     * @param by = Instance of the scenario
     */
    public List<String> getDropdownOptions(By by) {
        List<WebElement> values;
        List<String> options = new ArrayList<>();
        try {
            waitUntilVisible(by);
            WebElement element = this.findElement(by);
            this.ElementHighlighter(element);
            Select dropdown = new Select(element);
            values = dropdown.getOptions();

            for (WebElement option : values) {
                options.add(option.getText());
            }
        } catch (Exception ex) {
            log.error("Failed to get selected dropdown option with the locator: " + by);
        }
        return options;
    }

    /**
     * This method will scroll Left
     *
     * @param element Web Element to scroll
     */
    public void ScrollToLeft(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("arguments[0].scrollLeft", element);
    }

    /**
     * This method will scroll Right
     *
     * @param element Web Element to scroll
     */
    public void ScrollToRight(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("arguments[0].scrollRight", element);
    }

    /**
     * This method will enter the text in specified location using java script
     *
     * @param by   reference of the element
     * @param text input text
     */
    public void enterTextUsingJavaScriptExe(By by, String text) {
        try {
            WebElement element = DriverManager.getDrv().findElement(by);
            JavascriptExecutor jse = (JavascriptExecutor) DriverManager.getDrv();
            jse.executeScript("arguments[0].value='" + text + "';", element);
        } catch (Exception ex) {
            log.error("**EXCEPTION** Failed to enter the text " + ex);
        }
    }

    public String GetCurrentBrowserURL() {
        return DriverManager.getDrv().getCurrentUrl();
    }

    public boolean IsElementEnabled(By by) {
        boolean flag = false;
        try {
            WebElement element = DriverManager.getDrv().findElement(by);
            flag = element.isEnabled();
        } catch (Exception e) {
            log.error("**EXCEPTION** Element is not enabled. Could be expected too depends on TC -->" + by.toString());
        }
        return flag;

    }

    /**
     * This method will return the Attribute value present in the webElement
     *
     * @param by reference for the WebElement
     * @return
     */
    public String getAttributeValue(By by, String attribute) {
        return this.findElement(by).getAttribute(attribute);
    }

    public void keyBoardEventHoldKey(Keys KeyToPress) {
        Actions actions = new Actions(DriverManager.getDrv());
        Action act = actions.keyDown(KeyToPress).build();
        act.perform();
        this.commonHelpers.thinkTimer(1000);
    }

    public void keyBoardEventReleaseKey(Keys KeyToPress) {
        Actions actions = new Actions(DriverManager.getDrv());
        Action act = actions.keyUp(KeyToPress).build();
        act.perform();
        this.commonHelpers.thinkTimer(1000);
    }

    public void rightClickAndSelect(By element, By optionToSelect) {
        Actions move = new Actions(DriverManager.getDrv());
        move.moveToElement(this.findElements(element).get(1)).contextClick().build().perform();
        this.clickOnElement(optionToSelect);
    }

    public List<String> getRightClickOptions(By element, By options) {
        Actions move = new Actions(DriverManager.getDrv());
        move.moveToElement(this.findElements(element).get(1)).contextClick().build().perform();
        List<WebElement> opt = this.findElements(options);
        List<String> rightClickOptions = new ArrayList<>();
        for (WebElement webElement : opt) {
            rightClickOptions.add(webElement.getText());
        }
        return rightClickOptions;
    }

    public boolean verifyCheckBoxSelection(String checkBoxName, String state) {
        String actualState = this
                .findElement(By.xpath(
                        String.format("//label[contains(text(),\"%s\")]/preceding-sibling::input", checkBoxName)))
                .isSelected() ? "checked" : "unchecked";
        return actualState.equalsIgnoreCase(state);
    }

    public Object getElementPropertyValueUsingJS(By by, String property) {
        WebElement elem = this.findElement(by, true);
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        Object value = "";
        switch (property) {
            case "disabled":
                value = js.executeScript("return arguments[0].disabled", elem);
                break;
            case "checked":
                value = js.executeScript("return arguments[0].checked", elem);
                break;
            case "innerText":
                value = js.executeScript("return arguments[0].innerText", elem);
                break;
        }
        return value;
    }

    public void copyPasteText(By by, String text) {
        StringSelection stringSelection = new StringSelection(text);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
        WebElement input = this.findElement(by);
        input.sendKeys(Keys.SHIFT, Keys.INSERT);
    }

    public void scrollInternalScrollBarOnPage(String offset) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        // js.executeScript("document.getElementsByClassName('ag-body-viewport
        // ag-layout-auto-height ag-row-no-animation')[0].scrollBy(0,550)");
        js.executeScript(
                "document.getElementsByClassName('ag-body-viewport ag-layout-auto-height ag-row-no-animation')[0].scrollBy(0,"
                        + offset + ")");
    }

    // vertical Scroll on the basis of className
    public void scrollVerticallyInternalScrollBarOnPage(String attribute, String attributeValue, String offset) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        // js.executeScript("document.getElementsByClassName('ag-body-viewport
        // ag-layout-auto-height ag-row-no-animation')[0].scrollBy(0,550)");
        if (attribute.equals("class")) {
            js.executeScript("document.getElementsByClassName('" + attributeValue + "')[0].scrollBy(0," + offset + ")");
        } else {
            js.executeScript("document.getElementById('" + attributeValue + "').scrollBy(0," + offset + ")");
        }
    }

    public Object getScrollOffSet(String attribute, String attributeValue, String offsetType) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        Object scroll;
        if (offsetType.equals("top")) {
            if (attribute.equals("class")) {
                scroll = js
                        .executeScript("return document.getElementsByClassName('" + attributeValue + "')[0].scrollTop");
            } else {
                scroll = js.executeScript("return document.getElementById('" + attributeValue + "').scrollTop");
            }
        } else {
            if (attribute.equals("class")) {
                scroll = js.executeScript(
                        "return document.getElementsByClassName('" + attributeValue + "')[0].scrollLeft");
            } else {
                scroll = js.executeScript("return document.getElementById('" + attributeValue + "').scrollLeft");
            }
        }
        return scroll;

    }

    public void scrollHorizontalBarOnPage(String offset) {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript(
                "document.getElementsByClassName('ag-body-horizontal-scroll-viewport')[0].scrollBy(" + offset + ",0)");
    }

    public String getElementCssProperty(By by, String property) {
        String value = this.findElement(by, true).getCssValue(property);
        if (property.contains("color")) {
            value = Color.fromString(value).asHex();
        }
        log.error(property + " for element is :" + value);
        return value;
    }

    public String switchToTabAndGetPageTitle(By by) {
        ArrayList<String> tabs = new ArrayList<>(this.GetWindowHandles());
        DriverManager.getDrv().switchTo().window(tabs.get(1));
        String title = this.getText(by);
        DriverManager.getDrv().close();
        DriverManager.getDrv().switchTo().window(tabs.get(0));
        return title;
    }

    public void fileUpload(By by, String filePath) {
        this.findElement(by).sendKeys(filePath);
    }

    public boolean verifyAlphabeticalSorting(List<WebElement> elemList) {
        String previous = "";
        boolean sortingflag = true;
        for (WebElement elm : elemList) {
            final String current = elm.getText();
            if (current.compareToIgnoreCase(previous) < 0) {
                sortingflag = false;
            }
            previous = current;
        }
        return sortingflag;
    }

    /**
     * This method will enter text into text box by clearing the existing text in
     * text box
     *
     * @param element = webElement
     * @param text    = Text to enter in textbox
     */
    public void enterText(WebElement element, String text) {
        try {
            this.ElementHighlighter(element);
            if (element.getTagName() == "input") {
                element.click();
                element.sendKeys(Keys.BACK_SPACE);
                element.sendKeys("");
            }
            element.clear();
            element.sendKeys(text);
        } catch (Exception ex) {
            log.error(" **EXCEPTION** Failed to Enter Text :" + text + " = with message: " + ex.getMessage());
        }
    }

    /**
     * This method will return the Attribute value present in the webElement
     *
     * @param element reference for the WebElement
     * @return
     */
    public String getAttributeValue(WebElement element, String attribute) {
        return element.getAttribute(attribute);
    }

    public boolean verifyDefaultSelectedDateInCalendar() {
        boolean check = false;
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat simpleformat = new SimpleDateFormat("d MMMM yyyy EEEE");
        String[] toArr = simpleformat.format(cal.getTime()).split(" ");
        String calendarDate = this.getText(currentDate);
        if (calendarDate.equals(toArr[0])) {
            log.error("Date Range is picking today date by default");
            check = true;
        }
        this.clickOnElement(By.xpath(String.format(dateXpath, toArr[0])));
        return check;
    }
    public String buildGenericXpathForStringforPurpleBar(String text,String index) {
        {
            if (!(index.equalsIgnoreCase(""))) {
                return String.format(this.purplebarxpath+"[" + Integer.parseInt(index) + "]", text);
            }
            if(elementIsDisplayed(By.xpath(favname)))
            {
                String favlen= this.getText(By.xpath(favname));
                Assert.assertTrue(favlen.length()>5);
            }
            else if(elementIsDisplayed(By.xpath(viewname)))
            {
                String viewlen= this.getText(By.xpath(viewname));
                Assert.assertTrue(viewlen.length()>5);
            }
            return String.format(this.purplebarxpath,text);
        }
    }

    public String buildGenericXpathForStringforAuditTable(String text,String index) {
        {
            if (!(index.equalsIgnoreCase(""))) {
                return String.format(this.audittablexpath+"[" + Integer.parseInt(index) + "]", text);
            }
            return String.format(this.audittablexpath,text);
        }
    }



    public boolean verifyDefaultTime() {
        boolean flag = true;
        if (this.commonHelpers.verifyKeyinContextStore("preferredTimeFormat")) {
            String timeFormat = (String) this.commonHelpers.getValuefromContextStore("preferredTimeFormat");

            String fromHr = this.getSelectedDropdownValue(By.xpath(String.format(this.hours, "1")));
            String fromMins = this.getSelectedDropdownValue(By.xpath(String.format(this.minutes, "1")));
            String ToHr = this.getSelectedDropdownValue(By.xpath(String.format(this.hours, "2")));
            String ToMins = this.getSelectedDropdownValue(By.xpath(String.format(this.minutes, "2")));
            if (timeFormat.equalsIgnoreCase("12-Hour")) {
                String fromAmPm = this.getSelectedDropdownValue(By.xpath(String.format(this.ampmOptions, "1")));
                String ToAmPm = this.getSelectedDropdownValue(By.xpath(String.format(this.ampmOptions, "2")));
                if (!(fromHr.equals("12") && fromMins.equals("00") && fromAmPm.equalsIgnoreCase("AM")
                        && ToHr.equals("11") && ToMins.equals("59") && ToAmPm.equalsIgnoreCase("PM"))) {
                    flag = false;
                }
            }
            if (timeFormat.equalsIgnoreCase("24-Hour")) {
                if (!(fromHr.equals("00") && fromMins.equals("00") && ToHr.equals("23") && ToMins.equals("59"))) {
                    flag = false;
                }
            }
        }

        return flag;
    }

    public void selectTime(String dateWithTime, String timeType) {
        String index = "2";
        if (dateWithTime.contains("ContextStore-")) {
            dateWithTime = (String) this.commonHelpers.getValuefromContextStore(dateWithTime);
        }
        if (timeType.equals("fromTime")) {
            index = "1";
        }
        String[] time = dateWithTime.split(" ");
        String[] hrMin = time[1].split(":");
        this.selectDropdown(By.xpath(String.format(this.hours, index)), "text", hrMin[0]);
        this.selectDropdown(By.xpath(String.format(this.minutes, index)), "text", hrMin[1]);
        if (time.length > 1) {
            this.selectDropdown(By.xpath(String.format(this.ampmOptions, index)), "text", time[2]);
        }

    }

    /*
     * IFRAME related code
     ** 
     * START**
     */
    public void switchToIframe(String idOrName) {
        DriverManager.getDrv().switchTo().frame(idOrName);
    }

    public void switchToIframe(int count) {
        DriverManager.getDrv().switchTo().frame(count);
    }

    public void switchToParentIframe() {
        DriverManager.getDrv().switchTo().defaultContent();

    }
    /*
     * IFRAME related code
     ** 
     * END**
     */

    public void clickOnPage() {
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("document.getElementsByTagName('html')[0].click()");
    }

    public void validationOfLabels(DataTable data) throws InterruptedException {
        Thread.sleep(3000);
        List<String> dataList = data.asList(String.class);
        for (String dataValue : dataList) {
            if(dataValue.contains("Context-")){
                dataValue = String.valueOf(this.commonHelpers.getValuefromContextStore(dataValue));
            }
            Assert.assertTrue("The Value : "+ dataValue + " is not displayed on screen",elementIsDisplayed(By.xpath(String.format(labelContainsText,dataValue))));
        }
    }


    public void verifyCheckBox_PerformAction(By by,String state) {
        //checked" : "unchecked"
        WebElement wb = this.findElement(by);
        if(state.equalsIgnoreCase("checked")){
            if(wb.isSelected()==false){
                this.JavaScriptClick(by);
            }
            else {
                this.JavaScriptClick(by);
                this.JavaScriptClick(by);
            }
        } else if (state.equalsIgnoreCase("unchecked")) {
            if(wb.isSelected()==true){
                this.JavaScriptClick(by);
            }
        }
    }

    public void verifyRadioBox_PerformAction() {
        boolean csvStatus = this.verifyCheckBoxSelection("csv", "checked");
        boolean xlsxStatus = this.verifyCheckBoxSelection("xlsx", "checked");
        if(csvStatus==true){
            this.JavaScriptClick(this.ExcelRadioBox);
        }
        else if(xlsxStatus==true){
            this.JavaScriptClick(this.CSVRadioBox);
        }
    }

    public void Mouse_MoveToElement_Click(By by) {
        Actions actions = new Actions(DriverManager.getDrv());
        actions.moveToElement(this.findElement(by, false));
        actions.click().build().perform();
    }

    public void PageRefresh(){
        DriverManager.getDrv().navigate().refresh();
    }


    public void clickOnElementByJavaScriptIndex(String text,String index){
        commonHelpers.thinkTimer(300);
        this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(text,index)));
    }
    public void selectFilterOptions(String filterOptions){
        SoftAssertions softly = new SoftAssertions();
        ShipmentOverviewPage shipmentOverviewPage =new ShipmentOverviewPage(commonHelpers);
        this.Refresh_Page(2);
        if(this.elementIsDisplayed(CloseUpdateTerms)){
            this.JavaScriptClick(CloseUpdateTerms);
        }
        this.commonHelpers.thinkTimer(5000);
        String[] levels = filterOptions.split("-");
        clickOnElement(shipmentOverviewPage.filterChevron);// Click on Filter
        for(String level : levels){
            if(level.contains(":")){
                String[] text = level.split(":");
                this.waitUntilVisible(this.getByusingString(this.buildGenericXpathForString(text[0],text[1])));
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(text[0],text[1])));
            }else {
               // this.waitUntilVisible(By.xpath(String.format(shipmentOverviewPage.containsPlaceHolder, level)));
               // this.JavaScriptClick(By.xpath(String.format(shipmentOverviewPage.containsPlaceHolder, level)));
                this.waitUntilVisible(By.xpath(String.format(shipmentOverviewPage.containsFilterValue, level)));
                this.JavaScriptClick(By.xpath(String.format(shipmentOverviewPage.containsFilterValue, level)));
            }
        }
    }

    public static boolean getCEHostExecution(){
        boolean systemServerFlag=false;
        try {
            String systemName = InetAddress.getLocalHost().getHostName();
            String configMachine = GenericFunction.ReadConfigFile("CEServerMachine");
            if(systemName.equalsIgnoreCase(configMachine)){
                systemServerFlag = true;
            }
//            System.out.println("System Name : " + systemName);
        }
        catch (Exception E) {
            System.err.println(E.getMessage());
        }
        return systemServerFlag;
    }

    public void Refresh_Page(int count) {
        try {
            while (count > 0) {

                DriverManager.getDrv().navigate().refresh();
                this.waitUntilNotVisible(this.loadingIndicator);
                this.commonHelpers.thinkTimer(2000);
                if ((this.elementIsDisplayed(this.Errorpage))) {
                    log.info("Error page occured" + this.findElement(this.Errorpage).getText());

                }
                count--;
            }
        }
        catch (Throwable ex)
        {
            log.error(" **EXCEPTION** Could not find the element with " + ex +" Error page Occured");

        }
    }

    public boolean javaScriptClickOnElementEvent(By by){
        boolean booleanClickFlag = false;
        try {
            this.waitUntilNotVisible(this.loadingIndicator,200);
            Mouse_MoveToElement(by);
            this.JavaScriptClick(findElement(by));
            this.waitUntilNotVisible(this.loadingIndicator);
            booleanClickFlag = true;
        } catch (Exception e) {
            log.error(" ** EXCEPTION ** Unable to click the element : " + e.getMessage());
//           Assert.fail("Element is not clickable --> " + by.toString());
            booleanClickFlag = false;
        }
        return booleanClickFlag;
    }

    public boolean isAttributePresent(WebElement element, String attribute) {
        boolean result = false;
        try {
            String value = element.getAttribute(attribute);
            if (value != null){
                result = true;
            }
        } catch (Exception e) {}

        return result;
    }
}