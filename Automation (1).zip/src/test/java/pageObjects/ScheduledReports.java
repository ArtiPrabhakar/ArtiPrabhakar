package pageObjects;

import common.DriverManager;
import io.cucumber.datatable.DataTable;
import common.CommonHelpers;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

@Slf4j
public class ScheduledReports extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public static String ModifiedName=null;
    public static String reportFile=null;
    public static String formattedDate=null;
    public By scr_Btn_CreateAScheduledReport = By.xpath("//span[contains(text(),'CREATE A SCHEDULED REPORT')]");
    public By scr_Txt_Report_ChooseAReport = By.xpath("//div[contains(text(),'Choose a Report')]");
    public By scr_TxtBox_Report_ReportName = By.xpath("//input[@formcontrolname='reportName']");

    public By scr_select_Report_type = By.xpath("//label[contains(text(),'Report Type')]/..//select");

    public By  firstRecordName = By.xpath("(//div[@role='gridcell' and @col-id='reportName'])[1]//a");

    public String scr_errorMessageXpathReportPage = "(//label[contains(text(),'%s')]/../following::div[contains(text(),'%s')])[%s]";

    public By scr_DrpDwn_Report_ChooseView = By.xpath("(//div[@class='sr-tabs']/ul/li/a[@role='tab']/span[@class='sr-tabs__nav-lnk-txt'])[4]");
    public By scr_SearchBox_Report_ChooseView_InsideDrpDwn = By.xpath("//div[@class='sr-searchbox']/input");
    public By scr_DrpDwn_Report_ChooseAccounts = By.xpath("(//app-sr-tabs[@class='sr-shipment-tabs']//span[@class='chevron'])[2]");
    public By scr_DrpDwn_CE_Report_ChooseAccounts = By.xpath("//app-company-workgroup-dropdown//span[@class='sr-ctdropdown-chevron float-r']");
    public By scr_DrpDwn_Report_ChooseAccounts_InsideDrpDwn = By.xpath("(//div[contains(@class,'sr-searchbox__icon')]/following::input)[1]");
    public By scr_TxtBox_Report_ReportPrefix = By.xpath("//input[@formcontrolname='reportPrefix']");

    public By scr_DrpDwn_SendOption_ChooseOption = By.xpath("//select[@name='sr-select']/option[contains(text(),'Download')]/..");
    public By scr_DrpDwn_SendOption_Language = By.xpath("//option[contains(text(), 'English')]/..");
    public By scr_TxtBox_SendOption_AddEmail = By.xpath("//input[@formcontrolname='mail']");
    public By scr_TxtBox_SendOption_SubjectMessage = By.xpath("//input[@formcontrolname='mailSubject']");
    public By scr_TxtBox_SendOption_MailMessage = By.xpath("//textarea[@formcontrolname='mailMessage']");

    public String elipsesByRecord = "//div[@col-id='reportName']//a[contains(text(),'%s')]/preceding::div[@col-id='elipsis' and @role='gridcell']//div[contains(@class,'kebab-icn')]";

    public String actionOnRecord = "//div[@class='sr-elipsis-dropdown']//*[contains(text(),'%s')]";
    public By scr_Btn_SendOption_AddEmailAddress = By.xpath("//span[contains(text(), '+ Add Email Address (Max 4)')]");
    public By scr_DrpDwn_Frequency_Frequency = By.xpath("//label[contains(text(), 'FREQUENCY')]/following::app-sr-dropdown[@formcontrolname='frequency']");
    public By scr_DrpDwn_Frequency_Hour = By.xpath("//div[@class='inline-dropdown d-flex']//a[@role='tab']");
    public By scr_SearchBox_Frequency_Hour_InsideDrpDwn = By.xpath("//input[contains(@class,'sr-searchbox__input')]");
    public By scr_DrpDwn_Frequency_TimeZone = By.xpath("//label[contains(text(), 'TIMEZONE')]/following::a[@role='tab']");
    public By scr_DrpDwn_Frequency_TimeZone_InsideDrpDwn = By.xpath("//label[contains(text(), 'TIMEZONE')]/following::input[@type='text']");
    public By scr_Btn_Frequency_StartEndDates_StartDate = By.xpath("//input[@formcontrolname='fromDate']");
    public By scr_Btn_Frequency_StartEndDates_EndDate = By.xpath("//input[@formcontrolname=\"toDate\"]");

    public By scr_Btn_RightArrow = By.xpath("(//th[@class='next available'])[1]");
    public By scr_Btn_Filters = By.xpath("//div[@class='sr-schedule-report-filter-box']");
    public By scr_Btn_Filters_ReportName = By.xpath("//a[normalize-space()='REPORT NAME']");
    public By scr_SearchBox_Filters_ReportName_Search = By.xpath("//input[@placeholder=\"Search: Report Name\"]");
    public By scr_Btn_Filters_View = By.xpath("//a[text()='VIEW']");
    public By scr_DrpDwn_Filters_View_All = By.xpath("//a[@aria-controls='All']");
    public By scr_Btn_Filters_Hour = By.xpath("//a[normalize-space()='HOUR']");
    public By RRfilterChevron = By.xpath("//span[@class='sr-schedule-report-filter-box__title']");
    public String RRfilterApply = "//button[contains(text(),\"%s\")]";
    public String selectCreatorType = "//label[contains(text(),\"%s\")]";
    public String selectFilter = "//*[contains(text(),\"%s\")]";
    public String apply = GenericFunction.locale != Constants.EN_US
            ? this.genericFunctionObject.getLocalizedValue("Apply")
            : "Apply";
    public String applyUpperCase = apply.toUpperCase();
    public String RRbubbleFilters = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s')]";
    public String filters_RR = "//*[contains(text(),'%s')]";

    public String filters_path = "//div[@class='sr-pill__label']//span[contains(text(),'%s')]/..//span[contains(text(),'%s')]";

    public String columnName = "//a[text()='%s']//ancestor::div[@role='row']//span[@class='creator_0']";

    public By scr_Btn_Filters_Download = By.xpath("//a[normalize-space()='DOWNLOAD']");
    public By scr_DrpDwn_Filters_Download_InsideDownload = By.xpath("//select[@name='sr-select']");
    public By scr_Btn_Filters_Frequency = By.xpath("//a[normalize-space()='FREQUENCY']");
    public By scr_Btn_Filters_DateStartEnd = By.xpath("//a[normalize-space()='DATE: START/END']");
    public By scr_Btn_HamburgerIcn = By.xpath("//div[@class=\"hamburger-icn\"]");
    public By scr_Btn_HamburgerIcn_DeleteAll = By.xpath("//a[normalize-space()= 'Delete All']");
    public By scr_Btn_ClearAll = By.xpath("//button[contains(text(), 'Clear All')]");
    public String scr_CheckBox_Company = "//app-company-workgroup-dropdown//*[contains(text(),\"%s\")]";
    public String dateSelection = "//div[@class='calendar left']//td[contains(@class,'available')]/span[./text()=\"%s\"]";
    public String scr_containsHolder = "//*[contains(text(),\"%s\")]";
    public By Auditfavname = By.xpath("//div[@class='ag-root ag-unselectable ag-layout-auto-height']//*[contains(text(),'FAVORITE')]");
    public By Auditviewname = By.xpath("//div[@class='ag-root ag-unselectable ag-layout-auto-height']//*[contains(text(),'VIEW')]");


    public String selectAccountCheckBox = "(//input[@role='checkbox']/following::label)[%s]";
    public String scr_Frequency_Hours = "//label[@for='%s']";

    public By specificDateRangeFrom = By.xpath("//input[@name='fromDate']");
    public By specificDateRangeTo = By.xpath("//input[@name='toDate']");
    public By monthField = By.xpath("//th[@class='month drp-animate']");
    public By calenderLeftArrow = By.xpath(
            ".//span[@class='calendar-icon calendar-icon--left']//parent::span//parent::button");
    public By calenderRightArrow = By.xpath(
            ".//span[@class='calendar-icon calendar-icon--right']//parent::span//parent::button");

    public By scr_Btn_ClearAll_disabled = By.xpath("//button[contains(text(),'Clear All') and @disabled]");
    public By filterCancelButton = By.xpath("//app-shipment-filter//button[contains(text(),'CANCEL')]");
    public By RRfilterCancelButton = By.xpath("//button[contains(text(),'CANCEL')]");

    public String scr_dropdown_SendOptions = "(//option[text()=\"%s\"]/parent::select)[1]";

    public String scr_selectOption ="//select/option[text()=\"%s\"]";
    public By scr_Btn_Continue = By.xpath("//button[contains(text(), 'CONTINUE')]");
    public By scr_Btn_Save = By.xpath("//button[contains(text(), 'SAVE')]");

    public By scr_DrpDwn_Frequency_DayOfTheWeek = By.xpath("(//label[contains(text(),'DAY OF THE WEEK')]/../following::span[@class='chevron'])[1]");

    public By scr_Btn_SendOption_Continue = By.xpath("(//button[contains(text(), 'CONTINUE')])[2]");

    public By HamburgIcon_ClearAll = By.xpath("//div[@class='hamburger-icn']//following::button[.='Clear All']");
    public By btn_Hour = By.xpath("//li[contains(@class,'multinav')]//a[contains(.,'HOUR')]");
    public By btn_Hour_DrpdwnTextBox = By.xpath("//div[@class='sr-searchbox']//input");

    public String reportTypeDropdown = "//select[@name='sr-select']";

    public String reportTypeOptions = "//input[@tabindex='0' and @type='checkbox' and @id='%s']";

    public String filterButtonDropdown = "//div[@class='sr-schedule-report-filter-box']";
    public By btn_Hour_Dropdown = By.xpath("//a[@class='sr-tabs__nav-lnk sr-tabs__nav-lnk--menu']");
    public By btn_Hour_Chckbox = By.xpath("//input[@tabindex='0' and @type='checkbox']");
    public By btn_Hour_All_Chckbox = By.xpath("//input[@tabindex='0' and @type='checkbox' and @id='All']");
    public By btn_Hour_Apply = By.xpath("//button[contains(text(),'APPLY')]");

    public By btn_frequency_Apply = By.xpath("//option[@value='0: All']//parent::select");

    public By Val_breadcrumb = By.xpath("//a[@class='sr-breadcrumb__item']");

    public By title = By.xpath("//div[@class='sr-pre-shipment__title-bold m-l-6']");

    public By Reset = By.xpath("//button[contains(.,'Reset')]");
    public By FilterCount = By.xpath("// span[@class='m-l-2 fw-bold']");
    public By Badge = By.xpath("//span[@class='sr-schedule-report__badge']");
    public By scr_label_AccName = By.xpath("//li[contains(@class, '_main__menu')]//div[contains(@class, 'separator')]");
    public By scr_Reports_Firstrecord = By.xpath("(//div[@col-id='creator']//div//span[contains(@class,'creator')])[1]");
    public By scr_list_Allreports = By.xpath("//div[@col-id='creator']//div//span[contains(@class,'creator')]");
    public By scr_Filters_Creator_SearchboxText = By.xpath("//input[contains(@placeholder,'Search: First Name,')]");
    public By scr_Filters_Creatorlist = By.xpath("//input[@tabindex='0']//..//label");
    public By scr_Filters_CreatorOpts_SelectAll = By.xpath(" //input[@value='Select All']");
    public By scr_RR_Apply = By.xpath("//button[contains(text(),'APPLY')]");
    public By scr_DrpDwn_RRFilters_ViewTab = By.xpath("//a[@aria-controls='All']");
    public By scr_RRFilters_ViewTab_inside = By.xpath("//label[@for='All']");

    public By FrstRow = By.xpath("//div[@row-id='0']//div[@col-id='reportName']//a");
    public String company = null;
    public By scr_file_ReportName = By.xpath("(//div[@col-id='reportName']//app-report-link//div//a)[1]");
   // public By scr_EditBtn_ReportInformation = By.xpath("(//img[@src='../../../../assets/images/edit_icon_white@3x.png'])[1]");
    public By scr_EditBtn_ReportInformation = By.xpath("(//img[@src='assets/images/edit_icon_white@3x.png'])[1]");

    public By scr_SearchBox_Productcenter_Companies = By.xpath("//input[@placeholder='Search Accounts / Companies / Global Entity Numbers']");
    public By scr_Btn_Productcenter_companies_DeleteIcon = By.xpath("//span[@class='delete-icn m-l-2']");
    public By scr_Btn_Pdtcenter_companies_DltConfirmation = By.xpath("//span[contains(text(), 'Delete')]");
    public By scr_Btn_Pdtcenter_companies_close = By.xpath("//button[contains(text(), ' Close ')]");
    public By scr_Txt_ChooseAcc_ErrorMsg = By.xpath("//div[contains(text(), ' Company associated with this report')]");
    public By scr_DrpDwn_ChooseAcc = By.xpath("//div[@class='sr-ctdropdown']//div[@class='sr-ctdropdown']");
    public By scr_DrpDwn_ChooseAcc_DrpDwnValues = By.xpath("(//mat-tree[@role='company-tree']//mat-tree-node//div//div//input[@role='checkbox'])[2]");
    public By scr_DrpDwn_ChooseAcc_DrpDwn_Apply = By.xpath("//button[normalize-space()='Apply']");
    public By scr_ReportFile_CompanyName = By.xpath("//div[@row-id=0]//div[@col-id='company']//span");
    public By scr_Chkbox_Creatoropt = By.xpath("(//input[@tabindex='0']//..//label)[3]");
    public By scr_Txt_ReportInfo_companyName = By.xpath("//div[contains(text(), 'Company')]//div");
    public By scr_Txt_Report_continue = By.xpath("(//button[contains(text(), 'CONTINUE')])[1]");
    public By scr_Txt_Reportinfo_comName = By.xpath("(//div[@class='account-text'])[1]");
    public By scr_icon_EditIcon = By.xpath("//img[contains(@src,'edit_icon')]/parent::div");
    public By scr_icon_ActiveIcon = By.xpath("//img[contains(@src,'edit_icon')]/parent::div[@class='sr-list-icn']");
    public String Scr_companyName = "//*[contains(text(),\"%s\")]";
    public String cancelButtonConfirmationDialog = "//span[contains(text(),\"%s\")]//parent::button";
    public String deleteButtonConfirmationDialog = "//div[@class='sr-modal-btns m-b-2']//button[contains(text(),\"%s\")]";
    public By ListOfReports = By.xpath("//div[@col-id='reportName']");
    public By DetailReportLabel = By.xpath("//div[@class='sr-label sr-label--wt']");
    public String NotSortable = "//span[@class='ag-header-cell-text' and text()='%s']";
    public String Sortable = "//span[.='%s']//..//span[@ref='eSortAsc']";
    public String DetailReport_ColumnName = "//div[@col-id='%s' and @role='gridcell']";
    public By hamburgerIcon = By.xpath("//div[@class='hamburger-icn']");
    public By hamburgerIconOption = By.xpath("//ul[@class='sr-bulkMenulist__items']//a");
    private String purpleBarSpanData = "//div[contains(text(),'%s')]/span";
    private String purpleBarDivData = "//div[contains(text(),'%s')]/div";

    private By purpleBarAccountData = By.xpath("//div[contains(text(),'Account :')]/div[@class='account-text']");

    public By Status_CompletedOption = By.xpath("//input[@id='option1']");
    public By Status_FailedOption = By.xpath("//input[@id='option2']");
    public By Edit_FreqInfo = By.xpath("//div[contains(.,'Frequency Information') and @class='sr-label sr-label--wt']//..//..//img");
    public String FetchFieds_DetailReport = "(//div[@class='sr-list-txt'])[%s]//div[contains(@class,'sr-data')]";
    public By Editicon = By.xpath("//div[@class='sr-list-icn']//img");
    public By FreqInfoTabFreqLabel = By.xpath("//div[.=' Frequency Information ']//..//div[contains(.,' Frequency : ')]//span");
    public By Btn_Back = By.xpath("//button[@class='sr-btn sr-btn--wt']");
    public By label_ReportName = By.xpath("//div[@class='sr-caro-header-txt']//span");
    public By noResult = By.xpath("//div[@class='sr-multinav-subchild--noresult']");
    public By ActiveTab_Status = By.xpath("//a[@class='sr-tabs__nav-lnk sr-tabs__nav-lnk--menu active']//span[@class='sr-tabs__nav-lnk-txt']");
    public By getLable_EditReport = By.xpath("(//div[@class='sr-section__title'])[1]");
    public By getLabel_GuidanceText = By.xpath("//div[@class='sr-download-center__title']");
    public By VerifyDisabledFields_EditOption = By.xpath("//div[contains(@class,'cursor-none')]//label[contains(@class,'lnk-txt')]");
    public By scr_Report_DwnloadIcn = By.xpath("(//div[@class='active download-file-icn --dk cursor-pointer'])[1]");
    public By scr_btn_DeleteSelected = By.xpath("//a[contains(text(), 'Delete Selected')]");
    public By scr_Report_CheckBoxes = By.xpath("//div[@class='ag-selection-checkbox']//input[@ref='eInput']");
    public String scr_Report_CheckBoxesIndex = "(//div[@class='ag-selection-checkbox']//input[@ref='eInput'])[%s]";
    public By scr_report_Hamburger_Dwnloadoptn = By.xpath("//a[contains(text(), 'Download Selected')]");
    public By scr_DwnldSelected_ErrMsg = By.xpath("//div[contains(text(), 'Cannot download more')]");
    public By scr_DwnldSelected_Cancel = By.xpath("//span[contains(text(),'Cancel')]");
    public By scr_btn_DwnldSelected = By.xpath("//a[contains(text(), 'Download Selected')]");
    public By scr_DltSelected_ConfirmPopup = By.xpath("//div[contains(text(),'delete the scheduled report?')]");
    public By scr_btn_delete = By.xpath("//button[contains(text(),'Delete')]");

    public By scr_Txt_Filterbuble_All = By.xpath("//span[@class='sr-pill__val']//span[1]");
    public By scr_Chkbox_Creatorin = By.xpath("(//input[@tabindex='0']//..//label)[2]");

    public By drpdwn_freq_download = By.xpath("//select[@name='sr-select']");

    public By ReportType = By.xpath("//select[contains(@class,'fdx-c-form-group__select cursor-pointer ng-untouched ng-pristine ng-valid')]");
    public String Edit_icon = "//div[contains(text(),\"%s\")]//..//..//img[contains(@src,'edit_icon')]";
    public String getVal_Keybased = "//*[contains(text(),\"%s\")]//span";
    public By StatusTabInFilters = By.xpath("//a[text()='STATUS']");

    public By NonEditable_ReportType = By.xpath("//app-sr-dropdown[@formcontrolname='reportType']//form[contains(@class,'ng-untouched')]");

    public By HourRunTime = By.xpath("(//input[@role='checkbox'])[1]");
    public By emailBody=By.xpath("//div[contains(@class,'subject')]/following-sibling::div");
    public By emailSubject=By.xpath("//div[contains(@class,'subject')]");
    public By reportFileName=By.xpath("//div[@class='file-detailsSP__saveAsTxt']/following-sibling::div");
    public String chooseviewdrpdwnval = "//*[@class='sr-weather-multiselect__items margin-0']//li//*[contains(text(),\"%s\")]";
    public By chooseviewbtn = By.xpath("//a[@aria-controls='ALL SHIPMENTS']//*[@class='chevron']");

    public ScheduledReports(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
    }

    public void ClickOnDropDownOptions(String value) {

        commonHelpers.thinkTimer(300);
        this.JavaScriptClick(By.xpath("//span[contains(text(), '" + value + "')]"));

    }

    public void ClickOnDropDownCheckBoxOption(String value)  {
        this.JavaScriptClick(By.xpath(String.format(scr_CheckBox_Company,value)));
    }

    public void clickOnSelectDropDown(String value) {
        this.JavaScriptClick(By.xpath(String.format(scr_dropdown_SendOptions,value)));
        try {
            Thread.sleep(4000);
        } catch (Exception e) {

        }
        this.JavaScriptClick(By.xpath(String.format(scr_selectOption,value)));
    }


    public void selectFromAndToDates(String startDate,String endDate){

        JavaScriptClick(scr_Btn_Frequency_StartEndDates_StartDate);
        Date currentDate = new Date();
        LocalDateTime localDateTime = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        int startDayOfMonth = localDateTime.plusDays(Integer.parseInt(startDate)).getDayOfMonth();
        int startMonthValue = localDateTime.plusDays(Integer.parseInt(startDate)).getMonthValue();

        int endDayOfMonth = localDateTime.plusDays(Integer.parseInt(endDate)).getDayOfMonth();
        int endMonthValue = localDateTime.plusDays(Integer.parseInt(endDate)).getMonthValue();

        JavaScriptClick(By.xpath(String.format(dateSelection,String.valueOf(startDayOfMonth))));
        JavaScriptClick(scr_Btn_Frequency_StartEndDates_EndDate);

        if((endMonthValue-startMonthValue) > 0){
            JavaScriptClick(scr_Btn_RightArrow);
            JavaScriptClick(By.xpath(String.format(dateSelection,String.valueOf(endDayOfMonth))));
        }else{
            JavaScriptClick(By.xpath(String.format(dateSelection,String.valueOf(endDayOfMonth))));
        }


    }


    public void fillInformationInReportTab(String reportName,String reportPrefix,String chooseView,String accountType,String chooseAccount,String format,String reportNameKey,String reportType) {

        if(!GenericFunction.PORTAL.contains("CE")) {
            if(!reportType.equalsIgnoreCase("")) {
                this.selectDropdown(scr_select_Report_type, "text", reportType);
            }
        }

        if(reportName.equalsIgnoreCase("")){
            String randomNumber = "Auto"+this.getCurrentDateinFormat("MMddYYYY,HHmmss").replace("IST", "").replace(",", "").replace(" ", "");
            this.commonHelpers.AddToContextStore(reportNameKey,randomNumber);
            this.enterText(scr_TxtBox_Report_ReportName,randomNumber);
        }else if(!reportName.equalsIgnoreCase("Modification Not Required")){
            this.commonHelpers.AddToContextStore(reportNameKey,reportName);
            this.commonHelpers.thinkTimer(3000);
            this.enterText(scr_TxtBox_Report_ReportName,reportName);
        }

        if (!reportPrefix.equalsIgnoreCase("")) {
            this.JavaScriptClick(scr_TxtBox_Report_ReportPrefix);
            this.enterText(scr_TxtBox_Report_ReportPrefix,reportPrefix);
        }

        if (!chooseView.equalsIgnoreCase("")) {
            this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
            this.enterText(scr_SearchBox_Report_ChooseView_InsideDrpDwn, chooseView);
            this.ClickOnDropDownOptions(chooseView);
        }

        if(!reportType.contains("Pre-Shipment")) {
            if (!chooseAccount.equalsIgnoreCase("")) {

                if (GenericFunction.PORTAL.contains("CE")) {
                    this.JavaScriptClick(scr_DrpDwn_CE_Report_ChooseAccounts);
                    this.enterText(scr_DrpDwn_Report_ChooseAccounts_InsideDrpDwn, chooseAccount);
                    this.ClickOnDropDownCheckBoxOption(chooseAccount);
                } else {
                    this.JavaScriptClick(scr_DrpDwn_Report_ChooseAccounts);
                    if (chooseAccount.length() < 3) {
                        int selectAccounts = Integer.parseInt(chooseAccount);

                        if (selectAccounts > 1) {
                            for (int eachAccount = 1; eachAccount <= selectAccounts; eachAccount++) {
                                this.JavaScriptClick(By.xpath(String.format(selectAccountCheckBox, eachAccount)));
                                this.commonHelpers.AddToContextStore("account" + eachAccount, this.getText(By.xpath(String.format(selectAccountCheckBox, eachAccount))));
                            }
                        } else {
                            this.JavaScriptClick(By.xpath(String.format(selectAccountCheckBox, selectAccounts)));
                        }

                    } else {
                        this.enterText(scr_DrpDwn_Report_ChooseAccounts_InsideDrpDwn, chooseAccount);
                        this.JavaScriptClick(By.xpath(String.format(scr_containsHolder, chooseAccount)));
                    }
                }
            }

            if (GenericFunction.PORTAL.contains("CE")) {
                if(elementIsDisplayed(this.getByusingString(this.buildGenericXpathForString("Apply", "")))) {
                    this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Apply", "")));
                }
            }

            if (accountType.equalsIgnoreCase("Payer")) {
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString("Both", "")));
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString("Payer", "")));
            } else if (accountType.equalsIgnoreCase("Shipper")) {
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString("Both", "")));
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString("Shipper", "")));
            } else if(!accountType.equalsIgnoreCase("Modification Not Required")){
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString("Both", "")));
            }

        }


        if(format.equals("csv")){
            this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(".csv","")));
        }
        else if(format.equals("viceversa")) {
            verifyRadioBox_PerformAction();
        }
        else{
            this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(".xlsx","")));
        }

    }

    public void fillAllTheInformationInSendOptionTab(String chooseOption, String email, String language, String subject, String message) {
        waitUntilClickable(scr_DrpDwn_SendOption_ChooseOption);
        this.ScrollToTop();
        this.selectDropdown(scr_DrpDwn_SendOption_ChooseOption, "text", chooseOption);
        this.selectDropdown(scr_DrpDwn_SendOption_Language, "text", language);

        if (chooseOption.equals("Email") || chooseOption.equals("Download & Email")) {
            this.commonHelpers.thinkTimer(2000);
            this.enterText(scr_TxtBox_SendOption_AddEmail, email);
            if(GenericFunction.PORTAL.contains("CE")) {
                this.enterText(scr_TxtBox_SendOption_SubjectMessage, subject);
                this.enterText(scr_TxtBox_SendOption_MailMessage, message);
            }
        }
    }
    public boolean validateClearAllButtonStatus(String state) {
        if (state.equalsIgnoreCase("disabled"))
            return this.elementIsDisplayed(this.scr_Btn_ClearAll_disabled);
        else if (state.equalsIgnoreCase("enabled"))
            return this.elementIsDisplayed(this.scr_Btn_ClearAll);
        return false;
    }

    public Boolean selectOrDeselectRRFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
         this.JavaScriptClick(this.findElement(RRfilterChevron));
        for (String key : dataFilters.keySet()) {
            this.SelectFilterForRR(key, dataFilters.get(key).split(":"));
        }
        Boolean checkFilter = false;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(String.valueOf(this.RRfilterApply), this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicatorContains);
            this.ScrollToTop();
            int i=0;
            for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "OWNER":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.RRbubbleFilters, key.split(":")[0], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Creator is not displayed", checkFilter);
                            break;
                        case "VIEW":
                        case "FREQUENCY":
                        case "DOWNLOAD":
                        case "STATUS":
                        case "DATE: START/END":
                       case "HOUR":
                            this.JavaScriptClick(this.btn_Hour);
                            this.JavaScriptClick(this.btn_Hour_Dropdown);
                            if(i==0) {
                                this.JavaScriptClick(this.btn_Hour_All_Chckbox);
                            }
                            this.enterText(this.btn_Hour_DrpdwnTextBox,key);
                            commonHelpers.thinkTimer(500);
                            this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                            this.JavaScriptClick(this.btn_Hour_Apply);
                            this.waitUntilNotVisible(this.loadingIndicatorContains);
                            checkFilter=true;
                            Assert.assertTrue("Creator is not displayed", checkFilter);
                            i++;
                            break;
                    }
                    log.info(dataTable + "is displayed");
                }
            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.RRfilterCancelButton));
        }
        return checkFilter;
    }
    public void SelectFilterForRR(String status, String[] filterCriteria) {
        if (!this.findElement(RRfilterChevron).getAttribute("class").contains("active")) {
//              this.JavaScriptClick(this.findElement(RRfilterChevron));
        }
        int i=0;
        for (String filter : filterCriteria) {
            //  this.JavaScriptClick(this.findElement(this.getByusingString(
            //     String.format(this.filterxpath, filter))));
            switch (status.split(":")[0]) {
                case "OWNER":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "OWNER")));
                    this.JavaScriptClick(By.xpath(
                            String.format(selectCreatorType, filter)));
                    break;
                case "HOUR":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "HOUR")));
                    this.JavaScriptClick(this.btn_Hour_Dropdown);
                    if(i==0) {
                        this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox, "unchecked");
                    }
                    if(filter.equalsIgnoreCase("all"))
                        this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                    else {
                        this.enterText(this.btn_Hour_DrpdwnTextBox, filter);
                        commonHelpers.thinkTimer(500);
                        this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox, "checked");
                    }
                    break;
                case "VIEW":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "VIEW")));
                    this.JavaScriptClick(this.btn_Hour_Dropdown);
                    this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"unchecked");
                    this.enterText(this.btn_Hour_DrpdwnTextBox,filter);
                    this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                    break;
                case "FREQUENCY":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "FREQUENCY")));
                    this.selectDropdown(this.drpdwn_freq_download, "text", filter);
                    break;
                case "STATUS":
                    this.JavaScriptClick(this.StatusTabInFilters);
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
                    this.JavaScriptClick(By.xpath(
                            String.format(selectCreatorType, filter)));
                    break;
                case "MESSAGE":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "MESSAGE")));
                    this.JavaScriptClick(By.xpath(
                            String.format(selectCreatorType, filter)));
                    break;
                case "DOWNLOAD":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "DOWNLOAD")));
                    this.selectDropdown(this.drpdwn_freq_download, "text", filter);
                    break;

                case "REPORT NAME":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "REPORT NAME")));
                    this.enterText(scr_SearchBox_Filters_ReportName_Search, filter);
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
                    this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                    break;

                case "HOURS":
                    if (!this.findElement(RRfilterChevron).getAttribute("class").contains("active")) {
                        this.JavaScriptClick(this.findElement(RRfilterChevron));
                    }
                    this.clickOnElement(By.xpath(
                            String.format(selectFilter, "HOUR")));
                    this.JavaScriptClick(this.btn_Hour_Dropdown);
                    if(this.getCount(By.xpath("//label[@for='All']"))==1) {
                        this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox, "unchecked");
                    }
                    this.enterText(this.btn_Hour_DrpdwnTextBox,filter);
                    this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
                    break;

                case "DATE":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "DATE: START/END")));
                    this.SelectFromandToDatesInCalendarWithOkButton(filterCriteria);
                    break;

                case "REPORT TYPE":
                    this.JavaScriptClick(By.xpath(
                            String.format(selectFilter, "REPORT TYPE")));
                    this.JavaScriptClick(By.xpath(
                            String.format(reportTypeOptions, filter)));
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
//                    this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
                    break;
            }
            i++;
        }
    }
    public void navigateToFrequencyTabAndFillTheInformation(String frequency, String day, String hour, String timezone, String startDate, String endDate) {
        commonHelpers.thinkTimer(1000);
        this.JavaScriptClick(scr_DrpDwn_Frequency_Frequency);
        this.selectDropdown(By.xpath(String.format(scr_dropdown_SendOptions,"Daily")), "text", frequency);
        if(frequency.equalsIgnoreCase("Weekly")){
            ScrollByOffset("0", "100");
            this.JavaScriptClick(scr_DrpDwn_Frequency_DayOfTheWeek);
            if(!day.equalsIgnoreCase("")) {
                this.JavaScriptClick(By.xpath(String.format(Scr_companyName, day)));
            }else{
                commonHelpers.thinkTimer(2000);
            }
            this.JavaScriptClick(scr_DrpDwn_Frequency_DayOfTheWeek);


        }
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        if(hour.contains(":")){
            String[] hoursArray = hour.split(":");
            for(String hourData: hoursArray){
                this.enterText(scr_SearchBox_Frequency_Hour_InsideDrpDwn, hourData);
                this.JavaScriptClick(By.xpath(String.format(scr_Frequency_Hours, hourData)));
                commonHelpers.thinkTimer(200);
            }
        }else {
            this.enterText(scr_SearchBox_Frequency_Hour_InsideDrpDwn, hour);
            this.clickOnElement(By.xpath(String.format(scr_containsHolder, hour)));
        }
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        this.JavaScriptClick(scr_DrpDwn_Frequency_TimeZone);
        this.enterText(scr_SearchBox_Frequency_Hour_InsideDrpDwn,timezone);
        this.JavaScriptClick(By.xpath(String.format(scr_containsHolder,timezone)));


        if(!startDate.equalsIgnoreCase("")){
            selectFromAndToDates(startDate, endDate);
        }
        JavaScriptClick(scr_Btn_Save);
        this.waitUntilNotVisible(this.loadingIndicatorContains);

    }
    public void clickOnOption(String filterOption) {
//        this.ScrollIntoView(findElement(By.xpath(String.format(String.valueOf(filters_RR), filterOption))));
        this.clickOnElementByJavaScriptIndex("FILTERS","1");
        this.Mouse_MoveToElement(By.xpath(String.format(filters_RR, filterOption)));
        this.JavaScriptClick(By.xpath(String.format(filters_RR, filterOption)));
    }

    public void columnName(String AccountName) {
        String ActualName = this.getText(By.xpath(String.format(columnName,AccountName))).trim();
        String value = ActualName.replace(" &nbsp;","");
        String[] Data = value.split(" ");
        Assert.assertTrue(Data[0].matches("^[a-zA-Z]*$"));
        Assert.assertTrue(Data[1].matches("^[a-zA-Z]*$"));
        Assert.assertTrue(Data[2].replace("(","").replace(")","").matches("^[0-9]*$"));
    }

    public void VerifytheFilterDrpdwn(){
        Assert.assertEquals(1,this.getCount(this.RRfilterChevron));
    }

    public void VerifytheClearAllOption(){
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        Assert.assertEquals(1,this.getCount(this.HamburgIcon_ClearAll));
    }

    public void ClickonClearAllbutton(){
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.clickOnElement(this.scr_Btn_ClearAll);
    }

    public void BadgeStatus(String filterCount) {
        int status = this.getCount(this.Badge);
        Assert.assertEquals(Integer.parseInt(filterCount),status);
    }

    public void ResetButton(){
        this.JavaScriptClick(this.Reset);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    public void validate_breadcrumb(String value) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        String[] ExpbreadCrumbs = value.split(",");
        List<String> ActualContent = new ArrayList<String>();
        for (WebElement element : this.findElements(this.Val_breadcrumb)) {
            ActualContent.add(element.getText().trim());
        }
        for (int status = 0; status < ActualContent.size(); status++) {
            String expected = ExpbreadCrumbs[status].trim();
            String actual = ActualContent.get(status).trim();
            if(!( GenericFunction.locale.equalsIgnoreCase(Constants.EN_US))){
                expected = genericFunctionObject.getLocalizedValue(expected);
            }
            Assert.assertEquals(expected, actual);
        }
    }

    public void validateTitle(String title) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        String msg= this.getText(this.title);
        Assert.assertEquals(title,this.getText(this.title));
    }

    public void verifyallreports() {
        List<WebElement> aList = this.findElements(this.scr_list_Allreports);
        Set<String> unique = new HashSet<>();
        for (WebElement e : aList) {
            unique.add(e.getText());
            Assert.assertTrue(e.getText().contains(this.getText(scr_label_AccName))
            || e.getText().contains("")|| e.getText()!= this.getText(scr_label_AccName));
        }

    }

    public void verifyDefaultreport() {
        String reportName = this.getText(this.scr_Reports_Firstrecord);
        String labelName = this.getText(this.scr_label_AccName);
        Assert.assertEquals(true, reportName.contains(labelName));
    }

    public void verifyOnlyContributorReports() {
        this.commonHelpers.thinkTimer(5000);
        this.waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> aList = this.findElements(this.scr_list_Allreports);
        for (WebElement e : aList) {
            System.out.println("list text is "+e.getText());
            System.out.println("name text is "+this.getText(scr_label_AccName));
            Assert.assertEquals(true,e.getText().contains(this.getText(scr_label_AccName)));
        }
    }

    public void verifySearchBoxLabel(){
        Assert.assertEquals(true,this.elementIsPresent(scr_Filters_Creator_SearchboxText));

    }

    public void verifyNameandID(String CreatorName){
        JavaScriptClick(scr_Filters_Creator_SearchboxText);
        this.enterText(this.scr_Filters_Creator_SearchboxText,CreatorName);
        this.commonHelpers.thinkTimer(2000);
        String name= this.getText(this.scr_Filters_Creatorlist);
        this.commonHelpers.thinkTimer(2000);
        String details[] = name.split("\\(");
        String fullName = details[0].trim();
        String number = details[1].replace("\\)","").trim();
        Assert.assertEquals(true,fullName.toLowerCase().contains(CreatorName.toLowerCase()));
        Assert.assertEquals(true,name.toLowerCase().contains(number));

    }

    public void verifyCreatorreportfromSearch(){
        String name= this.getText(this.scr_Filters_Creatorlist);
        this.clickOnElement(this.scr_Filters_Creatorlist);
        JavaScriptClick(this.scr_RR_Apply);
        this.commonHelpers.thinkTimer(5000);
        this.waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> aList = this.findElements(this.scr_list_Allreports);
        for (WebElement e : aList) {
            Assert.assertEquals(true,e.getText().equals(name));
        }
    }

    public void selectMultipleOptions(){
        JavaScriptClick(scr_Filters_CreatorOpts_SelectAll);
        this.commonHelpers.thinkTimer(2000);
        JavaScriptClick(scr_Filters_CreatorOpts_SelectAll);
    }

    public void selectMultipleFilters(){
        this.JavaScriptClick(scr_DrpDwn_RRFilters_ViewTab);
        this.JavaScriptClick(scr_RRFilters_ViewTab_inside);
        this.JavaScriptClick(scr_RRFilters_ViewTab_inside);
        JavaScriptClick(this.scr_RR_Apply);
        this.commonHelpers.thinkTimer(1000);
        this.JavaScriptClick(scr_Btn_ClearAll);
        this.JavaScriptClick(Reset);
    }

    public void verifyFilterinFilterBubble(){
        this.JavaScriptClick(scr_DrpDwn_RRFilters_ViewTab);
        this.JavaScriptClick(scr_RRFilters_ViewTab_inside);
        this.JavaScriptClick(scr_RRFilters_ViewTab_inside);
        String filtervalue = this.getText(scr_RRFilters_ViewTab_inside);
        JavaScriptClick(this.scr_RR_Apply);
        Assert.assertEquals(true,filtervalue.contains(this.getText(scr_Txt_Filterbuble_All)));
        this.JavaScriptClick(scr_Btn_ClearAll);
        this.JavaScriptClick(Reset);
    }

    public void verifyMultipleFilters() {
        String firValue = this.getText(scr_Chkbox_Creatorin);
        this.JavaScriptClick(scr_Chkbox_Creatorin);
        String secValue = this.getText(scr_Chkbox_Creatoropt);
        this.JavaScriptClick(scr_Chkbox_Creatoropt);
        JavaScriptClick(this.scr_RR_Apply);
        this.commonHelpers.thinkTimer(2000);
        List<WebElement> alist = this.findElements(this.scr_Txt_Filterbuble_All);
        for (WebElement e : alist) {
            Assert.assertTrue(e.getText().contains(firValue) || e.getText().contains(secValue));

        }
    }

    public void validateFilters(String filter,String strFlag) {
        String[] filterpath = filter.split(":");
        if(strFlag.equalsIgnoreCase("true")) {
            Assert.assertTrue("Validation of filter : " + filter, this.elementIsDisplayed(By.xpath(String.format(this.filters_path, filterpath[0], filterpath[1]))));
        }else{
            Assert.assertFalse("Validation of filter : " + filter, this.elementIsDisplayed(By.xpath(String.format(this.filters_path, filterpath[0], filterpath[1]))));
        }
    }



    public void FrstReportSelection() {
        this.JavaScriptClick(this.FrstRow);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    public String verifycompanyname() {
        company = this.getText(scr_Txt_Reportinfo_comName);
        this.JavaScriptClick(scr_EditBtn_ReportInformation);
        this.commonHelpers.thinkTimer(3000);
        By accountDropdown=By.xpath("//span[@class='sr-ctdropdown-value']");
        this.JavaScriptClick(accountDropdown);
        this.commonHelpers.thinkTimer(3000);
        By apply=By.xpath("//button[contains(text(),'Apply')]");
        this.JavaScriptClick(apply);
        String companyinreport = this.getText(By.xpath(String.format(Scr_companyName, company)));
        Assert.assertEquals(true, companyinreport.toLowerCase().contains(company.toLowerCase()));
        return company;
    }
    public void DeleteCompany() {
        String companyName = company;
        System.out.println(companyName);
        this.enterText(scr_SearchBox_Productcenter_Companies, companyName);
        this.commonHelpers.thinkTimer(3000);
        JavaScriptClick(scr_Btn_Productcenter_companies_DeleteIcon);
        JavaScriptClick(scr_Btn_Pdtcenter_companies_DltConfirmation);
        this.commonHelpers.thinkTimer(2000);
        JavaScriptClick(scr_Btn_Pdtcenter_companies_close);
    }
    public void VerifyCompanyinList() {
        String ComName = this.getText(scr_ReportFile_CompanyName);
        Assert.assertEquals(true, ModifiedName.contains(ComName));
    }

    public String VerifyEditIcon(String label) {
        this.commonHelpers.thinkTimer(5000);
        this.waitForDOMToLoad(DriverManager.getDrv());
        ModifiedName = this.getText(scr_Txt_Reportinfo_comName);
        List<WebElement> elements = this.findElements(this.scr_icon_ActiveIcon);
        int count = elements.size();
        Assert.assertEquals(3,count);
        return ModifiedName;
    }
    public  void VerifyReportandEditIcon(String label){
        JavaScriptClick(this.scr_file_ReportName);
        List<WebElement> elements = this.findElements(this.scr_icon_ActiveIcon);
        int count = elements.size();
        Assert.assertEquals(3,count);

    }
    public void VerifyEditforReportInf() {
        this.commonHelpers.thinkTimer(5000);
        this.waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> elements = this.findElements(this.scr_icon_EditIcon);
        for (int iconEdit = 0; iconEdit <= 2; iconEdit++) {
            String value = elements.get(iconEdit).getAttribute("class");
            if (value.contains("sr-list-icn")) {
                Assert.assertEquals(true, value.contains("sr-list-icn"));
            } else {
                Assert.assertEquals(true, value.contains("disabled"));
            }
        }
    }
    public void VerifyAccountandSelect(){
        JavaScriptClick(scr_DrpDwn_ChooseAcc);
        this.commonHelpers.thinkTimer(3000);
        JavaScriptClick(scr_DrpDwn_ChooseAcc_DrpDwnValues);
        JavaScriptClick(scr_DrpDwn_ChooseAcc_DrpDwn_Apply);
        JavaScriptClick(scr_Txt_Report_continue);
        JavaScriptClick(scr_Btn_SendOption_Continue);
        JavaScriptClick(scr_Btn_Save);
    }
    public void VerifyErrorMsg(){
        JavaScriptClick(scr_EditBtn_ReportInformation);
        this.commonHelpers.thinkTimer(2000);
        Assert.assertEquals(true, this.elementIsPresent(scr_Txt_ChooseAcc_ErrorMsg));
    }



    public void validateDetailedReportPageHeaders() {
        commonHelpers.thinkTimer(4000);
        List<WebElement> headers = this.findElements(this.DetailReportLabel);
        for (WebElement element : headers) {
            Assert.assertTrue(element.getText().trim().equalsIgnoreCase("Report Information")
                    || element.getText().trim().equalsIgnoreCase("Send Information")
                    || element.getText().trim().equalsIgnoreCase("Frequency Information"));
        }
    }

    public void verifyTheIsnotSortable(String ColumnName) {
        this.ScrollIntoViewColumnwise(ColumnName);
        Assert.assertTrue(this.getCount(By.xpath(String.format(NotSortable,ColumnName)))==1);
    }

    public void verifyTheIsSortable(String ColumnName) {
        this.ScrollIntoViewColumnwise(ColumnName);
        Assert.assertTrue(this.getCount(By.xpath(String.format(Sortable,ColumnName)))==1);
    }

    public void verifyTheIsDisplayedForEachReport(String ColumnName) throws ParseException {
        switch (ColumnName) {
            case "DELETE ICON":
                int count = this.getCount(By.xpath(String.format(this.DetailReport_ColumnName,"remove")));
                Assert.assertTrue(count > 1);
                break;

            case "OUTPUT FILE NAME":
                List<WebElement> OutputFileHeader = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"outputFileName")));
                Assert.assertTrue(OutputFileHeader.size() > 1);
                for (WebElement element : OutputFileHeader) {
                    String name = element.getText().trim();
                    Assert.assertTrue(name.contains("csv")
                            || name.contains("xlsx"));
                }
                break;

            case "RUN DATE":
                List<WebElement> RunDateheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"runDate")));
                Assert.assertTrue(RunDateheaders.size() > 1);
                for (WebElement element : RunDateheaders) {
                    Assert.assertTrue(element.getText().trim().contains("/") || element.getText().trim().contains("-")
                            && element.getText().trim().contains(":"));
                }
                //compare date and time
                String dateFormatForCompariosn = "dd/mm/yyyy HH:mm";
                Date d1 = this.dateTimeUtils.stringToDate(RunDateheaders.get(0).getText(), dateFormatForCompariosn);
                Date d2 = this.dateTimeUtils.stringToDate(RunDateheaders.get(1).getText(), dateFormatForCompariosn);
                if (d1.compareTo(d2) > 0) {
                    System.out.println("Dates are in descending order");
                    System.out.println("Date1 occurs after Date2");
                }
                break;

            case "LAST DOWNLOAD":
                List<WebElement> LastColCount = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"downloadReportDetailsList")));
                for (int status = 1; status <= 3; status++) {
                    LastColCount.get(status).click();
                    this.commonHelpers.thinkTimer(2000);
                }
                this.PageRefresh();
                this.waitForDOMToLoad(DriverManager.getDrv());
                this.waitUntilNotVisible(this.loadingIndicatorContains);
                List<WebElement> LastColheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"lastDownload")));
                for (int status = 1; status <= 3; status++) {
                    Assert.assertTrue(LastColheaders.get(status).getText().trim().contains("/")
                            && LastColheaders.get(status).getText().trim().contains(":"));
                }
                break;

            case "File Size":
                List<WebElement> FileSizeheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"fileSize")));
                Assert.assertTrue(FileSizeheaders.size() > 1);
                for (WebElement element : FileSizeheaders) {
                    Assert.assertTrue(element.getText().trim().contains("kb")
                            || element.getText().trim().contains("mb"));
                }
                break;

            case "STATUS":
                this.scrollHorizontalBarOnPage("300");
                List<WebElement> Statusheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"status_1")));
                Assert.assertTrue(Statusheaders.size() > 1);
                for (WebElement element : Statusheaders) {
                    Assert.assertTrue(element.getText().trim().equalsIgnoreCase("completed")
                            || element.getText().trim().equalsIgnoreCase("Failed")
                            || element.getText().trim().equalsIgnoreCase("In progress "));
                }
                break;

            case "VIEW":
                this.scrollHorizontalBarOnPage("300");
//                this.ScrollIntoViewColumnwise("VIEW");
                List<WebElement> Viewheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"viewName")));
                Assert.assertTrue(Viewheaders.size() > 1);
//                for (WebElement element : Viewheaders) {
//                    Assert.assertTrue(element.getText().toLowerCase().trim().equalsIgnoreCase("at risk"));
//                }
                break;

            case "REASON":
                List<WebElement> Reasonheaders = this.findElements(By.xpath(String.format(this.DetailReport_ColumnName,"reason")));
                Assert.assertTrue(Reasonheaders.size() > 1);
                for (WebElement element : Reasonheaders) {
                    if (element.getText().contains("") || element.getText().contains(null)) {
                        System.out.println("Reason no availbale for the records");
                    }
                }
                break;
        }
    }

    public void validateOptionsInHamburgerMenu() {
        this.clickOnElement(this.hamburgerIcon);
        //hamburger handling
        this.clickOnElement(this.hamburgerIcon);
        List<WebElement> options = this.findElements(this.hamburgerIconOption);
        for (WebElement element : options) {
            Assert.assertTrue(element.getText().trim().equalsIgnoreCase("Delete All")
                    || element.getText().trim().equalsIgnoreCase("Delete Selected (1)")
                    || element.getText().trim().equalsIgnoreCase("Download Selected (1)"));
        }
    }


    public void validateErrorMessagesFromReportTab(String reportname) {
        String firstRecord = (String) this.commonHelpers.getValuefromContextStore(reportname);
        this.JavaScriptClick(scr_TxtBox_Report_ReportName);
        this.clickOnElement(scr_TxtBox_Report_ReportName);
        this.keyBoardEventHoldKey(Keys.TAB);
//        this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"REPORT NAME","Required","1"))));
        this.enterText(scr_TxtBox_Report_ReportName,"Aut");
        this.keyBoardEventHoldKey(Keys.TAB);
        this.commonHelpers.thinkTimer(2000);
//        this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
//        this.JavaScriptClick(this.scr_TxtBox_Report_ReportPrefix);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_containsHolder,"Report Name should have Min 5 characters and Max 30 Character"))));
        this.enterText(scr_TxtBox_Report_ReportName,firstRecord);
        this.commonHelpers.thinkTimer(2000);
//        this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
        if(firstRecord.length()>5){
            List<WebElement> ele = this.findElements(By.xpath("//div[contains(@class,'text-danger')]"));
            if(ele.size()>=1){
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_containsHolder,"Report name already exists. Please provide a unique report name"))));
            }
        }
        this.JavaScriptClick(scr_TxtBox_Report_ReportName);
//        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"CHOOSE VIEW","Required","1"))));
//        this.JavaScriptClick(scr_DrpDwn_Report_ChooseAccounts);
//        this.JavaScriptClick(scr_TxtBox_Report_ReportName);
//        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"CHOOSE ACCOUNT(S)","Required","1"))));
    }

    public void validateErrorMessagesFromSendOptionTab(String chooseOption) {

        waitUntilClickable(scr_DrpDwn_SendOption_ChooseOption);
        this.selectDropdown(scr_DrpDwn_SendOption_ChooseOption, "text", chooseOption);
        this.ScrollToTop();
        if (chooseOption.equals("Email") || chooseOption.equals("Download & Email")) {
            this.commonHelpers.thinkTimer(2000);
        this.clickOnElement(scr_TxtBox_SendOption_AddEmail);

        if(GenericFunction.PORTAL.contains("CE")) {
            this.clickOnElement(scr_TxtBox_SendOption_SubjectMessage);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage, "ADD EMAIL(S)", "Email is a required field.", "1"))));
            this.clickOnElement(scr_TxtBox_SendOption_AddEmail);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage, "SUBJECT/MESSAGE", "Required", "1"))));
            this.clickOnElement(scr_TxtBox_SendOption_MailMessage);
            this.clickOnElement(scr_TxtBox_SendOption_AddEmail);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage, "SUBJECT/MESSAGE", "Required", "2"))));
        }else{
            this.keyBoardEventHoldKey(Keys.TAB);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage, "ADD EMAIL(S)", "Email is a required field.", "1"))));
        }
        }

    }

    public void validateErrorMessagesFromFrequencyTab(String frequency) {
//        this.JavaScriptClick(scr_DrpDwn_Frequency_Frequency);
        this.selectDropdown(By.xpath(String.format(scr_dropdown_SendOptions,"Daily")), "text", frequency);

        if(frequency.equalsIgnoreCase("Weekly")){
            this.JavaScriptClick(scr_DrpDwn_Frequency_DayOfTheWeek);
            this.JavaScriptClick(scr_DrpDwn_Frequency_Frequency);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"DAY OF THE WEEK","Required","1"))));
        }
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        this.verifyCheckBox_PerformAction(this.HourRunTime,"unchecked");
        this.JavaScriptClick(scr_DrpDwn_Frequency_Frequency);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"HOUR (RUN TIME)","Required","1"))));
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        this.JavaScriptClick(scr_DrpDwn_Frequency_TimeZone);
        this.clickOnElementByJavaScriptIndex("Clear","");
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"TIMEZONE","Required","1"))));
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        this.JavaScriptClick(scr_Btn_Frequency_StartEndDates_StartDate);
        this.JavaScriptClick(scr_DrpDwn_Frequency_Hour);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_errorMessageXpathReportPage,"START/END DATES","Required","1"))));

    }

    public void drillDownRRRecord(String action, String record) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.ScrollByOffset("0","250");
        this.clickOnElement(By.xpath(String.format(elipsesByRecord,record)));
        this.Mouse_MoveToElement_Click(By.xpath(String.format(actionOnRecord,action)));
    }



    public void verifyEditReportLabelName(String Expectedvalue) {
        Assert.assertEquals(this.getText(this.getLable_EditReport).toLowerCase().trim(), Expectedvalue.toLowerCase().trim());
    }

    public void verifyGuidanceLabelName(String Expectedvalue) {
        Assert.assertTrue(this.getText(this.getLabel_GuidanceText).toLowerCase().trim().contains(Expectedvalue.toLowerCase().trim()));
    }


    public void ApplyFilter_ReportName(String ReportName){
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.clickOnOption("REPORT NAME");
        this.enterText(this.btn_Hour_DrpdwnTextBox,ReportName);
            this.commonHelpers.thinkTimer(3000);
            this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
            this.JavaScriptClick(this.btn_Hour_Apply);
            this.waitUntilNotVisible(this.loadingIndicatorContains);

    }



    public void ApplyFilter_Status(String StatusOption) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        if (StatusOption.contains("completed")) {
            this.JavaScriptClick(this.Status_CompletedOption);
        }
        if (StatusOption.contains("failed")) {
            this.JavaScriptClick(this.Status_FailedOption);
        }
        this.JavaScriptClick(this.btn_Hour_Apply);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    public void ClickOnButtonIsDisplayedInConfirmationDialog(String button) {
        if (button.contains("Delete")) {
            // this.commonHelpers.AddToContextStore("TotalComments", this.findElements(this.AllComments).size());
            this.clickOnElement(By.xpath(String.format(deleteButtonConfirmationDialog, button)));
        } else if (button.contains("Cancel"))
            this.clickOnElement(By.xpath(String.format(cancelButtonConfirmationDialog, button)));
    }

    public void storeFirstRecord(String name) {
        String firstRecord = this.getText(firstRecordName);
        this.commonHelpers.AddToContextStore(name,firstRecord);
    }

    public void validateTheReportInformationWithData(String reportType,String view, String company, String accountType) {

        if(reportType.contains("Pre-Shipment")) {
            Assert.assertEquals("Validation of view data ", view, this.getText(By.xpath(String.format(this.purpleBarSpanData, "Favorite"))));
            Assert.assertEquals("Validation of reportType data ", reportType, this.getText(By.xpath(String.format(this.purpleBarSpanData, "Report Type"))));
        }else {
            Assert.assertEquals("Validation of view data ", view, this.getText(By.xpath(String.format(this.purpleBarSpanData, "View"))));

            if (GenericFunction.PORTAL.contains("CE")) {
                Assert.assertEquals("Validation of company data ", company, this.getText(By.xpath(String.format(this.purpleBarDivData, "Company"))));
            } else {
                if (company.length() < 3) {
                    int selectAccounts = Integer.parseInt(company);
                    if (selectAccounts > 1) {
                        for (int eachAccount = 1; eachAccount <= selectAccounts; eachAccount++) {
                            Assert.assertTrue("", this.getText(purpleBarAccountData).contains(this.commonHelpers.getValuefromContextStore("account" + eachAccount).toString()));
                        }
                    } else {
                        Assert.assertTrue("Verify the existance of Account : ", this.getText(purpleBarAccountData).contains(this.commonHelpers.getValuefromContextStore("account" + selectAccounts).toString()));
                    }
                }
            }

            Assert.assertEquals("Validation of accountType data ", accountType, this.getText(By.xpath(String.format(this.purpleBarDivData, "Account Type"))));
        }
    }

    public void validateTheSenderInformationWithData(String download, String email) {
        Assert.assertEquals("Validation of download data ",download,this.getText(By.xpath(String.format(this.purpleBarSpanData,"Download"))));
        Assert.assertEquals("Validation of Email data ",email,this.getText(By.xpath(String.format(this.purpleBarSpanData,"Email"))));
    }

    public void validateTheFrequencyInformationWithData(String frequency, String day, String hour, String timeZone, String startDate, String endDate, String format) {
        Date currentDate = new Date();
        LocalDateTime localDateTime = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();


        Assert.assertEquals("Validation of frequency data ",frequency,this.getText(By.xpath(String.format(this.purpleBarSpanData,"Frequency"))));
        if(!day.equalsIgnoreCase("")) {
            Assert.assertEquals("Validation of day data ", day, this.getText(By.xpath(String.format(this.purpleBarSpanData, "Day"))));
        }
        Assert.assertEquals("Validation of hour data ", hour, this.getText(By.xpath(String.format(this.purpleBarSpanData, "Hour"))));
        Assert.assertTrue("Validation of timeZone data ",this.getText(By.xpath(String.format(this.purpleBarSpanData, "Time Zone"))).contains(timeZone));

        LocalDateTime startDateWithFormat = localDateTime.plusDays(Integer.parseInt(startDate));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        String startDateAfterFormat = startDateWithFormat.format(formatter);
        Assert.assertEquals("Validation of Start Date data ", startDateAfterFormat, this.getText(By.xpath(String.format("("+this.purpleBarSpanData+")[1]", "Date: Start/End"))));
        LocalDateTime endDateWithFormat = localDateTime.plusDays(Integer.parseInt(endDate));
        String endDateAfterFormat = endDateWithFormat.format(formatter);
        Assert.assertEquals("Validation of End Date data ", endDateAfterFormat, this.getText(By.xpath(String.format("("+this.purpleBarSpanData+")[2]", "Date: Start/End"))).replace("- ",""));
    }

    public void SelectFromandToDatesInCalendarWithOkButton(String[] filter) {
        boolean toDate = true;
        boolean fromDate = true;
        this.commonHelpers.AddToContextStore("FromDate", GetLastdateFromCurrentDate(filter[1]));
        if (fromDate) {
            String[] fromArr = this.commonHelpers.getValuefromContextStore("FromDate").toString().split(" ");
            try {
                this.commonHelpers.AddToContextStore("ToDate", GetLastdateFromCurrentDate(filter[2]));
            } catch (Exception e) {
                log.info("To Date is not available");
                toDate = false;
            }

            this.JavaScriptClick(this.specificDateRangeFrom);
            while (!this.getText(monthField).split(" ")[0].equals(fromArr[1])) {
                this.JavaScriptClick(calenderLeftArrow);
            }
            this.JavaScriptClick(By.xpath(String.format(dateXpath, fromArr[0])));
        }
        // this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        else if (toDate) {
            String[] toArr = this.commonHelpers.getValuefromContextStore("ToDate").toString().split(" ");
            this.clickOnElement(this.specificDateRangeTo);
            while (!this.getText(monthField).split(" ")[0].equals(toArr[1])) {
                this.clickOnElement(calenderRightArrow);
            }
            this.clickOnElement(By.xpath(String.format(dateXpath, toArr[0])));
            //   this.setTimeHoursMins(0, 0, 0);
            // this.JavaScriptClick(By.xpath(this.CalenderOKButton));
        }
    }

    public String GetLastdateFromCurrentDate(String dateValue) {
        DateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy EEEE");
        Date myDate = new Date(System.currentTimeMillis());
        Calendar cal = Calendar.getInstance();
        if (dateValue.contains("-")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt("-" + dateValue.split("-")[1]));
        } else if (dateValue.equalsIgnoreCase("Today")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, 0);
        } else if (dateValue.contains("+")) {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt(dateValue.split("\\+")[1]));
        } else {
            cal.setTime(myDate);
            cal.add(Calendar.DATE, Integer.parseInt("-" + dateValue));
        }
        return dateFormat.format(cal.getTime());
    }

    public void btnBack() {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        Assert.assertTrue(this.getCount(this.Btn_Back) == 1);
    }

    public void ValidateReportName(String ActualReportName) {
        this.waitUntilVisible(this.label_ReportName);
        this.waitUntilVisible(this.label_ReportName);
        this.commonHelpers.thinkTimer(5000);
        this.waitForDOMToLoad(DriverManager.getDrv());
        System.out.println("ActualReportName : " + this.getText(this.label_ReportName).toLowerCase());
        System.out.println("ExpectedReportName : " + ActualReportName.toLowerCase());
        Assert.assertEquals("Report Name is mismatch", this.getText(this.label_ReportName).toLowerCase(), ActualReportName.toLowerCase());
    }

    public void VaidatefieldsinDetailsReportpage(String field1, String field2, String field3, String field4, String field5, String field6, String field7,String field8, String tabName, String Index) {
        List<String> list = new ArrayList<String>(Arrays.asList(field1, field2, field3, field4, field5, field6, field7,field8));
        list.removeAll(Arrays.asList("", null));
        List<String> Actuallist = new ArrayList<String>();
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        List<WebElement> ele = this.findElements(By.xpath(String.format(FetchFieds_DetailReport, Index)));
        for (WebElement element : ele) {
            Actuallist.add(element.getText());
        }
        for (int status = 0; status < ele.size(); status++) {
            Assert.assertTrue(Actuallist.get(status).contains(field1)|| Actuallist.get(status).contains(field2)|| Actuallist.get(status).contains(field3)
            ||Actuallist.get(status).contains(field4)||Actuallist.get(status).contains(field5)||Actuallist.get(status).contains(field6)||Actuallist.get(status).contains(field7)
            ||Actuallist.get(status).contains(field8));
        }
    }

    public void ValidateEditOption(){
        Assert.assertTrue(this.getCount(this.Editicon)==3);
    }

    public void verifytheUpdatedvaluesInfreqTab(String ExpectedTime){
        this.commonHelpers.thinkTimer(3000);
       // WebElement element=this.findElement(By.xpath("//option[contains(text(),'"+ExpectedTime+"')]//..//..//select"));
       // Select sel=new Select(element);
       // String selectedOption=sel.getFirstSelectedOption().getText();
        String Freq = this.getText(this.FreqInfoTabFreqLabel);
        Assert.assertTrue(Freq.equals(ExpectedTime));
    }

    public void ActiveTabStatus(String tabname) {
        String TabName = this.getText(this.ActiveTab_Status);
        Assert.assertTrue(TabName.trim().contains(tabname));
    }

    public void VerifyDisabledFields() {
        for (WebElement status : this.findElements(this.VerifyDisabledFields_EditOption)) {
            Assert.assertTrue(status.getText().trim().toLowerCase().equalsIgnoreCase("REPORT TYPE") ||
                    status.getText().trim().toLowerCase().equalsIgnoreCase("CHOOSE VIEW"));
        }
    }

    public void SelectFileFromList() {
        this.JavaScriptClick(FrstRow);
    }

    public void VerifyDwnloadIcn() {
        Assert.assertEquals(true, this.elementIsPresent(scr_Report_DwnloadIcn));
        this.JavaScriptClick(scr_Report_DwnloadIcn);
    }

    public void SelectMultipleCheckbox() {
        int numberOfUncheckedCheckBox = this.findElements(this.scr_Report_CheckBoxes).size();
        if(numberOfUncheckedCheckBox<=11) {
            for (int checkbox = 1; checkbox <= numberOfUncheckedCheckBox; checkbox++) {
                if (this.findElement(By.xpath(String.format(scr_Report_CheckBoxesIndex, checkbox))).isEnabled())
                    this.JavaScriptClick(By.xpath(String.format(scr_Report_CheckBoxesIndex, checkbox)));
            }
        }
        else if(numberOfUncheckedCheckBox > 11){
            for (int checkbox = 1; checkbox <= 11; checkbox++) {
                if (this.findElement(By.xpath(String.format(scr_Report_CheckBoxesIndex, checkbox))).isEnabled())
                    this.JavaScriptClick(By.xpath(String.format(scr_Report_CheckBoxesIndex, checkbox)));
            }
        }
    }

    public void VerifyErrorMsgforDwnloadoptn() {
        this.JavaScriptClick(scr_Btn_HamburgerIcn);
        this.JavaScriptClick(scr_report_Hamburger_Dwnloadoptn);
        Assert.assertEquals(true, this.elementIsPresent(scr_DwnldSelected_ErrMsg));
        this.JavaScriptClick(scr_DwnldSelected_Cancel);

    }

    public void VerifyDeleteSelectedOption() {
        this.JavaScriptClick(scr_Btn_HamburgerIcn);
        List<WebElement> menuOptions = this.findElements(this.hamburgerIconOption);
        boolean DeleteSelectedOptionExist = false;
        for (WebElement options : menuOptions) {
            if (options.getText().equals("Delete Selected")) {
                DeleteSelectedOptionExist = true;
                break;
            }
        }
        if (!DeleteSelectedOptionExist) {
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
        }
    }


    public void verifySelectedCountinMenu(){
        int numberOfUncheckedCheckBox = this.findElements(this.scr_Report_CheckBoxes).size();
        int count=0;
        for(int checkbox=1;checkbox<=3;checkbox++){
            if(this.findElement(By.xpath(String.format(scr_Report_CheckBoxesIndex,checkbox))).isEnabled()){
                this.JavaScriptClick(By.xpath(String.format(scr_Report_CheckBoxesIndex,checkbox)));
                count++;
            }
        }
        this.JavaScriptClick(hamburgerIcon);
        String name= this.getText(this.scr_btn_DwnldSelected);
        String num = name.substring(name.indexOf("(") +1, name.indexOf(")"));
        if (num.contains(String.valueOf(count))){
            Assert.assertTrue(true);
        }
        else {
            Assert.assertTrue(false);
        }
    }

    public void selectDownloadSelected(){
        this.JavaScriptClick(scr_btn_DwnldSelected);
    }
    public void verifyDownloadedZipFile() {
        this.commonHelpers.thinkTimer(5000);
        File filpath;
        if (GenericFunction.OS.contains("Window")) {
             filpath = AdvisoryPage.getLastModified(System.getProperty("user.home") + "\\Downloads");
            this.commonHelpers.thinkTimer(5000);
        }else{
             filpath = AdvisoryPage.getLastModified("/root/Downloads");
        }
        Assert.assertEquals(true,filpath.toString().contains(".zip"));
    }

    public void selectDeleteSelected(){
        this.JavaScriptClick(hamburgerIcon);
        this.JavaScriptClick(scr_btn_DeleteSelected);
        Assert.assertEquals(true,this.elementIsPresent(scr_DltSelected_ConfirmPopup));
        Assert.assertEquals(true,this.elementIsPresent(scr_btn_delete));
        Assert.assertEquals(true,this.elementIsPresent(scr_DwnldSelected_Cancel));

    }

    public void defaultMessageInFilter(){
        Assert.assertEquals(this.getText(noResult).trim(),Constants.SearchDefaultText);
    }

    public void FilterStatus(String filterCount) {
        String status = this.getText(this.FilterCount);
        Assert.assertTrue(status.contains(filterCount));
    }

    public boolean reportTypeDropdown() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(By.xpath(String.format(reportTypeDropdown)));
        this.waitUntilNotVisible(By.xpath(String.format(reportTypeDropdown)));
        return this.elementIsDisplayed(By.xpath(String.format(reportTypeDropdown)));
    }

    public void verifyReportTypeDefaultValue(){
        String value = this.getSelectedDropdownValue(ReportType);
        Assert.assertTrue(value.toLowerCase().trim().equals("shipment report"));
    }

    public void verifyNonEditableForReportType(){
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        Assert.assertTrue(this.getCount(this.NonEditable_ReportType)==1);
    }

    public void VerifydropdownoptionsforReportType(List<String> expectedOptions) {
            List<String> actualOptions = this.getDropdownOptions(ReportType);
            Assert.assertTrue(actualOptions.equals(expectedOptions));
    }

    public  void EditIconInScheduledReportDetails(String FieldName){
        this.JavaScriptClick(By.xpath(String.format(Edit_icon,FieldName)));
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    public void validateReportNameError(String reportname){
        String firstRecord = (String) this.commonHelpers.getValuefromContextStore(reportname);
        this.enterText(scr_TxtBox_Report_ReportName,firstRecord);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_containsHolder,"Report name already exists. Please provide a unique report name"))));
    }

    public void getvalueBasedOnKey(String key, String Expected){
        String Actual = this.getText(By.xpath(String.format(getVal_Keybased,key)));
        Assert.assertEquals(Actual.toLowerCase().trim(),Expected.toLowerCase().trim());
    }

    public void verifyEmailBodyIsNotEditable(){
        //validate body text is matching
        String body= this.getText(emailBody);
        Assert.assertEquals(Constants.emailBody,body);

    }

    public void verifyPrefixChangeShouldChangeInReportName(String prefix,String text){
        this.elementClear(scr_TxtBox_Report_ReportPrefix);
        this.enterText(scr_TxtBox_Report_ReportPrefix,prefix);
        this.clickOnElementByJavaScriptIndex(text, "");
        String subjectText= this.getText(emailSubject);
        Assert.assertTrue(subjectText.contains(prefix));
    }

    public void verifyReportNameIsCombinationOfPrefixAndDateAndExtension(String prefix,String format){
        String ReportFileName= prefix+"_"+formattedDate+"."+format;
        Assert.assertEquals(reportFile,ReportFileName);
    }

    public void verifyEmailMessageIsNotEditable(){

        //validate subject text is matching & report name is same as user entered
        String subjectText= this.getText(emailSubject);
        Assert.assertEquals(String.format(Constants.emailMessage,reportFile),subjectText);

        //validate subject is non editable
        WebElement subjectField= DriverManager.getDrv().findElement(emailSubject);
        Assert.assertTrue(subjectField.getAttribute("class").contains("readonly"));
    }

    public void selectFormatUnderReportTab(String format){
        if(format.equals("csv")){
            this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(".csv","")));
        }
        else if(format.equals("viceversa")) {
            verifyRadioBox_PerformAction();
        }
    }

    public void enterNameUnderReportTab(String reportName,String reportNameKey,String prefix){
        if(reportName.equalsIgnoreCase("")){
            String randomNumber = "Auto"+this.getCurrentDateinFormat("MMddYYYY,HHmmss").replace("IST", "").replace(",", "").replace(" ", "");
            this.commonHelpers.AddToContextStore(reportNameKey,randomNumber);
            // a) Verify user should min 5 and max 30 characters
            String minVal=randomNumber.substring(0,4);
            this.enterText(scr_TxtBox_Report_ReportName,minVal);
            commonHelpers.thinkTimer(2000);
            this.clickOnElement(scr_TxtBox_Report_ReportPrefix);
            commonHelpers.thinkTimer(5000);
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(scr_containsHolder,"Report Name should have Min 5 characters and Max 30 Character"))));
            this.elementClear(scr_TxtBox_Report_ReportName);

            //b) Verify special character is not allowed
            this.enterText(scr_TxtBox_Report_ReportName,randomNumber);
            this.enterText(scr_TxtBox_Report_ReportPrefix,prefix);
            LocalDateTime myDateObj = LocalDateTime.now();
            System.out.println("Before formatting: " + myDateObj);
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd_MMM_yyyy_HH_mm");
            //11_Jun_2024_20_29
            formattedDate = myDateObj.format(myFormatObj);
            System.out.println("After formatting: " + formattedDate);
            commonHelpers.thinkTimer(2000);
            reportFile= this.getText(reportFileName);
        }else if(!reportName.equalsIgnoreCase("Modification Not Required")){
            this.commonHelpers.AddToContextStore(reportNameKey,reportName);
            this.commonHelpers.thinkTimer(3000);
            this.enterText(scr_TxtBox_Report_ReportName,reportName);
        }
    }

    public void selectViewUnderReportTab(String chooseView){
        if (!chooseView.equalsIgnoreCase("")) {
            this.JavaScriptClick(scr_DrpDwn_Report_ChooseView);
            this.enterText(scr_SearchBox_Report_ChooseView_InsideDrpDwn, chooseView);
            this.ClickOnDropDownOptions(chooseView);
        }
    }

    public void validateViewUnderReportTab(String view){
        if (!view.equalsIgnoreCase("")) {
           String actualView= this.findElement(scr_DrpDwn_Report_ChooseView).getText();
           Assert.assertTrue("Selected different view",view.contains(actualView.trim()));
        }
    }

    public void enterReportType(String reportType,String chooseAccount){
        if(!reportType.contains("Pre-Shipment")) {
            if (!chooseAccount.equalsIgnoreCase("")) {

                if (GenericFunction.PORTAL.contains("CE")) {
                    this.JavaScriptClick(scr_DrpDwn_CE_Report_ChooseAccounts);
                    this.enterText(scr_DrpDwn_Report_ChooseAccounts_InsideDrpDwn, chooseAccount);
                    this.ClickOnDropDownCheckBoxOption(chooseAccount);
                } else {
                    this.JavaScriptClick(scr_DrpDwn_Report_ChooseAccounts);
                    if (chooseAccount.length() < 3) {
                        int selectAccounts = Integer.parseInt(chooseAccount);

                        if (selectAccounts > 1) {
                            for (int eachAccount = 1; eachAccount <= selectAccounts; eachAccount++) {
                                this.JavaScriptClick(By.xpath(String.format(selectAccountCheckBox, eachAccount)));
                                this.commonHelpers.AddToContextStore("account" + eachAccount, this.getText(By.xpath(String.format(selectAccountCheckBox, eachAccount))));
                            }
                        } else {
                            this.JavaScriptClick(By.xpath(String.format(selectAccountCheckBox, selectAccounts)));
                        }

                    } else {
                        this.enterText(scr_DrpDwn_Report_ChooseAccounts_InsideDrpDwn, chooseAccount);
                        this.JavaScriptClick(By.xpath(String.format(scr_containsHolder, chooseAccount)));
                    }
                }
            }
        }
    }

    public void Locale_breadcrumb_validation(String value){
        String expvalue="";
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        if(value.equalsIgnoreCase("FedEx copyrightSymbol Surround")) {
            String[] ExpbreadCrumbs = value.split(" ");
            List<String> ActualContent = new ArrayList<String>();
            String ExpectedBreadCrumb = this.getText(By.xpath("(//ul[@class='sr-breadcrumb']//a)[1]"));
            for (int content = 0; content < ExpbreadCrumbs.length; content++) {
                if (!(GenericFunction.locale.equalsIgnoreCase(Constants.EN_US))) {
                    ActualContent.add(content, genericFunctionObject.getLocalizedValue(ExpbreadCrumbs[content].toString().trim()));
                }
            }
            String Actualvalue = ActualContent.get(0).toString().trim() + ActualContent.get(1).toString().trim() + " " + ActualContent.get(2).toString().trim();
            Assert.assertEquals(ExpectedBreadCrumb, Actualvalue);
        }

        if(value.equalsIgnoreCase("Overview")){
            String ExpectedBreadCrumb = this.getText(By.xpath("(//ul[@class='sr-breadcrumb']//a)[2]"));
            if (!(GenericFunction.locale.equalsIgnoreCase(Constants.EN_US))) {
                expvalue = genericFunctionObject.getLocalizedValue(value.trim());
            }
            Assert.assertEquals(ExpectedBreadCrumb,expvalue);
        }
    }
    public boolean VerifyDropdownValuesVisible(DataTable dataTable) {
        boolean flag = true;
        List<String> values = dataTable.asList(String.class);
        for (String val : values) {
            if (this.elementIsDisplayed(By.xpath(String.format(chooseviewdrpdwnval, val)))) {
                flag = true;
            } else {
                flag = false;
                log.error(" This dropdown value is not Visible --> " + val);
                break;
            }
        }
        return flag;
    }
    public void clickChooseViewDropdown() {
        this.JavaScriptClick(this.chooseviewbtn);
    }

}
