package pageObjects;


import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class AccountAlias extends SeleniumGenericFunction {

    public CommonHelpers commonHelpers;
    public String addAccountAlias_div_ContainsGenericXpath = "//div[contains(text(),\"%s\")]";
    public String addAccountAlias_ContainsGenericXpath = "//%s[contains(text(),\"%s\")]";
    public String addAccountAlias_account_alias = "//span[contains(text(),\"%s\") and @ref='eText']";
    public By addAccountAlias_searchbox = By.xpath("//input[@placeholder='Search Accounts & Aliases']");
    public By addAccountAlias_searchIcon = By.xpath("//div[contains(@class,'sr-searchbox__icon')]");
    public By accountid_1 = By.xpath("(//div[@col-id='accountId' and @role='gridcell'])");
    public By aliasText_1 = By.xpath("(//div[@col-id='aliasName' and @role='gridcell'])//span[contains(@class,'text-exceeds')]");
    public By multipleAliasTrashIcon = By.xpath("(//span[contains(@class,'delete-icn-multiple')])[1]");

    public String buttonText = "//button[contains(.,\"%s\")]";
    public By accountsDropdown = By.xpath("//span[contains(@class,'chevron')]");
    public By accountsDDText = By.xpath("(//label[contains(@class,'fdx-c-form-group__label')])[2]");
    public String closeAccountsDD = "//div[@class='close-icn bk']";
    public String deleteIcon = "(//span[contains(@class,'fdx-c-form-group__icon delete-icn-multiple')])[1]";
    public String editIcon = "(//span[contains(@class,'fdx-c-form-group__icon edit-icn-multiple')])[1]";
    public By aliasFirstDropdown = By.xpath("(//div[contains(@class,'d-flex cursor-pointer')])[1]");
    public By aliasDDText = By.xpath("(//label[contains(@class,'fdx-c-form-group__label')])[2]");
    public By aliasSecondDropdown = By.xpath("(//div[contains(@class,'d-flex cursor-pointer')])[2]");
    public String aliasDDExpand = "//div[contains(@class,'sr-group m-t-2')][2]/div[contains(@class,'sr-account-alias__multiselect')]";
    public String aliasDDCollapse = "//div[contains(@class,'sr-group m-t-2')][1]/div[contains(@class,'sr-account-alias__multiselect')]";
    public String breadcrumbMenu = "//div[contains(@class,'hamburger-icn')]";
    //input[@id='INPUT']
    public  By createAliasInputNameMultipleAcc = By.xpath("//input[@id='INPUT']");
    public  By selectAccountMultipleAccAlias = By.xpath("//a/span[contains(text(),'Select')]");
    public  By EnabledAccountsCheckboxesMultipleAccAlias =By.xpath("//div[@role='tabpanel']//label[not(contains(@for,'|'))]");
    public By SaveBtnInMultipleAccAlias = By.xpath("//button[contains(text(),' SAVE ALIAS ')]");
    public By CloseBtnInMultipleAccAlias =By.xpath("//button[contains(text(),' Close ')]");
    public By selectedAccountsInMultipleAccAliasExpand=By.xpath("//label[@class='fdx-c-form-group__label']");
    public String DustbinDeleteIcnInMultipleAccAlias = "//div[@class='ellipsis m-b-2']/span[contains(text(),\"%s\")]//..//span[@class='fdx-c-form-group__icon delete-icn-multiple']";
    public By cancelBtnInMultipleAccAlias = By.xpath("//span[contains(text(),'Cancel')]");
    public By DeleteAliasBtnInMultipleAccAlias =By.xpath("//span[contains(text(),'Delete Alias')]");
    public By InputTxtBoxSearchAlias = By.xpath("//input[@placeholder='Search Accounts & Aliases']");
    public By SearchIcnBtnToSearchAccountAlias = By.xpath("//div[@class='sr-searchbox__icon sr-searchbox__icon_right']");
    public By SearchedOptionAccountAliasDetails = By.xpath("//span[@class='sr-account-alias__btnText']");
    public  String accountAliasNameExpansionBtn = "//div[@class='ellipsis m-b-2']/span[contains(text(),\"%s\")]//..//../div[@class='d-flex cursor-pointer']";
    public  String currentEnabledCheckBoxAccountNum = "(//div[@role='tabpanel']//label[not(contains(@for,'|'))])[\"%s\"]";
    public  By currentEnabledInputChkBox= By.xpath("(//div[@role='tabpanel']//label[not(contains(@for,'|'))]//..//input)");
    public  String currentListOfAccNoMAlias="(//label[@class='fdx-c-form-group__label'])[\"%s\"]";
    public  String headerAccountAliasName="//div[@class='ellipsis m-b-2']/span[contains(text(),\"%s\")]";
    public By firstSingleAccountDeleteIcns = By.xpath("(//span[@class='delete-icn float-r mrg-top'])[1]");
    public By listOfSingleAccountDeleteIcns = By.xpath("//span[@class='delete-icn float-r mrg-top']");
    public  By deletePopUpWindow = By.xpath("//div[@class='fdx-c-modal__main fdx-c-modal__main--large']");
    public  By addAnAliasFirstBtn = By.xpath("(//span[text()=' Add an Alias '])[1]");
    public  By addAnAliasSecondBtn = By.xpath("(//span[text()=' Add an Alias '])[2]");
    public  By inputAddAliasName = By.xpath("//input[@id='data?.accountId']");
    public By applyBtnAddAllias = By.xpath("//button[text()='Apply']");
    public  String deleteBtnInSingleAccountAlias = "//span[text()=\"%s\"]//..//span[@class='delete-icn float-r mrg-top']";
    public  By deleteAliasPopUpModalMessage = By.xpath("//div[text()=' Are you sure you want to delete this Account Alias? ']");
    public String deleteAliasPopUpAliasName = "//div[contains(text(),\"%s\")]";
    public By deleteAliasModelPopupCloseIcn = By.xpath("//div[@class='close-icn']");
    public  String textAliasName = "//div[@class='sr-grid__cell--lnk']//span/span[text()=\"%s\"]";

    public String accNumOfAliasName = "//span[text()=\"%s\"]//..//..//..//..//../div[@col-id='accountId']";
    public String addAliasBtnwrtACCno ="//div[contains(text(),\"%s\")]//..//span//span[contains(text(),'Add an Alias')]";

    public By accountsNoBesideAddAliasBtn=By.xpath("//span[contains(text(),' Add an Alias ')]//..//..//..//..//..//..//div[@col-id='accountId']");
    public String addAliasButtonsBesideAccNo= "//div[contains(text(),\"%s\")]//..//span//button//span[contains(text(),' Add an Alias ')]";
    public By addANameWaterMark =By.xpath("//input[@placeholder='Add a Name']");
    public By closeCrossIcnInsideTxtBox=By.xpath("//div[@class='m-r-1 close-icn-input']");
    public By charecterLimitTextInfo =By.xpath("//span[contains(text(),'0/30')]");
    public By applyButtonDisabled =By.xpath("//button[@disabled and contains(text(),'Apply')]");
    public By applyButtonEnabled =By.xpath("//button[contains(text(),'Apply')]");
    public String accNumbersInSingleAlias = "//span[text()=\"%s\"]";
    public String deleteIcnOfSpecificAccno= "//span[text()=\"%s\"]//..//span[@class='delete-icn float-r mrg-top']";
    public By errorMsgForSpecialCharecter = By.xpath("//span[@class='sr-account-alias-invalid-input-text']");
    public  By redHighLightedBorderInTxtBox= By.xpath("//div[@class='border_red_input']");
    public By accountNumsHavingTrashIcnBeside = By.xpath("//span[@class='delete-icn float-r mrg-top']//..//..//..//..//..//div[@col-id='accountId']");
    public String deleteTrashIcnOfAccountNum = "//div[contains(text(),\"%s\")]//..//span/span[@class='delete-icn float-r mrg-top']";
    public String editPencilIcnOfAccountNum = "//div[contains(text(),\"%s\")]//..//span/span[@class='edit-icn float-r mrg-top-right']";
    public  String addAliasBtnWRTAccNum = "//div[text()=\"%s\"]//..//div[@col-id='aliasName']//span[text()=' Add an Alias ']";
    public By chooseAccount =By.xpath("//div[text()='Multiple Accounts']//..//button//span[text()='Choose Accounts ']");
    public By multipleAccountGridPanel = By.xpath("//app-collapsible-multiple-account-panel-group");
    public String deleteTrashIcnBesideMultipleAccAliasName= "//span[contains(text(),\"%s\")]//..//..//div[@class='ellipsis m-b-2']/span[@class='fdx-c-form-group__icon delete-icn-multiple']";
    public String editPencilIcnBesideMultipleAccAliasName = "//span[contains(text(),\"%s\")]//..//..//div[@class='ellipsis m-b-2']/span[@class='fdx-c-form-group__icon edit-icn-multiple']";
    public By subHeadingInPopUpMulipleAccAlias= By.xpath("//div[text()='Create a name to reference grouped accounts.']");
    public By AddAliasToMultipleAccountsTxt= By.xpath("//div[text()='Add Alias to ' and text()='Multiple Accounts ']");
    public By listOfChkBox= By.xpath("//div[@role='tabpanel']//label[not(contains(@for,'|'))]//..//input");
    public String blueDotIndicatorBesideAccNum = "//label[contains(text(),\"%s\")]//..//..//..//..//span[@class='indicator']";
    public String currentSelectedChkBox = "(//div[@role='tabpanel']//label[(contains(@for,'|'))]//..//input[@aria-checked='true'])[\"%s\"]";
    public By selectedAccNumTxtBox=By.xpath("//a/span[@class='sr-tabs__nav-lnk-txt']");
    public  By disabledButtonSaveAlais =By.xpath("//button[@disabled and contains(text(),' SAVE ALIAS ')]");
    public String currentSelectedChkBoxEnabled= "(//div[@role='tabpanel']//label[not(contains(@for,'|'))]//..//input)[%s]";
    public String searchAliasByNameOutput = "//div[@col-id='aliasName']//span[text()=\"%s\"]";
    public By specialMsgErrorWarning = By.xpath("(//div[@id='alertID']/span)[1]");
    public String blueDotIndicatorBesideAliasName = "//span[contains(text(),\"%s\")]/span";
    public By firstEnabledChkBox = By.xpath("(//input[@aria-checked='true'])[1]");
    public By listOfSelectedChkBox= By.xpath("//input[@aria-checked='true']");
    public By firstAlreadyEnabledChkBox= By.xpath("(//div[@role='tabpanel']//label[(contains(@for,'|'))]//..//input)[1]");
    public By accountAliasPageHeader=By.xpath("//div[text()='Add Account Alias']");
    public By accountAliasPageSubHeader = By.xpath("//div[text()='Create a reference name to each of your account numbers below. ']");
    public By accountAliasPageSingleAccHeader= By.xpath("//div[text()='Add Alias to a Single Account']");
    public By accountAliasPageSingleAccSubHeader= By.xpath("//div[text()='Add Alias to a Single Account']");
    public By accountAliasPageMultiAccHeader1= By.xpath("//div[text()='Add Alias to']");
    public By accountAliasPageMultiAccHeader2= By.xpath("//div[text()='Multiple Accounts']");
    public By accountAliasPageMultiAccSubHeader= By.xpath("//div[text()='Create a name to reference grouped accounts. ']");
    public By secionsInAccountAlias= By.xpath("//div[@class='sr-grid-row']/div");
    public By addAnAliasWaterMark =By.xpath("//input[@placeholder='Add an Alias']");
    public By selectAccNumWaterMark =By.xpath("//span[text()='Select']");
    public By createAnAliasTxt =By.xpath("//span[text()='Create an Alias']");
    public By chooseAnAliasTxt =By.xpath("//span[text()='Choose Accounts']");
    public By exportBtnIcn = By.xpath("//span[contains(@class,'export-icn')]");
    public By questionMarIcn = By.xpath("//span[@class='help-icn']");
    public By txtBoxFileNameInsideDownloadWindow= By.xpath("//input[@id='fileName']");
    public By fileNameTextInsideDownloadWindow=By.xpath("//div[@class='file-detailsSP__nameTxt']");
    public By downloadBtn = By.xpath("//button[text()=' Download ']");
    public By closeBtn= By.xpath("//button[text()=' Close ']");

    public By firstEnabledUnChkedChkBox=By.xpath("(//div[@role='tabpanel']//label[not(contains(@for,'|'))]//..//input[@aria-checked='false'])[2]");
    public By firstEnabledChkedChkBox=By.xpath("(//div[@role='tabpanel']//label[(contains(@for,'|'))]//..//input[@aria-checked='true'])[1]");
    public By listOfEnabledUnchkedChkBox =By.xpath("//div[@role='tabpanel']//label[not(contains(@for,'|'))]//..//input[@aria-checked='false']");
    public By listOfEnabledChkedChkBox = By.xpath("//div[@role='tabpanel']//label[(contains(@for,'|'))]//..//input[@aria-checked='true']");
    public String listOfEnabledChkedChkBoxByIndex = "(//div[@role='tabpanel']//label[(contains(@for,'|'))]//..//input[@aria-checked='true'])[%s]";
    public By csvOptionDownload =By.xpath("//input[@id='csv']");
    public By xlsxOptionDownload =By.xpath("//input[@id='xlsx']");
    public String AccountNumberWRTEditBtn="(//span[@class='edit-icn float-r mrg-top-right']//..//..//..//..//../div[@col-id='accountId'])[%s]";
    public String AliasNameWRTEditBtn="(//span[@class='edit-icn float-r mrg-top-right']//..//..//..//..//../div[@col-id='aliasName']//span//span[@class='text-exceeds'])[%s]";
    public By listOfActiveAccountNum = By.xpath("//span[@class='edit-icn float-r mrg-top-right']//..//..//..//..//../div[@col-id='accountId']");
    public By GreyedOutAccountNumbersInChooseAccountsDropDown=By.xpath("//label[contains(@for,'|')]//..//input[@disabled]");
    public By listOfAllAccountNumbers=By.xpath("//div[@col-id='accountId' and @role='gridcell']");
    public String checkBoxEnabledAvailable="//input[@id=\"%s\" and not(contains(@id,'|'))]";
    public By searchBoxInsideSelectAccountNumber = By.xpath("//input[contains(@class,'sr-searchbox__input') and not(contains(@placeholder,'Search'))]");
    public By listOfAccountNumberInMultipleAccountAliasSearch=By.xpath("//div[@class='sr-checkbox m-b-1 sr-checkbox--lg']//input[@type='checkbox' or @disabled]");
    public String editIcnSingleAccountAliasBesideAliasName="(//span[contains(text(),\"%s\")]//..//span[@class='edit-icn float-r mrg-top-right'])[1]";
    public String editIcnBesideSingleAccountAccountNumber="//div[text()=\"%s\"]//..//div[@col-id='aliasName']//span[@class='edit-icn float-r mrg-top-right']";
    public By specialCharecterErrorWarning = By.xpath("//span[text()=' Special characters not allowed']");
    public String singleAccountAliasNameWRTAccountNumber="//div[text()=\"%s\"]//..//div[@col-id='aliasName']//span[text()=\"%s\"]";
    public String accountNumberWRTAliasName="//span[text()=\"%s\"]//..//..//..//..//../div[@col-id='accountId']";
    public By addAnAliasBtns=By.xpath("(//span[text()=' Add an Alias '])");
    public By accountNumberWRTAddAnAliasFirstBtn =By.xpath("(//span[text()=' Add an Alias '])[1]//..//..//..//..//..//..//div[@col-id='accountId']");
    public String Validate_Sorting = "//span[contains(text(),'%s')]//..//span[@ref='eSortAsc']";
    public By InitialCount = By.xpath("//span[@ref='eText' and contains(.,'(')]");
    public By ValidRecord = By.xpath("//div[@row-index='0']//div[@col-id='accountId']");
    public By InvalidRecord = By.xpath("//div[@class='sr-legacy-search-searchbox-message' and contains(.,'No results found.')]");

    public String billToAliasWRTAccountNum="//input[@value=\"%s\"]//..//..//..//..//span[@class='alias-link']";
    public By accountAliasCheckBox=By.xpath("//li[@class='sr-multinav-subchild__item is-alias']//input[@role='checkbox']");
    public By aliasNamesInBillToSearchBox=By.xpath("//li[@class='sr-multinav-subchild__item is-alias']//span[@class='alias-link']");
    public By noResultsFoundMessage= By.xpath("//div[text()=' No results found. ']");
    public By selectAllCheckBox=By.xpath("//input[@role='checkbox' and @value='Select All']");
    public By Filters =By.xpath("//span[text()='FILTERS']");
    public By shipperInformation= By.xpath("//a[text()='Shipper Information']");
    public By billToTransportation=By.xpath("//a[text()='Bill To (Transportation) ']");
    public By searchPopUpBox =By.xpath("//ul[@class='sr-multinav-subchild']");
    String chkBoxWRTAliasName="//span[contains(text(),\"%s\")]//..//input";
    String accNumSearchResWRTAliasName="//li/span[contains(text(),\"%s\")]//..//div//label";
    String BarInSearchResWRTAliasName ="//li[text()=' | ']//span[contains(text(),\"%s\")]";
    public  String selectedRowAliasNameSA="//span[text()=\"%s\"]//..//..//..//..//..//..//div[contains(@class,'selected')]";
    public String selectedRowAccountNumberSA ="//div[contains(text(),\"%s\")]//..//..//div[contains(@class,'selected')]";
    public By accountNumVerticalBaraliasName=By.xpath("//div[contains(@class,'sr-modal__specific-text')]");
    //Subscribed Accounts
    public By addAliasFirstLinkSA=By.xpath("(//span[text()='Add Alias'])[1]");
    public By accountNumWRTFirstAddAliasLinkSA=By.xpath("(//span[text()='Add Alias']//..//..//div)[1]");
    public String aliasNameInSubscribedAccountsWRTAliasName="//div[contains(text(),\"%s\")]/span";
    public   String aliasNameInEditPopupSubscribedAccounts="//div[contains(@class,'modal') and contains(text(),\"%s\")]";
    public By getAllRowTextInSubscribeAccounts=By.xpath("//app-account-link/div");

    public By btn_Hour_Chckbox = By.xpath("//input[@tabindex='0' and @type='checkbox']");
    public By filterBubbleValidate = By.xpath("//*[@class='sr-pill__label']//span[@class='sr-pill-item__txt']");
    public String disabledButton="//button[contains(text(),\"%s\") and @disabled]";
    public String enabledButton="//button[contains(text(),\"%s\")]";
    public String firstCheckBoxAccNumOfSavedMultipleAccountAlias="(//span[@class='va-2px' and contains(text(),\"%s\")]//..//..//..//li//input)[1]";
    public By accountNumberDropDownExpandAndCollapse=By.xpath("//a[contains(@class,'sr-tabs__nav-lnk sr-tabs__nav-lnk--menu')]/span[@class='sr-tabs__nav-lnk-txt']");

    public By addAccountAlias_searchbox_InAccountsFilter=By.xpath("//ul[@class='sr-multinav-subchild']//input[@placeholder='Search']");
    public By getAccountsNoBesideAddAliasBtnInAccountsFilter=By.xpath("//span[contains(text(),'Add Alias')]//parent::li//label");
    public String addAliasButtonsBesideAccNoInAccountsFilter="//label[contains(text(),\"%s\")]//parent::div/../../..//span[contains(text(),'Add Alias')]";
    public By AccountFilterBubbleValues=By.xpath("//div[@class='sr-pill__label']/span");


    public AccountAlias(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
    }

    public void validateLabels(DataTable dataTable) {
//        Map<String, String> dataOptions = dataTable.asMap(String.class, String.class);
        List<String> allValues = dataTable.asList(String.class);
        for (String value : allValues) {
            if(!value.equals("Choose Accounts")) {
                Assert.assertTrue("", this.elementIsDisplayed(By.xpath(String.format(addAccountAlias_div_ContainsGenericXpath, value))));
            }
            else {
                Assert.assertTrue("", this.elementIsDisplayed(By.xpath(String.format(buttonText, value))));
            }
        }
    }

    public void clickChooseAccounts(){
        this.clickOnElement(By.xpath(String.format(buttonText, "Choose Accounts")));
    }

    public void validateDeleteAliasFunction(){
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(addAccountAlias_ContainsGenericXpath,"span","Choose Accounts"))));
    }

    public void validateAccountAliasScreen(){
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(addAccountAlias_account_alias,"Accounts"))));
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(addAccountAlias_account_alias,"Alias"))));
        Assert.assertTrue(this.elementIsDisplayed(addAccountAlias_searchbox));
        Assert.assertTrue(this.elementIsDisplayed(addAccountAlias_searchIcon));
        Assert.assertTrue("Data is not numeric : ",StringUtils.isNumericSpace(this.getText(accountid_1)));
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        Assert.assertTrue("Data is not blank : ",StringUtils.isNotBlank(this.getText(aliasText_1)));

    }

    public void clickChooseAccountsDDAndValidate(){
        Assert.assertTrue(this.clickOnElementEvent(accountsDropdown));
        Assert.assertTrue("Account exists : ",StringUtils.isNumeric(this.getText(accountsDDText)));
        this.clickOnElement(accountsDropdown);
        this.clickOnElement(By.xpath(String.format(buttonText, "Cancel")));
    }

    public void validateGridListDDWithAliasNames(){
        Assert.assertTrue("Delete icon is displayed: ",this.elementIsDisplayed(By.xpath(String.format(deleteIcon))));
        Assert.assertTrue("Edit icon is displayed: ",this.elementIsDisplayed(By.xpath(String.format(editIcon))));
        this.clickOnElement(aliasFirstDropdown);
        Assert.assertTrue("Alias dropdown value exists : ",StringUtils.isNumeric(this.getText(aliasDDText)));

        this.clickOnElement(aliasSecondDropdown);
        Assert.assertTrue("2nd Alias dropdown expanded: ",this.elementIsDisplayed(By.xpath(String.format(aliasDDExpand))));
        Assert.assertTrue("1st Alias dropdown collapsed: ",this.elementIsNotDisplayed(By.xpath(String.format(aliasDDCollapse))));

    }
    public void clickBreadcrumbMenu(){
        JavaScriptClick(By.xpath(String.format(breadcrumbMenu)));
    }

    public  void deleteAllSingleAcooumts(){
        this.commonHelpers.thinkTimer(6000);
        int count=getCount(listOfSingleAccountDeleteIcns);
        for(int i=0;i<count;i++){
            JavaScriptClick(firstSingleAccountDeleteIcns);
            JavaScriptClick(DeleteAliasBtnInMultipleAccAlias);
            this.waitUntilNotVisible(this.loadingIndicatorContains);
            this.commonHelpers.thinkTimer(5000);
        }

    }

    public void addSingleAccountAllias(String AlliasName){
        if(this.findElements(addAnAliasFirstBtn).size()>=1){
            JavaScriptClick(addAnAliasFirstBtn);
            this.enterText(inputAddAliasName,AlliasName);
            JavaScriptClick(applyBtnAddAllias);


        }
    }




    public  void verifyAddAliasBtnBesideAccountNumber(){
        List<WebElement>listOfAccNoBesideAddAliasBtn=this.findElements(accountsNoBesideAddAliasBtn);
        for(WebElement el:listOfAccNoBesideAddAliasBtn){
            String accNum=el.getText();
            Assert.assertEquals(1,getCount(By.xpath(String.format(addAliasButtonsBesideAccNo,accNum))));
        }
    }


    public void verifyChooseAccountsBtn(){
        Assert.assertEquals(1,getCount(chooseAccount));
    }

    public void deleteSpecificMultipleAccAlias(String AliasName){
        //JavaScriptClick(By.xpath(String.format(accountAliasNameExpansionBtn,AliasName)));
        JavaScriptClick(By.xpath(String.format(DustbinDeleteIcnInMultipleAccAlias,AliasName)));
        Assert.assertEquals(true,this.findElement(deleteAliasPopUpModalMessage).isDisplayed());
        Assert.assertEquals(true,this.findElement(By.xpath(String.format(deleteAliasPopUpAliasName,AliasName))).isDisplayed());
        Assert.assertEquals(true,this.findElement(deleteAliasModelPopupCloseIcn).isDisplayed());
        Assert.assertEquals(true,this.findElement(cancelBtnInMultipleAccAlias).isDisplayed());
        Assert.assertEquals(true,this.findElement(DeleteAliasBtnInMultipleAccAlias).isDisplayed());
        JavaScriptClick(DeleteAliasBtnInMultipleAccAlias);
        this.commonHelpers.thinkTimer(3000);
        Assert.assertEquals(0,getCount(By.xpath(String.format(headerAccountAliasName,AliasName))));
    }
    public void verifyAccNumsAssociatedAfterDeleting(List<String>listOfAccNo){
        for(String str:listOfAccNo) {
            this.enterText(InputTxtBoxSearchAlias, str);
            JavaScriptClick(SearchIcnBtnToSearchAccountAlias);
            Assert.assertEquals(1, getCount(By.xpath(String.format(addAliasBtnWRTAccNum,str))));
        }
    }





    public  void deleteMultipleAccountAlias(String AliasName){
        this.waitUntilVisible(By.xpath(AliasName));
        JavaScriptClick(By.xpath( String.format(deleteTrashIcnBesideMultipleAccAliasName,AliasName)));
        JavaScriptClick(DeleteAliasBtnInMultipleAccAlias);
    }
    public void deleteSingleAccountAlias(String AliasName){
        this.searchAccountNumberOrAliasSaved(AliasName);
        JavaScriptClick(By.xpath(String.format(deleteBtnInSingleAccountAlias,AliasName)));
        JavaScriptClick(DeleteAliasBtnInMultipleAccAlias);
    }
    public HashMap<String,String> addMultipleAccountAlias(String AliasName,int countOfAccountNum){
        this.deleteAllSingleAcooumts();
        JavaScriptClick(chooseAccount);
        this.enterText(createAliasInputNameMultipleAcc,AliasName);
        this.clickOnElement(selectAccountMultipleAccAlias);
        int countOfEnabledChkBox=getCount(listOfEnabledUnchkedChkBox);
        HashMap<String,String>accountNums=new HashMap<String,String>();
        if(countOfEnabledChkBox>=countOfAccountNum+1){
            for(int iterator=0;iterator<countOfAccountNum;iterator++){
                this.commonHelpers.AddToContextStore(this.getAttributeValue(firstEnabledUnChkedChkBox,"value"),AliasName);
                accountNums.put(this.getAttributeValue(firstEnabledUnChkedChkBox,"value"),"");
                this.clickOnEnabledUncheckedChkBoxRandom();
            }
            JavaScriptClick(SaveBtnInMultipleAccAlias);
            JavaScriptClick(CloseBtnInMultipleAccAlias);
        }
        return accountNums;
    }
    public void clickOnEnabledUncheckedChkBoxRandom(){
        JavaScriptClick( firstEnabledUnChkedChkBox);
    }
    public void clickOnEnabledAlreadyCheckedCheckBox(){
        JavaScriptClick(firstEnabledChkedChkBox);
    }
    public HashMap<String,String> editMultipleAccountAlias(String AliasName,String newAliasName,int countOfAccNumSelect,int countOfAccNumDeSelect){
        HashMap<String,String>AccNum=new HashMap<>();
        JavaScriptClick(By.xpath(String.format(editPencilIcnBesideMultipleAccAliasName,AliasName)));
        this.enterText(createAliasInputNameMultipleAcc,newAliasName);
        JavaScriptClick(selectedAccNumTxtBox);
        if(countOfAccNumSelect>0){
            int countOfEnabledChkBox=getCount(listOfEnabledUnchkedChkBox);
            if(countOfEnabledChkBox>=countOfAccNumSelect+1){
                for(int iterator=0;iterator<countOfAccNumSelect;iterator++){
                    AccNum.put(this.getAttributeValue(firstEnabledUnChkedChkBox,"value"),"");
                    this.clickOnEnabledUncheckedChkBoxRandom();
                }

            }

        }
        else if(countOfAccNumDeSelect>0){
            int countOfSelectedCheckbox=getCount(listOfEnabledChkedChkBox);
            if(countOfSelectedCheckbox>=countOfAccNumDeSelect){
                for(int iterator=0;iterator<countOfAccNumDeSelect;iterator++){
                    AccNum.put(this.getAttributeValue(firstEnabledChkedChkBox,"value"),"");
                    this.clickOnEnabledAlreadyCheckedCheckBox();
                }
            }
        }
        JavaScriptClick(SaveBtnInMultipleAccAlias);
        JavaScriptClick(CloseBtnInMultipleAccAlias);
        return AccNum;
    }
    public void searchAccountNumberOrAliasSaved(String AliasName){
        this.enterText(InputTxtBoxSearchAlias,AliasName);
        JavaScriptClick(SearchIcnBtnToSearchAccountAlias);
    }
    public void editMultipleAccountWithOneAccount(String AliasName,String newAliasName){
        this.addMultipleAccountAlias(AliasName,2);
        HashMap<String,String>hm2=this.editMultipleAccountAlias(AliasName,newAliasName,0,1);
        this.searchAccountNumberOrAliasSaved(newAliasName);
        Assert.assertEquals(true,this.elementIsDisplayed(By.xpath(String.format(searchAliasByNameOutput,newAliasName))));
        for(Map.Entry<String,String>accNum:hm2.entrySet()){
            String accountNumber=accNum.getKey();
            this.searchAccountNumberOrAliasSaved(accountNumber);
            Assert.assertEquals(true,this.elementIsPresent(By.xpath(String.format(addAliasBtnWRTAccNum,accountNumber))));
        }
        Assert.assertEquals(true,this.elementIsNotDisplayed(By.xpath(String.format(headerAccountAliasName,newAliasName))));
        this.deleteSingleAccountAlias(newAliasName);

    }
    public void editMultipleAccountWithMoreThanOneAccount(String AliasName,String newAliasName){
        HashMap<String,String>hm1=this.addMultipleAccountAlias(AliasName,3);
        HashMap<String,String>hm2=this.editMultipleAccountAlias(AliasName,newAliasName,0,1);
        for(Map.Entry<String,String>accNum:hm2.entrySet()){
            String accountNumber=accNum.getKey();
            hm1.remove(accountNumber);
        }
        for(Map.Entry<String,String>accNum:hm2.entrySet()){
            String accountNumber=accNum.getKey();
            this.searchAccountNumberOrAliasSaved(accountNumber);
            Assert.assertEquals(true,this.elementIsPresent(By.xpath(String.format(addAliasBtnWRTAccNum,accountNumber))));
        }
        this.blueDotAndAccountNumberValidationAfterEdit(newAliasName,hm1);
        this.deleteMultipleAccountAlias(newAliasName);

    }
    public void editMultipleAccountWithoutChangingAccountNumber(String AliasName,String newAliasName){
        HashMap<String,String>hm1=this.addMultipleAccountAlias(AliasName,2);
        HashMap<String,String>hm2=this.editMultipleAccountAlias(AliasName,newAliasName,0,0);
        this.blueDotAndAccountNumberValidationAfterEdit(newAliasName,hm1);
        this.deleteMultipleAccountAlias(newAliasName);

    }
    public void editMultipleAccountWithAddingOneAccount(String AliasName,String newAliasName){
        HashMap<String,String>hm1=this.addMultipleAccountAlias(AliasName,2);
        HashMap<String,String>hm2=this.editMultipleAccountAlias(AliasName,newAliasName,1,0);
        for(Map.Entry<String,String>account:hm2.entrySet()){
            String accountNumber=account.getKey();
            hm1.put(accountNumber,"");
        }
        this.blueDotAndAccountNumberValidationAfterEdit(newAliasName,hm1);
        this.deleteMultipleAccountAlias(newAliasName);
    }

    public void blueDotAndAccountNumberValidationAfterEdit(String AliasName,HashMap<String,String>listOfAccNum){
        JavaScriptClick(By.xpath(String.format(accountAliasNameExpansionBtn,AliasName)));
        Assert.assertEquals(true,this.findElement(By.xpath(String.format(headerAccountAliasName,AliasName))).getText().contains(AliasName));
        String numberOfAccounts=Integer.toString(listOfAccNum.size());
        Assert.assertEquals(true,this.findElement(By.xpath(String.format(headerAccountAliasName,AliasName))).getText().contains(numberOfAccounts));
        for(Map.Entry<String,String>accounts:listOfAccNum.entrySet()){
            String accountNum = accounts.getKey();
            Assert.assertEquals(1,getCount(By.xpath(String.format(blueDotIndicatorBesideAccNum,accountNum))));
        }
    }
    public void verifyValidAliasName(String AliasName,DataTable table){
        List<String>listOfData=table.asList();
        JavaScriptClick(By.xpath(String.format(editPencilIcnBesideMultipleAccAliasName,AliasName)));
        for(int iterator=0;iterator<listOfData.size();iterator++){
            String olds;
            String news;
            if(iterator==0){
                olds=AliasName;
                news=listOfData.get(iterator);
            }
            else{
                olds=listOfData.get(iterator-1);
                news=listOfData.get(iterator);
            }
            this.editMultipleAccountAlias(olds,news,0,0);
            Assert.assertEquals(true,this.findElement(By.xpath(String.format(headerAccountAliasName,news))).getText().contains(news));

        }
        this.deleteMultipleAccountAlias(listOfData.get(listOfData.size()-1));

    }

    public void specialCharecterMultipleAccountAliasName(String specialChar){
        JavaScriptClick(chooseAccount);
        this.enterText(createAliasInputNameMultipleAcc,specialChar);
        Assert.assertEquals(true,this.elementIsPresent(specialMsgErrorWarning));
        JavaScriptClick(cancelBtnInMultipleAccAlias);

    }
    public void switchTabs(){
        AdvisoryPage advisoryPage=new AdvisoryPage(commonHelpers);
        advisoryPage.NavigateToSubMenu("Preferred Locations");
        advisoryPage.NavigateToSubMenu("Add Account Alias");
    }
    public void editScenarioVerification(String AliasName,String newAliasName){
        this.editMultipleAccountWithOneAccount(AliasName,newAliasName);
        this.switchTabs();
        this.editMultipleAccountWithMoreThanOneAccount(AliasName,newAliasName);
        this.switchTabs();
        this.editMultipleAccountWithoutChangingAccountNumber(AliasName,newAliasName);
        this.switchTabs();
        this.editMultipleAccountWithAddingOneAccount(AliasName,newAliasName);
        this.switchTabs();
    }
    public void verifySorting(List<String>sortedArray,List<String>unSortedArray){
        Collections.sort(sortedArray);
        for(int iterator=0;iterator<sortedArray.size();iterator++){
            Assert.assertEquals(sortedArray.get(iterator),unSortedArray.get(iterator));
        }
    }
    public List<String> getAlreadySelectedAcoountNumbers(String AliasName){
        List<String>accountNumbers=new ArrayList<>();
        JavaScriptClick(By.xpath(String.format(editPencilIcnBesideMultipleAccAliasName,AliasName)));
        JavaScriptClick(selectedAccNumTxtBox);
        int countOfSelectedCheckbox=getCount(listOfEnabledChkedChkBox);
        for(int iterator=1;iterator<=countOfSelectedCheckbox;iterator++){
            String index=Integer.toString(iterator);
            String xpath=String.format(listOfEnabledChkedChkBoxByIndex,index);
            System.out.println(xpath);
            String accountNum=this.findElement(By.xpath(xpath)).getAttribute("value");
            System.out.println(accountNum);
            accountNumbers.add(accountNum);
        }
        JavaScriptClick(cancelBtnInMultipleAccAlias);
        return accountNumbers;
    }
    public void verifySortingOfAccountNumbers(String AliasName){
        List<String>listOfAccNum=this.getAlreadySelectedAcoountNumbers(AliasName);
        this.verifySorting(listOfAccNum,listOfAccNum);
    }
    public String[][] getExcelData(String fileType, String sheetname) throws IOException {
        AdvisoryPage advisoryPage=new AdvisoryPage(commonHelpers);
        File filpath = advisoryPage.getLastModified(genericFunctionObject.home + genericFunctionObject.slashBasedOnOs + Constants.downloadFolder + genericFunctionObject.slashBasedOnOs);
        FileInputStream fs = null;
        XSSFWorkbook wb;
        fs = new FileInputStream(filpath.toString());
        wb = new XSSFWorkbook(fs);
        XSSFSheet sheet = wb.getSheetAt(0);
        int lastrow = sheet.getLastRowNum();
        int lastcol = sheet.getRow(0).getLastCellNum();
        log.info("Last row : " + lastrow);
        String[][] excelData = new String[lastrow + 1][lastcol];

        for (int erow = 0; erow <= lastrow; erow++) {
            Row rb = sheet.getRow(erow);
            for (int ecolumn = 0; ecolumn < lastcol; ecolumn++) {
                Cell cb = rb.getCell(ecolumn);
                excelData[erow][ecolumn] = cb.getStringCellValue();
//
            }
        }
        return excelData;
    }
    public void validate_excelData_UIData(String excelData[][],String UIData[][]){
        int rows=excelData.length;
        int cols=excelData[0].length;
        for(int irow=0;irow<rows;irow++){
            for (int jcol=0;jcol<cols;jcol++){
                Assert.assertEquals(excelData[irow][jcol].toLowerCase(),UIData[irow][jcol].toLowerCase());
            }
        }
    }
    public String[][] getUIData(){
        int cols=2;
        commonHelpers.thinkTimer(3000);
        this.waitUntilVisible(listOfActiveAccountNum);
        int rows=this.findElements(listOfActiveAccountNum).size()+1;
        String UIData[][]=new String[rows][cols];
        UIData[0][0]="Accounts";
        UIData[0][1]="Alias";
        for(int irow=1;irow<rows;irow++){
            String AccountNum=getText(By.xpath(String.format(AccountNumberWRTEditBtn,irow)));
            log.info(AccountNum);
            UIData[irow][0]=AccountNum;
        }

        for(int irow=1;irow<rows;irow++){
            String AliasName=getText(By.xpath(String.format(AliasNameWRTEditBtn,irow)));
            log.info(AliasName);
            UIData[irow][1]=AliasName;
        }
        return UIData;
    }
    public void validateExcelAndUI() throws IOException {
        this.validate_excelData_UIData(this.getExcelData("",""),this.getUIData());
    }
    public void validateFileNameSameAsSaved(String text){
        this.enterText(this.txtBoxFileNameInsideDownloadWindow,text);
        Assert.assertEquals(true,getText(this.fileNameTextInsideDownloadWindow).contains(text));
    }
    public void verifyAddAliasButtonBesideAccountNumbers(HashMap<String,String>listOfAccountNums){
        for(Map.Entry<String,String>accountNum:listOfAccountNums.entrySet()){
            String account_number=accountNum.getKey();
            searchAccountNumberOrAliasSaved(account_number);
            Assert.assertEquals(true,this.findElement(By.xpath(String.format(addAliasBtnWRTAccNum,account_number))).isDisplayed());
        }
    }
    public void verifyDeleteScenario(String AliasName){
        HashMap<String,String>accountNums=this.addMultipleAccountAlias(AliasName,2);
        this.blueDotAndAccountNumberValidationAfterEdit(AliasName,accountNums);
        JavaScriptClick(By.xpath(String.format(deleteTrashIcnBesideMultipleAccAliasName,AliasName)));
        Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(deleteAliasPopUpAliasName,AliasName))));
        JavaScriptClick(DeleteAliasBtnInMultipleAccAlias);
        this.verifyAddAliasButtonBesideAccountNumbers(accountNums);
        this.switchTabs();
    }
    public  void addSingleAccountAlias(DataTable table){
        this.deleteAllSingleAcooumts();
        List<String>listOfAliasNames=table.asList();
        for(int iterator=0;iterator<listOfAliasNames.size();iterator++){
            String name=listOfAliasNames.get(iterator);
            this.commonHelpers.thinkTimer(5000);
            JavaScriptClick(addAnAliasFirstBtn);
            this.commonHelpers.thinkTimer(5000);
            this.enterText(inputAddAliasName,name);
            if(getCount(redHighLightedBorderInTxtBox)>=1 || getCount(applyButtonDisabled)>=1){
                log.info("This is not allowed");
                Assert.assertEquals(true,name.length()<3 || checkForSpecialCharecter(name));
                JavaScriptClick(closeCrossIcnInsideTxtBox);
                continue;
            }
            else{
                this.commonHelpers.thinkTimer(5000);
                Assert.assertEquals(1,getCount(applyButtonEnabled));
                JavaScriptClick(applyButtonEnabled);
                String accountNumber=getText(By.xpath(String.format(accNumOfAliasName,name)));
                this.commonHelpers.AddToContextStore(name,accountNumber);
            }
        }
    }
    public boolean checkForSpecialCharecter(String name){
        Pattern pattern = Pattern.compile("[^A-Za-z0-9]");
        Matcher m = pattern.matcher(name);
        boolean specialCharecterIsPresent = m.find();
        return specialCharecterIsPresent;
    }
    public void deleteSingleAccountAliasVerification(String AliasName){
        String accountNumber=getText(By.xpath(String.format(accNumOfAliasName,AliasName)));
        deleteSingleAccountAlias(AliasName);
        searchAccountNumberOrAliasSaved(accountNumber);
        this.commonHelpers.thinkTimer(3000);
        Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(addAliasBtnWRTAccNum,accountNumber))));

    }
    public void addAndCancelAndDelete(String AliasName){
        HashMap<String,String>listOfAccNums=this.addMultipleAccountAlias(AliasName,2);
        JavaScriptClick(By.xpath(String.format(deleteTrashIcnBesideMultipleAccAliasName,AliasName)));
        JavaScriptClick(cancelBtnInMultipleAccAlias);
        this.blueDotAndAccountNumberValidationAfterEdit(AliasName,listOfAccNums);
        this.deleteMultipleAccountAlias(AliasName);
        this.verifyAddAliasButtonBesideAccountNumbers(listOfAccNums);

    }
    public void verifySortingOfExcelAccountsColumns() throws IOException {
        String[][] excelData=this.getExcelData("","");
        int rows=excelData.length;
        List<String>arrayOfAccountNums=new ArrayList<>();
        for(int iterator=1;iterator<rows;iterator++){
            arrayOfAccountNums.add(excelData[iterator][0]);
        }
        verifySorting(arrayOfAccountNums,arrayOfAccountNums);
    }


    public void validateGreyedOutAccountNumbersInChooseAccountsDropDown(HashMap<String,String>accountNumbers,String AliasName){
        List<WebElement>greyAccountNumsList=this.findElements(GreyedOutAccountNumbersInChooseAccountsDropDown);
        for(WebElement element:greyAccountNumsList){
            String []details=element.getAttribute("id").split("[|, ?.@]+",2);
            String accountNum=details[0];
            String name=details[1];
            Assert.assertEquals(true,(accountNumbers.containsKey(accountNum))&&(AliasName.contains(name)));
        }

    }
    public HashMap<String,String> getAllAccountNumbers(){
        List<WebElement>accountNums=this.findElements(listOfAllAccountNumbers);
        HashMap<String,String>AllAccountNumber=new HashMap<>();
        for(WebElement element:accountNums){
            String accountNumber=element.getText();
            AllAccountNumber.put(accountNumber,"");
        }
        return AllAccountNumber;
    }
    public void ValidateAccountNumsAssociatedScenario(String Alias1){
        HashMap<String,String>AllAccountsNumbers=this.getAllAccountNumbers();
        HashMap<String,String>AddedAccountNums=this.addMultipleAccountAlias(Alias1,2);
        JavaScriptClick(chooseAccount);
        JavaScriptClick(selectAccountMultipleAccAlias);
        this.validateGreyedOutAccountNumbersInChooseAccountsDropDown(AddedAccountNums,Alias1);
        for(Map.Entry<String,String>accounts:AllAccountsNumbers.entrySet()){
            if(!AddedAccountNums.containsKey(accounts.getKey())){
                Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(checkBoxEnabledAvailable,accounts.getKey()))));
            }
        }
    }

    public void validateSelectAllCheckBox(){
        int AccountNumbersUnchecked=getCount(currentEnabledInputChkBox);
        JavaScriptClick(By.xpath(String.format(currentSelectedChkBoxEnabled,1)));
        for(int iterator=2;iterator<=AccountNumbersUnchecked;iterator++){
            Assert.assertEquals(true,getAttributeValue(By.xpath(String.format(currentSelectedChkBoxEnabled,iterator)),"aria-checked").contains("true"));
        }
    }
    public void searchAccountNumberResultInMultipleAccountAlias(String accountNumSubstr){
        List<WebElement>searchedAccountNums=this.findElements(listOfAccountNumberInMultipleAccountAliasSearch);
        if(accountNumSubstr.length()>=2) {
            int count = searchedAccountNums.size();
            if (count > 1) {
                int iterator = 1;
                for (WebElement element : searchedAccountNums) {
                    if (iterator == 1) continue;
                    String text = getAttributeValue(element, "id");
                    Assert.assertEquals(true, text.contains(accountNumSubstr));
                    iterator++;
                }
            } else {
                log.info("No account Nums to validate");
            }
        }
        else{
            for (WebElement element : searchedAccountNums) {
                String text = getAttributeValue(element, "id");
                if(!text.contains(accountNumSubstr)){
                    log.info("searched value is different but still in the list so searched funtionality is failing for <2 charecters as expected");
                    Assert.assertEquals(true,!text.contains(accountNumSubstr));
                }
            }
        }
    }

    public void editSingleAccountAlias(String AccountNumber,String oldValue,String updatedValue){
        this.commonHelpers.thinkTimer(4000);
        JavaScriptClick(By.xpath(String.format(editIcnBesideSingleAccountAccountNumber,AccountNumber)));
        this.commonHelpers.thinkTimer(3000);
        this.enterText(inputAddAliasName,updatedValue);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        if(getCount(applyButtonDisabled)>=1 || getCount(redHighLightedBorderInTxtBox)>=1){
            Assert.assertEquals(true,updatedValue.length()<3 || checkForSpecialCharecter(updatedValue));
            if(checkForSpecialCharecter(updatedValue)){
                Assert.assertEquals(true,elementIsPresent(specialCharecterErrorWarning));
            }
            this.JavaScriptClick(closeCrossIcnInsideTxtBox);
            return;
        }
        this.commonHelpers.thinkTimer(5000);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.JavaScriptClick(applyButtonEnabled);
        this.commonHelpers.thinkTimer(5000);
        Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(singleAccountAliasNameWRTAccountNumber,AccountNumber,updatedValue))));
    }
    public HashMap<String,String> addSingleAccountAlias(List<String>listOfAliasName){
        this.commonHelpers.thinkTimer(5000);
        if(listOfAliasName.size()>=getCount(addAnAliasBtns)){
            deleteAllSingleAcooumts();
            return addSingleAccountAlias(listOfAliasName);
        }
        HashMap<String,String>mapAccountWithAliasName=new HashMap<>();
        for(int iterator=0;iterator<listOfAliasName.size();iterator++){
            this.commonHelpers.thinkTimer(5000);
            String accountNumber=getText(accountNumberWRTAddAnAliasFirstBtn);
            JavaScriptClick(addAnAliasFirstBtn);
            this.commonHelpers.thinkTimer(5000);
            this.enterText(inputAddAliasName,listOfAliasName.get(iterator));
            if(this.elementIsDisplayed(this.applyBtnAddAllias)){
                JavaScriptClick(applyBtnAddAllias);
            }
            mapAccountWithAliasName.put(accountNumber,listOfAliasName.get(iterator));
            this.commonHelpers.AddToContextStore(listOfAliasName.get(iterator),accountNumber);
        }
        return mapAccountWithAliasName;
    }
    public void updatingSingleAccountAlias(List<String>list,String updatedAliasName){
        HashMap<String,String>accountAlias=this.addSingleAccountAlias(list);
        this.commonHelpers.thinkTimer(5000);
        Iterator<String>iterator=accountAlias.keySet().iterator();
        String accountNum=iterator.next();
        String aliasName=accountAlias.get(accountNum);
        this.editSingleAccountAlias(accountNum,aliasName,"@3/j");
        this.editSingleAccountAlias(accountNum,aliasName,updatedAliasName);
        this.deleteAllSingleAcooumts();
    }
    public void editSingleAccountAliasWithouSaving(List<String>list,String updatedAliasName){
        HashMap<String,String>accountAlias=this.addSingleAccountAlias(list);
        this.commonHelpers.thinkTimer(2000);
        Iterator<String>iterator=accountAlias.keySet().iterator();
        String accountNum1=iterator.next();
        String aliasName1=accountAlias.get(accountNum1);
        String accountNum2=iterator.next();
        String aliasName2=accountAlias.get(accountNum2);
        JavaScriptClick(By.xpath(String.format(editIcnBesideSingleAccountAccountNumber,accountNum1)));
        this.commonHelpers.thinkTimer(2000);
        this.enterText(inputAddAliasName,updatedAliasName);
        this.commonHelpers.thinkTimer(2000);
        JavaScriptClick(By.xpath(String.format(editIcnBesideSingleAccountAccountNumber,accountNum2)));
        this.commonHelpers.thinkTimer(2000);
        Assert.assertEquals(1,getCount(inputAddAliasName));
        Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(singleAccountAliasNameWRTAccountNumber,accountNum1,aliasName1))));
        Assert.assertEquals(false,elementIsPresent(By.xpath(String.format(singleAccountAliasNameWRTAccountNumber,accountNum1,updatedAliasName))));
        JavaScriptClick(closeCrossIcnInsideTxtBox);
        this.deleteAllSingleAcooumts();
    }
    public void editAddAnAliasWithoutApplying(String AliasName){
        this.commonHelpers.thinkTimer(2000);
        String accountNumber=getText(accountNumberWRTAddAnAliasFirstBtn);
        JavaScriptClick(addAnAliasFirstBtn);
        this.commonHelpers.thinkTimer(2000);
        this.enterText(inputAddAliasName,AliasName);
        this.commonHelpers.thinkTimer(2000);
        JavaScriptClick(addAnAliasFirstBtn);
        this.commonHelpers.thinkTimer(2000);
        Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(addAliasBtnWRTAccNum,accountNumber))));
        JavaScriptClick(closeCrossIcnInsideTxtBox);
    }
    public void editAccountAliasWithValues(List<String>list, DataTable table){
        this.addSingleAccountAlias(list);
        List<String>listOfEditName=table.asList();
        for(int iterator=0;iterator<listOfEditName.size();iterator++){
            String olds,news;
            if(iterator==0){
                olds=list.get(0);
                news=listOfEditName.get(0);
            }
            else{
                olds=listOfEditName.get(iterator-1);
                news=listOfEditName.get(iterator);
            }
            String accountNum=getText(By.xpath(String.format(accountNumberWRTAliasName,olds)));
            editSingleAccountAlias(accountNum,"",news);
        }
        this.deleteAllSingleAcooumts();
    }

    public void ValidateSearchAccountNumberOrAliasSaved(String Account_AliasName){

        List<String> BeforeContent = new ArrayList<String>();
        List<String> AfterContent = new ArrayList<String>();
        List<WebElement>BeforeCount=this.findElements(InitialCount);
        for(WebElement element:BeforeCount){
            BeforeContent.add(element.getText());
        }

        if(Account_AliasName.length()>=3) {
            this.enterText(InputTxtBoxSearchAlias, Account_AliasName);
            JavaScriptClick(SearchIcnBtnToSearchAccountAlias);
            if(this.getCount(this.ValidRecord)==1){
                Assert.assertEquals(this.getCount(this.ValidRecord), 1);
            }
            else if(this.getCount(this.InvalidRecord)==1){
                Assert.assertEquals(this.getCount(this.InvalidRecord), 1);
            }
        }
        if(accNumOfAliasName.length()<=2){
            this.enterText(InputTxtBoxSearchAlias, Account_AliasName);
            JavaScriptClick(SearchIcnBtnToSearchAccountAlias);
            List<WebElement>AfterCount=this.findElements(InitialCount);
            for(WebElement element:AfterCount){
                AfterContent.add(element.getText());
                Assert.assertTrue(BeforeContent.toString().contentEquals(AfterContent.toString()));
            }
        }
    }

    public void verifyTheIsSortable(String ColumnName) {
        this.ScrollIntoViewColumnwise(ColumnName);
        Assert.assertTrue(this.getCount(By.xpath(String.format(Validate_Sorting,ColumnName)))==1);
    }

    public void validateWaterMarkforSearchBar(){
        Assert.assertTrue(this.elementIsDisplayed(addAccountAlias_searchbox));
    }
    public void validateWaterMarkforSearchBarLocalization(String searchBox){
        By addAccountAlias_searchbox1
                = By. xpath("// input[@placeholder='"+searchBox+"']");
        Assert.assertTrue(this.elementIsDisplayed(addAccountAlias_searchbox1));
    }
    public void storeAccountNumberAliasMapInContextStore(){
        String UIData[][]=this.getUIData();
        int rows=UIData.length;
        for(int irow=1;irow<rows;irow++){
            String accNum=UIData[irow][0];
            String alias=UIData[irow][1];
            this.commonHelpers.AddToContextStore(accNum,alias);
        }
    }
    public  void validateValuesAliasNameFromAccountAliasToShipment(){
        this.commonHelpers.thinkTimer(3500);
        int iterator=1;
        List<WebElement>ListOfChecBoxes=this.findElements(accountAliasCheckBox);
        for(WebElement element:ListOfChecBoxes){
            if(iterator==1) {
                iterator++;
                continue;
            }
            String accountNum=getAttributeValue(element,"value");
            String alias=getText(By.xpath(String.format(billToAliasWRTAccountNum,accountNum)));
            if(alias.equalsIgnoreCase("Add Alias")) continue;
            Assert.assertEquals(true,this.commonHelpers.getValuefromContextStore(accountNum).equals(alias));
        }
    }
    public void searchBoxValidation(String substring,int sizeOfSearchList){
        if(!elementIsPresent(noResultsFoundMessage)) {
            if(getCount(accountAliasCheckBox)>1){
                Assert.assertEquals(true,elementIsPresent(selectAllCheckBox));
            }
            else{
                Assert.assertEquals(false,elementIsPresent(selectAllCheckBox));

            }
            List<WebElement> listOfAliasNames = this.findElements(aliasNamesInBillToSearchBox);
            int iterator = 1;
            for (WebElement element : listOfAliasNames) {
                if (iterator == 1) {
                    iterator++;
                    continue;
                }
                String aliasName = getText(element);
                Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(chkBoxWRTAliasName,aliasName))));
                Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(accNumSearchResWRTAliasName,aliasName))));
                Assert.assertEquals(true,elementIsPresent(By.xpath(String.format(BarInSearchResWRTAliasName,aliasName))));
                if (aliasName.toLowerCase().contains(substring.toLowerCase()) == true) {
                    Assert.assertEquals(true, aliasName.toLowerCase().contains(substring.toLowerCase()));
                } else {
                    int size2=this.findElements(aliasNamesInBillToSearchBox).size();
                    Assert.assertEquals(true, (substring.length() < 3) && (sizeOfSearchList==size2));
                    break;
                }
            }
        }
    }
    public void getAccounAliasTable(){
        String [][]UIData=this.getUIData();
        HashMap<String,String>AllAccountNums=this.getAllAccountNumbers();
        for(int row=1;row<UIData.length;row++){
            this.commonHelpers.AddToContextStore(UIData[row][0],UIData[row][1]);
        }
        for(Map.Entry<String,String>accounts:AllAccountNums.entrySet()){
            String accountNumber=accounts.getKey();
            if(!this.commonHelpers.verifyKeyinContextStore(accountNumber)){
                this.commonHelpers.AddToContextStore(accountNumber,"Add Alias");
            }
        }
    }
    public HashMap<String,String> getSubscribedAccountsTableData(){
        HashMap<String,String>accountAlias=new HashMap<>();
        List<WebElement>listOfElements=this.findElements(getAllRowTextInSubscribeAccounts);
        for(WebElement element:listOfElements){
            String text=getText(element);
            String[] AccountAlias=text.split("[|, ?.@]+",2);
            accountAlias.put(AccountAlias[0],AccountAlias[1]);

        }
        return accountAlias;
    }
    public void validate_details_AccountAlias_And_SubscribeAccounts(){
        HashMap<String,String>accountAlias=this.getSubscribedAccountsTableData();
        for(Map.Entry<String,String>accountdetails:accountAlias.entrySet()){
            Assert.assertEquals(accountAlias.get(accountdetails.getKey()),this.commonHelpers.getValuefromContextStore(accountdetails.getKey()));
        }
    }

    public void click_checkbox(){
        this.verifyCheckBox_PerformAction(this.btn_Hour_Chckbox,"checked");
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    public void bubbleFilter(String name){
        Assert.assertTrue(this.getText(filterBubbleValidate).contains(name));
    }

    public void ValidateValuesfromExcel_IgnoringBlankCells(String SearchValue) throws IOException {
        ArrayList<String> ExcelData = new ArrayList<>();
        this.commonHelpers.thinkTimer(5000);
        for (Row row : new XSSFWorkbook(new FileInputStream(new AdvisoryPage(commonHelpers).getLastModified(System.getProperty("user.home") + "\\Downloads").toString())).getSheetAt(0)) {
            for (Cell cell : row) {
                ExcelData.add(cell.getStringCellValue());
            }
        }
        for (String value : ExcelData ) {
            boolean isValueFound = value.contains(SearchValue);
            if (isValueFound) {
                Assert.assertTrue(isValueFound);
                break;
            }
        }
    }

    public int validateExcelWithCount(String SheetName) throws IOException {
        AdvisoryPage advisoryPage = new AdvisoryPage(commonHelpers);
        File filpath;
        if (GenericFunction.OS.contains("Window")) {
            filpath = advisoryPage.getLastModified(System.getProperty("user.home") + "\\Downloads");
            this.commonHelpers.thinkTimer(5000);
        }else{
            filpath = advisoryPage.getLastModified("/root/Downloads");
        }
        FileInputStream fs = new FileInputStream(filpath.toString());
        XSSFWorkbook wb = new XSSFWorkbook(fs);
        XSSFSheet sheet = wb.getSheet(SheetName);
        int lastrow = sheet.getLastRowNum();
        int lastcol = sheet.getRow(1).getLastCellNum();
        return lastrow;
    }
    public void selectAccountNumber(int count){
        JavaScriptClick(accountNumberDropDownExpandAndCollapse);
        for(int iter=0;iter<count;iter++){this.clickOnEnabledUncheckedChkBoxRandom();}
    }
        public void editSecondAddAnAliasWithApplying(DataTable table) {
        List<String> listOfAliasNames = table.asList();
        for (int iterator = 0; iterator < listOfAliasNames.size(); iterator++) {
            String name = listOfAliasNames.get(iterator);
            this.commonHelpers.thinkTimer(5000);
            JavaScriptClick(addAnAliasSecondBtn);
            this.commonHelpers.thinkTimer(5000);
            this.enterText(inputAddAliasName, name);
            if (getCount(redHighLightedBorderInTxtBox) >= 1 || getCount(applyButtonDisabled) >= 1) {
                log.info("This is not allowed");
                Assert.assertEquals(true, name.length() < 3 || checkForSpecialCharecter(name));
                JavaScriptClick(closeCrossIcnInsideTxtBox);
                continue;
            } else {
                this.commonHelpers.thinkTimer(5000);
                Assert.assertEquals(1, getCount(applyButtonEnabled));
                JavaScriptClick(applyButtonEnabled);
                String accountNumber = getText(By.xpath(String.format(accNumOfAliasName, name)));
                this.commonHelpers.AddToContextStore(name, accountNumber);
            }
        }
    }

    public void validateAddAccountAliasSearchBoxInAccountFilter(){
        Assert.assertTrue(this.elementIsDisplayed(addAccountAlias_searchbox_InAccountsFilter));
    }

    public  void verifyAddAliasBtnBesideAccountNumberInAccountFilter(){
        List<WebElement>listOfAccNoBesideAddAliasBtn=this.findElements(getAccountsNoBesideAddAliasBtnInAccountsFilter);
        for(WebElement el:listOfAccNoBesideAddAliasBtn){
            String accNum=el.getText().trim();
            Assert.assertEquals(1,getCount(By.xpath(String.format(addAliasButtonsBesideAccNoInAccountsFilter,accNum))));
        }
    }

    public void validateAccountColumnFilterBubble(String addAlias)
    {
        StringBuilder str = new StringBuilder();
        List<WebElement> filterList = DriverManager.getDrv().findElements(AccountFilterBubbleValues);
        for (WebElement w : filterList) {
            str.append(w.getText() + " ");
        }
        System.out.println("Actual String is " + str);
        if(!addAlias.equalsIgnoreCase("AddAlias")) {
            Assert.assertTrue("Doesn't match", Pattern.matches(
                    "[A-Z]*+[:]+[\" \"]+([0-9]{9}+[\" \"])*", str));
        }else{
            Assert.assertTrue("Doesn't match", Pattern.matches(
                    "([A-Z]*+[:]+[\" \"]+([0-9]{9}+[\" | \"]+[A-Za-z0-9]*+[\" \"]?)*)", str));
        }
    }
    public void storeAccountNumberAliasMapInContextStore(String aliasname){
        String UIData[][]=this.getUIData();
        int rows=UIData.length;
        for(int irow=1;irow<rows;irow++){
            String accNum=UIData[irow][0];
            String alias=UIData[irow][1];
            this.commonHelpers.AddToContextStore(aliasname,accNum);
            this.commonHelpers.AddToContextStore(accNum,alias);


        }
    }


}


