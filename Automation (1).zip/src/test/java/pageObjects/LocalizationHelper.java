package pageObjects;

import common.CommonHelpers;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

@Slf4j
public class LocalizationHelper extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;

    public GenericFunction genericFuncObj;
    public ShipmentOverviewPage shipmentOverviewPage;

    public String filterViewxpath = ".//*[contains(text(),\"%s\")]";
    public By filterChevron = By.xpath("(//ul[@role='tablist']//a)[1]");

    public LocalizationHelper(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.genericFuncObj = new GenericFunction();
        this.shipmentOverviewPage = new ShipmentOverviewPage(commonHelpers);
    }

    public void selectColumnOptions(String tab, DataTable table){
        List<String> columnOptions = table.asList(String.class);
        String element = this.findElement(this.shipmentOverviewPage.columnChevron).getAttribute("class");
        if (!element.contains("active"))
            this.JavaScriptClick(this.shipmentOverviewPage.columnChevron);

        if(tab.equalsIgnoreCase("Shipment")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Shipment");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }else if(tab.equalsIgnoreCase("Shipper")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Shipper");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }else if(tab.equalsIgnoreCase("Recipient")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Recipient");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }

        String localClearValue = this.genericFuncObj.getLocalizedValue("Clear All");
        this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localClearValue)));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localClearValue)));


        for(String columns : columnOptions){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(columns);
            this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.submenuText, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.submenuText, levelLocalizationValue)));
        }

        String localApply = this.genericFuncObj.getLocalizedValue("Apply");
        this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localApply)));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localApply)));

     }

    public void selectColumnOptionsBasedOnSearch(String tab, DataTable table){
        List<String> columnOptions = table.asList(String.class);
        String element = this.findElement(this.shipmentOverviewPage.columnChevron).getAttribute("class");
        if (!element.contains("active"))
            this.JavaScriptClick(this.shipmentOverviewPage.columnChevron);

        if(tab.equalsIgnoreCase("Shipment")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Shipment");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }else if(tab.equalsIgnoreCase("Shipper")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Shipper");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }else if(tab.equalsIgnoreCase("Recipient")){
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue("Recipient");
            this.waitUntilVisible(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format("//ul[@role='tablist' and @class='sr-tabs__nav']"+this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
        }

        String localClearValue = this.genericFuncObj.getLocalizedValue("Clear All");
        this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localClearValue)));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localClearValue)));

        for (String columns : columnOptions) {
            String levelLocalizationValue = columns;
            this.enterText(By.xpath("//input[@placeholder='Search for Columns']"),columns);
            this.waitUntilNotVisible(this.loadingIndicator);
            this.clickOnElement(By.xpath("//ul[@class='sr-legacy-search-list__colfilter']//li[1]"));
            this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.SubmenuOption, levelLocalizationValue)));
            this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.SubmenuOption, levelLocalizationValue)));
        }

        String localApply = this.genericFuncObj.getLocalizedValue("Apply");
        this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localApply)));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, localApply)));

    }

     public void clickOnElementByTranslatedText(String value){
         if(value.contains(":")){
             String[] text = value.split(":");
             String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(text[0]);
             this.waitUntilVisible(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,text[1])));
             this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,text[1])));
         }else {
             String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(value);
             this.waitUntilVisible(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,"")));
             this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,"")));
         }
     }

    public void SelectFiltersinView(Map<String, String> filterTable) {
        this.JavaScriptClick(this.findElement(filterChevron));
        for (String viewName : filterTable.keySet()) {
            log.info("View Name: " + viewName);
            String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(viewName);
            if (this.elementIsNotDisplayed(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue)))) {
                this.ScrollIntoView(this.findElement(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue))));
            }
            this.waitUntilVisible(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue)));
            this.JavaScriptClick(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue)));
            String[] filters = filterTable.get(viewName).trim().split(",");
            for (String filter : filters) {
                log.info("Filter Name: " + filter);
                if(filter.contains(":")){
                    String[] text = filter.split(":");
                    String levelLocalizationValue2 = this.genericFuncObj.getLocalizedValue(text[0]);
                    if (this.elementIsNotDisplayed(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue2,text[1])))) {
                        this.ScrollIntoView(this.findElement(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue2,text[1]))));
                    }
                    this.waitUntilVisible(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue2,text[1])));
                    this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue2,text[1])));
                    String filterName = filter.split(":")[0].trim().replace(" ", "");
                    if (filterName.equalsIgnoreCase("Healthcare Identifier")) {
                        commonHelpers.thinkTimer(5000);
                    }
                }
                else {
                    String levelLocalizationValue2 = this.genericFuncObj.getLocalizedValue(filter);
                    if (this.elementIsNotDisplayed(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue2)))) {
                        this.ScrollIntoView(this.findElement(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue2))));
                    }
                    this.waitUntilVisible(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue2)));
                    this.JavaScriptClick(this.getByusingString(String.format(filterViewxpath, levelLocalizationValue2)));
                    String filterName = filter.split(":")[0].trim().replace(" ", "");
                    if (filterName.equalsIgnoreCase("Healthcare Identifier")) {
                        commonHelpers.thinkTimer(5000);
                    }
                }

            }
        }
    }

    public void selectFilterOptions(String filterOptions){
        SoftAssertions softly = new SoftAssertions();
//        List<String> filterData = table.asList(String.class);
        String[] levels = filterOptions.split("-");
        String element = this.findElement(this.shipmentOverviewPage.filterChevron).getAttribute("class");
        if (!element.contains("active"))
            this.JavaScriptClick(this.shipmentOverviewPage.filterChevron);// Click on Filter

        for(String level : levels){
            if(level.contains(":")){
                String[] text = level.split(":");
                String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(text[0]);
                this.waitUntilVisible(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,text[1])));
                this.JavaScriptClick(this.getByusingString(this.buildGenericXpathForString(levelLocalizationValue,text[1])));
            }else {
                String levelLocalizationValue = this.genericFuncObj.getLocalizedValue(level);
                this.waitUntilVisible(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
                this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.containsPlaceHolder, levelLocalizationValue)));
            }
        }

//        this.clickOnElement(By.xpath(String.format(filterCategory, level1)));
//        this.clickOnElement(By.xpath(String.format(filterCategory, level2)));
//        String level1LocalizationValue = this.genericFuncObj.getLocalizedValue(levels[0]);
//        String level2LocalizationValue = this.genericFuncObj.getLocalizedValue(levels[1]);

//        this.shipmentOverviewPage.SelectFilterOptions(level1LocalizationValue,level2LocalizationValue);

//        for (String option : filterData) {
//            String getLocalizedValue = this.genericFuncObj.getLocalizedValue(option);
//            this.Mouse_MoveToElement( this.getByusingString(String.format("//ul[@class='sr-multinav-subchild date-time-box']"+this.shipmentOverviewPage.containsPlaceHolder, getLocalizedValue)));
//
//            softly.assertThat(this.elementIsDisplayed(
//                    this.getByusingString(String.format("//ul[@class='sr-multinav-subchild date-time-box']"+this.shipmentOverviewPage.containsPlaceHolder, getLocalizedValue)))).isTrue();
//        }
//        softly.assertAll();
    }

    public void selectFilterOptionValues(DataTable table){
        List<String> filterValuesOptions = table.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        for (String option : filterValuesOptions) {
            String getLocalizedValue = this.genericFuncObj.getLocalizedValue(option);
            this.Mouse_MoveToElement( this.getByusingString(String.format(this.shipmentOverviewPage.containsPlaceHolder, getLocalizedValue)));
            softly.assertThat(this.elementIsDisplayed(
                    this.getByusingString(String.format(this.shipmentOverviewPage.containsPlaceHolder, getLocalizedValue)))).isTrue();
        }
        softly.assertAll();
    }




}
