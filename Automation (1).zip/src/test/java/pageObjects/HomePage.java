package pageObjects;

import API.ResponseModels.Shipments;
import common.CommonHelpers;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * HomePage is POM for Surround Landing Page
 */

@Slf4j
public class HomePage extends SeleniumGenericFunction {
    public static boolean whiteScreenFlag = true;
    public CommonHelpers commonHelpers;
    public LoginPage loginPage;
    public GenericFunction genericFuncObj;

    public By languageSelector = By.id("SHFLanguageDropdownID");
    public By registeredSymbol = By.xpath("//ul[@class='sr-breadcrumb']//a/sup");
    public By welcomeText = By.xpath("(//ul[@class='sr-dash-info']//div/p)[1]");
    public By currentSnapshotOftheDay = By.xpath("//ul[@class='sr-dash-info']//p[@class='sr-dash-text p-t-8']");
    public By viewOnDashboard = By.xpath("(//div[@class='sr-tile']//a)[1]");
    public By shippedInLastWeek = By.xpath("(//div[@class='sr-tile']//div[@class='sr-tile-subtitle'])[1]");
    public By viewAccountSummary = By.xpath("(//div[@class='sr-tile']//a)[2]");
    public By deliveriesScheduledToday = By.xpath("(//div[@class='d-flex']//div[@class='sr-tile-title'])[2]");
    public By deliveriesScheduledTodayHelpText = By.xpath("(//div[@class='sr-tile']//div[@class='sr-tile-subtitle'])[2]");
    public By viewInMyShipments = By.xpath("(//div[@class='sr-tile']//a)[3]");
    public By blueTickIconDownloadCenter = By.xpath("//span[contains(@class,'download-center-notifiction-icn')]");
    public By alertIcon = By.xpath("//*[@class='sr-header__acn-item alert-icn']");
    public By lastUpdatedAt = By.xpath(".//*[contains(text(),' Updated at ')]//parent::p//span");
    public By fedExLogo = By.xpath("//*[contains(@alt,'FedEx Logo')]");
    public By searchIcon = By.xpath(".//img[@alt='Search']");
    public By printingServices = By
            .xpath(".//span[contains(text(),'Printing Services')] | .//span[contains(text(),'Design & Print')]");
    public String carouselxpath = ".//app-carousel//li[%s]/a";

    public String numbersOnOverviewRightSide = "(//div[@class='sr-tile']/div[@class='sr-tile-val'])[%s]";

    public By shipmentsInProgress = By.xpath("(//div[@class='d-flex']//div)[2]");

    public String ShipmentsCountHomePage = "(.//*[contains(text(),\"%s\")])[1]//parent::div//*[@class='sr-tile-val']";
    public String staticTextxpath = "(.//*[contains(text(),\"%s\")])[1]//parent::div//*[@class='sr-tile-subtitle']";
    public String countOfShipments = ".//*[contains(text(),\"%s\")]//parent::div//div[@class='sr-card-val']";
    public By logOutLink = By.xpath(".//*[contains(@data-analytics,'SIGN OUT')]");
    public By CElogout = By.xpath("//u[contains(text(),'Sign Out')]");
    public By rightChevron = By.xpath(".//*[@class='sr-innernav-icn chevron-right']");
    public By homePagecarousel = By.xpath("//*[@class='sr-dash--caro']");
    public By stateOfSubNav = By.xpath("(.//app-sidenav//div)[2]");
    public By allShipmentCount = By
            .xpath("//div[contains(text(),'SHIPMENTS IN PROGRESS')]//preceding::div[@class='sr-tile-val']");
    public By globalImgIcon = By.xpath(this.buildXpathForClass("caas-icon caas-icon"));
    public By languageDrpDwn = By.xpath(".//button[contains(@id,'dropdown')]");
    public String languageDrpDwnValue = ".//a[contains(text(), \"%s\")]";
    public By contry = By.xpath("//*[contains(@class,'language_dropdown')]//div[contains(@class,'icon_link')]");
    public String dateLocator = "//div[contains(@class,'date')]";
    public String menu = "//span[contains(text(),\"%s\")]";
    public String advisorySubMenu = "//a[contains(@href,'/advisories')]/span[text()=\"%s\"]";
    public String CEmenu = "(.//span[contains(text(),\"%s\")])[2]";

    public String leftSideMenuOption = "//a[@class='sr-aside__list-item']//span[text()=\"%s\"]";
    public String SubmenuModulesXpath = ".//*[contains(text(),\"%s\")]//parent::a//*[contains(@class,'toggle-icn')]";
    public String SubmenuModulesExpandedXpath = "//*[contains(text(),\"%s\")]//parent::a//*[contains(@class,'toggle-icn up')]";
    public String fedexBrdCrmb = ".//app-breadcrumb//a[contains(text(), 'FedEx')]";
    public String fedexMenuBrdCrmb = ".//app-breadcrumb//a[contains(text(), \"%s\")]";
    public String menuHighlight = "//span[contains(text(),\"%s\")]//ancestor::a";
    public String companyNameLoc = "//*[contains(text(), \"%s\")]";
    public String rightChevronXpath = "//*[contains(text(),\"%s\")]//parent::div//a";
    public String overviewPageLink = "//*[contains(text(),\"%s\")]//ancestor::li//a";
    public String rightChevronDisabled = "//*[contains(text(),\"%s\")]//parent::div//a[@class='sr-tile-acn chevron-right-wt cursor-none']";
    public String allShipmentCountXpath = "//*[contains(text(),\"%s\")]//parent::div//*[contains(@class, 'sr-tile-val')]";
    public String verifySubMenu = ".//ul/li/a//span[text()=\"%s\"]";
    public String verifyColumnValue = ".//div//span[text()=\"%s\"]";
    public By SearchXpath = By.xpath(".//*[@type='search']");
    public String externalLinkXpath = ".//*[@class='sr-aside__list']//*[contains(text(),\"%s\")]//parent::a";
    public By whatsNewMenuText = By.xpath("//span[normalize-space()=\"What's New\"]");
    public By whatsNewMenu = By.xpath("//span[normalize-space()=\"What's New\"]//ancestor::li");
    //public String whatsNewLink = "//span[normalize-space()=\"%s\"]//parent::a";
    public String menuOptionCollapseLink = "//span[contains(text(),\"%s\")]/ancestor::li//span[@class='sr-aside__list-item-toggle toggle-icn']";
    public By whatsNewPopupModal = By
            .xpath("//app-dashboard//div[@class='fdx-c-modal__main fdx-c-modal__main--large']");
    public By whatsNewPopupTitle = By.xpath("//app-dashboard//div[contains(@class,'sr-modal__title')]");
    public By whatsNewPopupSubTitle = By.xpath("//app-dashboard//div[contains(@class,'sr-modal__sub-title')]");
    public By whatsNewPopupViewButton = By
            .xpath("//app-dashboard//button[@type='button'][normalize-space()='View whats new']");
    public By whatsNewPopupCloseButton = By
            .xpath("//app-dashboard//span[@class='fdx-c-button__title'][normalize-space()='Close']");
    public By whatsNewPopupCloseIcon = By.xpath("//app-dashboard//div[@class='close-icn']");
    public String leftMenuIconsAndActiveState = "//ul/li/a/*[contains(@class,\"%s\")]";
    public String leftMenuIconsAndDisabledState = "//ul/li/a/em[contains(@class,\"%s\")]";
    public By role = By.xpath("//*[@class='m-t-1']");
    /**
     * WebElement with there finding property
     */


    String topNavigation = "//ul[@class='sr-breadcrumb']//a[text()=\"%s\"]";
    public HomePage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.loginPage = new LoginPage(this.commonHelpers);
        this.genericFuncObj = new GenericFunction();
    }

    /**
     * Verify Side Menu Visibility
     *
     * @param menuOption
     */
    public void verifySideMenuVisibility(String menuOption) {
        //if (Constants.SubMenuModules.contains(menuOption)) {
        // this.waitUntilVisible(By.xpath(String.format(CEmenu, menuOption)));
        if (this.elementIsNotDisplayed(By.xpath(String.format(SubmenuModulesExpandedXpath, menuOption)))) {
            this.JavaScriptClick(By.xpath(String.format(SubmenuModulesXpath, menuOption)));
        }
    }

    public Boolean IsSideMenuVisibility(String menuOption) {
        if (Constants.SubMenuModules.contains(menuOption)) {
            // this.waitUntilVisible(By.xpath(String.format(CEmenu, menuOption)));
            return this.elementIsDisplayed(By.xpath(String.format(SubmenuModulesXpath, menuOption)));
        } else {
            return this.elementIsDisplayed(By.xpath(String.format(menu, menuOption)));
        }
    }


    /**
     * Check for Persistent Header
     *
     * @param menuOption
     * @return WebElement
     */
    public WebElement verifyPersitentHeader(String menuOption) {
        return menuOption.contains("FedEx® Surround") || menuOption.contains("FedEx(MD) Surround") ? this.findElement(By.xpath(fedexBrdCrmb))
                : this.findElement(By.xpath(String.format(fedexMenuBrdCrmb, menuOption)));
    }

    /**
     * @param menuOption
     * @return
     */
    public boolean verifyMenuHighlight(String menuOption) {
        this.waitUntilNotVisible(this.loadingIndicator);
        String highLight = this.findElement(By.xpath(String.format(menuHighlight, menuOption))).getAttribute("class");
        return highLight.contains("active");
    }

    /**
     * @return true / false based on status of sub-nav options
     */
    public boolean expandSubNavigation() {
        try {
            String status = this.findElement(stateOfSubNav).getAttribute("class");
            return status.split("--")[1].equalsIgnoreCase("expanded");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * @return true if rightChevron is displayed
     */
    public boolean VerifyChevronisDisplayed() {
        return this.elementIsDisplayed(rightChevron);
        // return
        // this.elementIsDisplayed(this.getByusingString(String.format(rightChevronXpath,
        // linkName)));
    }

    public Boolean ValidateExternalLinks(String link) {
//        if (link.contains("What's New")) {
//            return this.findElement(String.format(whatsNewLink,link)).getAttribute("href").replace("%20", "")
//                    .equalsIgnoreCase(Constants.ExternalLinks.get(link).replace(" ", ""));
//        } else {
        String url = "";
        if (GenericFunction.locale != Constants.EN_US) {
            url = Constants.ExternalLinks.get(link).replace(" ", "").replace(Constants.EN_US, GenericFunction.locale);
            link = this.genericFunctionObject.getLocalizedValue(link);
        }
        Assertions.assertThat(this.findElement(By.xpath(String.format(this.externalLinkXpath, link))).getAttribute("href")
                .replace("%20", "")).isEqualToIgnoringCase(url.replace(" ", ""));
        return true;
        //}
    }

    public Boolean VerifyLinkNavigation(String link) {
        // this.JavaScriptClick(By.xpath(String.format(this.externalLinkXpath, link)));
        return this.GetWindowHandles().size() > 1;
    }

    /**
     * @return true if rightChevron is displayed
     */
    public boolean VerifyChevronisDisplayedWhenDiabled(String linkName) {
        // return this.elementIsDisplayed(rightChevron);
        return this.elementIsDisplayed(this.getByusingString(String.format(rightChevronXpath, linkName)));
    }

    public boolean VerifyChevronisDisabled(String linkaname) {
        return this.elementIsDisplayed(this.getByusingString(String.format(rightChevronDisabled, linkaname)));
    }

    /**
     * Click
     */
    public void ClickChevron() {
        this.clickOnElement(rightChevron);
    }

    /**
     * Verify Date with SysDate
     *
     * @return true false
     */
    public void VerifyDateWithSysDate() {
        this.waitUntilVisible(lastUpdatedAt);
        this.waitUntilNotVisible(loadingIndicator);
        String actualTime = this.getText(lastUpdatedAt);
        String expectedTime = this.getDateinFormat("hh:mm aa, M/d/y z"); // Since we have set the time format via API before this step
        log.info("Expected Time is "+expectedTime);
        Assertions.assertThat(actualTime)
                .isEqualTo(expectedTime);
    }

    /**
     * Verify Current Date
     *
     * @return boolean
     */
    public boolean VerifyCurrentDate() {
        String pattern = "EEEEE, MMMMM dd yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String expectedDate = simpleDateFormat.format(new Date());
        String actualDate = this.getText(By.xpath(dateLocator));
        actualDate = actualDate.replaceAll("\\n", " ");
        return actualDate.equalsIgnoreCase(expectedDate);
    }

    /**
     * @param index
     * @param title
     * @return
     */
    public boolean navigateAndValidateCarosel(String index, String title) {
        String xpath = String.format(carouselxpath, index.equalsIgnoreCase("second") ? "2" : "1");
        this.clickOnElement(this.getByusingString(xpath));
        return this.elementIsDisplayed(By.xpath(buildXpathForString(title)));
    }

    /**
     * @param count
     * @param subModule
     * @return
     */
    public boolean validatecountOfShipments(String count, String subModule) {
        String xpath = String.format(countOfShipments, subModule);
        return Integer.parseInt(count) == Integer.parseInt(this.getText(By.xpath(xpath)));
    }

    /**
     * @param title
     * @param subModule
     * @return
     */
    public boolean ValidateStatictextInModule(String title, String subModule) {
        String expectedStaticText;
        String staticpath = String.format(staticTextxpath, subModule);
        String actualStatictext = this.getText(this.getByusingString(staticpath));
        if (subModule.equalsIgnoreCase("Deliveries Scheduled Today")) {
            expectedStaticText = Constants.PlannedDeliveriesText;
        } else if (subModule.equalsIgnoreCase("Upcoming Deliveries")) {
            expectedStaticText = Constants.PlannedNextFewDaysText;
        } else {
            expectedStaticText = Constants.SOPINTERVENED;
        }
        return expectedStaticText.trim().equalsIgnoreCase(actualStatictext.trim());
    }

    /**
     * Logout from Surround
     */
    public void logOut() {
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("Shipper")
                || this.commonHelpers.getValuefromContextStore("UserContext").toString().toLowerCase()
                .contains("user")) {
            //this.clickOnElement(loginLinksurround);
            this.clickOnElement(loginIconSurround);
            this.clickOnElement(logOutLink);
        } else {
            this.clickOnElement(CElogout);
        }
        //boolean flag = this.elementIsDisplayed(this.CEsignOutLink);
        this.commonHelpers.thinkTimer(5000);
    }

    /**
     * Validate Header Element
     *
     * @param table
     * @return
     */
    public boolean ValidateHeaderElements(DataTable table) {
        boolean flag = true;
        try {
            this.commonHelpers.thinkTimer(2000);
            boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                this.loginPage.WaitForStressPage();
            }
            List<String> headerElements = table.asList(String.class);
            for (String header : headerElements) {
                if (flag) {
                    if (header.equalsIgnoreCase("FedEx logo")) {
                        flag = this.elementIsDisplayed(fedExLogo);
                    } else if (header.equalsIgnoreCase("Search icon")) {
                        flag = this.elementIsDisplayed(searchIcon);
                    } else if (header.equalsIgnoreCase("Printing services/Design & Print")) {
                        flag = this.elementIsDisplayed(printingServices);
                    } else if (header.equalsIgnoreCase("role")) {
                        flag = this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(Constants.IRDisplayName)));
                    } else {
                        header = header.contains("ContextStore-")
                                ? this.commonHelpers.getValuefromContextStore(header).toString()
                                : header;
                        String xpath = ".//span[contains(text(),\"" + header + "\")]";
                        flag = this.elementIsDisplayed(this.getByusingString(xpath));
                    }
                } else
                    break;
            }
        } catch (Exception ex) {
            flag = false;
            log.error("**EXCEPTION** Something went wrong in validation of ValidateHeaderElements" + ex.getMessage());
        }

        return flag;
    }

    /**
     * Validate Header Element
     *
     * @param table
     * @return
     */
    public boolean ValidateFooterElements(DataTable table) {
        this.ScrollToBottom();
        boolean flag = true;
        try {
            List<String> footerElements = table.asList(String.class);
            for (String footer : footerElements) {
                if (flag) {
                    String xpath = this.buildXpathForString(footer);
                    flag = this.elementIsDisplayed(this.getByusingString(xpath));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error(" **EXCEPTION** Something went wrong in validation of ValidateFooterElements" + ex.getMessage());
        }
        return flag;
    }

    /**
     * Validate Header Element
     *
     * @return
     */
    public boolean ValidateSocialIcon(DataTable table) {
        boolean flag = true;
        try {
            List<String> socialIcons = table.asList(String.class);
            for (String icon : socialIcons) {
                if (flag) {
                    flag = this.elementIsDisplayed(By.xpath(buildXpathForHref(icon)));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error("**EXCEPTION** Something went wrong in validation of ValidateSocialIcon" + ex.getMessage());
        }
        return flag;
    }

    /**
     * @return
     */
    public boolean VerifyHomePageCarouselIsVisible() {
        if (this.elementIsDisplayed(this.loadingIndicator)) {
            this.waitUntilNotVisible(this.loadingIndicator);
        }
        this.elementIsDisplayed(homePagecarousel);
        return this.elementIsDisplayed(By.xpath(buildXpathForString("All Shipments")));
    }

    /**
     * @param companyName
     * @return
     */
    public boolean VerifyCompanyNameIsVisible(String companyName) {
        return this.elementIsDisplayed(By.xpath(String.format(companyNameLoc, companyName)));
    }

    /**
     * This method selects a company in CE
     *
     * @param companyName
     */
    public void SelectCompanyNameinCE(String companyName) {
        this.clickOnElement(By.xpath(String.format(companyNameLoc, companyName)));
    }

    /**
     * @param shipments
     * @param attribute
     * @return
     */
    public boolean ValidateAPIwithUIforShipments(Shipments shipments, String attribute) {
        boolean flag = false;
        int actualCount = 0;
        int expCount = 0;
        switch (attribute.split("-")[0]) {
            case "SHIPMENTS IN PROGRESS":
                actualCount = Integer.parseInt(this
                        .getText(this.getByusingString(String.format(ShipmentsCountHomePage, attribute)))
                        .replace(",", ""));
                expCount = shipments.getAllShipment();
                flag = (expCount == actualCount);
                break;
            case "MONITORED":
                attribute = attribute.split("-")[1];
                actualCount = Integer.parseInt(this
                        .getText(this.getByusingString(String.format(ShipmentsCountHomePage, attribute)))
                        .replace(",", ""));
                switch (attribute) {
                    case "Deliveries Scheduled Today":
                        expCount = shipments.getMonitoredShipment().getPlannedDeliveries();
                        break;
                    case "Upcoming Deliveries":
                        expCount = shipments.getMonitoredShipment().getPlannedDeliveriesNextFewDays();
                        break;
                    case "Intervened Shipments":
                        expCount = shipments.getMonitoredShipment().getSopIntervened();
                        break;
                }
                flag = (expCount == actualCount);
                break;
        }
        return flag;
    }

    /**
     * @param count
     * @return
     */
    public boolean VerifyAllShipmentCount(String count) {
        String actualCount = this.findElement(allShipmentCount).getText();
        return actualCount.equalsIgnoreCase(count);
    }

    public boolean ValidateLanguageDropdown(DataTable table) {
        List<Boolean> flag = new ArrayList<>();
        flag.add(this.elementIsDisplayed(languageDrpDwn));
        this.clickOnElement(languageDrpDwn);
        List<String> languages = table.asList(String.class);
        for (String language : languages) {
            language = String.format(languageDrpDwnValue, language);
            flag.add(this.elementIsDisplayed(By.xpath(language)));
        }
        return !flag.contains(false);
    }

    /**
     * Get the Viewing Count for given Monitored Shipments ex:Deliveries Scheduled
     * Today
     *
     * @return String value
     */
    public String ValidateMonitoredShipmentsLinksCount(String linkName) {
        String actualCount = this.getText(this.getByusingString(String.format(allShipmentCountXpath, linkName)));
        if (Integer.parseInt(actualCount.replace(",", "")) > 0) {
            this.clickOnElement(this.getByusingString(String.format(rightChevronXpath, linkName)));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
        return actualCount;
    }

    public boolean CompareCountonPageandViewing(String pageCount, String viewingCount) {
        return pageCount.equals(viewingCount);
    }

    /**
     * Clicks specified chevron on overview page
     *
     * @param chevron
     */
    public void ClickSpecifiedChevron(String chevron) {

        if (chevron.equalsIgnoreCase("Deliveries Scheduled Today")) {
            this.clickOnElement(this.getByusingString(String.format(overviewPageLink, chevron)));
        } else
            this.clickOnElement(this.getByusingString(String.format(rightChevronXpath, chevron)));
    }

    /**
     * @return true if "Search" is not present in Dashboard page False if "Search"
     * false if "Search" is present in Dashboard page
     */
    public boolean VerifySearchisDisplayed() {
        return this.elementIsDisplayed(SearchXpath);
    }

    /**
     * Gets the shipment count for specified chevron on overview page
     *
     * @param chevron
     */
    public String getMonitoredShipmentCount(String chevron) {
        String count = this.getText(this.getByusingString(String.format(allShipmentCountXpath, chevron)));
        return count;
    }

    public boolean ValidateIfMonitoredShipmentCountZero(String chevron) {
        int count = Integer.parseInt(getMonitoredShipmentCount(chevron).replaceAll(",", ""));

        boolean isDisabledActual = this
                .elementIsDisplayed(this.getByusingString(String.format(rightChevronDisabled, chevron)));
        boolean isDisabledExpected = count == 0;

        Assert.assertEquals(chevron + " chevron is enabled/disabled when count is: " + count,
                isDisabledActual, isDisabledExpected);

        return isDisabledActual;
    }

    /**
     * Verifies the sub menu nav
     *
     * @return boolean
     */
    public boolean verifySubMenu(String subMenu) {
        return this.elementIsDisplayed(getByusingString(String.format(verifySubMenu, subMenu)));
    }

    /**
     * @param menuOption
     * @return returns the flag
     */
    public boolean VerifyWhatsNewHighlight(String menuOption) {
        this.waitUntilNotVisible(this.loadingIndicator);
        List<Boolean> filterflags = new ArrayList<>();

        String timeStampFromApi = this.commonHelpers.getValuefromContextStore("dateOfDeploymentUnixTimeStampInSeconds")
                .toString();
        LocalDate deploymentDate = Instant.ofEpochSecond(Long.parseLong(timeStampFromApi))
                .atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();
        long diff = ChronoUnit.DAYS.between(deploymentDate, today);
        long daysToHighlightWhatsNew = Long
                .parseLong(this.commonHelpers.getValuefromContextStore("daysToHighlightWhatsNew").toString());

        boolean showWhatsNew = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("showWhatsNew").toString());
        if (showWhatsNew && diff <= daysToHighlightWhatsNew) {
            // What's New text color
            String color = this.findElement(whatsNewMenuText).getCssValue("color");
            String hexaColor = Color.fromString(color).asHex();
            filterflags.add(hexaColor.equalsIgnoreCase("#008a00"));

            // What's New background highlight
            String backGroundColor = Color.fromString(this.findElement(whatsNewMenu).getCssValue("background-color"))
                    .asHex();
            filterflags.add(backGroundColor.equalsIgnoreCase("#000000"));

            // What's New background highlight when do mouse hover
            this.Mouse_MoveToElement(this.findElement(whatsNewMenu));
            backGroundColor = Color.fromString(this.findElement(whatsNewMenu).getCssValue("background-color")).asHex();
            filterflags.add(backGroundColor.equalsIgnoreCase("#000000"));
        } else {
            String color = this.findElement(whatsNewMenuText).getCssValue("color");
            String hexaColor = Color.fromString(color).asHex();
            filterflags.add(!hexaColor.equalsIgnoreCase("#008a00"));

            // What's New background highlight
            String backGroundColor = Color.fromString(this.findElement(whatsNewMenu).getCssValue("background-color"))
                    .asHex();
            filterflags.add(!backGroundColor.equalsIgnoreCase("#328832"));

            // What's New background highlight when do mouse hover
            this.Mouse_MoveToElement(this.findElement(whatsNewMenu));
            backGroundColor = Color.fromString(this.findElement(whatsNewMenu).getCssValue("background-color")).asHex();
            filterflags.add(!backGroundColor.equalsIgnoreCase("#f2f2f2"));
        }
        return !filterflags.contains(false);
    }

    /*
     * Verify Side Menu Visibility
     *
     * @param menuOption
     *
     * @return WebElement
     */

    public void navigateToDefaultSubMenu(String menuOption) {
        //if (Constants.SubMenuModules.contains(menuOption)) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if(this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase(
                "CE"))
        {
            this.waitUntilVisible(By.xpath(String.format(CEmenu, menuOption)));
        }
        if (menuOption.equalsIgnoreCase(Constants.Nav_Advisories)) {
            this.JavaScriptClick(By.xpath(String.format(advisorySubMenu, Constants.Nav_SubMenu_Shipments)));
        } else if (menuOption.equalsIgnoreCase(Constants.Nav_Sustainability)) {
            this.clickOnElement(By.xpath(String.format(menu, Constants.Nav_SubMenu_Sustainability)));
        } else if (menuOption.equalsIgnoreCase(Constants.Nav_Preferences)
                || menuOption.equalsIgnoreCase(Constants.Nav_CE_Preferences)) {
            this.clickOnElement(By.xpath(String.format(menu, Constants.Nav_SubMenu_Settings)));
        } else if (menuOption.equalsIgnoreCase(Constants.Nav_Dashboard)) {
            this.clickOnElement(By.xpath(String.format(menu, Constants.Nav_SubMenu_ActiveShipments)));
        }
        this.waitUntilVisible(this.loadingIndicator);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToTop();
        //}
        // Workaround for white screen visibility (It displays for one time for every
        // login while navigating to any menu after login)
        if (whiteScreenFlag) {
            this.commonHelpers.thinkTimer(3000);
            whiteScreenFlag = false;
        }
    }

    /*
     * Verify What's New Popup
     *
     * @param menuOption
     *
     * @return WebElement
     */
    public Boolean VerifyWhatsNewPopup() {
        this.waitUntilNotVisible(this.loadingIndicator);
        List<Boolean> filterflags = new ArrayList<>();

        String releaseForWhatsNew = this.commonHelpers.getValuefromContextStore("releaseForWhatsNew").toString();
        String releaseVersion = this.commonHelpers.getValuefromContextStore("releaseVersion").toString();
        String timeStampFromApi = this.commonHelpers.getValuefromContextStore("dateOfDeploymentUnixTimeStampInSeconds")
                .toString();

        LocalDate deploymentDate = Instant.ofEpochSecond(Long.parseLong(timeStampFromApi))
                .atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate today = LocalDate.now();
        long diff = ChronoUnit.DAYS.between(deploymentDate, today);
        long daysToHighlightWhatsNew = Long
                .parseLong(this.commonHelpers.getValuefromContextStore("daysToHighlightWhatsNew").toString());

        boolean showWhatsNew = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("showWhatsNew").toString());
        if (showWhatsNew && diff <= daysToHighlightWhatsNew) {
            if (releaseForWhatsNew.equals(releaseVersion)) {
                filterflags.add(this.elementIsNotDisplayed(whatsNewPopupTitle));
            } else {
                this.waitUntilVisible(this.whatsNewPopupModal);
                if (this.elementIsDisplayed(whatsNewPopupModal)) {
                    filterflags.add(this.elementIsDisplayed(whatsNewPopupTitle));
                    filterflags.add(this.findElement(whatsNewPopupTitle).getText().equals(Constants.WhatsNew_Title));
                    filterflags.add(this.elementIsDisplayed(whatsNewPopupSubTitle));
                    filterflags.add(
                            this.findElement(whatsNewPopupSubTitle).getText().equals(Constants.WhatsNew_Sub_Title));
                    filterflags.add(this.elementIsDisplayed(whatsNewPopupViewButton));
                    filterflags.add(
                            this.findElement(whatsNewPopupViewButton).getText().equals(Constants.WhatsNew_View_Button));
                    filterflags.add(this.elementIsDisplayed(whatsNewPopupCloseButton));
                    filterflags.add(this.findElement(whatsNewPopupCloseButton).getText()
                            .equals(Constants.WhatsNew_Close_Button));
                    filterflags.add(this.elementIsDisplayed(whatsNewPopupCloseIcon));
                    this.clickOnElement(whatsNewPopupCloseIcon);
                } else {
                    filterflags.add(false);
                }
            }
        }
        return !filterflags.contains(false);
    }

    public boolean verifyColumnValue(String ColumnValue) {
        return this.elementIsDisplayed(getByusingString(String.format(verifyColumnValue, ColumnValue)));
    }

    public boolean verifyColumnsAreDisplayed(DataTable columnTable) {
        boolean flag = true;
        try {
            List<String> columnNames = columnTable.asList(String.class);
            for (String columnName : columnNames) {
                if (flag) {
                    flag = this.elementIsDisplayed(getByusingString(String.format(verifyColumnValue, columnName)));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error("**EXCEPTION** Something went wrong in validation of column display" + ex.getMessage());
        }
        return flag;
    }

    public boolean verifySideMenuIconsAndActiveState(DataTable table) {
        Map<String, String> menus = table.asMap(String.class, String.class);
        boolean flag = false;
        HashSet<Boolean> flags = new HashSet<>();
        String xpath = "";
        this.commonHelpers.thinkTimer(5000);
        for (String menu : menus.keySet()) {
            switch (menu) {
                case "CE Dashboard":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "ce-dashboard-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "ce-dashboard-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Overview":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "overview-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "overview-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Dashboard":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "toggle-icn up";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "toggle-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Advisories":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "advisory-icn";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "advisory-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "My Shipments":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "shipment-icn";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "shipment-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Download Center":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "download-center-icn";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "download-center-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Sustainability":
                    boolean sustainabilityFeatureEnabled = (boolean) this.commonHelpers.getValuefromContextStore("sustainabilityFeatureEnabled");
                    if (!sustainabilityFeatureEnabled) {
                        flag=true;
                        log.info(" **INFORMATION** Sustainability flag is off. hence avoiding the validation for the same. It will not appear on left side");
                    }

                else if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "sustainability-icn";
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                                true);

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "sustainability-icn";
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                                true);
                    }

                    break;
                case "Product Center":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "product-icn";

                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Preferences":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "toggle-icn up";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "settings-icn sr-aside__list-item-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "CE Preferences":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "ce-preferences-icn sr-aside__list-item-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "ce-preferences-icn sr-aside__list-item-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Training Videos":
                    xpath = "training-videos-icn";
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                                true);
                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndDisabledState, xpath)),
                                true);
                    }
                    break;
                case "Whats New":
                    xpath = "whats-new-icn";
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                                true);

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {

                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndDisabledState, xpath)),
                                true);
                    }
                    break;
                case "Quick Help":
                    xpath = "help-icn";
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                                true);

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {

                        flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndDisabledState, xpath)),
                                true);
                    }

                    break;
                case "Contact Us":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "contactus-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "contactus-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Surround Terms":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "terms-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "terms-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                case "Management Center":
                    if (menus.get(menu).equalsIgnoreCase("Active")) {
                        xpath = "management-icn active";

                    } else if (menus.get(menu).equalsIgnoreCase("Inactive")) {
                        xpath = "management-icn";
                    }
                    flag = this.elementIsDisplayed(By.xpath(String.format(this.leftMenuIconsAndActiveState, xpath)),
                            true);
                    break;
                default:
                    Assert.fail("You have passed an option which does not exist. \n Add in code or correct in tests --> " + menu);
            }
            log.info("Menu: " + menu + " > State: " + menus.get(menu) + " : " + flag);
            flags.add(flag);
        }
        return !flags.contains(false);
    }

    public void validateHomePageDataTranslation(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Welcome,":
                    softly.assertThat(this.getText(this.welcomeText) + " ").isEqualTo(localisedValue);
                    break;
                case "Here is your current snapshot for the day":
                    softly.assertThat(this.getText(this.currentSnapshotOftheDay)).isEqualTo(localisedValue);
                    break;
                case "SHIPMENTS IN PROGRESS":
                    softly.assertThat(this.getText(this.shipmentsInProgress)).isEqualTo(localisedValue);
                    break;
                case "View on Dashboard":
                    softly.assertThat(this.getText(this.viewOnDashboard)).isEqualTo(localisedValue);
                    break;
                case "of your shipments shipped in the last week have been delivered":
                    softly.assertThat(this.getText(this.shippedInLastWeek)).isEqualTo(localisedValue);
                    break;
                case "View Account Summary":
                    softly.assertThat(this.getText(this.viewAccountSummary)).isEqualTo(localisedValue);
                    break;
                case "Deliveries Scheduled Today":
                    softly.assertThat(this.getText(this.deliveriesScheduledToday) + " ").isEqualToIgnoringCase(localisedValue);
                    break;
                case "These shipments are expected to arrive today":
                    softly.assertThat(this.getText(this.deliveriesScheduledTodayHelpText)).isEqualTo(localisedValue);
                    break;
                case "View in My Shipments":
                    softly.assertThat(this.getText(this.viewInMyShipments)).isEqualTo(localisedValue);
                    break;
                case "Overview":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.topNavigation, localisedValue)))).isTrue();
                    break;
                case "FedEx":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.topNavigation, localisedValue)))).isTrue();
                    break;
                case "copyrightSymbol":
                    softly.assertThat(this.getText(this.registeredSymbol)).isEqualTo(localisedValue);
                    break;
                case "Surround":
                    // As there is a space that comes before Surround
                    localisedValue = " " + localisedValue;
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.topNavigation, localisedValue)))).isTrue();
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public boolean ValidateLeftSideMenuVisibility(String option, String state) {
        return state=="visible"?this.elementIsDisplayed(this.getByusingString(String.format(this.leftSideMenuOption,option))):
                this.elementIsNotDisplayed(this.getByusingString(String.format(this.leftSideMenuOption,option)));

    }

    // it can give the number of shipments for Shipments in Progress
    // Can be exteneded for % and Deliveres scheduled Today
    public int getNumberFromPurpleBarHomePage(String option) {
        int count=0;
        if(option.equalsIgnoreCase("Shipments in Progress"))
            // removing the commas from the number and spaces if any
            count=Integer.parseInt(this.getText(this.getByusingString(String.format(this.numbersOnOverviewRightSide,1))).replace(",","").replace(" ",""));
        return count;
    }

    public boolean ValidateFooterElementsForLocalization(DataTable table) {
        this.ScrollToBottom();
        String lang  = GenericFunction.ReadConfigFile("LANG");
        boolean flag = true;
        try {
            List<String> footerElements = table.asList(String.class);
            for (String footer : footerElements) {
                if (flag) {
                    if(!lang.equalsIgnoreCase("en-us")){
                        footer=this.genericFuncObj.getLocalizedValue(footer);
                    }
                    String xpath = this.buildXpathForString(footer);
                    flag = this.elementIsDisplayed(this.getByusingString(xpath));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error(" **EXCEPTION** Something went wrong in validation of ValidateFooterElements" + ex.getMessage());
        }
        return flag;
    }
}
