package pageObjects;

import API.ResponseModels.*;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import stepDefinitions.TestAPI;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.*;


@Slf4j
public class ShipmentDetails extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;

    public By purplePanelTrackingNbrXpath = By
            .xpath("//div[@class='sr-caro-header']//div[@class='sr-caro-header-txt']");
    public String purplePanelSecondRowHeaders = ".//div[@class='sr-caro__panel active']//li[%s]//*[contains(@class,'sr-label sr-label--wt')]";
    public String purplePanelSecondRowData = "//div[contains(text(),\"%s\")]/following-sibling::div[contains(@class,'sr-data')]";

    public String purpleGenericXpath = "//div[@class='sr-caro']//div[contains(text(),\"%s\")]";
    public String shipmentDataContains = "(//label[contains(text(),\"%s\")]/following::div)[1]";
    public By purplePanelScheduledDeliveryEndofDay = By
            .xpath("//div[contains(text(),'SCHEDULED DELIVERY')]/parent::div//*[contains(text(),'by end of day')]");

    public String carouselNav = ".//*[contains(@class,'sr-caro-arrow--%s')]//div";
    public String labelHeader = ".//form//*[contains(text(),\"%s\")]";
    public String Labelsxpath = ".//div[contains(@class,'sr-form-wrapper')][%s]//label";
    public String tabName = ".//ul[@role='tablist']//span[contains(text(),\"%s\")]";
    public String myshipments_Filters_SecondLevelCategories=".//*[contains(text(),\"%s\")]// ancestor::*[contains(@class,'sr-multinav')]//*[@class='sr-multinav-child']// a";

    public String trackingId = "//*[contains(text(),'Tracking Number:')]";

    public String purpleBarTextAfterTrackingNumber = "//div[@class=\"sr-grid-8col d-flex\"]";

    public String siteMap = "//*[contains(text(),'Site Map')]";
    public By breadCrumbElement = By.xpath("//*[contains(@class,'sr-breadcrumb__item')]");
    public String scanMode = "//*[contains(text(),\"%s\")]";
    public By columnInScan = By.xpath("//div[@role='tabpanel']//following::li[@class='sr-list__item']");
    public String scanEventDate = "(.//div[@role='tabpanel']//*[@class='sr-list__item'])[%s]//*[@class='sr-grid-3col']";
    public String scanEventLocation = "(.//div[@role='tabpanel']//*[@class='sr-list__item'])[%s]//*[@class='sr-grid-2col'][1]";
    public String scanEventStatus = "(.//div[@role='tabpanel']//*[@class='sr-list__item'])[%s]//*[@class='sr-grid-2col'][2]";
    public String scanEventDetails = "(.//div[@role='tabpanel']//*[@class='sr-list__item'])[%s]//*[contains(@class,'sr-list-txt--lt')]";
    public String shipperLocation = "//li[@class='sr-list__item']//div[contains(text(),\"%s\")]/following-sibling::div[contains(@class,'sr-data')]";
    public String columnHeaderxpath = ".//span[contains(text(),\"%s\")]";
    public String tableHeaders = ".//*[@ref='eText' and contains(text(),\"%s\")]";
    public By xpieceShipmentsXpath = By.xpath(".//*[@class='sr-accordion-head__txt shipment-txt']");
    public By trackingNbrViewing = By
            .xpath("//div[@class=\"sr-accordion-head__txt sr-accordion-head__txt--br view-txt shipment-txt\"]");
    public String trackingNbrDelivered = "//div[@class=\"sr-accordion-head__txt bold-txt\" and contains(text(),\"%s\")]";
    public String inTransitExceptions = "//div[@class=\"sr-accordion-head__txt bold-txt\"]/span[contains(text(),\"%s\")]";
    public String viewingMPSXpath = ".//*[contains(text(),'Viewing %s')]";
    public String masterMPSIdXpath = ".//*[contains(text(),'%s (Master)')]";
    public String mpsTableXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//*[@aria-colindex=\"%s\"]";
    public By historyTab = By.xpath("//*[contains(text(),'History')]");
    public String historyTableXpath = "(//*[contains(text(),\"%s\")]//following::div[contains(text(),\"%s\")])[1]";
    public String sepHistoryTableXpath = "(.//app-ce-shipment-sep-history-grid//div[@col-id=\"%s\" and contains(text(),\"%s\")])[1]";
    public String sepHistoryCommentsTableXpath = "(.//app-ce-shipment-sep-history-grid//div[@col-id=\"%s\"]//*[contains(text(),\"%s\")])[1]";
    public By MPStableStatusXpath = By.xpath(".//*[contains(@class,'sr-accordion-panel-head--grey')]");
    public By collpaseExpandChevron = By.xpath(".//*[contains(text(),'Piece')]//parent::div//span");
    public String trackingIdxpath = ".//*[contains(text(),' Tracking Number: %s')]";
    public By backLink = By.xpath(".//*[contains(text(),'BACK')]");
    public String masterTrackNumLink = ".//*[contains(text(),'%s (Master)')]";
    public By eventCount = By.xpath("//div[@role='tabpanel']//li[contains(@class , 'sr-list')]");
    public By lastEventDate = By
            .xpath("(.//div[@role='tabpanel']//*[@class='sr-list__item'])[2]//*[@class='sr-grid-3col']");
    public By lastEventLocation = By
            .xpath("(.//div[@role='tabpanel']//*[@class='sr-list__item'])[2]//*[@class='sr-grid-2col'][1]");
    public By lastEventStatus = By
            .xpath("(.//div[@role='tabpanel']//*[@class='sr-list__item'])[2]//*[@class='sr-grid-2col'][2]");
    public By lastEventDetails = By
            .xpath("(.//div[@role='tabpanel']//*[@class='sr-list__item'])[2]//*[contains(@class,'sr-list-txt--lt')]");
    public String exceptionIcon = "//div[@role='tabpanel']//li[%s]//div[contains(@class,'sr-list-icn')]";
    public String SummaryBarxpath = ".//app-panel//*[contains(text(),\"%s\")]";
    public By estScheduledDelDate = By
            .xpath("//div[contains(text(),'ESTIMATED SCHEDULED DELIVERY')]/following-sibling::div[1]");
    public String estScheduledDelDateTime = "//div[contains(text(),'ESTIMATED SCHEDULED DELIVERY')]/following-sibling::div[%s]";
    public String ValueFromLabel = ".//*[contains(text(),\"%s\")]//parent::div//*[@class='sr-data']";
    public String LinkFromLabel = ".//*[contains(text(),\"%s\")]//parent::div//*[@class='sr-data']/a";
    public By EditIcon = By.xpath("//img[contains(@src,'edit')]");
    public By DeleteIcon = By.xpath("//img[contains(@src,'delete')]");
    public String interventionButton = "//*[contains(text(),\"%s\")]";
    public By CheckingforNoIntervention = By
            .xpath("//*[contains(text(),' Please update when you have initiated an intervention. ')]");
    public By VerifyRequired = By.xpath("//div[contains(text(), 'Required')]");
    public By status = By.xpath("//label[contains(text(),'STATUS')]//preceding::select");
    public By statusInProgress = By.xpath("//label[contains(text(),'STATUS')]//preceding::select/option[1]");
    public By OnDemandCare = By
            .xpath("//label[contains(text(),'Intervention Type')]/preceding-sibling::select/option[1]");
    public By interventionType = By.xpath("//label[contains(text(),'Intervention Type')]/preceding-sibling::select");
    public String headersXpath = ".//*[contains(@class,'ag-header-container')]//*[contains(text(),\"%s\")]";
    public String sepheadersXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-tabs']//*[contains(text(),'History(SEP)')]";
    public String fusionheadersXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-tabs']//*[contains(text(),'History(Fusion)')]";
    public By Commentbox = By.xpath("//textarea[@name='intvComment']");
    public By AllComments = By.xpath(".//*[@class='sr-list sr-list--wt']//li");
    public By CaseID = By.xpath("//input[@id='INPUT']");
    public By comentBoxText = By.xpath("//div[contains(text(),'INTERVENTION STATUS')]/following-sibling::div[1]/br[2]");
    public By caseIdBoxText = By.xpath("//div[contains(text(),'INTERVENTION STATUS')]/following-sibling::div[1]/br[3]");
    public String commentsTab = "//a[@aria-controls=\"%s\"]";
    public String addCommentShipperField = "//label[contains(text(),\"%s\")]/..";
    public By addCommentButton = By
            .xpath("//button[contains(text(),'Add internal comment')]//span[@class='sr-btn-icn add-comment-icn']");
    public String deleteButtonConfirmationDialog = "//div[@class='sr-btn-group sr-btn-group--vr']//button[contains(text(),\"%s\")]";
    public String iCalledRadioButtons = "//input[@id=\"%s\"]/..";
    public String linksInComment = "//span[contains(text(),\"%s\")]";
    public String addCommentShipperFieldDropDown = "//label[contains(text(),\"%s\")]//parent::span//select";
    public By leaveCommentTextBox = By.xpath("//textarea[@placeholder='Leave a comment']");
    public By commentEllipses = By.xpath("//button[@class='fdx-c-dropdown__button']");
    public String commentEllipsesDropDown = "//button[contains(text(),\"%s\")]";
    public By firstColumn = By.xpath("//div[@class='sr-list-txt sr-list-txt--sm p-l-2']");
    public By secondColumn = By.xpath("//div[@class='sr-list-txt sr-list-txt--sm p-l-2']");
    public By thirdColumn = By.xpath("//div[@class='sr-list-txt sr-list-txt--lt']");
    public By requiredFields = By.xpath("//div[contains(text(),'Required')]//parent::div");
    public By confirmationDialog = By.xpath("//div[@class='sr-modal__title']");
    public String errorMessageXpath = "//div[contains(text(),\"%s\")]";
    public String cancelButtonConfirmationDialog = "//span[contains(text(),\"%s\")]//parent::button";
    public String defaultRadioButton = "//input[@id=\"%s\"]";
    public String caseIdTextField = "//label[contains(text(),\"%s\")]//parent::div//input";
    public By ellipsesExpand = By.xpath("//div[@class='fdx-c-dropdown fdx-c-dropdown--is-open']//ul");
    public String PanelValuesXpath = ".//app-panel//*[contains(text(),'%s:  %s')]";
    public By timeZoneDDXpath = By.xpath(".//select[@name='sr-select']");
    // Since time zone comes under history and More details so we can use indexing
    // in the second %s [1/2] and [Local/destination time zone] in first %s
    public String timeZoneDropDown = "(//select[@name='sr-select']/option[text()=\"%s\"])[%s]";

    // Its present under both history and
    public String expandCollapse = "(//div[contains(@class,'sr-accordion-panel')]//span[@class='toggle-title'])[%s]";
    // Tooling xpaths
    public String TooltipsXpath = ".//*[contains(text(),\"%s\")]//*[@class='sr-info__text']";
    public By commitTimer = By.xpath("//span[contains(@class,'sr-data--wt')]");
    public By watchIcon = By.xpath("//div[@class='watch-list']//span[contains(@class,'icon')]");
    public By watchFilled = By.xpath("//div[contains(@class,'watch-list')]//span[contains(@class,'filled')]");
    public By watchEmpty = By.xpath("//div[contains(@class,'watch-list')]//span[contains(@class,'watchlist-icn')]");
    public String watchedText = "//div[contains(@class,'watch-list')]//span[contains(text(),\"%s\")]";
    public String lastCommentDateTimeColumn = "//a[contains(text(),\"%s\")]/ancestor::div[@col-id='trackingNumber']/following-sibling::div[@col-id='lastCommentOn']";
    public String lastCommentColumn = "//a[contains(text(),\"%s\")]/ancestor::div[@col-id='trackingNumber']/following-sibling::div[@col-id='lastComment']";
    public By firstTrackingNumberInList = By.xpath("//div[@row-index='0']/div[@col-id='trackingNumber']//a");
    public By lastCommentAddedDateTime = By.xpath("//div[@class='sr-list-txt sr-list-txt--fs11'][1]");
    public String commentEllipseRow = "//li[%s]//button[@class='fdx-c-dropdown__button']";

    public By getStatusUpdates = By.xpath("//span[@class='sr-statusUpdate--txt']");
    public By contactUsLink = By.xpath(".//*[contains(text(),'CONTACT YOUR SUPPORT TEAM')]");
    public By contactYourSupportTeam = By.xpath("//div[@class='sr-caro-footer']");
    public By statusXpath = By.xpath("(.//*[@class='sr-list-txt'])[1]");
    public String predictionStatus = "//div[contains(text(),'PREDICTION')]/following-sibling::div[contains(text(),\"%s\")]";
    public By interventionReasonSection = By
            .xpath("//div[contains(text(),'INTERVENTION STATUS')]/following-sibling::div[1]");
    public String scanEventColumnHeader = "//div[contains(@class,'header-cell-label')]/span[text()=\"%s\"]";
    public String returnTrackNumberLink = "//div[@class='sr-grid__cell--lnk']/a[text()=\"%s\"]";
    public By returnToShipperLabel = By.xpath("//div[@col-id='reason']//div[@class='sr-grid__cell--lnk']");
    public By CustomerreturnToShipperLabel = By.xpath(".//*[contains(text(),'Return Tracking Number')]");
    public String trackingNumberOnSummaryBar = "//div[@class='sr-caro-header-txt']/span[contains(text(),\"%s\")]";
    public By logCallButton = By.xpath("//button[contains(text(),'Log call')]//span[@class='sr-btn-icn call-icn']");
    public By addInternalCommentButton = By
            .xpath("//button[contains(text(),'Add internal comment')]//span[@class='sr-btn-icn add-comment-icn']");
    public String iCalledDDXpath = ".//option[contains(text(),\"%s\")]";
    public String clickDropDownBox = "//select[contains(@id,\"%s\")]";
    public String buttonXpath = "//button[contains(text(),\"%s\")]";
    public String buttonXpathCombinedFiles = "(//button[contains(text(),\"%s\")])[2]";
    public String inputText = "//label[contains(text(),\"%s\")]//preceding-sibling::input";
    public By logCallLink = By.xpath("//span[normalize-space()='Log call']");
    public By addInternalCommentLink = By.xpath("//span[normalize-space()='Add internal comment']");
    public By cancelLink = By.xpath("//span[normalize-space()='Cancel']");
    public By specifyCallParty = By.id("callParty");
    public By lastColumnShipmentsList = By.xpath("//div[@col-id='lastCommentOn']");
    public By statusDetailReason = By.xpath("(.//*[@col-id='reason' and @role!='columnheader'])[1]");
    public By journeyMapShipmentDetails = By.xpath("//div[@id='journeymap']");
    public By destinationPinIcon = By.xpath("//div[@class='destination-pin-icon']");
    public By deliveryVehicleIcon = By.xpath("//div[@class='delivery-Vehicle-icon']");
    public By updatedTimeMap = By.xpath("//app-journey-map//div[@class='sr-list-txt sr-list-txt--bd']");
    public By countDownInSecMap = By.xpath("//app-journey-map//div[@class='sr-list-txt']");
    public By zoomInOutMap = By.xpath("div[class='leaflet-control-zoom leaflet-bar leaflet-control']");
    public By predictionData = By.xpath(".//div[contains(text(),'PREDICTION')]/following-sibling::div[1]");
    public String historyTableXpathShipper = "//li[@class='sr-list__item']//div[contains(text(),\"%s\")][1]";
    public String columnPositionInDetailsPage = "//app-sr-tab[%s]//div/div/span[@ref='eText']";
    public String firstColumnHeader = "//app-sr-tab[%s]//div[@ref='eCenterContainer']/div[1]/div[1]";
    public By ScrollBar = By.xpath(".//*[contains(@class,'ag-body-horizontal-scroll-viewport')]");
    public By CERheader = By
            .xpath(".//*[@class='sr-grid-row']//*[contains(text(),'Customer Exception Request (CER)')]");
    public String CERComment = ".//*[@class='sr-grid-row']//*[contains(text(),\"%s\")]";
    public String CERNumber = ".//*[@class='sr-grid-row']//*[contains(text(),'CER Number: %s')]";
    public By CERModule = By.xpath(".//*[@class='sr-grid-row']//*[@class='sr-list-txt sr-list-txt--comp']");
    public By payerIconInDetailsPage = By.xpath("//span[text()='Payer']/parent::div[contains(@class,'payer')]");
    public By HistoryFusion = By.xpath(".//*[contains(text(),'History(Fusion)')]");
    public By HistorySep = By.xpath(".//*[contains(text(),'History(SEP)')]");
    public By RowsPerPageSep = By
            .xpath("(.//*[contains(text(),'Rows per page:')])[1]//ancestor::app-sr-table-pagination//Select");
    public By IndustryVerticalTitle = By.xpath("(.//*[@class='sr-form-title'])[2]");
    public String moduleXpaths = ".//*[@class='sr-label' and contains(text(),\"%s\")]//ancestor::div//*[contains(text(),\"%s\")]";
    public String commentDropdown = ".//select[@id=\"%s\"]/option";
    public String commentContextMenu = ".//div[text()=\"%s\"]/ancestor::div//button[@id='contextMenu']";
    public String commentEditButton = ".//button[text()='Edit']";
    public String commentDeleteButton = ".//button[text()='Delete']";
    public String updateComment = ".//span[text()='Update Comment']";
    public String updateLogCall = ".//span[text()='Update Log Call']";
    public String commentDeleteCancelPopup = ".//button[@type='button' and contains(text(),\"%s\")]";
    public String ShipmentStatus = ".//a[contains(text(),'Shipment Status')]";
    public String ShipmentStatusListFromMyShipments = ".//ul[@class='sr-multinav-subchild']//ul//li";
    public By tabsOnShipmentDetails = By.cssSelector("[role='tablist'] li span.sr-tabs__nav-lnk-txt");
    public By personalNotetextbox = By.cssSelector("#textMessage");
    public By personalNoteTable = By.cssSelector(".sr-list--wt li div[class*='sr-list-txt']");
    public By personalNoteDetails = By.xpath("//*[@class='sr-note-label']//.//../div");
    public By pesonalNoteInfo = By.cssSelector(".sr-note-info span");
    public String moreDetailsInfo = ".//li[@class='sr-list__item']//div[text()=' %s ']";
    public String columnValues = ".//div[@col-id=\"%s\" and @role='gridcell']";
    public By pageheader = By.xpath("//*[@class='sr-shipment-details__body']");
    public By localTimeZoneHistoryTabBy = By.xpath("//*[contains(@class,'sr-grid-3col')]/div[@class='sr-list-txt']");
    public By autoCommentRow = By.xpath("//*[@class='sr-list sr-list--wt']//li/div/div");
    public By commentsColumn = By.xpath("//*[@class='sr-grid-6col']");
    public By userName = By.xpath("//div[contains(@class,'fs-')]");
    public By commentsDropDown = By.xpath("//select[@id='Comments']");
    public String shipmentDetailsSection = "//*[contains(text(),\"%s\")]/following-sibling::div";
    public By cerNumber = By.xpath("//*[@col-id='identifier']");
    public By caseEbsLoginPageTitle = By.xpath("//*[@class='applogin-container']/p");
    public By myShipmentsHeaders = By.xpath("//*[@class='sr-caro-header']/div/div//div");
    public By trackingnum_Btn_GetStatusUpdates = By.xpath("//span[contains(text(),'Get Status Updates')]");
    public By trackingnum_DrpDwn_Languages = By.xpath("//select[@id='*LANGUAGE']");
    public By trackingnum_Txtbox_Email = By.xpath("//div[@class='sr-statusUpdate__group']//label[contains(text(), 'Email')]");
    public By trackingnum_TxtBox_EmailOuter = By.xpath("//div[@class='sr-statusUpdate__group']//input[@type='text']");
    public By trackingnum_Txtbox_YourName = By.xpath("//label[contains(text(), ' *Your Name ')]//..//input");
    public By trackingnum_Txtbox_YourEmail = By.xpath("//label[contains(text(), ' *Your Email ')]//..//input");
    public By trackingnum_Checkbox_Iagreeto = By.xpath("//input[@formcontrolname='chkAcceptTerms']");
    public By trackingnum_Btn_Submit = By.xpath("//button[contains(text(), ' SUBMIT ')]");
    public By trackingnum_Btn_Cancel = By.xpath("//span[contains(text(), 'CANCEL')]");
    public By trackingnum_Btn_AddAnotherEmail = By.xpath("//span[contains(text(), ' ADD ANOTHER EMAIL ADDRESS ')]");
    public By trackingnum_Text_IAgreeToThe = By.xpath("//label[contains(text(), ' I agree to the ')]");
    public By trackingnum_Text_TermsOfUse = By.xpath("//a[contains(text(), 'Terms of use')]");
    TestAPI apiCall;
    String shipmentDataLabel = "//label[normalize-space()=\"%s\"]//following::div[contains(text(),\"%s\")]";

    // Service - Type of Service
    String sectionSubsection = "//div[@class='sr-form-title' and contains(text(),\"%s\")]/following-sibling::div/div/label[contains(text(),\"%s\")]";
    // Service / Package / Time Stamps
    String mainSections = "//div[@class='sr-form-title' and contains(text(),\"%s\")]";
    String packageDetails = "//*[text()=' %s ']/../div";
    // Values under various sections like Service Type / Surround Eligibility
    public String valuesUnderSectionOnShipmentData = "//*[contains(text(),\"%s\")]/../div";
    public By myshipments_Filters = By.xpath("//span[.='FILTERS' or .='FILTRES' or .='FILTROS']");
    public By myshipments_Filters_FirstLevelCategories = By.xpath("//ul[@class='sr-multinav-parent']//a");
    public By myshipments_Txt_Filters_CombinationsNotAllowed = By.xpath("(//div[@class='sr-legacy-search-searchbox-character'])[1]");
    public By myshipments_Filters_SearchBar = By.xpath("//input[@placeholder='Search for filter' or @placeholder='Recherche de filtre']");
    public By myshipments_Txt_Filters_ConsecutiveNotAllowed = By.xpath("//div[@class='sr-legacy-search-searchbox-message']");

    public By myshipments_Export_label = By.xpath("//p[.='Export']//..//span[@class='question-gray-icn' or //p[.='Export']//..//span[@class='help-icon-margin']]");

    public By myshipments_Export = By.xpath("//p[.='Export']//..//span[contains(@class,'icon')]");
    public By myshipments_ExportLink_label = By.xpath("//span[@class='download-icn d-inline-block active']");
    public By myshipments_ExportLink = By.xpath("//span[contains(@class,'download-icn d-inline-block')]");
    public By myshipments_ScheduleReports_label = By.xpath("//p[.='Scheduled Reports']//..//span[contains(@class,'icon')]");

    public By myshipments_ScheduleReports = By.xpath("//p[.='Scheduled Reports']//..//span[contains(@class,'icon')]");
    public By myshipments_ScheduleReportslink_Label = By.xpath("//span[@class='external-link-icn active' or @class='external-link-icn']");
    public By myshipments_ScheduleReportslink = By.xpath("//span[contains(@class,'external-link-icn')]");

    public By myshipments_ExportButton =By.xpath("//a//span[@class='download-icn active']");
    public By myshipments_cancelButton = By.xpath("//button[@class='fdx-c-button fdx-c-button--text' and .='Cancel']");

    public By getMyshipments_Viewing_Count = By.xpath("(//div[.='Viewing']//..//div)[2]");

    public By Tooltip_presence = By.xpath("//div[contains(@class,'tooltip report-center')]/div[@class='sr-action__tooltip-desc-CV']");

    public By Header = By.xpath("//div[@class='sr-section__head']//div");
    public By cancelFilterBubble = By.xpath("//span[@class='sr-pill__close']");
    public By Banner = By.xpath("//div[@class='banner-close-icn']//..");
    public By Popupclosebutton = By.xpath("//div[@class='close-icn bk']");
    public By DisclaimerIcon = By.xpath("//div[contains(@class,'disclaimer')]//span");
    public By DisclaimerTxt = By.xpath("//div[contains(@class,'disclaimer')]//p");
    public By ExportPopupExistance = By.xpath("//div[@class='fdx-c-modal__main fdx-c-modal__main--small']");
    public By first_SC_report_HyperLink=By.xpath("(//div[@class='sr-grid__cell--lnk'])[1]/a");
    public String editPencilIcnInReportPage="(//div[@class='sr-list-icn']/img)[%s]";
    public By reportTypeDrpDwn=By.xpath("//app-sr-dropdown[@formcontrolname='reportType']//select");
    public By preShipmentOptionReportTypeDrpDwn=By.xpath("//app-sr-dropdown[@formcontrolname='reportType']//select/option[contains(@value,'1')]");
    public By chooseViewDrpDwn=By.xpath("//label[text()='CHOOSE ACCOUNT(S)']/parent::div/following-sibling::div[@class='sr-grid-6col sr-section__right']//a");

    public  By chooseViewSearchBox=By.xpath("//label[contains(text(),'CHOOSE VIEW')]//..//..//input[contains(@class,'sr-searchbox')]");
    String SubmitButtonValidation = "//button[contains(text(),\"%s\")]";
    String CancelButtonValidation = "//span[contains(text(),\"%s\")]";
    String ButtonDisabledValidation = "//button[@disabled and contains(text(),\"%s\")]";
    String TextValidationOnGetStatusUpdates = "//div[contains(text(),\'%s\')]";
    String addEmailInGetStatusUpdates = "//span[contains(text(),'ADD UP TO (%s) EMAIL ADDRESSES')]";
    public By ShiperAccNumber = By.xpath("//span[@class='shipperAccountNumber_0']");

    public By selectDelectShipmentID = By.xpath("(//label[contains(text(),'(company) check')])[1]");

    public ShipmentDetails(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.apiCall = new TestAPI(this.commonHelpers);
    }

    /**
     * If there is intervention added already this will delete that and adds a new
     * intervention
     */

    public void deleteInterventionAndVerifyRequiredField() {
        boolean state = this.elementIsDisplayed((DeleteIcon));
        this.ScrollToTop();
        if (state) {
            this.clickOnElement(DeleteIcon);
            this.clickOnElement(By.xpath(String.format(deleteButtonConfirmationDialog, "Delete")));
        }
        this.clickOnElement(EditIcon);
        this.clickOnElement(By.xpath(String.format(interventionButton, "Save")));
        List<WebElement> reqFields = this.findElements(VerifyRequired);
        Assert.assertEquals(3, reqFields.size());
    }

    public Boolean ValidateDetailswithUIandAPI(String module, String endPointKey) throws Exception {
        List<Boolean> validationflags = new ArrayList<>();
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        ShipmentTrackingDetails ShipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);
        if (module.equalsIgnoreCase("CER Comments")) {
            List<Comment> comments = ShipmentTrackingDetails.getShipmentDto().getComments();
            for (Comment comment : comments) {
                if (comment.getCustomerExceptionRequestDto() != null) {
                    validationflags.add(this.elementIsDisplayed(this.CERheader));

                    validationflags.add(this.elementIsDisplayed(this.getByusingString(
                            String.format(this.CERComment,
                                    comment.getCustomerExceptionRequestDto().getDate().split("-")[2].replaceFirst("0*",
                                            "")))));
                    validationflags.add(this.elementIsDisplayed(this.getByusingString(
                            String.format(this.CERNumber, comment.getCustomerExceptionRequestDto().getCerNumber()))));
                    validationflags.add(this.elementIsDisplayed(this.getByusingString(
                            String.format(this.CERComment, comment.getCustomerExceptionRequestDto().getComment()))));
                    String text = this.findElement(this.CERModule).getText().replace("\n", " ");
                    validationflags.add(text.contains(comment.getCustomerExceptionRequestDto().getCerType()));
                    validationflags.add(text.contains(comment.getCustomerExceptionRequestDto().getCerStatus()));
                }
            }
        }
        return !validationflags.contains(false);
    }

    /**
     * This method validates dropdowns in the Intervention addition or deletion
     *
     * @param dropdown
     * @param expectedOptions
     * @return
     */
    public Boolean VerifydropdownoptionsforIntervention(String dropdown, List<String> expectedOptions) {
        boolean flag = false;
        if (dropdown.equalsIgnoreCase("status")) {
            List<String> actualOptions = this.getDropdownOptions(status);
            flag = actualOptions.equals(expectedOptions);
        } else if (dropdown.equalsIgnoreCase("intervention type")) {
            List<String> actualOptions = this.getDropdownOptions(interventionType);
            flag = actualOptions.equals(expectedOptions);
        }
        return flag;
    }

    /**
     * This method gives all data to the Intervention addition or deletion
     *
     * @param columns
     */
    public void EnterallthedetailsforIntervention(Map<String, String> columns) {
        this.Mouse_MoveToElement(DriverManager.getDrv().findElement(EditIcon));
        this.clickOnElement(EditIcon);
        for (String column : columns.keySet()) {
            switch (column) {
                case "Status":
                    this.selectDropdown(status, "text", columns.get(column));
                    break;
                case "Intervention Type":
                    this.selectDropdown(interventionType, "text", columns.get(column));
                    break;
                case "Comments":
                    this.enterText(Commentbox, columns.get(column));
                    break;
                case "CaseId":
                    this.enterText(CaseID, columns.get(column));
                    break;
            }
        }
    }

    /**
     * This method does button operations for Intervention
     *
     * @param button
     */
    public void OperaionsforIntervention(String button) {

        switch (button) {
            case "Cancel":
                this.clickOnElement(By.xpath(String.format(interventionButton, "Cancel")));
                break;
            case "Save":
                this.clickOnElement(By.xpath(String.format(interventionButton, "Save")));
                this.waitUntilNotVisible(this.loadingIndicator);
                break;
            case "Update":
                this.clickOnElement(By.xpath(String.format(interventionButton, "Update")));
                this.waitUntilNotVisible(this.loadingIndicator);
                break;
            case "Delete":
                this.clickOnElement(By.xpath(String.format(interventionButton, "Delete")));
                this.clickOnElement(By.xpath(String.format(deleteButtonConfirmationDialog, "Delete")));
                this.waitUntilNotVisible(this.loadingIndicator);
                break;
        }
    }

    /**
     * This method validates Commentbox Boundarylimit
     *
     * @param count
     */
    public boolean ValidateCommentboxBoundarylimit(String count) {
        int actualLimit = Integer.parseInt(this.findElement(Commentbox).getAttribute("maxlength"));
        return actualLimit == Integer.parseInt(count);
    }

    /**
     * This method validates CommentCaseId box Boundarylimit
     */

    public int ValidateCaseIDBoundarylimit() {
        return Integer.parseInt(DriverManager.getDrv().findElement(CaseID).getAttribute("maxlength"));
    }

    public Boolean ValdatePanelitems(String field, String value) {
        return this.elementIsDisplayed(this.getByusingString(String.format(this.PanelValuesXpath, field, value)));
    }

    public Boolean validateContactUsLink(String contextStoreValue, String emailTo) {
        this.waitUntilVisible(contactUsLink);
        String link = this.findElement(this.contactUsLink).getAttribute("href").replace("%20", "");
        log.info("UI Link: " + link);

        // Default value in subject
        String subject = "FedExSurroundSupport";

        // for premium customer subject and email id changes
        if (emailTo.contains("PriorityAlert"))
            subject = "FedExPriorityAlertSupport/MISurroundPremium";

        String expectedLink = String.format(Constants.Contactus,
                emailTo, subject, this.commonHelpers.getValuefromContextStore(contextStoreValue));
        log.info("Expected link : " + expectedLink);
        return link.equalsIgnoreCase(expectedLink);
    }

    public Boolean ValidateDetailsPageWithAPI(DataTable table) throws Exception {
        List<Boolean> flags = new ArrayList<>();
        List<String> apiFields = table.asList(String.class);
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        Response resp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Details");
        ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);
        for (String field : apiFields) {
            if ("subStatus".equals(field)) {
                if (virtualizationFlag) {
                    flags.add(shipmentTrackingDetails.getTrackingApiDto().getSubStatus()
                            .equalsIgnoreCase(Constants.signatureDoneBy));
                }
                flags.add(this.elementIsDisplayed(
                        By.xpath(this
                                .buildXpathForString(shipmentTrackingDetails.getTrackingApiDto().getSubStatus()))));
            }
        }
        return !flags.contains(false);
    }

    public Boolean ValidateDetailsPageWithAPI(DataTable table, String section) {
        Boolean flag = false;
        Map<String, String> fields = table.asMap(String.class, String.class);
        switch (section) {
            case "Industry Vertical":
                flag = this.ValidateIndustryVerticalData(section, fields);
                break;
        }
        return flag;
    }

    public Boolean ValidateIndustryVerticalData(String section, Map<String, String> fields) {
        String Header = this.findElement(this.IndustryVerticalTitle).getText();
        log.info("UI header element: " + Header);
        boolean flag = Header.equalsIgnoreCase(section);
        if (flag) {
            for (String module : fields.keySet()) {
                String value = fields.get(module).contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(fields.get(module)).toString()
                        : fields.get(module);
                if (module.equalsIgnoreCase("Industry Vertical")) {
                    flag = this
                            .elementIsDisplayed(By.xpath(String.format(this.moduleXpaths, module, value)));
                }
            }
        }
        return flag;
    }

    public boolean ValidateSummaryBar(DataTable tableViews) throws Exception {
        ShipmentTrackingDetails shipmentTrackingDetails = new ShipmentTrackingDetails();
        List<String> expectedpanels = tableViews.asList(String.class);
        String index = "0";
        boolean flag = true;
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        this.ScrollIntoView(this.findElement(this.getByusingString(this.buildXpathForString("Tracking Number:"))));
        this.waitUntilVisible(this.getByusingString(this.buildXpathForString(String.format("Tracking Number: %s",
                this.commonHelpers.getValuefromContextStore("Tracking Number").toString()))));
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("user")
                && (expectedpanels.contains("Status") || expectedpanels.contains("Delivery"))) {
            Response resp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Details");
            shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(), ShipmentTrackingDetails.class);
        }
        for (String panel : expectedpanels) {
            String expectedText = "";
            String actualText = "";
            if (!flag) {
                break;
            } else {
                switch (panel) {
                    case "Status":
                        index = "1";
                        actualText = shipmentTrackingDetails.getShipmentDto().getStatus();
                        expectedText = virtualizationFlag ? actualText
                                : this.getText(this.statusXpath).split("\n")[0].trim();
                        break;
                    case "Prediction":
                        index = "2";
                        expectedText = Constants.Prediction;
                        break;
                    case "Intervention Status":
                        index = "4";
                        expectedText = Constants.InterventionStatus;
                        break;
                    case "Scheduled Delivery":
                        index = "3";
                        expectedText = Constants.DeliveryStatus;
                        break;
                    case "Delivery":
                        index = "3";
                        if (!virtualizationFlag) {
                            String shipmentStatus = shipmentTrackingDetails.getTrackingApiDto().getKeyStatus();
                            switch (shipmentStatus) {
                                case "In transit":
                                    expectedText = Constants.Intransit;
                                    break;
                                case "Delivered":
                                    expectedText = Constants.DeliveredTime;
                                    break;
                                case "Exception":
                                    expectedText = Constants.Exception;
                                    break;
                            }
                            actualText = shipmentTrackingDetails.getTrackingApiDto().getKeyStatus();
                            break;
                        } else {
                            expectedText = Constants.Intransit;
                        }
                    case "From":
                        index = "1";
                        expectedText = Constants.From;
                        break;
                    case "To":
                        index = "2";
                        expectedText = Constants.To;
                        break;
                }
            }
            if (!virtualizationFlag) {
                actualText = this.getText(this.getByusingString(String.format(purplePanelSecondRowHeaders, index)));
            } else if (actualText.equals("")) {
                actualText = expectedText;
            }
            flag = expectedText.equalsIgnoreCase(actualText);
        }
        return flag;
    }

    public Boolean ValidateToolTip(String SectionName) {
        String UIcontent = this.findElement(this.getByusingString(String.format(this.TooltipsXpath, SectionName)))
                .getAttribute("innerHTML");
        String expected = SectionName.equalsIgnoreCase("Shipment Specific") ? Constants.ShipmentSpecificTip
                : Constants.GenericTip;
        return UIcontent.equalsIgnoreCase(expected);
    }

    public Boolean ValidateColumnHeaders(String shipmentType, DataTable columnHeaders) {
        boolean flag = false;
        List<String> expectedHeaders = columnHeaders.asList(String.class);
        if (shipmentType.equalsIgnoreCase("MPS")) {
            for (String header : expectedHeaders) {
                flag = this.elementIsDisplayed(this.getByusingString(String.format(this.columnHeaderxpath, header)));
                if (!flag) {
                    break;
                }
            }
        }
        return flag;
    }

    public Boolean ValidateColumnHeaders(DataTable columnHeaders) {
        Boolean flag = false;
        this.clickOnElement(this.HistoryFusion);
        List<String> expectedHeaders = columnHeaders.asList(String.class);
        for (String header : expectedHeaders) {
            this.Mouse_MoveToElement(
                    this.findElement(getByusingString(String.format(this.fusionheadersXpath, header))));
            flag = this.elementIsDisplayed(this.getByusingString(String.format(this.fusionheadersXpath, header)));
            if (!flag) {
                break;
            }
        }
        return flag;
    }

    public Boolean ValidateColumnHeaders(DataTable columnHeaders, String tab) {
        Boolean flag = false;
        if (tab.equalsIgnoreCase("History(SEP)")) {
            this.clickOnElement(this.HistorySep);
            List<String> expectedHeaders = columnHeaders.asList(String.class);
            for (String header : expectedHeaders) {
                this.Mouse_MoveToElement(
                        this.findElement(getByusingString(String.format(this.sepheadersXpath, header))));
                flag = this.elementIsDisplayed(this.getByusingString(String.format(this.sepheadersXpath, header)));
                if (!flag) {
                    break;
                }
            }
        } else if (tab.equalsIgnoreCase("History(Fusion)")) {
            this.clickOnElement(this.HistoryFusion);
            List<String> expectedHeaders = columnHeaders.asList(String.class);
            for (String header : expectedHeaders) {
                this.Mouse_MoveToElement(
                        this.findElement(getByusingString(String.format(this.fusionheadersXpath, header))));
                flag = this.elementIsDisplayed(this.getByusingString(String.format(this.fusionheadersXpath, header)));
                if (!flag) {
                    break;
                }
            }
        }
        return flag;
    }

    public void ValidateHistoryDetailswithAPI(String tab, String endPointKey, DataTable table) {
        Boolean flag = true;
        try {
            List<String> UIValidations = table.asList(String.class);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                    ShipmentTrackingDetails.class);

        } catch (Exception e) {
            log.info("Something went wrong in ValidateHistoryDetailswithAPI method: " + e.getMessage());
        }
    }

    public Boolean CEValidateMPSfieldsWithUI(String endPointKey, DataTable dataTable) {
        boolean flag = true;
        try {
            List<String> UIValidations = dataTable.asList(String.class);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                    ShipmentTrackingDetails.class);
            this.commonHelpers.AddToContextStore("ShipmentDetails", shipmentTrackingDetails);
            String trackingId = this.commonHelpers.getValuefromContextStore("ContextStore-mastertrackingNumber")
                    .toString();
            for (String value : UIValidations) {
                if (flag) {
                    switch (value) {
                        case "Number of shipments":
                            int expected = shipmentTrackingDetails.getShipmentDto().getMultiPieceShipments().size();
                            int actual = Integer.parseInt(this.getText(xpieceShipmentsXpath).substring(0, 1));
                            flag = expected == actual;
                            break;
                        case "viewing shipmentId":
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(String.format(viewingMPSXpath, trackingId)));
                            break;
                        case "Master shipmentId":
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(String.format(masterMPSIdXpath, trackingId)));
                            break;
                    }
                } else {
                    break;
                }

            }
        } catch (Exception e) {
            log.info("Something went wrong in ValidateMPStableWithUI method: " + e.getMessage());
        }
        return flag;
    }

    public void SelectValueFromDropDown(String selection, String recordsCount) {
        this.selectDropdown(this.timeZoneDDXpath, selection, recordsCount);
        if (this.elementIsDisplayed(loadingIndicator))
            this.waitUntilNotVisible(loadingIndicator);
    }

    public Boolean ValidateMPSfieldsWithUI(String endPointKey, DataTable dataTable) {
        boolean flag = true;
        try {
            List<String> UIValidations = dataTable.asList(String.class);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                    ShipmentTrackingDetails.class);
            this.commonHelpers.AddToContextStore("ShipmentDetails", shipmentTrackingDetails);
            String trackingId = this.commonHelpers.getValuefromContextStore("ContextStore-mastertrackingNumber")
                    .toString();
            for (String value : UIValidations) {
                if (flag) {
                    switch (value) {
                        case "Number of shipments":
                            int expected = shipmentTrackingDetails.getShipmentDto().getMultiPieceShipments().size();
                            int actual = Integer.parseInt(this.getText(xpieceShipmentsXpath).split(" ")[0]);
                            flag = expected == actual;
                            break;
                        case "viewing shipmentId":
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(String.format(viewingMPSXpath, trackingId)));
                            break;
                        case "Master shipmentId":
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(String.format(masterMPSIdXpath, trackingId)));
                            break;
                        case "STATUS":
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(this.getXPathforAnyElementWithText("DELIVERED")));
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(this.getXPathforAnyElementWithText("IN TRANSIT")));
                            flag = this
                                    .elementIsDisplayed(
                                            this.getByusingString(this.getXPathforAnyElementWithText("EXCEPTIONS")));
                            break;

                    }
                } else {
                    break;
                }

            }
        } catch (Exception e) {
            log.info("Something went wrong in ValidateMPStableWithUI method: " + e.getMessage());
        }
        return flag;
    }

    public Boolean ValidateShipmentHistoryforCE(String endPointKey, DataTable dataTable, String... tab)
            throws Exception {
        boolean flag = true;
        List<String> TableHeaders = dataTable.asList(String.class);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);
        Response prefResp = this.commonHelpers.GetValueFromResponseCollection("CE_Preferences_user");
        UserPreferences usp = this.commonHelpers.unMarshall(prefResp.asString(), UserPreferences.class);
        if (tab != null && tab.length > 0) {
            int counter = 1;
            if (shipmentTrackingDetails.getShipmentDto().getScanHistory().size() > 20) {
                this.selectDropdown(RowsPerPageSep, "text", "100");
            }
            for (ScanHistory history : shipmentTrackingDetails.getShipmentDto().getScanHistory()) {
                for (String column : TableHeaders) {
                    log.info("Column: " + column);
                    if (flag) {
                        switch (column) {
                            case "ID":
                                column = "id";
                                this.ScrollIntoView(
                                        this.findElement(
                                                By.xpath(String.format(sepHistoryTableXpath, column, counter))));
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(sepHistoryTableXpath, column, counter)));
                                break;
                            case "SCAN CODE":
                                column = "scanCode";
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(sepHistoryTableXpath, column, history.getScanCode())));
                                break;
                            case "EXCEPTION CODE DESCRIPTION":
                                column = "codeDescription";
                                if (history.getCodeDescription() != "") {
                                    flag = this.elementIsDisplayed(
                                            this.getByusingString(
                                                    String.format(sepHistoryTableXpath, column,
                                                            history.getCodeDescription())));
                                } else
                                    flag = true;

                                break;
                            case "DATE/TIME":
                                column = "scanEventDateTime";
                                String date = history.getScanEventDateTime().split("T")[0];
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(sepHistoryTableXpath, column,
                                                        date)));
                                String time = history.getScanEventDateTime().split("T")[1].substring(0, 5);
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(sepHistoryTableXpath, column,
                                                        time)));
                                break;
                            case "LOCATION ID":
                                column = "scanEventLocationId";
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(sepHistoryTableXpath, column,
                                                        history.getScanEventLocationId())));
                                break;
                            case "COMMENTS":
                                column = "comments";
                                if (history.getComments() != "") {
                                    String comments = history.getComments().split(" ")[0];
                                    flag = this.elementIsDisplayed(
                                            this.getByusingString(
                                                    String.format(sepHistoryCommentsTableXpath, column,
                                                            comments)));
                                } else {
                                    flag = true;
                                }
                                break;
                            case "FEDEX ID":
                                column = "employeeId";
                                if (history.getEmployeeId() != "") {
                                    flag = this.elementIsDisplayed(
                                            this.getByusingString(
                                                    String.format(sepHistoryCommentsTableXpath, column,
                                                            history.getEmployeeId())));
                                } else {
                                    flag = true;
                                }
                                break;
                        }
                    } else {
                        break;
                    }
                }
                if (!flag) {
                    break;
                } else
                    counter++;
            }
        } else {
            for (History history : shipmentTrackingDetails.getShipmentDto().getHistory()) {
                for (String column : TableHeaders) {
                    if (flag) {
                        switch (column) {
                            case "SCAN CODE":
                                flag = this.elementIsDisplayed(
                                        this.getByusingString(
                                                String.format(historyTableXpath, column, history.getScanCode())));
                                break;
                            case "CODE DESCRIPTION":
                                flag = this.elementIsDisplayed(this.getByusingString(
                                        String.format(historyTableXpath, column, history.getCodeDescription())));
                                break;
                            case "STATUS DETAIL":
                                flag = this.elementIsDisplayed(this
                                        .getByusingString(
                                                String.format(historyTableXpath, column, history.getStatusDetail())));
                                break;
                            case "LOCATION ID":
                                flag = this.elementIsDisplayed(this
                                        .getByusingString(
                                                String.format(historyTableXpath, column, history.getLocationId())));
                                break;
                            case "DATE":
                            case "TIME":
                                String dateFromAPI = this.commonHelpers.GetDatefromAPI(history.getCreateDate(), column,
                                        shipmentTrackingDetails.getShipmentDto().getUtcOffset(),
                                        usp.getPreferredDateFormat());
                                if (history.getCreateDate().length() <= 10)
                                    flag = true;
                                else
                                    flag = this.elementIsDisplayed(
                                            this.getByusingString(
                                                    String.format(historyTableXpath, column, dateFromAPI)));
                                break;
                        }
                    } else {
                        break;
                    }
                }
                if (!flag) {
                    break;
                }
            }
        }
        return flag;
    }

    public Boolean ValidateMPStableWithUI(String endPointKey, DataTable dataTable) {
        ShipmentTrackingDetails ShipmentTrackingDetails = (ShipmentTrackingDetails) this.commonHelpers
                .getValuefromContextStore("ShipmentDetails");
        String index;
        String expectedText;
        String actualText;
        boolean flag = true;
        List<String> TableHeaders = dataTable.asList(String.class);
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            for (MultiPieceShipment mps : ShipmentTrackingDetails.getTrackingApiDto().getMultiPieceShipments()) {
                for (String column : TableHeaders) {
                    if (flag) {
                        switch (column) {
                            case "TRACKING NUMBER":
                                index = "1";
                                flag = this.elementIsDisplayed(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                break;
                            case "SHIP DATE":
                                index = "2";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getShipDate();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                            case "STATUS":
                                index = "3";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getStatus();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                            case "SCHEDULED DELIVERY DATE":
                                index = "4";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getScheduledDeliveryDate();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                        }
                    }
                    break;
                }
                break;
            }
        } else {
            for (MultiPieceShipment mps : ShipmentTrackingDetails.getShipmentDto().getMultiPieceShipments()) {
                for (String column : TableHeaders) {
                    if (flag) {
                        switch (column) {
                            case "TRACKING NUMBER":
                                index = "1";
                                flag = this.elementIsDisplayed(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                break;
                            case "SHIP DATE":
                                index = "2";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getShipDate();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                            case "STATUS":
                                index = "3";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getStatus();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                            case "SCHEDULED DELIVERY DATE":
                                index = "4";
                                expectedText = this.getText(this
                                        .getByusingString(
                                                String.format(mpsTableXpath, mps.getTrackingNumber(), index)));
                                actualText = mps.getScheduledDeliveryDate();
                                flag = expectedText.equalsIgnoreCase(actualText);
                                break;
                        }
                    }
                    break;
                }
                break;
            }
        }

        return flag;
    }

    public Boolean ValidateMPScollapseAndExpand(String viewingStatus) {
        boolean flag = false;
        flag = Boolean
                .parseBoolean(this.findElement(this.MPStableStatusXpath).getAttribute("aria-expanded"));
        this.clickOnElement(collpaseExpandChevron);
        if (flag) {
            flag = Boolean
                    .parseBoolean(this.findElement(this.MPStableStatusXpath).getAttribute("aria-expanded"));
            this.clickOnElement(collpaseExpandChevron);
            flag = Boolean
                    .parseBoolean(this.findElement(this.MPStableStatusXpath).getAttribute("aria-expanded"));
        }
        return flag;
    }

    public void ValidateMPStrackNuminDetails() {
        boolean flag = true;
        ShipmentTrackingDetails ShipmentTrackingDetails = (ShipmentTrackingDetails) this.commonHelpers
                .getValuefromContextStore("ShipmentDetails");
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            for (MultiPieceShipment mps : ShipmentTrackingDetails.getTrackingApiDto().getMultiPieceShipments()) {
                if (flag) {
                    this.clickOnElement(
                            this.getByusingString(String.format(mpsTableXpath, mps.getTrackingNumber(), "1")));
                    this.waitUntilNotVisible(this.loadingIndicator);
                    flag = this.elementIsDisplayed(
                            this.getByusingString(String.format(this.trackingIdxpath, mps.getTrackingNumber())));
                    if (!mps.getTrackingNumber().equalsIgnoreCase(
                            this.commonHelpers.getValuefromContextStore("mastertrackingNumber").toString())) {
                        this.clickOnElement(this.backLink);
                        this.waitUntilNotVisible(this.loadingIndicator);
                    }
                } else {
                    break;
                }
            }
        } else {
            for (MultiPieceShipment mps : ShipmentTrackingDetails.getShipmentDto().getMultiPieceShipments()) {
                if (flag) {
                    this.clickOnElement(
                            this.getByusingString(String.format(mpsTableXpath, mps.getTrackingNumber(), "1")));
                    this.waitUntilNotVisible(this.loadingIndicator);
                    flag = this.elementIsDisplayed(
                            this.getByusingString(String.format(this.trackingIdxpath, mps.getTrackingNumber())));
                    if (!mps.getTrackingNumber().equalsIgnoreCase(
                            this.commonHelpers.getValuefromContextStore("mastertrackingNumber").toString())) {
                        this.clickOnElement(this.backLink);
                        this.waitUntilNotVisible(this.loadingIndicator);
                    }
                } else {
                    break;
                }
            }
        }

    }

    public void NavigateSummaryBar(String arrow) {
        this.JavaScriptClick(this.getByusingString(String.format(carouselNav, arrow)));
    }

    public boolean ValidatehrefLink(String hrefLink, String SupportTeam) {
        String actualLink = this.findElement(this.getByusingString(this.buildXpathForString(SupportTeam)))
                .getAttribute("href");
        String expectedLink = Constants.SupportLink;
        return expectedLink.contains(actualLink.replace("%20", " "));
    }

    public void ClickonTab(String displayLink) {
        this.ScrollToTop();
        this.clickOnElement(this.getByusingString(String.format(tabName, displayLink)));
    }

    public Boolean ValidateExternalLinks(String SectionName) {
        List<String> expectedlinks = (List<String>) this.commonHelpers.getValuefromContextStore("ExternalActualLinks");
        String xpath = SectionName.equalsIgnoreCase("Shipment Specific") ? ".//*[@class='sr-grid-6col m-r-7']%s"
                : ".//*[@class='sr-grid-6col m-l-7']%s";
        String LinksXpath = String.format(xpath, "//*[@class='sr-tooling-tile']//a");
        for (WebElement element : this.findElements(this.getByusingString(LinksXpath))) {
            element.click();
        }
        int NooftabsOpened = this.GetWindowHandles().size();
        if (SectionName.equalsIgnoreCase("Shipment Specific"))
            return expectedlinks.size() == NooftabsOpened - 1;
        else
            return expectedlinks.size() == NooftabsOpened - 4;
    }

    public Boolean ValidateToolingSections(String SectionName, DataTable table) throws Exception {
        boolean flag = true;
        List<String> ValidationParameters = table.asList(String.class);
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Details");
        ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);
        String xpath = SectionName.equalsIgnoreCase("Shipment Specific") ? ".//*[@class='sr-grid-6col m-r-7']%s"
                : ".//*[@class='sr-grid-6col m-l-7']%s";
        for (String param : ValidationParameters) {
            if (flag) {
                switch (param) {
                    case "Label":
                        List<String> ActualLabels = new ArrayList<String>();
                        List<String> ExpectedLabels;
                        String LabelXpath = String.format(xpath, "//*[@class='sr-tooling__subtitle']");
                        for (WebElement element : this.findElements(this.getByusingString(LabelXpath))) {
                            ActualLabels.add(element.getText().trim());
                        }
                        Collections.sort(ActualLabels);
                        Collections.sort(ExpectedLabels = SectionName.equalsIgnoreCase("Shipment Specific")
                                ? Constants.ShipmentSpecificToolLabels
                                : Constants.GenericToolLabels);
                        flag = ActualLabels.equals(ExpectedLabels);
                        break;
                    case "Content":
                        List<String> ActualContent = new ArrayList<String>();
                        List<String> ExpectedContent = new ArrayList<>();
                        String ContentXpath = String.format(xpath, "//*[@class='sr-tooling__subcontent']");
                        for (WebElement element : this.findElements(this.getByusingString(ContentXpath))) {
                            ActualContent.add(element.getText().trim());
                        }
                        Collections.sort(ActualContent);
                        Collections.sort(ExpectedContent = SectionName.equalsIgnoreCase("Shipment Specific")
                                ? Constants.ShipmentSpecificToolContent
                                : Constants.GenericToolContent);
                        flag = ActualContent.equals(ExpectedContent);
                        break;
                    case "Links":
                        List<String> ActualLinks = new ArrayList<>();
                        List<String> ExternalActualLinks = new ArrayList<>();
                        String LinksXpath = String.format(xpath, "//*[@class='sr-tooling-tile']//a");
                        for (WebElement element : this.findElements(this.getByusingString(LinksXpath))) {
                            ExternalActualLinks.add(element.getAttribute("href"));
                            ActualLinks.add(SectionName.equalsIgnoreCase("Shipment Specific")
                                    ? element.getAttribute("href").split("\\?")[0]
                                    : element.getAttribute("href"));
                        }
                        Collections.sort(ActualLinks);
                        List<String> ExpectedLinks = new ArrayList<>();
                        if (SectionName.equalsIgnoreCase("Shipment Specific")) {
                            ExpectedLinks.add(shipmentTrackingDetails.getShipmentDto().getShipmentSpecificExternalUrl()
                                    .getCaseManagementFieldClientURL());
                            ExpectedLinks.add(shipmentTrackingDetails.getShipmentDto().getShipmentSpecificExternalUrl()
                                    .getSenseAwareIdDasboardURL());
                            ExpectedLinks.add(
                                    shipmentTrackingDetails.getShipmentDto().getShipmentSpecificExternalUrl()
                                            .getEopsURL());
                        } else {
                            ExpectedLinks.add(
                                    shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                            .getConsURL());
                            ExpectedLinks.add(
                                    shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                            .getFoisURL());
                            ExpectedLinks.add(shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                    .getSenseAwareURL());
                            ExpectedLinks.add(
                                    shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                            .getThorURL());
                            ExpectedLinks.add(
                                    shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                            .getTripsURL());
                            ExpectedLinks.add(shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                    .getWeightAndBalanceURL());
                            ExpectedLinks.add(shipmentTrackingDetails.getShipmentDto().getShipmentGenericExternalUrl()
                                    .getWorkbenchURL());
                        }
                        Collections.sort(ExpectedLinks);
                        flag = ActualLinks.equals(ExpectedLinks);
                        this.commonHelpers.AddToContextStore("ExternalActualLinks", ExternalActualLinks);
                        break;
                }
            }
        }
        return flag;
    }

    public By generic_subtitle = By.xpath(".//*[@class='sr-grid-6col m-l-7']//*[@class='sr-tooling__subtitle']");
    public By generic_subcontent = By.xpath(".//*[@class='sr-grid-6col m-l-7']//*[@class='sr-tooling__subcontent']");
    public By generic_link = By.xpath(".//*[@class='sr-grid-6col m-l-7']//*[@class='sr-tooling-tile']//a");

    public void ValidateTooling(String SectionName, DataTable table) throws Exception {
        boolean flag = true;
        List<String> ValidationParameters = table.asList(String.class);
        for (String param : ValidationParameters) {
            if (flag) {
                switch (param) {
                    case "Label":
                        List<String> ActualLabels = new ArrayList<String>();
                        List<String> ExpectedLabels;
                        for (WebElement element : this.findElements(this.generic_subtitle)) {
                            ActualLabels.add(element.getText().trim());
                        }
                        Collections.sort(ActualLabels);
                        Collections.sort(ExpectedLabels = Constants.GenericToolLabels);
                        Assert.assertTrue(ActualLabels.equals(ExpectedLabels));
                        break;
                    case "Content":
                        List<String> ActualContent = new ArrayList<String>();
                        List<String> ExpectedContent = new ArrayList<>();
                        for (WebElement element : this.findElements(this.generic_subcontent)) {
                            ActualContent.add(element.getText().trim());
                        }
                        Collections.sort(ActualContent);
                        Collections.sort(ExpectedContent = Constants.GenericToolContent);
                        Assert.assertTrue(ActualContent.equals(ExpectedContent));
                        break;

                    case "Links":
                        List<String> ActualLinks = new ArrayList<>();
                        List<String> ExternalActualLinks = new ArrayList<>();
                        for (WebElement element : this.findElements(this.generic_link)) {
                            ActualLinks.add(element.getAttribute("href"));
                        }
                        Collections.sort(ActualLinks);
                        Collections.sort(ExternalActualLinks = Constants.GenericToolLinks);
                        Collections.sort(ExternalActualLinks);
                        Assert.assertTrue(ActualLinks.equals(ExternalActualLinks));
                        break;
                }
            }
        }
    }

    public boolean ValidateHeadersinDetails(DataTable table) {
        List<String> expectedHeaders = table.asList(String.class);
        boolean flag = true;
        for (String header : expectedHeaders) {
            Assertions.assertThat(this.elementIsPresent(this.getByusingString(String.format(labelHeader, header))))
                    .isTrue();
        }
        return flag;
    }

    public Boolean ValidateLabelValues(String LabelinUI, String SurroundEligibility) throws Exception {
        String expectedText = "";
        String actualText = "";
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Details");
        ShipmentTrackingDetails ShipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);
        if (LabelinUI.contains("SURROUND ELIGIBILITY")) {
            expectedText = this.getText(this.getByusingString(String.format(this.ValueFromLabel, LabelinUI)));
            actualText = ShipmentTrackingDetails.getShipmentDto().getSurroundEnabledType();
        }
        Assertions.assertThat(expectedText).isEqualTo(actualText);
        return true;
    }

    public boolean ValidateLabelsinTabs(String subHeader) {
        List<String> expectedList = new ArrayList<>();
        List<String> actualList = new ArrayList<>();
        String index = "";
        switch (subHeader) {
            case "Service":
                index = "1";
                expectedList = Constants.ServiceLabels;
                break;
            case "Package":
                index = "2";
                expectedList = Constants.PackageLabels;
                break;
            case "Time Stamps":
                index = "3";
                if (this.commonHelpers.getValuefromContextStore("Status").toString().equalsIgnoreCase("Delivered")) {
                    expectedList = Constants.TimeStampDelivered;
                } else if (this.commonHelpers.getValuefromContextStore("Status").toString()
                        .equalsIgnoreCase("In Transit")) {
                    expectedList = Constants.TimeStampScheduled;
                }
                break;
        }
        for (WebElement element : this.findElements(this.getByusingString(String.format(Labelsxpath, index)))) {
            actualList.add(element.getText());
        }
        Collections.sort(expectedList);
        Collections.sort(actualList);
        return expectedList.size() >= actualList.size();
    }

    /**
     * Check Element is always present in screen if the difference between footer
     * element and Tracking is less than 700 it means we are still able to see
     * Tracking id.
     */
    public boolean checkElement() {
        boolean flag;
        this.waitForDOMToLoad(DriverManager.getDrv());

        // Taking the Tracking id y Coordinates.
        this.waitUntilVisible(By.xpath(trackingId));
        WebElement trackingIdElement = this.findElement(By.xpath(trackingId));
        int yCoordinates_trackingId = trackingIdElement.getLocation().getY();

        // Move to the bottom of screen //
        this.ScrollToBottom();

        WebElement siteMapElement = this.findElement(By.xpath(siteMap));
        int yCoordinates_siteMap = siteMapElement.getLocation().getY();

        flag = yCoordinates_siteMap - yCoordinates_trackingId < 700;

        log.info("Coordinates Difference = " + (yCoordinates_siteMap - yCoordinates_trackingId));
        return flag;
    }

    public boolean VerifyHistoryMode(String historyMode) {
        this.ScrollIntoView(this.findElement(By.xpath(String.format(scanMode, historyMode.toUpperCase()))));
        return this.elementIsDisplayed(By.xpath(String.format(scanMode, historyMode.toUpperCase())));
    }

    public String GetScanEventCount() {
        return String.valueOf(this.findElements(this.columnInScan).size() - 1);
    }

    public void switchScanEventMode(String modeType) {
        if (this.elementIsNotDisplayed(By.xpath(String.format(scanMode, modeType)))) {
            if (!modeType.equalsIgnoreCase("BACK")) {
                this.ScrollIntoView(this.findElement(this.historyTab));
                this.ScrollIntoView(this.findElement(By.xpath(String.format(scanMode, modeType))));
            }
        }
        this.JavaScriptClick(this.findElement(By.xpath(String.format(scanMode, modeType))));

    }

    public HashMap<String, String> GetScanEvent(String event, boolean... exception) {
        HashMap<String, String> eventsFromUI = new HashMap<String, String>();
        this.ScrollToTop();
        if (event.equalsIgnoreCase("last")) {
            if (this.elementIsDisplayed(By.xpath(String.format(scanMode, "COLLAPSE")))) {
                this.ScrollIntoView(this.findElement(By.xpath(String.format(scanMode, "COLLAPSE"))));
                this.clickOnElement(By.xpath(String.format(scanMode, "COLLAPSE")));
            }
            if (exception.length > 0 && exception != null) {
                eventsFromUI.put("date", this.getText(lastEventDate));
            }
            eventsFromUI.put("location", this.getText(lastEventLocation));
            eventsFromUI.put("status", this.getText(lastEventStatus));
            eventsFromUI.put("additionalInfo", this.getText(lastEventDetails));

        } else {
            int eventNumber = Integer.parseInt(event);
            if (exception.length > 0 && exception != null) {
                eventsFromUI.put("date", this.getText(By.xpath(String.format(this.scanEventDate, eventNumber))));
            }
            eventsFromUI.put("location", this.getText(By.xpath(String.format(this.scanEventLocation, eventNumber))));
            eventsFromUI.put("status", this.getText(By.xpath(String.format(this.scanEventStatus, eventNumber))));
            eventsFromUI.put("additionalInfo",
                    this.getText(By.xpath(String.format(this.scanEventDetails, eventNumber))));
        }
        return eventsFromUI;
    }

    public String getTrackingNumberFromCurrentURL() {
        String url = GetCurrentBrowserURL();
        String[] urlParts = url.split("/");
        return urlParts[urlParts.length - 1];
    }

    public String getTrackingNumberFromCurrentURL(String ID) {
        if (ID.equalsIgnoreCase("TrackingNumber")) {
            String url = GetCurrentBrowserURL();
            String[] urlParts = url.split("/");
            return urlParts[urlParts.length - 1].split("_")[1];
        } else
            return "";
    }

    public String getShipperLocationDetailsFromSummaryTab(String locationType) {
        String fullData = "";

        List<WebElement> elm = this.findElements(By.xpath(String.format(shipperLocation, locationType)));

        for (WebElement element : elm)
            fullData = fullData + " " + element.getText();
        return fullData;
    }

    public boolean ValidateShipmentAddressInSummaryTab(Map<String, String> columnTable) {
        List<Boolean> validationflags = new ArrayList<>();

        for (String viewName : columnTable.keySet()) {
            String[] columns = columnTable.get(viewName).trim().split(",");
            String actualValue = getShipperLocationDetailsFromSummaryTab(viewName);// gets values from UI
            log.info("The value from UI for " + viewName + " is = " + actualValue);

            // Validating all values
            if (actualValue.contains(commonHelpers.getValuefromContextStore(columns[0]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[1]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[2]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[3]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[4]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[5]).toString())
                    && actualValue.contains(commonHelpers.getValuefromContextStore(columns[6]).toString())) {
                validationflags.add(false);
            }
        }
        return validationflags.contains(false);
    }

    public Boolean ValidateDetailsinUI(String context, DataTable table) {
        List<String> UIValidations = table.asList(String.class);
        boolean flag = true;
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            if (context.equalsIgnoreCase("status")) {
                for (String key : UIValidations) {
                    if (flag) {
                        flag = this.elementIsDisplayed(this.getByusingString(String.format(this.SummaryBarxpath,
                                (this.commonHelpers.getValuefromContextStore(key).toString()))));
                    }
                }
            } else if (context.equalsIgnoreCase("dates")) {
                flag = this
                        .elementIsDisplayed(
                                this.getByusingString(String.format(this.SummaryBarxpath, "Delivered Time")));
                for (String key : UIValidations) {
                    if (flag) {
                        flag = this.elementIsDisplayed(this.getByusingString(String.format(this.SummaryBarxpath,
                                (this.commonHelpers.getValuefromContextStore(key).toString()))));
                    }
                }
            } else if (context.equalsIgnoreCase("estimatedDateTime")) {
                flag = this.elementIsDisplayed(
                        this.getByusingString(String.format(this.SummaryBarxpath, "ESTIMATED SCHEDULED DELIVERY")));
                for (String key : UIValidations) {
                    if (flag) {
                        flag = this.elementIsDisplayed(this.getByusingString(String.format(this.SummaryBarxpath,
                                (this.commonHelpers.getValuefromContextStore(key).toString()))));
                    }
                }
            } else if (context.equalsIgnoreCase("Scheduled Delivery Date")) {
                flag = this.elementIsDisplayed(
                        this.getByusingString(String.format(this.SummaryBarxpath, "SCHEDULED DELIVERY")));
                for (String key : UIValidations) {
                    if (flag) {
                        flag = this.elementIsDisplayed(this.getByusingString(String.format(this.SummaryBarxpath,
                                (this.commonHelpers.getValuefromContextStore(key).toString()))));
                    }
                }
            }
        }
        return flag;
    }

    public boolean ValidateExceptionIcon(String event) {
        int eventNumber = Integer.parseInt(event);
        return this.elementIsDisplayed(By.xpath(String.format(exceptionIcon, eventNumber)));
    }

    public void NavigateToSection(String section) {
        this.clickOnElement(this.getByusingString(String.format(commentsTab, section)));
    }

    public boolean VerifyAddCommentButtonIsDisplayed() {
        return this.elementIsDisplayed(addCommentButton);
    }

    public void ClickOnAddCommentButton() {
        this.clickOnElement(addCommentButton);
    }

    public boolean VerifyICalledOptions(DataTable dataTable) {
        boolean flag = true;
        List<String> values = dataTable.asList(String.class);
        for (String item : values) {
            if (this.elementIsNotDisplayed(By.xpath(String.format(iCalledRadioButtons, item)))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public boolean VerifyRadioButtonIsSelected(String value) {
        return this.findElement(By.xpath(String.format(defaultRadioButton, value))).isSelected();
    }

    public void SelectOptioninICalledField(String optionToSelect) {
        this.clickOnElement(By.xpath(String.format(iCalledRadioButtons, optionToSelect)));
    }

    public boolean VerifyShipperOptionFields(DataTable table) {
        boolean flag = true;
        List<String> values = table.asList(String.class);
        for (String item : values) {
            if (flag) {
                switch (item) {
                    case "ENTER CASE ID(S)":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperField, item)));
                        break;
                    case "CALL STATUS":
                    case "CASE STATUS":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperFieldDropDown, item)));
                        break;
                }
            } else
                break;
        }
        return flag;

    }

    public String GetMaxLimitOfTextBox() {
        return this.findElement(leaveCommentTextBox).getAttribute("maxlength");
    }

    public void AddDetailsForAddComment(Map<String, String> table) {
        for (String expkey : table.keySet()) {
            switch (expkey) {
                case "I called":
                case "CALL STATUS":
                case "CASE STATUS":
                    this.selectDropdown((By.xpath(String.format(addCommentShipperFieldDropDown, expkey))), "text",
                            table.get(expkey));
                    break;
                case "SPECIFY CALL PARTY":
                    this.elementIsDisplayed(specifyCallParty);
                    this.clickOnElement(specifyCallParty);
                    this.enterText(specifyCallParty, table.get(expkey));
                    break;
                case "ENTER CASE ID(S)":
                    this.clickOnElement(By.xpath(String.format(caseIdTextField, expkey)));
                    this.enterText(By.xpath(String.format(caseIdTextField, expkey)), table.get(expkey));
                    break;
                case "Comments":
                    String comment = GetShipmentComment(table.get(expkey));
                    if (table.get(expkey).contains("ContextStore-")) {
                        comment = (String) this.commonHelpers.getValuefromContextStore(table.get(expkey).split("-")[1]);
                    }
                    this.selectDropdown((By.xpath(String.format(addCommentShipperFieldDropDown, expkey))), "text",
                            comment);

                    // this.clickOnElement(leaveCommentTextBox);
                    // this.enterText(leaveCommentTextBox, table.get(expkey));
                    break;
                case "DATE TIME":
                    this.commonHelpers.AddToContextStore(table.get(expkey),
                            this.getCurrentDateinFormat("MM/dd/YYYY,HH:mm").replace("IST", ""));
                    break;
            }
        }
    }

    public String GetShipmentComment(String comment) {
        String ShipmentComment = "";
        switch (comment) {
            case "DELAY IN TRANSIT":
                ShipmentComment = Constants.ShipmentCommentDelayInTransit;
                break;
            case "EXPECT DELIVERY TODAY":
                ShipmentComment = Constants.ShipmentCommentExpectDeliveryToday;
                break;
            case "EXPECT DELIVERY NEXT":
                ShipmentComment = Constants.ShipmentCommentExpectDeliveryNext;
                break;
            case "INTERVENTION EXPECT DELIVERY TODAY":
                ShipmentComment = Constants.ShipmentCommentInterventionExpectDeliveryToday;
                break;
            case "INTERVENTION EXPECT NEXT BUSINESS":
                ShipmentComment = Constants.ShipmentCommentInterventionExpectNextBusiness;
                break;
            case "MONITORING FOR UPDATES":
                ShipmentComment = Constants.ShipmentCommentMonitoringForUpdates;
                break;
            case "NATIONAL SERVICE DISRUPTION":
                ShipmentComment = Constants.ShipmentCommentNationalServiceDisruption;
                break;
            case "REQUEST REATTEMPT":
                ShipmentComment = Constants.ShipmentCommentRequestReattempt;
                break;
            case "SERVICE UPGRADE REQUESTED":
                ShipmentComment = Constants.ShipmentCommentServiceUpgradeRequested;
                break;
        }
        return ShipmentComment;
    }

    public void ClickOnLinkInComment(String linkName) {
        this.clickOnElement(By.xpath(String.format(linksInComment, linkName)));
    }

    public boolean VerifyDataDisplayedInCommentList(Map<String, String> table) {
        boolean flag = true;
        for (String expkey : table.keySet()) {
            if (flag) {
                switch (expkey) {
                    case "I called":
                        flag = this.findElement(secondColumn).getAttribute("textContent")
                                .contains("Called" + ": " + table.get(expkey));
                        break;
                    case "NAME":
                        flag = this.findElement(firstColumn).getAttribute("textContent").equals(table.get(expkey));
                        break;
                    case "COMMENT":
                        String comment = GetShipmentComment(table.get(expkey));
                        if (table.get(expkey).contains("ContextStore-")) {
                            comment = (String) this.commonHelpers
                                    .getValuefromContextStore(table.get(expkey).split("-")[1]);
                        }
                        flag = this.findElement(thirdColumn).getAttribute("textContent").replaceAll("\\s", "")
                                .equals(comment.replaceAll("\\s", ""));
                        break;
                    case "ENTER CASE ID(S)":
                        flag = this.findElement(secondColumn).getAttribute("textContent")
                                .contains("Case Id" + ": " + table.get(expkey));
                        break;
                    case "CALL STATUS":
                        flag = this.findElement(secondColumn).getAttribute("textContent")
                                .contains("Call status" + ": " + table.get(expkey));
                        break;
                    case "CASE STATUS":
                        flag = this.findElement(secondColumn).getAttribute("textContent")
                                .contains("Case Status" + ": " + table.get(expkey));
                        break;
                    case "DATE TIME":
                        flag = this.findElement(secondColumn).getAttribute("textContent").contains(
                                this.commonHelpers.getValuefromContextStore(table.get(expkey)).toString().split("/")[2]
                                        .substring(0, 4));
                        break;
                }
            }
        }
        return flag;
    }

    public boolean VerifyRequiredFieldsInCommentSection(DataTable table) {
        boolean flag = true;
        List<String> expValues = table.asList(String.class);
        WebElement elem = this.findElement(requiredFields);
        List<WebElement> options = elem.findElements(By.tagName("label"));
        for (WebElement option : options) {
            if (flag) {
                for (String value : expValues) {
                    if (option.getText().equals(value)) {
                        flag = true;
                        break;
                    } else {
                        flag = false;
                    }
                }
            }
        }
        return flag;
    }

    public boolean ValidateEllipsesOptionsForComment(DataTable dataTable) {
        boolean flag = true;
        List<String> expValues = dataTable.asList(String.class);
        this.clickOnElement(commentEllipses);
        WebElement elem = this.findElement(ellipsesExpand);
        List<WebElement> options = elem.findElements(By.tagName("li"));
        for (WebElement option : options) {
            if (flag) {
                WebElement option2 = option.findElement(By.tagName("button"));
                for (String value : expValues) {
                    if (option2.getText().equals(value)) {
                        flag = true;
                        break;
                    } else {
                        flag = false;
                    }
                }
            }
        }
        this.clickOnElement(commentEllipses);
        return flag;
    }

    public void SelectOptionsForComment(String option) {
        this.clickOnElement(commentEllipses);
        this.clickOnElement((By.xpath(String.format(commentEllipsesDropDown, option))));
    }

    public boolean VerifyDataIsAutoPopulatedWhenEditCommentIsClicked(Map<String, String> table) {
        boolean flag = true;
        for (String expkey : table.keySet()) {
            if (flag) {
                switch (expkey) {
                    case "I CALLED":
                        Select select = new Select(
                                this.findElement((By.xpath(String.format(addCommentShipperFieldDropDown, expkey)))));
                        WebElement option = select.getFirstSelectedOption();
                        String defaultItem = option.getText();
                        flag = defaultItem.equalsIgnoreCase(table.get(expkey));
                        break;
                    case "ENTER CASE ID(S)":
                        String commentCase = this.findElement(By.xpath(String.format(caseIdTextField, expkey)))
                                .getAttribute("value");
                        flag = commentCase.equalsIgnoreCase(table.get(expkey));
                        break;
                    case "CALL STATUS":
                    case "CASE STATUS":
                        select = new Select(
                                this.findElement((By.xpath(String.format(addCommentShipperFieldDropDown, expkey)))));
                        option = select.getFirstSelectedOption();
                        defaultItem = option.getText();
                        flag = defaultItem.equalsIgnoreCase(table.get(expkey));
                        break;
                    case "COMMENT":
                        commentCase = this.findElement(leaveCommentTextBox).getAttribute("value");
                        flag = commentCase.equalsIgnoreCase(table.get(expkey));
                        break;
                }
            } else
                break;
        }
        return flag;
    }

    public boolean VerifyButtonIsDisplayedInConfirmationDialog(DataTable dataTable) {
        List<String> expValues = dataTable.asList(String.class);
        boolean flag = true;
        for (String button : expValues) {
            if (flag) {
                if (button.contains("Delete"))
                    flag = this.elementIsDisplayed(this.getByusingString(this.getXPathforButton(button)));
                else if (button.contains("Cancel"))
                    flag = this.elementIsDisplayed(By.xpath(String.format(cancelButtonConfirmationDialog, button)));
            }
        }
        return flag;
    }

    public boolean VerifyLinkInCommentSection(String linkName) {
        return this.elementIsDisplayed(By.xpath(String.format(linksInComment, linkName)));
    }

    public void ClickOnButtonIsDisplayedInConfirmationDialog(String button) {
        if (button.contains("Delete")) {
            this.commonHelpers.AddToContextStore("TotalComments", this.findElements(this.AllComments).size());
            this.clickOnElement(By.xpath(String.format(deleteButtonConfirmationDialog, button)));
        } else if (button.contains("Cancel"))
            this.clickOnElement(By.xpath(String.format(cancelButtonConfirmationDialog, button)));
    }

    public Boolean VerifyConfirmationDialogIsDisplayedWithErrorMessage() {
        boolean flag = true;
        if (this.elementIsDisplayed(confirmationDialog))
            flag = this.elementIsDisplayed(
                    (By.xpath(String.format(errorMessageXpath, Constants.deleteCommentConfirmationMessage))));
        return flag;
    }

    public boolean VerifyCommentIsDeletedFromCommentList() {
        boolean flag = true;
        flag = Integer.parseInt(this.commonHelpers.getValuefromContextStore("TotalComments").toString()) > this
                .findElements(this.AllComments).size();
        return flag;
    }

    public boolean VerifyGivenTextisDisplayed(String textString) {
        String trackingId = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        return this.elementIsDisplayed(this.getByusingString(this.buildXpathForString(trackingId)));
        // this.waitUntilNotVisible(this.loadingIndicator);
        // return this.elementIsDisplayed(By.xpath(textString));
    }

    public Map<String, String> GetUIDetail(List<String> fields) {
        Map<String, String> uiData = new HashMap<>();
        uiData.put("Tracking Number", this.commonHelpers.getValuefromContextStore("Tracking Number").toString());
        // uiData.put("Status",
        // this.commonHelpers.GetValuefromContextStore("Status").toString());
        for (String field : fields) {
            String value;
            if ("Commit Timer".equals(field)) {
                value = this.getText(this.commitTimer).trim();
                if (value.contains("hr")) {
                    uiData.put(field, value.split("r")[0].replace("Commit ", ""));
                } else if (value.contains("Past")) {
                    uiData.put(field, value.split(" ")[0]);
                }
            }
        }
        return uiData;
    }

    public Boolean ValidateLastColumnContainsPreferredDateFormat(String preferredDateFormat) {
        String trackNumber = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        DateFormat dateFormat;
        By lastCommentColumnValue = By.xpath(String.format(lastCommentColumn, trackNumber));
        String preDate = this.commonHelpers.getValuefromContextStore("PreferredDateFormat").toString();
        if (preDate.equals("DD-MMM-YYYY")) {
            String pFormat = preDate.replace("DD", "dd");
            dateFormat = new SimpleDateFormat(pFormat);
        } else {
            String pFormat = preDate.replace("DD", "d").replace("MM", "M");
            dateFormat = new SimpleDateFormat(pFormat);
        }
        String currentDate = dateFormat.format(new Date());
        String lastcolumnDate = this.getText(lastCommentColumnValue).split(",")[0].trim();
        return lastcolumnDate.equals(currentDate);
    }

    public void clickOnFirstTrackingNumberInList() {
        this.clickOnElement(firstTrackingNumberInList);
    }

    public Boolean ValidateLastCommentColumContainsSystemTimEZone() {
        SimpleDateFormat sdf = new SimpleDateFormat("z");
        String trackNumber = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        By lastCommentColumnValue = By.xpath(String.format(lastCommentColumn, trackNumber));
        return this.getText(lastCommentColumnValue).contains(sdf.format(new Date()));

    }

    public void AddLastCommentToContextStore(String lastComment) {
        String lastCommentDateAndTime = this.getText(lastCommentAddedDateTime);
        String[] arrString = lastCommentDateAndTime.split("\\r\\n");
        this.commonHelpers.AddToContextStore(lastComment, arrString[0].trim());
    }

    public String GetLastCommentDateTimeValueFromShipmentsPage() {
        String trackNumber = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        By lastCommentColumnValue = By.xpath(String.format(lastCommentDateTimeColumn, trackNumber));
        return this.getText(lastCommentColumnValue);
    }

    public String GetLastCommentValueFromShipmentsPage() {
        String trackNumber = this.commonHelpers.getValuefromContextStore("Tracking Number").toString();
        By lastCommentColumnValue = By.xpath(String.format(lastCommentColumn, trackNumber));
        return this.getText(lastCommentColumnValue);
    }

    /**
     * This method click watchlist icon
     *
     * @param textString
     * @return
     */
    public void WatchlistIconsClick(String textString) {
        switch (textString) {
            case "starIcon":
                this.clickOnElement(watchIcon);
                break;
            case "unwatch":
                this.clickOnElement(watchFilled);
                break;
            case "watch":
                this.clickOnElement(watchEmpty);
                break;
        }

    }

    /**
     * This method to verify watchlist icon
     *
     * @param textString
     * @return
     */
    public boolean VerifyWatchlist(String textString) {
        switch (textString) {
            case "watched":
                return this.elementIsDisplayed(this.getByusingString(String.format(watchedText, "watched")));
            case "unwatched":
                return this.elementIsDisplayed(this.getByusingString(String.format(watchedText, "unwatched")));
        }
        return false;
    }

    public void SelectOptionsForCommentByRow(String option, String row) {
        this.clickOnElement(By.xpath(String.format(commentEllipseRow, row)));
        this.clickOnElement((By.xpath(String.format(commentEllipsesDropDown, option))));
    }

    /**
     * This method verifies prediction status in details page
     *
     * @param status
     * @return boolean
     */
    public Boolean verifyPredictionStatusInDetailsPage(String status) {
        return this.elementIsDisplayed(By.xpath(String.format(predictionStatus, status)), true);
    }

    public Boolean verifyInterventionReason(String interventionReason) {
        String interventionText = this.getText(interventionReasonSection);
        return interventionText.contains(interventionReason);
    }

    public Boolean verifyscanEventColumnHeaderInDetailsPage(String header) {
        return this.elementIsDisplayed(By.xpath(String.format(this.scanEventColumnHeader, header)), true);
    }

    public Boolean validateReturnScanCodeLink(String keyToStore, String isClickable) {
        boolean flag;
        String returnTrackNum = this.commonHelpers.getValuefromContextStore(keyToStore).toString();
        if (!this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("user")) {
            String actualReturnCodeText = this.getText(returnToShipperLabel).replace("\n", "").replace("\r", "");
            if (isClickable.equalsIgnoreCase("clickable")) {
                Assert.assertEquals("Pkg returned text not shown", "Pkg returned to shipper   " + returnTrackNum,
                        actualReturnCodeText);
                this.clickOnElement(this.getByusingString(String.format(this.returnTrackNumberLink, returnTrackNum)));
            } else {
                Assert.assertEquals("Return Tracking Number text not shown",
                        "Return Tracking Number   " + returnTrackNum, actualReturnCodeText);
            }
            flag = true;
        } else {
            flag = this.getText(CustomerreturnToShipperLabel).replace("\n", "").replace("\r", "")
                    .equalsIgnoreCase(Constants.CustomerReturnTrckLabel + returnTrackNum);
            if (isClickable.equalsIgnoreCase("clickable")) {
                Assert.assertTrue("Return Tracking Number is not clickable",
                        this.IsElementEnabled(By.xpath(this.GetxpathForLink(returnTrackNum))));
                this.clickOnElement(this.getByusingString(String.format(this.returnTrackNumberLink, returnTrackNum)));
            } else {
                Assert.assertFalse("Return Tracking Number is clickable",
                        this.IsElementEnabled(By.xpath(this.GetxpathForLink(returnTrackNum))));
            }
            flag = true;
        }
        return flag;
    }

    public Boolean validateTrackingNumberOnShipmentDetails(String keyToStore) {
        String trackingNumber = this.commonHelpers.getValuefromContextStore(keyToStore).toString();
        // this.Mouse_MoveToElement(
        // this.findElement(By.xpath(String.format(this.trackingNumberOnSummaryBar,
        // trackingNumber))));
        return this.elementIsDisplayed(
                this.getByusingString(String.format(this.trackingNumberOnSummaryBar, trackingNumber)));
    }

    public boolean VerifyICalledOptions(String dropDown, DataTable dataTable) {
        boolean flag = true;
        // this.navigateToElement(By.xpath(String.format(clickDropDownBox, dropDown)));
        this.clickOnElement(By.xpath(String.format(clickDropDownBox, dropDown)));
        List<String> values = dataTable.asList(String.class);
        for (String item : values) {
            if (this.elementIsDisplayed(By.xpath(String.format(iCalledDDXpath, item)))) {
                flag = true;
            } else {
                flag = false;
                break;
            }
        }
        this.findElement(By.xpath(String.format(clickDropDownBox, dropDown))).sendKeys(Keys.ESCAPE);
        return flag;
    }

    public void clickOnButton(String buttonText) {
        if(elementIsDisplayed(selectDelectShipmentID)){
            this.clickOnElement(selectDelectShipmentID);
        }
        if ((buttonText.equals("Download") && this.commonHelpers.getValuefromContextStore("DownloadType") != null
                && this.commonHelpers.getValuefromContextStore("DownloadType").toString().contains("COMBINED FILES"))) {
            this.ScrollIntoView(findElement(By.xpath(String.format(buttonXpathCombinedFiles, buttonText))));
            this.Mouse_MoveToElement(findElement(By.xpath(String.format(buttonXpathCombinedFiles, buttonText))));
            this.clickOnElement(By.xpath(String.format(buttonXpathCombinedFiles, buttonText)));
        } else {
            this.ScrollIntoView(findElement(By.xpath(String.format(buttonXpath, buttonText))));
            this.Mouse_MoveToElement(findElement(By.xpath(String.format(buttonXpath, buttonText))));
            this.clickOnElement(By.xpath(String.format(buttonXpath, buttonText)));
        }
    }

    public boolean VerifyLogCallOptions(DataTable table) {
        boolean flag = true;
        List<String> values = table.asList(String.class);
        for (String item : values) {
            if (flag) {
                switch (item) {
                    case "ENTER CASE ID(S)":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperField, item)));
                        break;
                    case "CALL STATUS":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperField, item)));
                        break;
                    case "CASE STATUS":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperField, item)));
                        break;
                    case "ICALLED":
                        flag = this.elementIsDisplayed(By.xpath(String.format(addCommentShipperField, item)));
                        break;
                    case "COMMENT":
                        flag = this.elementIsDisplayed(leaveCommentTextBox)
                                && this.GetMaxLimitOfTextBox().equals("500");
                        break;
                    case "LOG CALL":
                        flag = this.elementIsDisplayed(logCallLink);
                        break;
                    case "CANCEL":
                        flag = this.elementIsDisplayed(cancelLink);
                        break;
                    case "ADD INTERNAL COMMENT":
                        flag = this.elementIsDisplayed(addInternalCommentLink);
                        break;
                }
            } else
                break;
        }
        return flag;
    }

    public String getMaxLimitiOfTextArea(String field) {
        return this.findElement(By.xpath(String.format(inputText, field))).getAttribute("maxlength");
    }

    public void selectValueFromDD(String dropDown, String option) {
        this.clickOnElement(By.xpath(String.format(clickDropDownBox, dropDown)));
        this.clickOnElement(By.xpath(String.format(iCalledDDXpath, option)));
    }

    public void AddDetailsForLogCall(Map<String, String> table) {
        for (String expkey : table.keySet()) {
            switch (expkey) {
                case "I CALLED":
                    this.selectDropdown((By.xpath(String.format(iCalledDDXpath, expkey))), "text", table.get(expkey));
                    break;
                case "ENTER CASE ID(S)":
                    this.clickOnElement(By.xpath(String.format(caseIdTextField, expkey)));
                    this.enterText(By.xpath(String.format(caseIdTextField, expkey)), table.get(expkey));
                    break;
                case "CALL STATUS":
                    this.selectDropdown((By.xpath(String.format(iCalledDDXpath, expkey))), "text", table.get(expkey));
                    break;
                case "CASE STATUS":
                    this.selectDropdown((By.xpath(String.format(iCalledDDXpath, expkey))), "text", table.get(expkey));
                    break;
                case "COMMENT":
                    this.clickOnElement(leaveCommentTextBox);
                    this.enterText(leaveCommentTextBox, table.get(expkey));
                    break;
                case "DATE TIME":
                    this.commonHelpers.AddToContextStore(table.get(expkey),
                            this.getCurrentDateinFormat("MM/dd/YYYY,HH:mm").replace("IST", ""));
                    break;
            }
        }
    }

    public boolean VerifyButtonsInCommentsSection(DataTable dataTable) {
        List<String> expValues = dataTable.asList(String.class);
        boolean flag = true;
        for (String button : expValues) {
            if (flag) {
                if (button.contains("Log call"))
                    flag = this.elementIsDisplayed(logCallButton);
                else if (button.contains("Add internal comment"))
                    flag = this.elementIsDisplayed(addInternalCommentButton);
            }
        }
        return flag;
    }

    public Boolean ValidateLabelValuesInShipmentDetails(String LabelinUI, String page) throws Exception {
        String expectedText;
        String actualText;
        ShipmentTrackingDetails ShipmentTrackingDetails;
        if (page.equalsIgnoreCase("CE_Shipments_Details")) {
            Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Details");
            ShipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(), ShipmentTrackingDetails.class);
            actualText = "SenseAware ID - " + ShipmentTrackingDetails.getShipmentDto().getSenseAwareIdSerial();
        } else {
            actualText = "SenseAware ID";
        }
        this.Mouse_MoveToElement(this.findElement(By.xpath(String.format(this.ValueFromLabel, LabelinUI))));
        expectedText = this.getText(this.getByusingString(String.format(this.ValueFromLabel, LabelinUI)));
        return expectedText.equalsIgnoreCase(actualText);
    }

    public boolean VerifyFieldVisibilityInShipmentDetails(DataTable table) {
        Map<String, String> fields = table.asMap(String.class, String.class);
        boolean flag = false;
        HashSet<Boolean> flags = new HashSet<>();
        for (String field : fields.keySet()) {
            if (fields.get(field).equalsIgnoreCase("visible")) {
                flag = this.elementIsDisplayed(By.xpath(String.format(this.ValueFromLabel, field)), true);
            } else if (fields.get(field).equalsIgnoreCase("invisible")) {
                flag = this.elementIsNotDisplayed(By.xpath(String.format(this.ValueFromLabel, field)));
            }
            flags.add(flag);
        }
        return !flags.contains(false);
    }

    public String getStatusDetailFromShipmentDetails() {
        return this.getText(statusDetailReason);
    }

    public void AddStatusDetailsToContextStore(String desiredColumn) {
        String columnValueText = this.getStatusDetailFromShipmentDetails();
        this.commonHelpers.AddToContextStore(desiredColumn, columnValueText);
    }

    public boolean ValidateShipmentJourneyMap(DataTable dataTable) {
        List<String> expValues = dataTable.asList(String.class);
        boolean flag = this.elementIsDisplayed(journeyMapShipmentDetails);
        for (String value : expValues) {
            if (flag) {
                if (value.equalsIgnoreCase("Package Destination Location"))
                    flag = this.elementIsDisplayed(destinationPinIcon);
                else if (value.equalsIgnoreCase("Package Current Location"))
                    flag = this.elementIsDisplayed(deliveryVehicleIcon);
            }
        }
        return flag;
    }

    public boolean ValidateUpdatedTime(String preferredDateFormat) throws ParseException {
        boolean flag = this.elementIsDisplayed(journeyMapShipmentDetails);
        if (flag) {
            flag = this.elementIsDisplayed(updatedTimeMap)
                    && this.getText(updatedTimeMap).contains(Constants.UpdatedTimeMap);
        }
        return flag;
    }

    public boolean ValidateMapRefreshTime() {
        String actualText = "";
        int seconds = 0;
        if (this.elementIsDisplayed(journeyMapShipmentDetails)) {
            if (this.IsElementEnabled(countDownInSecMap)) {
                actualText = this.getText(countDownInSecMap);
                seconds = Integer.parseInt(actualText.replaceAll("[^0-9]", ""));
            }
        }
        return actualText.contains(Constants.MapRefreshText) && (seconds <= 120 && seconds >= 1);
    }

    public Boolean IsPredictionDataDisplayed() {
        Boolean flag = true;
        flag = this.elementIsDisplayed(predictionData);
        return flag;
    }

    public Boolean ValidateShipmentHistoryForShipper(String endPointKey, DataTable dataTable) throws Throwable {
        boolean flag = true;
        List<String> TableHeaders = dataTable.asList(String.class);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                ShipmentTrackingDetails.class);

        this.apiCall.get_the_user_preferences_using_for_the_user("MS_Preferences_user", "MS");
        int count = 0;
        for (ScanEventList scanEventList : shipmentTrackingDetails.getTrackingApiDto().getScanEventList()) {
            if (count < 10) {
                for (String column : TableHeaders) {
                    if (flag) {
                        switch (column) {
                            case "DATE":
                                flag = this.elementIsDisplayed(this.getByusingString(
                                        String.format(historyTableXpathShipper, scanEventList.getDate())));
                                break;
                            case "TIME":
                                TimeZone destTZ = TimeZone
                                        .getTimeZone(
                                                ZoneId.of(shipmentTrackingDetails.getTrackingApiDto().getDestTZ()));
                                TimeZone srcTz = TimeZone.getTimeZone(ZoneId.of(scanEventList.getGmtOffset()));
                                if (destTZ.equals(srcTz)) {
                                    flag = this.elementIsDisplayed(this.getByusingString(String
                                            .format(historyTableXpathShipper,
                                                    scanEventList.getTime().subSequence(0, 5))));
                                } else {
                                    String sourceDate = scanEventList.getDate() + " " + scanEventList.getTime();
                                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    formatter.setTimeZone(srcTz);
                                    Date date = new Date();
                                    try {
                                        date = formatter.parse(sourceDate);
                                    } catch (ParseException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    formatter.setTimeZone(destTZ);
                                    String targetDateTime = formatter.format(date);
                                    String targetTime = targetDateTime.split(" ")[1];
                                    flag = this.elementIsDisplayed(this.getByusingString(
                                            String.format(historyTableXpathShipper, targetTime.subSequence(0, 5))));
                                }
                                break;
                        }
                    } else {
                        break;
                    }
                }
                count++;
            }
            if (!flag) {
                break;
            }
        }
        return flag;
    }

    public Boolean verifyCERHeaders(Map<String, String> columns) {
        boolean flag = false;
        for (String column : columns.keySet()) {
            if (columns.get(column).equalsIgnoreCase("visible")) {
                flag = this.elementIsDisplayed(By.xpath(String.format(this.labelHeader, column.toUpperCase())), true);
            } else if (columns.get(column).equalsIgnoreCase("invisible")) {
                flag = this.elementIsNotDisplayed(By.xpath(String.format(this.labelHeader, column.toUpperCase())));
            }
        }
        return flag;
    }

    public Boolean VerifyColumnPosition(String order, String tab, DataTable table) {
        boolean flag = false;
        int i = 1;
        int count = 3;
        Map<String, String> expectedPositions = table.asMap(String.class, String.class);
        Map<String, String> actualPosition = new HashMap<>();
        Map<String, String> actualPositionTemp = new HashMap<>();

        if (tab.equalsIgnoreCase("SEP")) {
            tab = "1";
        } else if (tab.equalsIgnoreCase("FUSION")) {
            tab = "2";
        }

        if (order.equalsIgnoreCase("first")) {
            this.ScrollToLeft(this.findElement(ScrollBar));
        } else if (order.equalsIgnoreCase("second")) {
            this.clickOnElement(By.xpath(String.format(this.firstColumnHeader,
                    tab)));
            for (int k = 0; k < 6; k++) {
                this.keyBoardEvent(Keys.TAB);
            }

        }

        List<WebElement> elements = this.findElements(By.xpath(String.format(this.columnPositionInDetailsPage, tab)));

        for (WebElement element : elements) {
            actualPosition.put(String.valueOf(i), element.getText().trim());
            i++;
        }

        if (order.equalsIgnoreCase("second")) {

            for (int x = actualPosition.size(); x > 0; x--) {
                // count = 3;
                actualPositionTemp.put(String.valueOf(count), actualPosition.get(String.valueOf(x)));
                count--;

                if (count == 0)
                    break;
            }
            actualPosition.clear();
            actualPosition = actualPositionTemp;
        }

        for (String expectedPosition : expectedPositions.keySet()) {
            flag = expectedPositions.get(expectedPosition).equalsIgnoreCase(actualPosition.get(expectedPosition));

            if (!flag)
                break;
        }
        return flag;

    }

    public Boolean VerifyPayerIconInDetailsPage(String icon, String check) {
        By xpath = By.xpath("");
        boolean flag = false;
        if (icon.equalsIgnoreCase("Payer")) {
            xpath = this.payerIconInDetailsPage;
        }

        if (check.equalsIgnoreCase("Visible"))
            flag = this.elementIsDisplayed(xpath);
        else if (check.equalsIgnoreCase("Invisible"))
            flag = this.elementIsNotDisplayed(xpath);

        return flag;
    }

    public boolean VerifyShipmentDetailsCommentDropdown(String dropDown, DataTable dataTable) {
        HashSet<Boolean> result = new HashSet<>();
        List<String> dropdownItems = dataTable.asList(String.class);
        List<String> actualDropdownItems = new ArrayList<>();
        List<String> expectedDropdownItems = new ArrayList<>();

        for (String dropdown : dropdownItems) {
            expectedDropdownItems.add(this.GetShipmentComment(dropdown));
        }
        for (WebElement element : this.findElements(By.xpath(String.format(commentDropdown, dropDown)))) {
            result.add(expectedDropdownItems.contains(element.getText()));
        }
        return !result.contains(false);
    }

    public void updateComment(String action, String dropdown, DataTable dataTable) {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        this.clickOnElement(By.xpath(String.format(this.commentContextMenu, dropdown)));
        if (action.equalsIgnoreCase("edit")) {
            this.clickOnElement(By.xpath(this.commentEditButton));
            this.AddDetailsForAddComment(table);
            if (dropdown.equalsIgnoreCase("Internal Comment"))
                this.clickOnElement(By.xpath(this.updateComment));
            else if (dropdown.equalsIgnoreCase("Call Logged"))
                this.clickOnElement(By.xpath(this.updateLogCall));
        } else if (action.equalsIgnoreCase("delete")) {
            this.clickOnElement(By.xpath(this.commentDeleteButton));
            this.clickOnElement(By.xpath(String.format(this.commentDeleteCancelPopup, "Delete")));
        }
    }

    public List<String> getActiveShipmentStatusList() {
        List<String> shipmentStatusListofMyShipmentsPage = new ArrayList<>();
        this.clickOnElement(By.xpath(String.format(linksInComment, "FILTERS")));
        this.clickOnLastElement(this.ShipmentStatus);
        this.clickOnLastElement(this.ShipmentStatus);
        for (WebElement element : this.findElements(this.getByusingString(this.ShipmentStatusListFromMyShipments))) {
            shipmentStatusListofMyShipmentsPage.add(element.getText());
        }
        shipmentStatusListofMyShipmentsPage.removeAll(Constants.inactiveShipmentStatusList);
        return shipmentStatusListofMyShipmentsPage;
    }

    public boolean validateTabSequence(String tabName) {
        boolean result = false;
        int shipmentDataIndex = 1;
        List<WebElement> elementsList = this.findElements(this.tabsOnShipmentDetails);
        if (tabName.equals("all")) {
            boolean tabNo = elementsList.size() >= 4;
            String[] tabsArray = {"History(SEP)", "History(Fusion)", "Shipment Data", "Commodity Information",
                    "Tooling", "Comments"};
            List<String> tabsList = Arrays.asList(tabsArray);
            boolean tabDisplayd = true;
            for (WebElement tab : elementsList) {
                String tabNameAct = tab.getText();
                if (tabsList.indexOf(tabNameAct) == -1) {
                    tabDisplayd = false;
                }
            }
            result = tabNo && tabDisplayd;
        } else {
            for (int i = 0; i < elementsList.size(); i++) {
                String actTabName = elementsList.get(i).getText();
                if (actTabName.equalsIgnoreCase("Shipment Data")) {
                    shipmentDataIndex = i + 1;
                }
                if (actTabName.equalsIgnoreCase(tabName) && shipmentDataIndex < i + 1) {
                    log.info("Actual tabname from UI is " + actTabName + " and tabname to be matched with is "
                            + tabName);
                    result = true;
                    break;
                }
            }
        }

        return result;
    }

    public void setTextInPersonalNoteTextbox(String textToEnter) {
        this.enterText(personalNotetextbox, textToEnter);
    }

    public boolean validateDateFormatAndNote(String expectedNote, String expDate) {
        boolean flag = false;
        List<WebElement> elementsList = this.findElements(this.personalNoteTable);
        // Check f Note is not saved after clciking Cancel button
        if (expectedNote == "" && expDate == "") {
            return elementsList.size() == 0;
        }
        expectedNote = this.commonHelpers.getValuefromContextStore("personalNotesMessage").toString();
        String date = elementsList.get(0).getText();
        String[] expDateFormat = expDate.split(",");
//        String expDateFormatted = expDateFormat[1] + " " + expDateFormat[0];
        String expDateFormatted = expDateFormat[1].trim().split(" ")[0] + " " + expDateFormat[0];

        String actulaNote = elementsList.get(1).getText();
        if (actulaNote.equals(expectedNote) && expDateFormatted.contains(date)) {
            flag = true;
        }
        return flag;
    }

    public boolean validatePersonalNoteDetailsFields(String note, String charLimitText, boolean textboxStatus) {
        boolean flag = false;
        List<WebElement> elementsList = this.findElements(this.personalNoteDetails);
        String noteLabel = elementsList.get((0)).getText();
        String charLimit = elementsList.get((1)).getText();
        String buttons = elementsList.get((2)).getText();
        boolean noteTextFieldEnabled = this.IsElementEnabled((this.personalNotetextbox));
        if (noteLabel.equals(note) && charLimit.equals(charLimitText) && textboxStatus == noteTextFieldEnabled) {
            flag = true;
        }

        return flag;
    }

    public boolean validateNoteFieldLimit() {
        try {
            // Add some characters in field and check if character limit is decreased
            String textToSend = "Test Automation";
            int maxLim = 120;
            String charLimitAfterSettingtext = String.valueOf(maxLim - textToSend.length());
            this.setTextInPersonalNoteTextbox(textToSend);
            // Validate character limit of field after entering text
            String charRemain = this.getText(this.pesonalNoteInfo);
            Assert.assertEquals(charLimitAfterSettingtext, charRemain);
            // Check if field is not editable after enetring maximum characters
            String maxChar = this.commonHelpers.generateRandomString(maxLim);
            this.setTextInPersonalNoteTextbox(maxChar);
            String charRemainLast = this.getText(this.pesonalNoteInfo);
            Assert.assertEquals("0", charRemainLast);
            // Validate Special Charcaters are acceptable
            String specChar = "- / and () and +=-_*&%$#@!:;";
            String speclCharLen = String.valueOf(maxLim - specChar.length());
            this.setTextInPersonalNoteTextbox(specChar);
            String specialCharRemain = this.getText(this.pesonalNoteInfo);
            Assert.assertEquals(speclCharLen, specialCharRemain);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean validateMorDetailsInfo(String info) {
        String act_info = this.getText(By.xpath(String.format(this.moreDetailsInfo, info)));
        return info.equals(act_info);
    }

    public boolean validateColumnValues(String filterName, DataTable table) {
        List<String> columnName = table.asList(String.class);
        String columnId = "";
        boolean flag = true;
        for (String column : columnName) {
            switch (column) {
                case "LAST KNOWN LOCATION":
                    columnId = "lastKnownLocation";
                    break;
                case "RECIPIENT CITY":
                    columnId = "recipCityStateCountry";
                    break;
                case "SCHEDULED DELIVERY DATE":
                    columnId = "scheduledDeliveryDate";
                    break;
                case "Country Of Manufacturing":
                    columnId = "manufacture-country-code";
                    break;
                case "Harmonized Code(s)":
                    columnId = "code";
                    break;
                case "Description":
                    columnId = "description";
                    break;
                case "SHIP DATE":
                    columnId = "shipDate";
                    break;
                case "STATUS":
                    columnId = "status";
                    break;
            }

            List<WebElement> weList = this.findElements(By.xpath(String.format(this.columnValues, columnId)));
            if (filterName.equals("Commodity Information")) {
                List<HashMap<String, String>> commodities = (List<HashMap<String, String>>) this.commonHelpers
                        .getValuefromContextStore("commodities_obj");
                weList = this.findElements(By.xpath(String.format(this.columnValues, columnId)));
                for (int i = 0; i < commodities.size(); i++) {
                    Object expValue = commodities.get(i).get(columnId);
                    Object actValue = weList.get(i).getText();
                    if (columnId.equalsIgnoreCase("description")) {
                        // in UI we see there is a space after :
                        actValue = actValue.toString().replace(":", ": ");
                    }
                    if (expValue == null) {
                        expValue = "";
                    }
                    if (!Objects.equals(expValue, actValue)) {
                        flag = false;
                    }
                }
            } else {
                for (WebElement elm : weList) {
                    String columnData = elm.getText();
                    if (columnData.equals("")) {
                        flag = false;
                    } else {
                        flag = true;
                        break;
                    }
                }

            }

        }
        return flag;
    }

    public boolean verifypayerAccountDetails() {
        String payerAccountDetail = this.getText(
                this.getByusingString(String.format(this.valuesUnderSectionOnShipmentData, "Payer Account #")));
        String transportationValue = this.commonHelpers.getValuefromContextStore("billToAccount") == null ? ""
                : this.commonHelpers.getValuefromContextStore("billToAccount").toString();
        String dutiesValue = this.commonHelpers.getValuefromContextStore("ContextStore-billToDutiesAccount") == null
                ? ""
                : this.commonHelpers.getValuefromContextStore("billToDutiesAccount").toString();
        if (!transportationValue.equals("")) {
            Assert.assertTrue("Validation failed for Bill To Transportation on shipment details page under Payer ",
                    payerAccountDetail.contains(transportationValue + " - Transportation"));
        }
        if (!dutiesValue.equals("")) {
            Assert.assertTrue("Validation failed for Bill To Duties on shipment details page under Payer ",
                    payerAccountDetail.contains(dutiesValue + " - Duties"));
        }
        return payerAccountDetail.contains("Transportation") || payerAccountDetail.contains("Duties");
    }

    public void verifyDateFormatForAllFields(String ipDateFormat, String opDateFormat) {
        this.waitUntilVisible(this
                .getByusingString(String.format(this.SummaryBarxpath, "Delivered Time") + "/following-sibling::div"));
        commonHelpers.thinkTimer(3000);
        String deliveredTime = this.getText(this
                .getByusingString(String.format(this.SummaryBarxpath, "Delivered Time") + "/following-sibling::div"));
        // Verify Date format for Delivered Time
        Assert.assertNotNull(this.dateTimeUtils.isDate(deliveredTime, ipDateFormat, opDateFormat));
        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        List<WebElement> localTimeZone;
        if (user.equalsIgnoreCase("CE")) {
            localTimeZone = this.findElements(By.xpath(String.format(this.columnValues, "scanEventDateTime")));
        } else {
            // Verify Date format for Local Time Zone on History tab
            localTimeZone = this.findElements(this.localTimeZoneHistoryTabBy);
        }
        for (WebElement elem : localTimeZone) {
            String date = elem.getText();
            if (!date.equals("")) {
                if (date.contains(",")) {
                    Assert.assertNotNull(
                            this.dateTimeUtils.isDate(date.split(",")[1], ipDateFormat, opDateFormat));
                } else {
                    Assert.assertNotNull(this.dateTimeUtils.isDate(date, ipDateFormat, opDateFormat));
                }

            }

        }
        // Verify Date format for SHIP DATE and STANDARD TRANSIT
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Shipment Data")));
        Assert.assertNotNull(this.dateTimeUtils.isDate(
                this.getText(By.xpath(String.format(this.ValueFromLabel, "LABEL CREATED"))), ipDateFormat,
                opDateFormat));
        Assert.assertNotNull(this.dateTimeUtils.isDate(
                this.getText(By.xpath(String.format(this.ValueFromLabel, "SHIP DATE"))).split(" ")[1], ipDateFormat,
                opDateFormat));
        Assert.assertNotNull(this.dateTimeUtils.isDate(
                this.getText(By.xpath(String.format(this.ValueFromLabel, "STANDARD TRANSIT"))), ipDateFormat,
                opDateFormat));
    }

    public void verifyAutoComments(String commentType) {
        List<WebElement> autoCommntRow = this.findElements(this.autoCommentRow);
        String[] comnt = autoCommntRow.get(0).getText().split("\n");
        String orgComment = commentType;
        commentType = commentType.split("-")[0];
        switch (commentType) {
            case "auto populated":
                if ("Internal Comment" == comnt[0]) {
                    if (!(comnt[1].contains("(") && comnt[1].contains(")"))) {
                        Assert.assertNotNull(this.dateTimeUtils.isDate(comnt[1],
                                (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "dd/MM/yyyy"));
                    } else {
                        Assert.assertNotNull(this.dateTimeUtils.isDate(comnt[2],
                                (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "dd/MM/yyyy"));
                    }
                    Assert.assertEquals("", autoCommntRow.get(1).getText());
                    Assert.assertEquals(this.commonHelpers.getValuefromContextStore("comment"),
                            autoCommntRow.get(autoCommntRow.size() - 1).getText());
                    Assert.assertFalse(
                            this.elementIsDisplayed(By.xpath(String.format(this.commentContextMenu, "Internal Comment"))));
                }
                break;

            case "normal":
                Assert.assertTrue("Comments Rows", autoCommntRow.size() > 1);
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(String.format(this.commentContextMenu, "Internal Comment"))));
                Assert.assertEquals(3, comnt.length);
                Assert.assertEquals("Internal Comment", comnt[0]);
                Assert.assertNotNull(this.dateTimeUtils.isDate(comnt[2],
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "dd/MM/yyyy"));
                this.clickOnElement(By.xpath(String.format(this.commentContextMenu, "Internal Comment")));
                Assert.assertTrue(this.elementIsDisplayed(this.getByusingString(this.commentEditButton)));
                Assert.assertTrue(this.elementIsDisplayed(this.getByusingString(this.commentDeleteButton)));
                this.clickOnElement(By.xpath(String.format(this.commentContextMenu, "Internal Comment")));
                if (this.commonHelpers.verifyKeyInContextStore("lastComment")) {
                    String comment = this.getText(this.commentsColumn);
                    Assert.assertEquals(comment, this.commonHelpers.getValuefromContextStore("lastComment"));
                }
                break;
            case "Deleted":
                String comment = GetShipmentComment(orgComment.split("-")[1]);
                if (orgComment.contains("ContextStore-")) {
                    comment = (String) this.commonHelpers.getValuefromContextStore(orgComment.split("-")[1]);
                }
                boolean flag = this.findElement(thirdColumn).getAttribute("textContent").replaceAll("\\s", "")
                        .equals(comment.replaceAll("\\s", ""));
                Assert.assertFalse(flag);
                break;
            case "FedExId in":
                String fedId = comnt[1];
                String expVal = this.getText(this.userName) + " (" + this.commonHelpers.getValuefromContextStore("CE")
                        + ")";
                Assert.assertEquals(fedId, expVal);
                String expUrl = "https://hr-directory.prod.fedex.com/PeopleDirectory?Search="
                        + this.commonHelpers.getValuefromContextStore("CE");
                String actUrl = this.getAttributeValue(this.getByusingString(
                                this.getXPathforAnyElementWithText((String) this.commonHelpers.getValuefromContextStore("CE"))),
                        "href");
                Assert.assertEquals(expUrl, actUrl);
                break;
            case "Comment In Dropdown":
                String status = orgComment.split("-")[3];
                String commnt = orgComment.split("-")[1];
                if (commnt.contains("ContextStore")) {
                    commnt = (String) this.commonHelpers.getValuefromContextStore(orgComment.split("-")[2]);
                }
                List<String> options = this.getDropdownOptions(this.commentsDropDown);
                if (status.equals("Available")) {
                    Assert.assertTrue("Comment In drodown", options.indexOf(commnt) >= 0);
                } else {
                    Assert.assertEquals("Comment In drodown", -1, options.indexOf(commnt));
                }
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                break;
            default:
                break;
        }
    }

    public void verifySupportUpdateSection(String section) {
        List<WebElement> elms = this
                .findElements(this.getByusingString(String.format(this.shipmentDetailsSection, "Time Stamps")));
        section = section.split("-")[0];
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        switch (section) {
            case "Support Update":
                Assert.assertEquals(elms.get(1).getText(), section);
                Assert.assertTrue("Font Size",
                        elms.get(1).getCssValue("font-size").compareTo(elms.get(2).getCssValue("font-size")) > 0);
                String[] supportUpdate = elms.get(2).getText().split("\n");
                Assert.assertEquals(supportUpdate[0], this.commonHelpers.getValuefromContextStore("supportUpdate"));
                Assert.assertNotNull(this.dateTimeUtils.isDate(supportUpdate[1].split(" ")[0],
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "MM/dd/yyyy"));
                this.commonHelpers.AddToContextStore("supportUpdateTime", supportUpdate[1].split(" ")[3]);
                break;
            case "TimeFormat":
                String time = elms.get(2).getText().split("\n")[1];
                Assert.assertTrue(time.contains("AM") || time.contains("PM"));
                break;
            case "NotDisplayed":

                if (!virtualizationFlag) {
                    Assert.assertNotEquals("Support Update", elms.get(1).getText());
                }
                break;
            case "CER Numbers":
                Assert.assertTrue("CER Numbers", this.verifyCERNumbers());
            default:
                break;
        }
    }

    public boolean verifyCERNumbers() {
        boolean flag = true;
        String caseEbsHeader = Constants.CaseEbsHeader;
        List<WebElement> cerList = this.findElements(this.cerNumber);
        String[] cerListexp = ((String) this.commonHelpers.getValuefromContextStore("cerNumbers")).split(",");
        List<String> cerListE = Arrays.asList(cerListexp);
        Assert.assertEquals(cerListE.size(), cerList.size() - 1);
        for (int i = 0; i < cerListE.size(); i++) {
            Assert.assertEquals(cerListE.get(i), cerList.get(i + 1).getText());
        }

        String latestCer = cerList.get(1).getText();
        String cerLink = Constants.CERLink;
        for (WebElement cer : cerList) {
            String cerNumber = cer.getText();
            if (!cerNumber.equals("CER NUMBER")) {
                String tooltip = this.getAttributeValue(this.getByusingString(this.GetxpathForLink(cerNumber)), "href");
                if (!tooltip.equals(cerLink + cerNumber)) {
                    flag = false;
                }
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(cerNumber)));
                // ArrayList<String> tabs = new ArrayList<String> (this.GetWindowHandles());
                // DriverManager.getDrv()Manager.getDrv().switchTo().window(tabs.get(1));
                this.commonHelpers.thinkTimer(5000);
                if (!this.switchToTabAndGetPageTitle(this.caseEbsLoginPageTitle).equals(caseEbsHeader)) {
                    flag = false;
                }
                // DriverManager.getDrv()Manager.getDrv().close();
                // DriverManager.getDrv()Manager.getDrv().switchTo().window(tabs.get(0));
            }
        }

        this.NavigateToSection("comments");
        WebElement elm = this
                .findElement(this.getByusingString(this.getXPathforAnyElementWithText("CER Number:") + "/a"));
        String cer = elm.getText();
        String toolTipCommnt = elm.getAttribute("href");
        if (!toolTipCommnt.equals(cerLink + cer)) {
            flag = false;
        }
        this.NavigateToSection("Tooling");
        WebElement elmEbs = this
                .findElement(this.getByusingString(this.getXPathforAnyElementWithText("CaseEBS") + "/a"));
        toolTipCommnt = elmEbs.getAttribute("href");
        if (!toolTipCommnt.equals(cerLink + latestCer)) {
            flag = false;
        }
        elmEbs.click();
        // ArrayList<String> tabs = new ArrayList<String> (this.GetWindowHandles());
        // DriverManager.getDrv()Manager.getDrv().switchTo().window(tabs.get(1));
        if (!this.switchToTabAndGetPageTitle(this.caseEbsLoginPageTitle).equals(caseEbsHeader)) {
            flag = false;
        }
        // DriverManager.getDrv()Manager.getDrv().close();
        // DriverManager.getDrv()Manager.getDrv().switchTo().window(tabs.get(0));
        return flag;
    }

    public int verifyShipmentDetailsSummaryHeaders(String headerName) {
        List<WebElement> headers = this.findElements(this.myShipmentsHeaders);
        List<String> headerNamesList = new ArrayList<>();
        for (WebElement header : headers) {
            headerNamesList.add(header.getText());
        }
        return headerNamesList.indexOf(headerName);
    }

    public boolean validateTextUnderShipmentData(String mainElementText, String value) {
        return this.elementIsDisplayed(By.xpath(String.format(this.shipmentDataLabel, mainElementText, value)));
    }

    public void verifyPackageDetails(DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        for (String key : data.keySet()) {
            List<WebElement> elemList = this.findElements(By.xpath(String.format(this.packageDetails, key)));
            String expVal = "";
            if (key.equals("DIMENSIONS")) {
                Assert.assertEquals(this.getText(elemList.get(0)),
                        this.commonHelpers.getValuefromContextStore(data.get(key).split(",")[0]));
                Assert.assertEquals(this.getText(elemList.get(1)),
                        this.commonHelpers.getValuefromContextStore(data.get(key).split(",")[1]));
            } else {
                String[] expvalueArr = this.getText(elemList.get(0)).split("\n");
                Assert.assertEquals(this.commonHelpers.getValuefromContextStore(data.get(key).split(",")[0]) + " lbs",
                        expvalueArr[0]);
                Assert.assertEquals(this.commonHelpers.getValuefromContextStore(data.get(key).split(",")[1]) + " kgs",
                        expvalueArr[1]);
            }
        }
    }

    public void verifyCommentInCommentsDropdown(DataTable table) {
        List<String> actComments = new ArrayList<String>();
        List<String> expComments = table.asList(String.class);
        for (WebElement element : this.findElements(By.xpath(String.format(commentDropdown, "Comments")))) {
            actComments.add(this.getText(element));
        }
        for (String comment : expComments) {
            if (comment.contains("ContextStore-")) {
                comment = (String) this.commonHelpers.getValuefromContextStore(comment);
            }
            Assert.assertTrue("Comment in comments dropdown not matching", actComments.indexOf(comment) >= 0);

        }
    }

    public boolean validateSectionUnderShipmentData(String section) {
        String text = this.findElement(By.xpath(String.format(this.ValueFromLabel, section))).getText();
        switch (section) {
            case "SENSOR":
                if (this.commonHelpers.getValuefromContextStore("UserContext").toString().equals("CE")) {
                    Assert.assertEquals("Message for Sensor Mobile is not correct", "SenseAware Mobile", text);
                } else {
                    String sensorMobileJourneyId = (String) this.commonHelpers
                            .getValuefromContextStore("senseAwareJourneyId");
                    String href = this.findElement(By.xpath(String.format(LinkFromLabel, section)))
                            .getAttribute("href");
                    if (sensorMobileJourneyId != null) {
                        Assert.assertEquals("Message for sensor mobile journey id is not correct", text,
                                String.format(Constants.sensorMobileJourney, sensorMobileJourneyId));
                        Assert.assertEquals("Link for sensor mobile journey id is not correct", href,
                                String.format(Constants.SenseawareJourneyIdLinkUrl, sensorMobileJourneyId));
                    }
                }
                break;

        }
        return true;
    }

    // localization CODE BEGIN
    public void validateTabHeadings(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "History":
                case "Shipment Data":
                case "Personal Note":
                case "More Details":
                case "Commodity Information":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(this.tabName, localisedValue))))
                            .isTrue();
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void validatePersonalNoteDetailsFieldsForlocalization(DataTable dataTable) {
        // Click on the personal note
        String localisedValue;
        localisedValue = this.genericFunctionObject.getLocalizedValue("Personal Note");
        this.clickOnElement(this.getByusingString(String.format(this.tabName, localisedValue)));

        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        this.waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> elementsList = null;
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Add Personal Note":
                    if (!this.elementIsNotDisplayed(
                            this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)))) {
                        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)));
                        this.setTextInPersonalNoteTextbox(Constants.stringWithDifferentLang);

                    } else {
                        // in case add personal note button is not available clicking on edit note
                        localisedValue = this.genericFunctionObject.getLocalizedValue("Edit Personal Note");
                        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)));
                        log.info("**WARNING** Add Personal Note validation got skipped.");
                        this.setTextInPersonalNoteTextbox(Constants.stringWithDifferentLang);
                    }
                    elementsList = this.findElements(this.personalNoteDetails);
                    break;

                case "NOTE":
                    softly.assertThat(elementsList.get(0).getText()).isEqualTo(localisedValue);
                    break;

                case "Characters Remain":
                    softly.assertThat(elementsList.get(1).getText()).contains(localisedValue);

                    break;

                case "SAVE":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(this.getXPathforButton(localisedValue, true))))
                            .isTrue();
                    this.clickOnElement(this.getByusingString(this.getXPathforButton(localisedValue, true)));
                    this.waitUntilNotVisible(this.loadingIndicator);
                    break;

                case "Cancel":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)))).isTrue();
                    this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)));
                    break;
                case "Edit Personal Note":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)))).isTrue();
                    this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(localisedValue)));
                    // now validating if we have the text as equal to the one which we entered
                    softly.assertThat(this.getText(personalNotetextbox)).isEqualTo(Constants.stringWithDifferentLang);

                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void validateSectionUnderPurpleBarForLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {

                case "Piece Shipment":
                    softly.assertThat(this.getText(xpieceShipmentsXpath)).contains(localisedValue);
                    break;

                case "Viewing":
                    softly.assertThat(this.getText(trackingNbrViewing)).contains(localisedValue);
                    break;

                case "DELIVERED":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(trackingNbrDelivered, localisedValue)))).isTrue();
                    break;

                case "IN TRANSIT":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(inTransitExceptions, localisedValue)))).isTrue();
                    break;

                case "EXCEPTIONS":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(inTransitExceptions, localisedValue)))).isTrue();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void validateMultiplePiecesTable(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            softly.assertThat(
                            this.elementIsDisplayed(this.getByusingString(String.format(tableHeaders, localisedValue))))
                    .isTrue();
        }
        softly.assertAll();
    }

    public void validatePresenceOfText(String text) {
        if (!GenericFunction.virtualizationFlag) {

            if (text.contains("by end of day")) {
                Assertions.assertThat(this.elementIsPresent(this.purplePanelScheduledDeliveryEndofDay)).isTrue();
            }
        } else {
            log.info("**WARNING** -- Vritualisation was off so end of day check for Scheduled delivery is skipped.");
        }

    }

    public void validatePurpleBarForLocalization(DataTable dataTable) {

        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {

                case "TRACKING NUMBER":
                    softly.assertThat(this.getText(purplePanelTrackingNbrXpath)).contains(localisedValue);
                    break;

                case "Watch":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(watchedText, localisedValue))))
                            .isTrue();
                    break;

                case "Watched":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(watchedText, localisedValue))))
                            .isTrue();
                    break;

                case "Payer":
                    softly.assertThat(this
                                    .getText(this.getByusingString(String.format(purpleBarTextAfterTrackingNumber, "payer"))))
                            .contains(localisedValue.toUpperCase());
                    break;

                case "Shipper":
                    softly.assertThat(this
                                    .getText(this.getByusingString(String.format(purpleBarTextAfterTrackingNumber, "digital"))))
                            .contains(localisedValue.toUpperCase());
                    break;

                case "Select.onlyDigital":
                    softly.assertThat(this
                                    .getText(this.getByusingString(String.format(purpleBarTextAfterTrackingNumber, "payer"))))
                            .contains(localisedValue.toUpperCase());
                    break;

                case "Commit":
                    softly.assertThat(this.getText(commitTimer)).contains(localisedValue);
                    break;

                case "Past Commit Time":
                    softly.assertThat(this.getText(commitTimer)).contains(localisedValue);
                    break;

                case "BACK":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(this.getXPathforButton(localisedValue))))
                            .isTrue();
                    break;

                case "CONTACT YOUR SUPPORT TEAM":
                    softly.assertThat(this.getText(contactYourSupportTeam)).contains(localisedValue);
                    break;

                case "Get Status Updates":
                    softly.assertThat(this.getText(getStatusUpdates)).contains(localisedValue);
                    break;

                case "From":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 1))))
                            .isTrue();
                    break;

                case "To":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 2))))
                            .isTrue();
                    break;

                case "ESTIMATED DELIVERY":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 3))))
                            .isTrue();
                    String between = this.genericFunctionObject.getLocalizedValue("Between");
                    softly.assertThat(this
                                    .getText(this.getByusingString(String.format(purplePanelSecondRowData, localisedValue))))
                            .contains(between);
                    break;

                case "SCHEDULED DELIVERY":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 3))))
                            .isTrue();
                    String before = this.genericFunctionObject.getLocalizedValue("Before");
                    softly.assertThat(this
                                    .getText(this.getByusingString(String.format(purplePanelSecondRowData, localisedValue))))
                            .contains(before);
                    break;

                case "PREDICTION":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 2))))
                            .isTrue();
                    break;

                case "DELIVERED TIME":
                    softly.assertThat(this
                                    .elementIsDisplayed(this.getByusingString(String.format(purplePanelSecondRowHeaders, 3))))
                            .isTrue();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }

    public void validateSectionUnderShipmentData(String mainSection, DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();
        String mainSectionTranslation = this.genericFunctionObject.getLocalizedValue(mainSection);
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                // Since Payer has an option which comes as transportation
                case "Payer":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(mainSections, localisedValue))))
                            .isTrue();
                    localisedValue = this.genericFunctionObject.getLocalizedValue("Transportation");
                    softly.assertThat(this.elementIsDisplayed(
                                    this.getByusingString(String.format(valuesUnderSectionOnShipmentData, localisedValue))))
                            .isTrue();
                    break;

                case "Standard Transit":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(mainSections, localisedValue))))
                            .isTrue();
                    localisedValue = this.genericFunctionObject.getLocalizedValue("By");
                    softly.assertThat(this.elementIsDisplayed(
                                    this.getByusingString(String.format(valuesUnderSectionOnShipmentData, localisedValue))))
                            .isTrue();
                    break;

                case "MASTER TRACKING NUMBER":
                case "DEPARTMENT":
                case "PURCHASE ORDER":
                case "SHIPPER REFERENCE":
                    if (this.elementIsDisplayed(this.getByusingString(String.format(mainSections, localisedValue))))
                        softly.assertThat(this
                                        .elementIsDisplayed(this.getByusingString(String.format(mainSections, localisedValue))))
                                .isTrue();
                    else
                        log.error(
                                "**WARNING** This was not seen on shipment data hence skipped validation --> " + value);
                    break;

                case "Service":
                case "Package":
                case "Time Stamps":
                    softly.assertThat(
                                    this.elementIsDisplayed(this.getByusingString(String.format(mainSections, localisedValue))))
                            .isTrue();
                    break;
                default:
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(
                            String.format(sectionSubsection, mainSectionTranslation, localisedValue)))).isTrue();

            }
        }
        softly.assertAll();
    }

    public void validateOptionsUnderHistory(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        String localisedValue = "";
        SoftAssertions softly = new SoftAssertions();

        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Local Time Zone":
                case "Destination Time Zone":
                    softly.assertThat(this.elementIsPresent(
                            this.getByusingString(String.format(timeZoneDropDown, localisedValue, 1)))).isTrue();
                    break;
                case "COLLAPSE HISTORY":
                    softly.assertThat(this.getText(this.getByusingString(String.format(expandCollapse, 1))))
                            .contains(localisedValue);
                    break;
                case "EXPAND HISTORY":
                    this.clickOnElement(this.getByusingString(String.format(expandCollapse, 1)));
                    softly.assertThat(this.getText(this.getByusingString(String.format(expandCollapse, 1))))
                            .contains(localisedValue);
                    break;
                default:
                    Assertions.fail(
                            "An option has been passed which is not expected in validateTimeZoneOptions --> " + value);
            }
        }
        softly.assertAll();
    }

    public void validateDetailsPage(String field, String format, String timeFormat) throws ParseException {
        if (field.equalsIgnoreCase("ESTIMATED DELIVERY")) {
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(purpleGenericXpath, field))));
            String completeEdtwDate = getText(By.xpath(String.format(purpleGenericXpath + "/following::div", field)));
            String edtwDate = completeEdtwDate.split(" ")[0];
            String edtwTime = completeEdtwDate.split(" ")[2];
            String completeStandardTransitDate = getText(By.xpath(String.format(shipmentDataContains, "STANDARD TRANSIT")));

            String stdtDate = completeStandardTransitDate.split(" ")[0];
            String stsdtTime = "";
            if (completeStandardTransitDate.contains("end of day")) {
                stsdtTime = "23:59";
            } else {
                stsdtTime = completeStandardTransitDate.split(" ")[2];
            }
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            Date date1 = simpleDateFormat.parse(edtwDate);
            date1.setHours(Integer.parseInt(edtwTime.split(":")[0]));
            date1.setMinutes(Integer.parseInt(edtwTime.split(":")[1]));

            Date date2 = simpleDateFormat.parse(stdtDate + " " + stsdtTime);
            date2.setHours(Integer.parseInt(stsdtTime.split(":")[0]));
            date2.setMinutes(Integer.parseInt(stsdtTime.split(":")[1]));


            Assert.assertTrue("edtwDate : " + edtwDate+ " stdtDate " + stdtDate,(date1.before(date2) || date1.equals(date2)));
            // localization CODE END
        }
    }

    public void verifyCheckboxandText(DataTable table){
        List<String>list=table.asList();
        //validation for text
        for(String str:list){
            Assert.assertEquals(true,this.elementIsDisplayed(By.xpath("//label[contains(text(), '"+str+"')]")));
        }
        //validation for checkbox
        for(String str:list){
            Assert.assertEquals(true,this.elementIsPresent(By.xpath("//input[@id='"+str+"']")));

        }
        JavaScriptClick(By.xpath("//input[@id='"+list.get(0)+"']"));
    }
    public void fillEmailFields(List<String>list){
        this.selectDropdown(trackingnum_DrpDwn_Languages,"text",list.get(0));
//        this.clickOnElement(this.trackingnum_DrpDwn_Languages);
//        this.clickOnElement(By.xpath("//select[@id='LANGUAGE']/option[contains(text(),'"+list.get(0)+"')]"));
        int countOfEmail=1;
        for(int iterator=0;iterator<list.size();iterator++){
            if(getCount(By.xpath("(//label[contains(text(),'*Email')]/../input)["+countOfEmail+"]"))>=1 && countOfEmail<=5){
                this.clickOnElement(this.findElement(By.xpath("(//label[contains(text(),'*Email')]/../input)["+countOfEmail+"]")));
                this.enterText(this.findElement(By.xpath("(//label[contains(text(),'*Email')]/../input)["+countOfEmail+"]")),list.get(countOfEmail));
                if(getCount(By.xpath(String.format(addEmailInGetStatusUpdates,5-countOfEmail))) >=1){
                    JavaScriptClick(By.xpath(String.format(addEmailInGetStatusUpdates,5-countOfEmail)));
                }
                countOfEmail++;
            }
            else{
                break;
            }
        }
        Assert.assertEquals(5,countOfEmail-1);

        this.clickOnElement(this.trackingnum_Txtbox_YourName);
        this.enterText(this.trackingnum_Txtbox_YourName,list.get(6));
        this.clickOnElement(this.trackingnum_Txtbox_YourEmail);
        this.enterText(this.trackingnum_Txtbox_YourEmail,list.get(7));
        this.clickOnElement(this.trackingnum_Btn_Submit);
    }

    public void FieldLabels(DataTable table) {
        String menuOption = null;
        List<String> list = table.asList();
        for (String value : list) {
            String lang = GenericFunction.ReadConfigFile("LANG");
            if (!lang.equalsIgnoreCase("en-us")) {
                menuOption = new GenericFunction().getLocalizedValue(value);
            } else {
                menuOption = value;
            }
            switch (value) {
                case "Viewing":
                    int status = this.getCount(By.xpath("//div[.='" + menuOption + "']"));
                    Assert.assertEquals(status, 1);
                    break;

                case "Filters":
                    int filterStatus = this.getCount(By.xpath("//span[.='" + menuOption.toUpperCase() + "']"));
                    Assert.assertEquals(filterStatus, 1);
                    break;
            }
        }

    }

    public void firstLevelCategories(DataTable table) {
        List<String> Expectedlocale_value = new ArrayList<>();
        List<String> Actuallocale_value = new ArrayList<>();
        List<String> list = table.asList();
        this.clickOnElement(myshipments_Filters);
        this.commonHelpers.thinkTimer(2000);
        List<WebElement> Actualelements = this.findElements(myshipments_Filters_FirstLevelCategories);
        for (int actual = 0; actual < Actualelements.size(); actual++) {
            Actuallocale_value.add(Actualelements.get(actual).getText());
        }

        for (int i = 0; i < list.size(); i++) {
            String lang = GenericFunction.ReadConfigFile("LANG");
            if (!lang.equalsIgnoreCase("en-us")) {
                Expectedlocale_value.add(new GenericFunction().getLocalizedValue(list.get(i).trim()));
            }
        }
        Collections.sort(Expectedlocale_value);
        Collections.sort(Actuallocale_value);
        Expectedlocale_value.equals(Actuallocale_value);
    }

    public void allSearchTypes(DataTable table) {

        Map<String, String> dataFilters = table.asMap(String.class, String.class);
        List<String> list = table.asList();

        for (Map.Entry<String, String> pair : dataFilters.entrySet()) {
            System.out.println(String.format("Key (name) is: %s, Value (age) is : %s", pair.getKey(), pair.getValue()));
        }

        //To validate the message above the filter
        String locale_value = null;
        String lang = GenericFunction.ReadConfigFile("LANG");
        if (!lang.equalsIgnoreCase("en-us")) {
            locale_value = new GenericFunction().getLocalizedValue("SpecialCharacter Message");
        }
        int searchbox_SplCharMsg = this.getCount(By.xpath("(//div[@class='sr-legacy-search-searchbox-character'])[1]"));
        Assert.assertEquals(searchbox_SplCharMsg, 1);

        //To validate the search box field
        Assert.assertEquals(getCount(By.xpath("//input[@placeholder='Search for filter' or @placeholder='Recherche de filtre']")), 1);

        //To validate the diff combinations of the search entries

        for (Map.Entry<String, String> pair : dataFilters.entrySet()) {
            switch (pair.getKey()) {

                case "Consecutive SearchMessage":
                case "Consecutive special characters are not allowed":
                    searchvalidation(pair.getValue(), pair.getKey());
                    break;

                case "NoResults Found":
                case "No results found.":
                    searchvalidation(pair.getValue(), pair.getKey());
                    break;

                case "NoSpecial CharacterAllowed1":
                case "The following combination is not allowed:":
                    searchvalidation(pair.getValue(), pair.getKey());
                    break;

                case "NoSpecial CharacterAllowed2":
                case "please remove this from your search":
                    searchvalidation(pair.getValue(), pair.getKey());
                    break;
            }
        }

    }
        public void searchvalidation (String searchmsg, String FRNerrormsg){
            String locale_value;
            this.enterText(By.xpath("//input[@placeholder='Search for filter' or @placeholder='Recherche de filtre']"), searchmsg);
            this.commonHelpers.thinkTimer(2000);
            String erromsg = this.getText(By.xpath("//div[@class='sr-legacy-search-searchbox-message']"));
            String lang = GenericFunction.ReadConfigFile("LANG");
            if (!lang.equalsIgnoreCase("en-us")) {
                locale_value = new GenericFunction().getLocalizedValue(FRNerrormsg);
            } else {
                locale_value = FRNerrormsg;
            }

            if (FRNerrormsg.equals("NoSpecial CharacterAllowed1")) {
                String msg = erromsg.split(":")[0].trim();
                Assert.assertTrue(locale_value.contains(msg));
            } else if (FRNerrormsg.equals("NoSpecial CharacterAllowed2")) {
                String msg = erromsg.split("~")[1].trim();
                Assert.assertTrue(locale_value.contains(msg));
            } else {
                Assert.assertTrue(erromsg.trim().contains(locale_value));
            }
        }

    public void validateLabelsinShipment() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String count = (this.getText(this.getMyshipments_Viewing_Count).split("/")[0]).replace(",","");
        if(Integer.parseInt(count) <= 60000) {
            this.Mouse_MoveToElement(this.myshipments_ExportButton);
            this.commonHelpers.thinkTimer(2000);
            int ExportStatus = this.getCount(this.myshipments_Export_label);
            int ExportLinkStatus = this.getCount(this.myshipments_ExportLink_label);
            int ScheduleReportsStatus = this.getCount(this.myshipments_ScheduleReports_label);
            int ScheduleReportsLink = this.getCount(this.myshipments_ScheduleReportslink_Label);
//            int CancelButtton = this.getCount(this.myshipments_cancelButton);
            Assert.assertEquals(4, ExportStatus + ExportLinkStatus + ScheduleReportsStatus + ScheduleReportsLink);
        }

        if (Integer.parseInt(count) > 60000) {
            this.Mouse_MoveToElement(this.myshipments_ExportButton);
            this.commonHelpers.thinkTimer(2000);
            int ExportStatus = this.getCount(this.myshipments_Export_label);
            int ExportLinkStatus = this.getCount(this.myshipments_ExportLink_label);
            int ScheduleReportsStatus = this.getCount(this.myshipments_ScheduleReports_label);
            int ScheduleReportsLink = this.getCount(this.myshipments_ScheduleReportslink_Label);
//            int CancelButtton = this.getCount(this.myshipments_cancelButton);
            Assert.assertEquals(3, ExportStatus  + ScheduleReportsStatus + ScheduleReportsLink);
            Assert.assertTrue(ExportLinkStatus==0);
        }
    }

    public String getViewingCount() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String count = (this.getText(this.getMyshipments_Viewing_Count).split("/")[0]).replace(",", "");
        return count;
    }

    public void validateExportQuestionIcon_Popup(String FieldName) {
        switch (FieldName) {
            case "Export":
                this.waitUntilNotVisible(this.loadingIndicator);
                this.Mouse_MoveToElement(this.myshipments_ExportButton);
                this.Mouse_MoveToElement_Click(this.myshipments_Export);
                this.commonHelpers.thinkTimer(2000);
                String QuestionIconTxt = this.getText(this.DisclaimerTxt);
                Assert.assertEquals(QuestionIconTxt, "Click the link to export this file");

                this.Mouse_MoveToElement(this.myshipments_Export);
                this.JavaScriptClick(this.myshipments_ExportLink);
                this.commonHelpers.thinkTimer(2000);
                Assert.assertEquals(getCount(this.ExportPopupExistance), 1);
                if(this.elementIsDisplayed(this.Banner)) {
                    this.JavaScriptClick(this.Banner);
                }
                this.JavaScriptClick(this.Popupclosebutton);
                break;

            case "Scheduled Reports":
                this.waitUntilNotVisible(this.loadingIndicator);
                this.Mouse_MoveToElement_Click(this.myshipments_ExportButton);
                this.Mouse_MoveToElement_Click(this.myshipments_ScheduleReports);
                String SchReportQuestionIconTxt = this.getText(this.DisclaimerTxt);
                Assert.assertEquals(SchReportQuestionIconTxt.trim(), "Click the link to create a scheduled report for this file.");
                this.Mouse_MoveToElement_Click(this.DisclaimerIcon);

                this.Mouse_MoveToElement(this.myshipments_ExportButton);
                this.Mouse_MoveToElement_Click(this.myshipments_ScheduleReportslink_Label);
                this.waitUntilNotVisible(this.loadingIndicatorContains);
                Assert.assertEquals(this.getText(this.Header),"Create a Scheduled Report");
                break;
        }
    }

    public void removebubble(){
        this.JavaScriptClick(this.cancelFilterBubble);
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void validateExportQuestionIcon_PopupInvalidScenario(String FieldName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.Mouse_MoveToElement(this.myshipments_ExportButton);

        switch (FieldName) {
            case "Export":
                this.Mouse_MoveToElement_Click(this.myshipments_Export);
                String QuestionIconTxt = this.getText(this.DisclaimerTxt);
                Assert.assertEquals(QuestionIconTxt, "Click the link to export this file");
                this.Mouse_MoveToElement_Click(this.DisclaimerIcon);
                Assert.assertEquals(this.getCount(this.myshipments_ExportLink),1);
                break;

            case "Scheduled Reports":

                this.Mouse_MoveToElement_Click(this.myshipments_ScheduleReports);
                String SchReportQuestionIconTxt = this.getText(this.DisclaimerTxt);
                Assert.assertEquals(SchReportQuestionIconTxt.trim(), "Click the link to create a scheduled report for this file.");
                this.Mouse_MoveToElement_Click(this.DisclaimerIcon);

                this.Mouse_MoveToElement(this.myshipments_ExportButton);
                this.Mouse_MoveToElement_Click(this.myshipments_ScheduleReportslink);
                this.waitUntilNotVisible(this.loadingIndicatorContains);
                Assert.assertEquals(this.getText(this.Header),"Create a Scheduled Report");
                break;
        }
    }
    public void clickOnDownloadButton(String buttonText) {
        this.JavaScriptClick(By.xpath(String.format(buttonXpath, buttonText)));
    }

    public void ValidateTheSubmitButton() {
        int count = this.getCount((By.xpath(String.format(SubmitButtonValidation, "SUBMIT"))));
        Assert.assertEquals(count, 1);
    }

    public void ValidateTheCancelButton() {
        int count = this.getCount((By.xpath(String.format(CancelButtonValidation, "CANCEL"))));
        Assert.assertEquals(count, 1);
    }

    public void ValidateTheButtonIsDisabled(String buttonText) {
        int count = this.getCount((By.xpath(String.format(ButtonDisabledValidation, buttonText))));
        Assert.assertEquals(count, 1);
    }

    public void ValidateTheButtonIsEnabled(String buttonText) {
        int count = this.getCount((By.xpath(String.format(ButtonDisabledValidation, buttonText))));
        Assert.assertEquals(count, 1);
    }

    public void validationforNameEmailField() {
        this.enterText(this.trackingnum_Txtbox_YourName,"sampleName");
        this.enterText(this.trackingnum_Txtbox_YourEmail,"sampleEmail");
        this.elementClear(this.trackingnum_Txtbox_YourName);
        this.elementClear(this.trackingnum_Txtbox_YourEmail);
    }

    public void LabelValidationInGetStatusUpdates(String name) {
        int count = this.getCount((By.xpath(String.format(TextValidationOnGetStatusUpdates, name))));
        Assert.assertEquals(count, 1);
    }

    public void getShipperAccountNumber(String name){
        String Record = this.getText(this.ShiperAccNumber);
        this.commonHelpers.AddToContextStore(name,Record);
    }


    public void secondLevelCategories(String firstLevelFilter,DataTable table) {
        String locale_value = null;
        List<String> list = table.asList();
        List<String> resultList=new ArrayList<String>();
        this.clickOnElement(myshipments_Filters);
        this.commonHelpers.thinkTimer(2000);
        String lang = GenericFunction.ReadConfigFile("LANG");
       if (!lang.equalsIgnoreCase("en-us")) {
            firstLevelFilter = new GenericFunction().getLocalizedValue(firstLevelFilter);
        }
        //click on the first level category
        this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(firstLevelFilter))));
       this.commonHelpers.thinkTimer(2000);

        List<WebElement> elements = this.findElements(By.xpath(String.format(myshipments_Filters_SecondLevelCategories, firstLevelFilter)));
        for (WebElement element:elements) {
            resultList.add(element.getText().trim());
        }

        for (int i = 0; i < list.size(); i++) {

            if (!lang.equalsIgnoreCase("en-us")) {
                locale_value = new GenericFunction().getLocalizedValue(list.get(i).trim());
            } else {
                locale_value = list.get(i).trim();
            }
            Assert.assertTrue(resultList.contains(locale_value));
        }

        this.clickOnElement(myshipments_Filters);

    }

    public void allSearchTypesInColumns(DataTable table) {

        Map<String, String> dataFilters = table.asMap(String.class, String.class);
        List<String> list = table.asList();

        for (Map.Entry<String, String> pair : dataFilters.entrySet()) {
            System.out.println(String.format("Key (name) is: %s, Value (age) is : %s", pair.getKey(), pair.getValue()));
        }

        //To validate the message above the filter
        String locale_value = null;
        String lang = GenericFunction.ReadConfigFile("LANG");
        if (!lang.equalsIgnoreCase("en-us")) {
            locale_value = new GenericFunction().getLocalizedValue("SpecialCharacter Message");
        }
        //To validate the diff combinations of the search entries

        for (Map.Entry<String, String> pair : dataFilters.entrySet()) {
            switch (pair.getKey()) {

                case "Consecutive SearchMessage":
                case "Consecutive special characters are not allowed":
                    searchvalidationForColumns(pair.getValue(), pair.getKey());
                    break;

                case "NoResults Found":
                case "No results found.":
                    searchvalidationForColumns(pair.getValue(), pair.getKey());
                    break;

                case "NoSpecial CharacterAllowed1":
                case "The following combination is not allowed:":
                    searchvalidationForColumns(pair.getValue(), pair.getKey());
                    break;

                case "NoSpecial CharacterAllowed2":
                case "please remove this from your search":
                    searchvalidationForColumns(pair.getValue(), pair.getKey());
                    break;
            }
        }

    }

    public void searchvalidationForColumns(String searchmsg, String FRNerrormsg){
        String locale_value;
        String lang = GenericFunction.ReadConfigFile("LANG");

        if (!lang.equalsIgnoreCase("en-us")) {
            String placeholder = new GenericFunction().getLocalizedValue("Search for Columns");
            this.enterText(By.xpath("//input[@placeholder='"+placeholder+"']"), searchmsg);
        }else{
            this.enterText(By.xpath("//input[@placeholder='Search for Columns']"), searchmsg);
        }

        this.commonHelpers.thinkTimer(2000);
        String erromsg = this.getText(By.xpath("//div[@class='sr-legacy-search-searchbox-message']"));

        if (!lang.equalsIgnoreCase("en-us")) {
            locale_value = new GenericFunction().getLocalizedValue(FRNerrormsg);
        } else {
            locale_value = FRNerrormsg;
        }

        if (FRNerrormsg.equals("NoSpecial CharacterAllowed1")) {
            String msg = erromsg.split(":")[0].trim();
            Assert.assertTrue(locale_value.contains(msg));
        } else if (FRNerrormsg.equals("NoSpecial CharacterAllowed2")) {
            String msg = erromsg.split("~")[1].trim();
            Assert.assertTrue(locale_value.contains(msg));
        } else {
            Assert.assertTrue(erromsg.trim().contains(locale_value));
        }
    }

}


