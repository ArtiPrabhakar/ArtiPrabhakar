package pageObjects;

import API.ResponseModels.*;
import com.azure.cosmos.implementation.apachecommons.text.WordUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import genericfunctions.GenericFunction;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.assertj.core.util.Arrays;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class AdvisoryPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public HomePage homePage;
    public int weatherAlertCount;
    public int categoryCount = 0;
    public int TOTALCOUNT = 0;
    public GenericFunction genericFuncObj;
    public String advMenu = ".//%s[contains(text(),\"%s\")]//ancestor::a";
    public String defaultValue = "//*[contains(text(),\"%s\")]/../following::span[contains(text(),'Default')]";
    public String advSubMenu = ".//%s[text()=\"%s\"]//parent::a//parent::li";
    public By shipmentAlertCount = By.xpath("//div[contains(@class,'sr-navpane-val--lg')]");
    public By weatherCount = By.xpath("//span[contains(text(), 'Weather')]//preceding::span[@class='sr-subnav__list-item-val']");
    public String placeHoldertext = ".//*[@%s=\"%s\"]";
    public String favoriteDeleteIcon = "(//div[contains(@class,'sr-elipsis-dropdown z')]//span[contains(@class,'delete-icn m-l-2')])[1]";
    public By favoriteDelete_DeleteButton = By.xpath("//button[contains(text(),'Delete')]");
    public By favoriteDelete_CancelButton = By.xpath("//button/span[contains(text(),'Cancel')]");
    public String FromToTb = ".//input[contains(@placeholder,\"%s\")]";
    public String searchLabelsFromTo = "//label[@class=\"sr-search__label\" and contains(text(),\"%s\")]";
    public String SelectSearchResult = ".//*[contains(text(),\"%s\")]//ancestor::app-city-search-suggestion//li[%s]";
    public String SearchResultsList = ".//*[contains(text(),\"%s\")]//ancestor::app-city-search-suggestion//li";
    public By weatherLoader = By.xpath(".//*[contains(text(),'Loading weather forecast')]");
    public String weatherIcons = ".//*[contains(@placeholder,\"%s\")]//ancestor::app-city-search-suggestion//li";
    public String weatherIconsModel = ".//*[contains(@placeholder,\"%s\")]//ancestor::app-city-search-suggestion//li[%s]/div[%s]";
    public String maxTempTooltip = ".//*[contains(@placeholder,\"%s\")]//ancestor::app-city-search-suggestion//li[%s]//*[@class='sr-week__tooltip']/div";
    public String IconPhraseTooltip = ".//*[contains(@placeholder,\"%s\")]//ancestor::app-city-search-suggestion//li[%s]//*[@class='sr-week__tooltip-desc']";
    public String zoomInOutxpath = "(.//*[@title=\"%s\"])[%s]";

    public By filterButtonDropdown = By.xpath("//span[contains(text(),'FILTERS')]");
    public String addAccountAlias = "//%s[contains(text(),\"%s\")]";
    public String SelectedValueinSearchBox = ".//*[contains(text(),\"%s\")]//parent::div//input";
    public String advCheckBox = "//label[contains(text(),\"%s\")]";

    public String dateRangeXpath = "//div[contains(text(),\"%s\")]";
    public String headerXpath = "//li[contains(text(),\"%s\")]";
    public String daysXpath = "//label[contains(text(),\"%s\")]";
    public String todayXpath = "//label[contains(text(),\"%s\")]";
    public String advCheckBoxState = "//label[contains(text(),\"%s\")]/preceding-sibling::input";
    public String cluster = "//div[contains(text(),\"%s\")]";
    public String record = "//label[contains(text(),'Results')]";
    public String FavKebobMenu = ".//span[contains(@class,'kebab-icn ')]";
    public String mapOrListControl = "//div[contains(text(), \"%s\")]";
    public String listView = "(//div[@class='sr-card'])[1]//div[contains(text(),'Shipments')]//parent::div//following-sibling::div";
    public String countForCity = "(//div[contains(text(), \"%s\")])[1]//parent::div//following-sibling::div";
    public String switchView = "//span[@class='sr-toggle-sliderbox__switch']";
    public String categorySum = ".//div[contains(text(),\"%s\")]//following-sibling::div";
    public String mapView = "//a[@class='leaflet-control-zoom-in']";

    public By deleteMessagePopUpPS = By.xpath("//div[contains(text(),'You are about to delete')]");
    public String listViewLocator = "//app-list-view/div";// "(//div[@class='sr-card'])[1]";
    public By genericCityPin = By.xpath("//div[@id='Lmap']//div[contains(@class,'city-pin-icon')]");
    public By genericCluster = By.xpath("(//div[contains(@class,'cluster-icon') and not(contains(@class,'inactive-cluster-icon'))])[1]");
    public String genericCityCard = "//div[@class='sr-card']";

    public String addODLink = ".//*[contains(text(),\"%s\")]";
    public String ODApplyButton = "//button[contains(text(),\"%s\")]";
    public String ODfilterxpath = "//*[contains(text(),\"%s\")]";
    public String shipDateDropdownFilter = "//select[@name ='sr-select']";

    public String saveAsFav = "//*[contains(text(),'Save as favorite')]";
    public String FavNameInput = "//input[@id='INPUT']";
    public String SetAsDefaultFavCheckBox = "//label[@for='defaultFavorite']";
    public By viewSaveButton = By.xpath("//div/button[contains(text(),'Save') and @type='button']");
    public By viewSuccessfulMsgCloseButton = By.xpath("//button[contains(text(),'Close')]");
    public String viewSuccessfulMessage = "//div[contains(text(),'%s successfully created.')]";
    public String selectPrefLocationOption = ".//*[contains(text(),\"%s\")]";
    public By enterPrefLocation = By.xpath("//input[contains(@placeholder,'Enter City, State or Zip Code')]");
    public String Location1 = "//input[contains(@placeholder, \"%s\")]";
    public By Location2 = By.xpath("//div/input[contains(@class,'ng-valid')]");
    public By deleteOption = By.xpath("(//span[text()='Delete'])[2]");
    public By setAsDefault = By.xpath("(//span[text()='Set as Default'])[2]");
    public By clearDefault = By.xpath("(//span[text()='Clear Default'])[2]");
    public String verifyFavoriteInList = "//span[text()=\"%s\"]";
    public String deleteFileFromPS = ".//button[text()=' Delete ']";
    public String closeIcon = "(//span[@class=\"sr-flyout__close\"])[4]";
    public String cancelButtonPopUpPS = ".//button//span[text()=' Cancel ']";
    public String favClearDefaultEnabled = "//span[contains(text(),'Clear Default') and @disabled]";
    public String favClearDefaultDisabled = "//div[contains(@class,'sr-elipsis')]//span[text()='Clear Default' and not(@disabled)]";
    public By ClearDefToFavorite=By.xpath("//div[contains(@class,'sr-elipsis')]//span[text()='Clear Default']");

    public By enterODLocation = By.xpath("//input[contains(@class,'ng-touched')]");
    public String selectODOption = ".//input[contains(@placeholder,\"%s\")]";
    public By clickOnODTextbox = By.xpath("//div/input[contains(@class,'ng-valid')]");
    public String cityCountUI = "//div/span[contains(text(),\"%s\")]/ancestor::div/following-sibling::div/ul/li[1]/div/div[3]/div[2]";
    public By rightFlyoutShipmentsRightChervon = By.xpath(".//*[@class='sr-progressbar-data']//div[contains(text(),'All Shipments')]");
    public By shipmentsTotalBy = By.xpath(".//*[contains(text(),'Shipments')]/following-sibling::div");
    public By CitynameXpath = By.xpath("//div[contains(@class,'sr-title-20')]");
    public By leftFlyoutChevron = By.xpath(".//app-collapsed-advisories-panel/div/div[@class='chevron-right chevron-right--lg']");
    public String listviewRightChervon = ".//*[contains(text(),\"%s\")]/following::a";
    public String StandardFavPopUpMessage = "//div[contains(text(),' You are about to remove “%s”, as your default favorite, are you sure? ')]";
    public String listviewTotal = "//*[contains(text(),\"%s\")]//parent::div//following::div[contains(@class,'float-r')][1]";
    public By disabbledRightChevornsCountBy = By.xpath(".//div[@class='sr-card-nav chevron-right cursor-none']");
    public By zeroValueShipmentsCountBy = By.xpath("//div[contains(@class,'sr-card-txt')][text()=0]");
    // Weather pane
    //public String progressbarXpath = ".//*[contains(text(),\"%s\")]//parent::*[@class='sr-progressbar-data']//div[@class='fs-14']";
    public String progressbarXpath = ".//*[contains(text(),\"%s\")]//parent::*[@class='sr-progressbar-data']//div[@class='fs-14 m-r-3']";
    public String weatherAltchevronXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-progressbar-wrapper']//*[contains(@class,'sr-progressbar-icn')]";
    public String earlyOnTimeAtRiskNumbers = ".//*[contains(text(),\"%s\")]/following-sibling::div";
    public By TotalActiveWeatherImpacted = By.xpath(".//*[@class='sr-navpane']//span[contains(@class,'cursor')]");
    public By TotalActive = By.xpath(".//*[@class='sr-navpane-val']");
    public By weatherAlertsCountUI = By.xpath(".//*[contains(text(),'Shipments with weather risk.')]//parent::div//span");
    public String weatherAlertsCount = "//*[contains(text(),\"%s\")]/following-sibling::div";
    public String advisoriesWeatherChevronDisabled = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-progressbar-wrapper']//*[contains(@class,'cursor-none')]";
    public By totalWthImpactShipmentsCount = By.xpath("//span[contains(@class,'cursor-pointer')]");
    public By totalWthImpactShipmentsCountZero = By.xpath("//span[contains(@class,'cursor-none')]");
    public String statusLabelsDD = ".//*[contains(text(),'Shipment Status')]//ancestor::div[@class='sr-weather-toolbar__left']//app-shipment-status//label";
    public String StatuscheckBoxXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-weather-toolbar__left']//app-shipment-status//input[@value=\"%s\"]";
    public String viewImpactedLinkXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@class='sr-card']//div[contains(text(),'Shipments')]//ancestor::*[@class='sr-grid-row']//div[contains(@class,'sr-card-nav')]";
    public String listViewShipmentCount = ".//*[@class='sr-card']//div[contains(text(),'Shipments')]//ancestor::*[@class='sr-grid-row']//div[contains(@class,'sr-card-txt--bold')]";
    public String CityNameListView = ".//div[@class='sr-card']/div[%s]//div[@class='sr-card-name']//span";
    public By shipmentStatusDropdown = By.xpath("//span[contains(text(),'Shipment Status')]");
    public By regionStatusDropdown = By.xpath("//span[contains(text(),'Region')]");
    public String dropdownOption = "//label[@for=\"%s\"]";
    public By filterChevron = By.xpath("(//ul[@role='tablist']//a)[1]");
    public String selectRiskType = "//label[contains(text(),\"%s\")]";
    public String selectRiskSeverity = "//label[contains(text(),\"%s\")]";
    public String selectDate = "//label[contains(text(),\"%s\")]";
    public String filterBubbleXpath = "//*[@class='sr-pill__label']//span[contains(text(),\"%s\")]/parent::span/parent::div/span[contains(text(),\"%s:\")]";// ".//*[@class='sr-pill']//*[contains(text(),'
    public By searchForfilterInput = By.cssSelector((".sr-searchbox__input"));
    public By legacyFilterSearchIcon = By.cssSelector((".sr-searchbox__icon"));
    public By searchForColumnInput = By.cssSelector(("app-shipments-edit-column .search-filter .sr-searchbox__input"));
    public By columnSearchIcon = By.cssSelector(("app-shipments-edit-column .search-filter .sr-searchbox__icon"));
    public String searchForFilterResultText = "//*[contains(text(),\"%s\")]";
    public String cancelSpecificFilterItemFromBubble = ".//*[contains(text(),\"%s\")]/following-sibling::span[@class='sr-pill-item__close']";
    public String durationInNextDaysDropdownFilter = "//select[contains(@id,'In the next ')]";
    public String apply = GenericFunction.locale != Constants.EN_US
            ? this.genericFunctionObject.getLocalizedValue("Apply")
            : "Apply";
    public String applyUpperCase = apply.toUpperCase();

    public String applyButton = "//button[contains(text(),\"%s\")]";
    public By filterCancelButton = By.xpath("//button[contains(text(),'CANCEL')]");
    public String bubbleFilters = "//div/span[contains(text(),'%s:')]//following-sibling::span/span[contains(text(),'%s')]";

    public String statusCheckbox = "//label[@for=\"%s\"]/parent::div/input";
    public By clearButton = By.xpath("//div[contains(@class,'active')]//button[contains(text(),'Clear')]");
    public By clusterPin = By.xpath("(//div[@class='leaflet-marker-icon cluster-icon cluster-text leaflet-zoom-animated leaflet-interactive'])[1]");
    public By cityPinText = By.xpath("(//div[@class='city-pin-text'])[1]");
    public By cityPin = By.xpath("(//div[@class='city-pin-icon'])[1]");
    public String flyOutShipmentLinks = "//div[contains(text(),\"%s\")]/following-sibling::div";
    public By cityNameOnFlyout = By.xpath("//div[@class='sr-title-20']");
    public String cityShipmentlinksInListView = "(//div[contains(text(),\"%s\")]/parent::div/following-sibling::div//div[1])[1]";
    public String cityShimentlinkTxtInListView = "(//div[contains(text(),\"%s\")]/parent::div/following-sibling::div//div[2])[1]";
    public By cityNameInListView = By.xpath("(//div[@class='sr-card-name'])[1]");
    public By AlertIcon = By.xpath("//*[contains(@src,'icon_warning_red@3x.png')]");
    public String alertXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@class='sr-card__left']//*[contains(@src,'icon_warning_red@3x.png')]//ancestor::*[@class='sr-week__item cursor-pointer']//*[@class='sr-week-icn']";
    public String Alertdescription = ".//*[contains(text(),\"%s\")]//ancestor::div//*[@class='sr-card__details sr-card__details-%s']//strong";
    public String AlertSummary = ".//*[contains(text(),\"%s\")]//ancestor::div//*[@class='sr-card__details sr-card__details-%s']//li";
    public String ShipmentStatusListFromAdvisory = ".//div[@class='sr-weather-multiselect']//li";
    public String filterOptionXpath = "(//*[contains(text(),\"%s\")])[3]";
    public String displayOptionsCheckboxes = ("//*[text()=' Display: ']/../div/div/input");
    public By rightFlyOutOptionsBy = By.xpath(".//ul[@class='sr-progressbar-list sr-progressbar-list--card']/li//div[@class='sr-progressbar-data']/div[@class='m-b-3']");
    public By rightFlyOutOptionsListView = By.xpath(("//*[@class='sr-card__list']//div[@class='sr-card-txt']"));
    public String shipmentsNumber = "//div[contains(@class,'sr-card-txt') and contains(text(),\"%s\")]/parent::div/following-sibling::div/div[contains(@class,'sr-card-txt')]";
    public String shipmentsDestinationLastKnownLocation = "//div[@class='sr-card']//*[contains(text(),\"%s\")]";
    public String shipmentsArrow = "//div[contains(@class,'sr-card-txt') and contains(text(),\"%s\")]/parent::div/following-sibling::div/div[contains(@class,'sr-card-nav')]";
    public String preferredLocnNotAvailableLink = "//div[@class='sr-weather-no-location']";
    public String preferredLocnTopToolbar = "//div[contains(@class,'sr-weather-toolbar')]//*[contains(text(),\"%s\")]";
    public String advisories_watermark = "//input[@placeholder='Enter City, State or Zip Code']";
    public By advisories_LocationSearch = By.xpath("//input[@name='searchedLocation']");
    public By advisorydrpdwnoptions = By.xpath("//div[@class='sr-search']/ul/li");
    public By advisory_ListMapToggle = By.xpath("//span[@class='sr-toggle-sliderbox__switch']");
    public By advisory_MapFlyout_AffectedAreas = By.xpath("//span[contains(.,'Affected Areas')]//span[contains(.,'Zip')]");
    public By locationPin = By.xpath("//div[@class='city-pin-text']");
    public By mapPopUp = By.xpath("//div[@class='map-flyout']/div/span/span");

    public String ODApplyBtn = "//button[contains(text(),\"%s\")]";
    public String verifyODPairIcon = "//div/span[@class=\"%s\"]";
    public String addODPairButton = "//span[contains(text(),\"%s\")]";
    public String linkXpath = "//*[contains(text(),\"%s\")]";
    public String buttonXpathCombinedFiles = "(//button[contains(text(),\"%s\")])[2]";

    public By ODErrorMessage = By.xpath("//div[@class='sr-statusUpdate--error m-l-4 m-y-1']");

    public By InvalidODErrorMessage = By.xpath("//li[@class=\"sr-search-list__nodata\"]");
    public By blankOriginErrorMessage = By.xpath("//*[contains(text(),\"Add an Origin\")]");
    public By blankDestinationErrorMessage = By.xpath("//*[contains(text(),\"Add a Destination\")]");

    public By advisory_MapPopup_affectedCount = By.xpath("//span[@class= 'sr-pill__val']");
    public By advisory_MapPopup_ExportList = By.xpath(" //span[@class= 'download-icn active icon-box']");
    public By advisory_Btn_MapPopup_ExportList_DownloadOptn = By.xpath(" //button[@class= 'fdx-c-buttonDC fdx-c-buttonDC--primary']");
    public String kababIcon = "(//span[contains(@class,'kebab-icn-list m-l-2')])[2]";
    public String exportDownloadIcon = "//span[contains(@class,'download-icn icon-box active')]";
    public String verifyStateOrTerritoryValue = "(//div[@col-id='stateCode'])//div//span[text()=\"%s\"]";
    public String verifyRiskTypeValue = "(//div[@col-id='riskType'])//div//div[text()=\"%s\"]";
    String selectDaysRange="(//select[@name='sr-select']/option)[%s]";
    public By dateRangeInUI=By.xpath("//li[@class='p-a-3']/p[2]");
    public By uncheckedCheckBoxes=By.xpath("//input[@role='checkbox' and @aria-checked='false']");
    public By selectDrpDownDays=By.xpath("//select[@name='sr-select']");
    public By inputInTheNextCheckBox=By.xpath("//label[contains(text(),'In the next')]//..//input");
    public By kebabIcn =By.xpath("(.//span[contains(@class,'kebab-icn icn-kebab')])[1]");
    public String scheduleReportMenuLink="//div[@class='d-flex d-flex--space-between label']/div[contains(text(),\"%s\")]";
    public By navigateToCreateScheduleReportLnk=By.xpath("//span[@class='external-link-icn d-inline-block']");

    public By ScheduleReportLink = By.xpath("//div[contains(text(),'Scheduled Reports')]//..//span");

    public By ODclustermap = By.xpath("//*[@class=\"leaflet-marker-icon od-cluster-icon cluster-text leaflet-zoom-animated leaflet-interactive\"]");
    public String kebabIcnBesideFavorites="//span[text()=\"%s\"]//..//..//..//..//span[@class='kebab-icn-list m-l-2']";
    public By trashIcnToDeleteFavorite=By.xpath("//div[contains(@class,'sr-elipsis')]//span[@class='delete-icn m-l-2']");
    public By SetasDefToFavorite=By.xpath("//div[contains(@class,'sr-elipsis')]//span[text()='Set as Default']");
    public String plusIcnToExpandFlyOutHeader="(//span[contains(@class,'plus-icn')])[%s]";
    public String minusIcnToExpandFlyOutHeader="(//span[contains(@class,'minus-icn')])[1]";
    public By flyOutHeader=By.xpath("//div[@class='map-flyout']//div[@class='p-x-4']");
    public String flyOutHeaderTxtAtIndex="(//div[@class='map-flyout']//div[@class='p-x-4'])[%s]";
    public By originHeader=By.xpath("//span[contains(text(),'Origin')]//..//span[@class='sr-pre-shipment__bold']");
    public By destinationHeader=By.xpath("//span[contains(text(),'Destination')]//..//span[@class='sr-pre-shipment__bold']");
    public String locationInputBoxWithIndex="(//input[contains(@placeholder,\"%s\")])[%s]";
    public By addODPairLink=By.xpath("//span[contains(text(),'+ ADD (')]");
    public By ODClustorPurplePoint=By.xpath("//div[contains(@class,'od-cluster-icon')]");
    public By mapFlyOutPopUp=By.xpath("//div[@class='map-flyout']");
    public By commonFlyOutXpath=By.xpath("//div[contains(@class,'map-flyout')]");
    public String ODClustorPurplePointWithIndex = "(//div[contains(@class,'od-cluster-icon')])[%s]";
    public By clusteredFlyOutRow=By.xpath("//div[@class='map-flyout']//div[@class='sr-group']");
    public By countOfServices=By.xpath("//span[@class='cursor-pointer']");
    public By listOfServicesTxt=By.xpath("//div[@class='table-row-cell']/span");
    public String ExistanceFavName = "//ul[@class='sr-viewlist__items']//span[.=\"%s\"]";
    public By ValdeleteOption = By.xpath("(//ancestor::li[@role='tab']//span//div[contains(@class,'options')]//span[.='Delete'])[1]");
    public By ValDefault = By.xpath("(//ancestor::li[@role='tab']//span//div[contains(@class,'options')]//span[.='Set as Default'])[1]");
    public By ValClrDefault = By.xpath("(//ancestor::li[@role='tab']//span//div[contains(@class,'options')]//span[.='Clear Default'])[1]");

    public By upwards = By.xpath("//span[@class='toggle-icn icn up']");
    public By downwards = By.xpath("//span[@class='toggle-icn icn']");
    public By BeforeAction = By.xpath("//div[@class='sr-pill__label']//span[@class='sr-pill__val']");
    public By firstRecordName = By.xpath("(//div[contains(@class,'sr-viewlist')]//li[@class='sr-viewlist__item']//span)[1]");

    public By searchResult = By.xpath("//ul[@class='sr-search-list']//li[1]");
    public By clusters=By.xpath("//div[contains(@class,'cluster-text')]");

    public String FilterRemoveforWindSpeedRisk = "//*[text()=\"%s\"]//..//span[contains(@class,'close')]";
    public String selectFilter = "//*[contains(text(),\"%s\")]";

    public By CurrentStateName = By.xpath("//div[@ref='eCenterContainer']//div[@row-id='0']//div[@col-id='stateName']");
    public AdvisoryPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.homePage = new HomePage(commonHelpers);
    }

    public boolean VerifyMenuSelection(String menuType, String menuName) {
        String menu;
        if (menuType.equalsIgnoreCase("menu")) {
            menu = String.format(advMenu, "span", menuName);
            menu = this.findElement(By.xpath(menu)).getAttribute("class");
        } else {
            menu = String.format(advSubMenu, "span", menuName);
            menu = this.findElement(By.xpath(menu)).getAttribute("class");
        }
        return menu.contains("active");
    }

    public By categoryCount(String category) {
        return By.xpath(String.format(categorySum, category));
    }

    public boolean ValidateWeatherAlertCount() {
        return this.weatherAlertCount == this.categoryCount;
    }

    public void ValidateStatusBasedOnFlag(String status, String flag) {
        Boolean flag1 = this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE") ? Boolean.parseBoolean(this.commonHelpers.getValuefromContextStore("cePortalShowGlobalShipments").toString()) : Boolean.parseBoolean(this.commonHelpers.getValuefromContextStore("customerPortalShowUSInboundShipments").toString());
        this.commonHelpers.AddToContextStore(flag, flag1);
        if (flag1) {
            for (String chekbox : Constants.InternationalStatus) {
                By statusCheckboxEle = By.xpath(String.format(this.statusCheckbox, chekbox));
                this.JavaScriptClick(statusCheckboxEle);
            }
        }
        for (String chekbox : Constants.NonInternationalStatus) {
            log.info(chekbox);
            By statusCheckboxEle = By.xpath(String.format(this.statusCheckbox, chekbox));
            this.JavaScriptClick(statusCheckboxEle);
        }

    }

    public boolean VerifyPlaceHoldertext(String placeholder, List<String> holders) {
        boolean flag = true;
        //List<String> holders = table.asList(String.class);
        for (String holder : holders) {
            if (flag) {
                flag = this.elementIsDisplayed(this.getByusingString(String.format(this.placeHoldertext, placeholder, holder)));
            } else {
                break;
            }
        }
        return flag;
    }

    public void EnterLocation(String reference, String location) {
        try {
            this.enterText(this.getByusingString(String.format(FromToTb, reference.split("-")[0])), location);
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in EnterLocation method: " + e.getMessage());
        }
    }

    public boolean VerifySearchResults(String reference) {
        boolean flag = true;
        this.VerifyMenuSelection("subMenu", "Weather forecast");
        List<WebElement> results = this.findElements(this.getByusingString(String.format(this.SearchResultsList, reference.split("-")[0])));
        for (WebElement element : results) {
            if (flag) {
                String country = element.getText().split(",")[element.getText().split(",").length - 1].trim();
                flag = country.contains("USA") || country.equalsIgnoreCase("JAM");
            } else break;
        }
        return flag;
    }

    public void SelectSearchResults(String index, String reference) {
        String Selectindex = "";
        switch (index) {
            case "First":
                Selectindex = "1";
                break;
            case "Second":
                Selectindex = "2";
                break;
            case "Third":
                Selectindex = "3";
                break;
        }
        this.clickOnElement(this.getByusingString(String.format(this.SelectSearchResult, reference.split("-")[0], Selectindex)));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public boolean VerifySelectedValueinSearchBox(String cityName, String reference) {
        String SelectedText = this.findElement(this.getByusingString(String.format(this.SelectedValueinSearchBox, reference.split("-")[0]))).getAttribute("ng-reflect-model");
        return Arrays.asList(SelectedText.trim().split(",")).contains(cityName);
    }

    public void WaitweatherForcastisDisplayed() {
        this.waitUntilNotVisible(weatherLoader);
    }

    public boolean ValidatecityInMap(String cityName) {
        return this.elementIsDisplayed(this.getByusingString(this.buildXpathForString(cityName)), false);
    }

    public void MapOperations(String operation, String map) {
        String index = map.equalsIgnoreCase("From") ? "1" : "2";
        switch (operation) {
            case "Zoom in":
                this.clickOnElement(this.getByusingString(String.format(zoomInOutxpath, operation, index)));
                break;
            case "Zoom out":
                this.clickOnElement(this.getByusingString(String.format(zoomInOutxpath, operation, index)));
                break;
        }
    }

    public Boolean VerifyTemparatureInfo(String days, String reference) throws Exception {
        boolean flag = true;
        List<WebElement> weatherIcons = this.findElements(this.getByusingString(String.format(this.weatherIcons, reference.split("-")[0])));
        Response resp = this.commonHelpers.GetValueFromResponseCollection("MS_Advisories_weatherInfo");
        WeatherForecasts weatherForecastResp = this.commonHelpers.unMarshall(resp.asString(), WeatherForecasts.class);
        for (int i = 1; i <= weatherIcons.size(); ++i) {
            if (flag) {
                // String ApimaxTemp = weatherForecastResp.getDailyForecasts().get(i -
                // 1).getTemperature().getMaximum()
                // .getValue().toString();
                // String ApiminTemp = weatherForecastResp.getDailyForecasts().get(i -
                // 1).getTemperature().getMinimum()
                // .getValue().toString();
                // String ApiIconPhrase = weatherForecastResp.getDailyForecasts().get(i -
                // 1).getDay().getIconPhrase();
                // String UImaxTemp = this.getText(this.getByusingString(
                // String.format(this.maxTempTooltip, reference.split("-")[0],
                // String.valueOf(i))));
                // String UIminTemp = this.getText(this.getByusingString(
                // String.format(this.minTempTooltip, reference.split("-")[0],
                // String.valueOf(i))));
                // String UIiconPhrase = this.getText(this.getByusingString(
                // String.format(this.IconPhraseTooltip, reference.split("-")[0],
                // String.valueOf(i))));
                // flag = (UImaxTemp.contains(ApimaxTemp) && UIminTemp.contains(ApiminTemp)
                // && (ApiIconPhrase.equalsIgnoreCase(UIiconPhrase)));
                this.commonHelpers.thinkTimer(10000);
                String UImaxTemp = this.findElement(this.getByusingString(String.format(this.maxTempTooltip, reference.split("-")[0], i))).getAttribute("innerText");
                String UIminTemp = this.findElement(this.getByusingString(String.format(this.maxTempTooltip, reference.split("-")[0], i))).getAttribute("innerText");
                String UIiconPhrase = this.findElement(this.getByusingString(String.format(this.IconPhraseTooltip, reference.split("-")[0], i))).getAttribute("innerText");
                log.info("UI Icon Phrase: " + UIiconPhrase);
                flag = (UImaxTemp.contains("F") && UIminTemp.contains("F") && (UIiconPhrase.replace(" ", "").matches("^[a-zA-Z/-]*$")));
            } else {
                break;
            }
        }
        return flag;
    }

    public Boolean VerifyAlertsInfo(String Reference) throws Exception {
        boolean flag = true;
        List<WebElement> weatherIcons = this.findElements(AlertIcon);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(Reference);
        if (!resp.getBody().asString().contains("[]") && weatherIcons.size() != 0) {
            WeatherAlert weatherAlert = this.commonHelpers.unMarshall(resp.asString(), WeatherAlert.class);
            for (int i = 1; i <= weatherIcons.size(); ++i) {
                if (flag) {
                    this.commonHelpers.thinkTimer(10000);
                    weatherIcons.get(0).click();
                    String UIiconPhrase = this.findElement(By.xpath("//div[@class='sr-week-details']//li")).getAttribute("innerText");
                    log.info("UI Alert icon Phrase: " + UIiconPhrase);
                    flag = UIiconPhrase.contains(weatherAlert.getDescription().getEnglish());

                } else {
                    break;
                }
            }
        } else if (resp.getBody().asString().contains("[]") && weatherIcons.size() == 0) {
            log.info("There are no alerts present for the selected city/pincode");
        } else {
            Assert.fail("Weather icons present != API response");
        }
        return flag;
    }

    public boolean VerifyweatherForecastInfo(String days, String reference) {
        boolean flag1 = true;
        boolean flag;
        List<WebElement> weatherIcons = this.findElements(this.getByusingString(String.format(this.weatherIcons, reference.split("-")[0])));
        for (int i = 1; i <= weatherIcons.size(); ++i) {
            int counter = 2;
            if (flag1) {
                String day = this.findElement(this.getByusingString(String.format(this.weatherIconsModel, reference.split("-")[0], i, counter))).getAttribute("class");
                counter++;
                String date = this.findElement(this.getByusingString(String.format(this.weatherIconsModel, reference.split("-")[0], i, counter))).getAttribute("class");
                flag1 = day.contains("sr-week-day") && date.equalsIgnoreCase("sr-week-date");
            } else {
                break;
            }
        }
        flag = Integer.parseInt(days) == weatherIcons.size();
        return flag & flag1;
    }

    public boolean ValidateAPIwithUIforWeatherAlert(OverallAlert alert, String attribute) {
        boolean flag;
        String actualCount = null;
        String expCount = null;
        switch (attribute) {
            case "WeatherImpacted":
                actualCount = this.getText(weatherCount).trim().replace(",", "");
                expCount = alert.getWeatherImpacted().toString();
                break;
            case "ShipmentImpacted":
                actualCount = this.getText(shipmentAlertCount).trim().replace(",", "");
                expCount = alert.getWeatherImpacted().toString();
                this.weatherAlertCount = Integer.parseInt(actualCount);
                break;
            case "On Time":
                actualCount = this.getText(categoryCount(attribute)).trim().replace(",", "");
                expCount = alert.getOnTime().toString();
                this.categoryCount = Integer.parseInt(actualCount) + this.categoryCount;
                break;
            case "At Risk":
                actualCount = this.getText(categoryCount(attribute)).trim().replace(",", "");
                expCount = alert.getAtRisk().toString();
                this.categoryCount = Integer.parseInt(actualCount) + this.categoryCount;
                break;
            case "Intercepted":
                actualCount = this.getText(categoryCount(attribute)).trim().replace(",", "");
                expCount = alert.getIntercepted().toString();
                this.categoryCount = Integer.parseInt(actualCount) + this.categoryCount;
                break;
            case "Delayed":
                actualCount = this.getText(categoryCount(attribute)).trim().replace(",", "");
                expCount = alert.getDelayed().toString();
                this.categoryCount = Integer.parseInt(actualCount) + this.categoryCount;
                break;
            default:
                break;
        }
        Assertions.assertThat(expCount).isNotNull();
        flag = expCount.equalsIgnoreCase(actualCount);
        return flag;
    }

    public boolean verifyCheckBoxSelection(String checkBoxName, String state) {
        String actualState = this.findElement(By.xpath(String.format(advCheckBoxState, checkBoxName))).getAttribute("aria-checked").equals("true") ? "checked" : "unchecked";
        return actualState.equalsIgnoreCase(state);
    }

    public void performActionOnFilter(String action, String checkBoxName) {
        // String actualState = this.findElement(By.xpath(String.format(advCheckBox,
        // checkBoxName.toLowerCase())))
        // .getAttribute("ng-reflect-model").contains("true") ? "check" : "uncheck";

        // String actualState1 = this.findElement(By.xpath(String.format(advCheckBox,
        // checkBoxName.toLowerCase())))
        // .getAttribute("class").contains("ng-untouched") ? "check" : "uncheck";
        this.waitUntilNotVisible(By.xpath(String.format(advCheckBoxState, checkBoxName)));
        String actualState1 = this.findElement(By.xpath(String.format(advCheckBoxState, checkBoxName))).getAttribute("aria-checked").contains("true") ? "check" : "uncheck";

        if (!action.equalsIgnoreCase(actualState1)) {
            this.clickOnElement(By.xpath(String.format(advCheckBox, checkBoxName)));
        }
    }

    public void clickOnCityOrCluster(String notation, String count) {
        if (notation.equalsIgnoreCase("cluster")) {
            this.findElement(By.xpath(String.format(cluster, count)), false).click();
        }
    }

    public String validateCountOnPin(String city) {
        return this.getText(By.xpath(String.format(categorySum, city)));
    }

    public Boolean ValidateAlertsinAdvisories(String view) {
        List<WebElement> icons = this.findElements(this.AlertIcon);
        if (icons.size() == 0)
            log.info("**WARNING** NO alerts are visible on advisories , it could be no weather alerts for data present.");
        return true;
    }

    public boolean performActionOnFilterOption(String module, DataTable table) {
        Boolean flag = true;
        String Xpath = "";
        List<String> subModules = table.asList(String.class);
        if (module.equalsIgnoreCase("Date")) {
            for (String mod : subModules) {
                if (flag) {
                    switch (mod) {
                        case "Range":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.dateRangeXpath, mod)));
                            break;
                        case "Header":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.headerXpath, mod)));
                            break;
                        case "Days":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.daysXpath, mod)));
                            break;
                        case "Today":
                            flag = this.elementIsDisplayed(By.xpath(String.format(this.todayXpath, mod)));
                            break;
                    }
                    log.info("Test - Verifying: " + mod + "-" + flag);
                }

            }
        }
        return flag;
    }

    public Boolean ValidateWeatherForecast(String endpointKey) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        ArrayList validationFlags = new ArrayList();
        List<City> cities;
        try {
            if (!endpointKey.equalsIgnoreCase("MS_Advisories_PreferredLocations")) {
                OverallAlert alert = this.commonHelpers.unMarshall((resp.asString()), OverallAlert.class);
                Country country = alert.getCountries().get(0);
                cities = country.getCities();
            } else {
                cities = this.commonHelpers.unMarshall(resp, City[].class);
            }
            int counter = 0;
            if (cities.size() > 0) {
                for (City city : cities) {
                    if (validationFlags.size() == 0 || !validationFlags.contains(false)) {
                        String cityFormat = String.format("%s, %s, %s", city.getName(), city.getStateName(), city.getCountry());
                        log.info("City name in app format: " + cityFormat);
                        List<WebElement> elements = this.findElements(By.xpath(String.format(this.alertXpath, cityFormat)));
                        if (elements.size() > 0) {
                            for (WebElement ele : elements) {
                                if (validationFlags.size() == 0 || !validationFlags.contains(false)) {
                                    ele.click();
                                    this.commonHelpers.thinkTimer(1500);
                                    String description = city.getWeatherAlerts().get(0).getDescription().getEnglish().replace(" ", "");
                                    log.info("Description from API: " + description);
                                    String summary = city.getWeatherAlerts().get(0).getArea().get(0).getSummary().replace(" ", "");
                                    log.info("Summary from API: " + summary);
                                    log.info("==========================");
                                    log.info("Description from UI: " + this.findElements(By.xpath(String.format(this.Alertdescription, cityFormat, counter))).get(0).getText().replace(" ", ""));
                                    log.info("Summary from UI: " + this.findElements(By.xpath(String.format(this.AlertSummary, cityFormat, counter))).get(0).getText().split("-")[1].replace(" ", ""));
                                    validationFlags.add(description.equalsIgnoreCase(this.findElements(By.xpath(String.format(this.Alertdescription, cityFormat, counter))).get(0).getText().replace(" ", "")));
                                    validationFlags.add(summary.replace(" ", "").equalsIgnoreCase(this.findElements(By.xpath(String.format(this.AlertSummary, cityFormat, counter))).get(0).getText().split("-")[1].replace(" ", "")));
                                } else {
                                    break;
                                }
                            }
                        }
                        counter++;
                    } else {
                        break;
                    }
                }
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in validation of weather forecast");
            return false;
        }
        return !validationFlags.contains(false);

    }

    public void navigateToView(String view) {
        this.waitUntilNotVisible(this.loadingIndicator);
        String viewActiveState = this.findElement(By.xpath(String.format(mapOrListControl, view))).getAttribute("class");
        if (!viewActiveState.contains("active")) {
            this.clickOnElement(By.xpath(String.format(switchView, view)));
        }
    }

    public int getTopCardCityCountforFilter(String filter) {
        return filter.contains("+") ? Integer.parseInt(this.getText(By.xpath(listView))) : Integer.parseInt(this.getText(By.xpath(String.format(countForCity, filter))));
    }

    public boolean verifyListOrMapView(String view) {
        return view.equalsIgnoreCase("Map") ? this.elementIsDisplayed(By.xpath(mapView)) : this.elementIsDisplayed(By.xpath(listViewLocator));
    }

    public void ClickOnLinkForCity(String link, String cityName) {
        cityName = cityName.contains("ContextStore") ? this.commonHelpers.getValuefromContextStore(cityName).toString() : cityName;
        this.clickOnElement(By.xpath(String.format(this.viewImpactedLinkXpath, cityName)));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void validatezeros(String module) {
        boolean flag;
        if (module.equalsIgnoreCase("weather impacted shipments")) {
            flag = Integer.parseInt(this.getText(this.weatherAlertsCountUI)) > 0;
            if (!flag) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }

    public boolean visibilityOfCityPin(String cityPin, String visibility) {
        boolean state = false;
        if (cityPin.equalsIgnoreCase("City Pin")) {
            while (this.elementIsDisplayed(genericCluster, false))
                this.clickOnElement(this.findElement(genericCluster));
            this.waitUntilVisible(genericCityPin);
            state = this.elementIsDisplayed(genericCityPin, false);
        } else if (cityPin.equalsIgnoreCase("Cluster Pin")) {
            state = this.elementIsDisplayed(genericCluster, false);
        }

        if (visibility.equalsIgnoreCase("not visible") && !state) {
            return true;
        } else return visibility.equalsIgnoreCase("visible") && state;
    }

    public void ClickWeatherPaneLinks(String link) {
        Map<String, Boolean> linksMap = (Map<String, Boolean>) this.commonHelpers.getValuefromContextStore("AdvisoryLinks");
        Boolean flag = linksMap.get(link);
        if (!flag) {
            if (this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
                this.commonHelpers.removeKeyinContextStore(Constants.skipSteps);
            }
            if (link.equalsIgnoreCase("Active Weather Alerts")) {
                this.JavaScriptClick(TotalActiveWeatherImpacted);
            } else {
                this.JavaScriptClick(By.xpath(String.format(this.weatherAltchevronXpath, link)));
            }
            this.waitUntilNotVisible(this.loadingIndicator);
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    public Boolean ValidateWeatherAlertsInfo(String Validationcontext, DataTable dataTable) {
        Map<String, String> ValidationParams = dataTable.asMap(String.class, String.class);
        Map<String, Boolean> skipFlags = new HashMap<>();
        boolean flag = true;
        String Actual;
        int Expected = 0;
        for (String key : ValidationParams.keySet()) {
            if (this.elementIsNotDisplayed(TotalActive)) {
                this.clickOnElement(leftFlyoutChevron);
            }
            Response resp = this.commonHelpers.GetValueFromResponseCollection(ValidationParams.get(key));
            if (flag) {
                switch (key) {
                    case "Active Weather Alerts":
                        Actual = this.getText(TotalActiveWeatherImpacted);
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));

                        String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();

                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, user.equalsIgnoreCase("CE") ? "activeWeatherImpactedInternal" : "activeWeatherImpacted");
                        // flag = this.commonHelpers.AssertCountswithCorrection(Expected,
                        // Integer.parseInt(Actual.replace(",", "")));
                        flag = (Expected == Integer.parseInt(Actual.replace(",", "")));
                        break;
                    case "Total Active":
                        Actual = this.getText(TotalActive).substring(3);
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));
                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, "totalActive");
                        flag = this.commonHelpers.AssertCountswithCorrection(Expected, Integer.parseInt(Actual.replace(",", "")));
                        break;
                    case "On Time":
                        Actual = this.getText(By.xpath(String.format(this.progressbarXpath, key)));
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));
                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, "weatherImpactedOnTime");
                        flag = this.commonHelpers.AssertCountswithCorrection(Expected, Integer.parseInt(Actual.replace(",", "")));
                        break;
                    case "At Risk":
                        Actual = this.getText(By.xpath(String.format(this.progressbarXpath, key)));
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));
                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, "weatherImpactedAtRisk");
                        flag = this.commonHelpers.AssertCountswithCorrection(Expected, Integer.parseInt(Actual.replace(",", "")));
                        break;
                    case "Intervened":
                        Actual = this.getText(By.xpath(String.format(this.progressbarXpath, key)));
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));
                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, "weatherImpactedIntervened");
                        flag = this.commonHelpers.AssertCountswithCorrection(Expected, Integer.parseInt(Actual.replace(",", "")));
                        break;
                    case "Early":
                        Actual = this.getText(By.xpath(String.format(this.progressbarXpath, key)));
                        skipFlags.put(key, Actual.equalsIgnoreCase("0"));
                        Expected = this.commonHelpers.jsonHelpers.GetValueFromResp(resp, "weatherImpactedEarly");
                        flag = this.commonHelpers.AssertCountswithCorrection(Expected, Integer.parseInt(Actual.replace(",", "")));
                        break;
                }
                this.commonHelpers.AddToContextStore(key, Expected);
            } else break;
        }
        this.commonHelpers.AddToContextStore("AdvisoryLinks", skipFlags);
        return flag;
    }

    public boolean visibilityOfCityCard(String visibility) {
        boolean state = this.elementIsDisplayed(By.xpath(genericCityCard), false);
        if (visibility.equalsIgnoreCase("visible") && state) {
            return true;
        } else return visibility.equalsIgnoreCase("not visible") && !state;
    }

    public void NavigateToSubMenu(String subMenu) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.clickOnElement(By.xpath(String.format(advSubMenu, "span", subMenu)));
            //Actions actions=new Actions(DriverManager.getDrv());
            //actions.moveToElement(this.findElement(By.xpath(String.format(advSubMenu, "span", subMenu)))).doubleClick().build().perform();
        }
    }

    /**
     * This method gives TotalCont from Shipment page
     *
     * @return totalListUI
     */
    public HashMap<String, Integer> GettingTotalCont() {
        List<WebElement> cities = this.findElements(By.xpath("//div[@class='sr-card-name']"));
        HashMap<String, Integer> totalListUI = new HashMap<>();

        if (cities.size() != 0) {
            for (WebElement city : cities) {
                String cityName = city.getText().split(",")[0].trim(); // shipperCityCountUI
                totalListUI.put(cityName, Integer.parseInt(this.getText(By.xpath(String.format(cityCountUI, cityName)))));
            }
        }

        return totalListUI;
    }

    public void ClickOnCityPin(String Citypin) {
        this.clickOnElement(genericCityPin);
    }

    public void ClickOnrightChevronandStoreShimpentData(String Citypin) {
        this.commonHelpers.AddToContextStore("Total", this.getText(shipmentsTotalBy));
        this.commonHelpers.AddToContextStore("City", this.getText(CitynameXpath));
        this.clickOnElement(rightFlyoutShipmentsRightChervon);
    }

    public void ClickOnrightChevronandStoreShimpentData_forGivenCity(String Citypin) {
        this.commonHelpers.AddToContextStore("Total", this.getText(getByusingString(String.format(listviewTotal, Citypin))));
        this.commonHelpers.AddToContextStore("City", Citypin);
        this.clickOnElement(getByusingString(String.format(viewImpactedLinkXpath, Citypin)));
    }

    public void ClickOnrightChevronandStoreShipmentData() {
        List<WebElement> elements = this.findElements(By.xpath(this.listViewShipmentCount));
        for (WebElement element : elements) {
            if (Integer.parseInt(element.getText()) > 0) {
                String Citypin = this.getText(By.xpath(String.format(this.CityNameListView, elements.indexOf(element) + 1)));
                this.commonHelpers.AddToContextStore("City", Citypin);
                this.commonHelpers.AddToContextStore("Total", this.getText(getByusingString(String.format(listviewTotal, Citypin))));
                this.clickOnElement(getByusingString(String.format(viewImpactedLinkXpath, Citypin)));
                return;
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }

    public boolean CompareCountonPageandViewing(String viewingCount) {
        String pageCount = this.commonHelpers.getValuefromContextStore("Total").toString();
        return Integer.parseInt(viewingCount) <= Integer.parseInt(pageCount);
    }

    public boolean CompareCityonPageandCitybubble(String CityonCityBubble) {
        String Cityonpage = this.commonHelpers.getValuefromContextStore("City").toString();
        // return Cityonpage.equalsIgnoreCase(CityonCityBubble);
        return Cityonpage.split(",")[0].trim().equalsIgnoreCase(CityonCityBubble.split(",")[0].trim());
    }

    /**
     * Method to verify RightChevron is Clickable or not when Preferred city has no
     * Impacted Shipments
     *
     * @return boolean
     */
    public boolean isRightChevronClickable() {
        return this.findElements(zeroValueShipmentsCountBy).size() == this.findElements(disabbledRightChevornsCountBy).size();

    }

    public boolean ValidateIfWeatherRiskShipmentCountIsZero(String chevron) {
        int count = Integer.parseInt(getWeatherImpactedShipmentCount(chevron).replaceAll(",", ""));

        boolean isDisabledActual = this.elementIsDisplayed(this.getByusingString(String.format(advisoriesWeatherChevronDisabled, chevron)));
        boolean isDisabledExpected = count == 0;

        Assert.assertEquals(chevron + " chevron is enabled/disabled when count is: " + count, isDisabledActual, isDisabledExpected);

        return isDisabledActual;
    }

    public String getWeatherImpactedShipmentCount(String chevron) {
        return this.getText(this.getByusingString(String.format(weatherAlertsCount, chevron)));
    }

    public void verifyAvgWeatherCount() {
        this.waitUntilNotVisible(this.loadingIndicator);
        int early = Integer.parseInt(getWeatherImpactedShipmentCount("Early").replaceAll(",", ""));
        int onTime = Integer.parseInt(getWeatherImpactedShipmentCount("On Time").replaceAll(",", ""));
        int atRisk = Integer.parseInt(getWeatherImpactedShipmentCount("At Risk").replaceAll(",", ""));
        String countFromUI;
        if (early + onTime + atRisk != 0) {
            countFromUI = this.findElement(totalWthImpactShipmentsCount).getText();
        } else {
            countFromUI = this.findElement(totalWthImpactShipmentsCountZero).getText();
        }

        //int intervened = Integer.parseInt(getWeatherImpactedShipmentCount("Intervened").replaceAll(",", ""));
        int totalCount = Integer.parseInt(countFromUI.replaceAll(",", ""));
        // saving the value so that in case its 0 we can skip validation for other sections.
        TOTALCOUNT = totalCount;
        Assertions.assertThat(totalCount).withFailMessage("total count --> " + totalCount + "<-- on advisory page is not matching with sum of early+ontime+atrisk -->" + early + onTime + atRisk).isEqualTo(early + onTime + atRisk);


    }

    public void clickWeatherImpactedShipmentChevron(String chevron) {
        this.clickOnElement(By.xpath(String.format(weatherAltchevronXpath, chevron)));
    }

    public void SelectWeatherStatusdropdown(String ValueToSelect, String ddName) {
        String Status = this.commonHelpers.getValuefromContextStore(ValueToSelect).toString();
        this.JavaScriptClick(By.xpath(String.format(this.StatuscheckBoxXpath, ddName, Status)));
    }

    public Boolean ValidateGreyClusterorPins(String clusters, String citypins) {
        boolean flag;
        flag = this.elementIsDisplayed(By.xpath(".//*[contains(@class,'inactive-cluster-icon')]"), false);
        if (flag && this.findElements(By.xpath(".//*[contains(@class,'inactive-cluster-icon')]")).get(0).isDisplayed()) {
            this.JavaScriptClick(By.xpath(".//*[contains(@class,'inactive-cluster-icon')]"));
            this.commonHelpers.thinkTimer(2000);
        }
        flag = this.findElements(By.xpath(".//*[contains(@class,'inactive-pin-icon')]")).get(0).isDisplayed();
        return flag;
    }

    public Boolean ValidateDropDownvalues(String dropdownName) {
        boolean flag = true;
        List<WebElement> labels = this.findElements(By.xpath(String.format(this.statusLabelsDD, dropdownName)));
        List<String> LabelNames = new ArrayList<>();
        for (WebElement element : labels) {
            log.info("Label Name: " + element.getText());
            LabelNames.add(element.getText());
        }
        // Collections.sort(LabelNames);
        for (int i = 0; i < LabelNames.size(); ++i) {
            if (!LabelNames.get(i).equalsIgnoreCase(Constants.ActiveStatuses.get(i))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public Boolean ValidateDropdown(DataTable dropdownStatus) {
        boolean flag = true;
        List<String> statuses = dropdownStatus.asList(String.class);
        for (String status : statuses) {
            if (this.elementIsNotDisplayed(By.xpath(String.format(this.dropdownOption, status)))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public Boolean ValidateShipmentStatusCheckboxesPresence(DataTable dropdownStatuses) {
        boolean flag = true;
        List<String> statusesCheckbox = dropdownStatuses.asList(String.class);
        for (String statusCheckbox : statusesCheckbox) {
            if (this.elementIsNotDisplayed(By.id(statusCheckbox))) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    public String getCheckedStateOfShipmentStatus(String shipmentStatus) {
        By statusEle = By.xpath(String.format(this.statusCheckbox, shipmentStatus));
        return this.getAttributeValue(statusEle, Constants.EditColumnsCheckboxAttribute);
    }

    public void clickOnOption(String filterOption, String record) {
        // this.ScrollIntoView(findElement(By.xpath(String.format(filterOptionXpath, filterOption))));
        this.Mouse_MoveToElement(findElement(By.xpath(String.format(filterOptionXpath, filterOption, record))));
        this.JavaScriptClick(By.xpath(String.format(filterOptionXpath, filterOption, record)));
    }

    public List<String> getShipmentStatusList() {
        List<String> shipmentStatusListofAdvisoryPage = new ArrayList<>();
        for (WebElement element : this.findElements(this.getByusingString(this.ShipmentStatusListFromAdvisory))) {
            shipmentStatusListofAdvisoryPage.add(element.getText());
        }
        return shipmentStatusListofAdvisoryPage;

    }

    public boolean VerifySearchResultsForPIN(String reference) {
        boolean flag;
        this.VerifyMenuSelection("subMenu", "Weather forecast");
        this.waitUntilVisible(this.getByusingString(String.format(this.SearchResultsList, reference.split("-")[0])));
        List<WebElement> results = this.findElements(this.getByusingString(String.format(this.SearchResultsList, reference.split("-")[0])));
        WebElement element = results.get(0);
        //if (flag) {
        String country = element.getText().split(",")[element.getText().split(",").length - 1].trim();
        flag = country.equalsIgnoreCase("USA") || country.equalsIgnoreCase("JAM");
        //}
        return flag;
    }

    public boolean verifyAdvisoriesDisplaySection() {
        List<WebElement> displayOptions = this.findElements(By.xpath(this.displayOptionsCheckboxes));
        String destination = displayOptions.get(0).findElement(By.xpath("../label")).getText();
        String lastKnownLocn = displayOptions.get(1).findElement(By.xpath("../label")).getText();
        String destChecked = displayOptions.get(0).getAttribute("aria-checked");
        String lastKnownLocnCecked = displayOptions.get(1).getAttribute("aria-checked");
        return destination.equals("Destination") && lastKnownLocn.equals("Last known location") && destChecked.equals("true") && lastKnownLocnCecked.equals("true");
    }

    public boolean verifyRightFlyOutOptions(String view) {
        List<WebElement> options;
        int indexDest = 0, indexLastknwnLocn = 1;

        if (view.equals("Map")) {
            options = this.findElements(this.rightFlyOutOptionsBy);
        } else {
            options = this.findElements(this.rightFlyOutOptionsListView);
            indexDest = 1;
            indexLastknwnLocn = 2;
        }

        return options.get(indexDest).getText().equalsIgnoreCase("DESTINATION") && options.get(indexLastknwnLocn).getText().equalsIgnoreCase("LAST KNOWN LOCATION");
    }

    public void ValidateDataFromAdvisoryToShipment(String option) {
        // Click on the option from advisory page
        if (TOTALCOUNT == 0) {
            log.error(" **WARNING** Since number of shipments are 0 on Shipment section under Advisory Page, so no section on right side for -->" + option);
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            return;
        }
        WebElement element = this.findElement(By.xpath(String.format(shipmentsNumber, option)));
        // Saving the value for the number displayed
        int totalNumber = Integer.parseInt(element.getText());
        // Navigating to shipments page
        if (totalNumber == 0) {
            log.info("Count for " + option + " is 0. Hence we cannot goto shipment page");
            return;
        }
        this.clickOnElement(By.xpath(String.format(shipmentsArrow, option)));
        // Making sure the number we saw earlier is same as the number present on this page
        ShipmentOverviewPage shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
        int countOnMyShipments = shipmentOverviewPage.getViewCount();
        // checking the count on previous page matches with the count here
        Assertions.assertThat(Math.abs(totalNumber - countOnMyShipments)).withFailMessage("Matching for data on Advisory page - " + totalNumber + " != Viewing Count on my shipments page - " + countOnMyShipments).isLessThanOrEqualTo((int) Math.abs(.01 * totalNumber));

        // Validating region filter is not applied
        Assert.assertEquals(0, this.findElements(shipmentOverviewPage.filterApplied).stream().filter(s -> s.getText().contains("region")).count());
    }

    public void ValidateDataFromAdvisoryToShipmentLeftSide(String option) {
        // Click on the option from advisory page
        WebElement element = this.findElement(By.xpath(String.format(earlyOnTimeAtRiskNumbers, option)));
        // Saving the value for the number displayed
        int totalNumber = Integer.parseInt(element.getText());
        // Navigating to shipments page
        if (totalNumber == 0) {
            log.info("Count for " + option + " is 0. Hence we cannot goto shipment page");
            return;
        }
        this.clickOnElement(By.xpath(String.format(weatherAltchevronXpath, option)));
        // Making sure the number we saw earlier is same as the number present on this page
        ShipmentOverviewPage shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
        int countOnMyShipments = shipmentOverviewPage.getViewCount();
        // checking the count on previous page matches with the count here
        Assertions.assertThat(Math.abs(totalNumber - countOnMyShipments))
//                .withFailMessage("Matching for data on Advisory page - " + totalNumber +
//                " != Viewing Count on my shipments page - " + countOnMyShipments)
                .isLessThanOrEqualTo((int) Math.abs(.01 * totalNumber));

        // Validating region filter is not applied
        Assert.assertEquals(0, this.findElements(shipmentOverviewPage.filterApplied).stream().filter(s -> s.getText().contains("region")).count());
    }

    public String verifyLocationNotSetMessage() {
        return this.getText(By.xpath(this.preferredLocnNotAvailableLink));
    }


    public void validateWeatherForecastLocalisation(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String location = this.genericFunctionObject.getLocalizedValue("location");
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            switch (value) {
                case "Weather":
                    localisedValue = this.genericFunctionObject.getLocalizedValue(value);
                    //this.waitUntilNotVisible(this.loadingIndicator,40);
                    String WeatherName = this.getText(By.xpath("//a[@href='/fdxqa/advisories/weather']"));
                    Assert.assertEquals(localisedValue,WeatherName);
//                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.homePage.topNavigation, localisedValue)))).isTrue();
                    break;

                case "From:(Location)":
                    String from = this.genericFunctionObject.getLocalizedValue("FROM");
                    String finalString = from + ":(" + location + ")";
                    finalString = finalString.substring(0,1).toUpperCase()+finalString.substring(1).toLowerCase();
                    String FromName = this.getAttributeValue(By.xpath("(//input[@name='searchedLocation'])[1]"), "placeholder");
                    Assert.assertEquals(finalString.toLowerCase(),FromName.toLowerCase());
//                    // Verifying the placeholder also
//                    List<String> list = new ArrayList<>();
//                    list.add(finalString);
//                    softly.assertThat(this.VerifyPlaceHoldertext("placeholder", list)).isTrue();
                    break;

                case "To:(Location)":
                    String to = this.genericFunctionObject.getLocalizedValue("To");
                    finalString = to + ":(" + location + ")";
                    finalString = finalString.substring(0,1).toUpperCase()+finalString.substring(1).toLowerCase();
                    String ToName = this.getAttributeValue(By.xpath("(//input[@name='searchedLocation'])[2]"), "placeholder");
//                    String ToName = this.getText(By.xpath("(//input[@name=\"searchedLocation\"])[2]"));
//                    int Tocount = this.getCount(By.xpath("//label[normalize-space() = '"+finalString+"']"));
                    Assert.assertEquals(finalString.toLowerCase(),ToName.toLowerCase());
//                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.searchLabelsFromTo, finalString)))).isTrue();
                    // Verifying the placeholder also
//                    List<String> tolist = new ArrayList<>();
//                    tolist.add(finalString);
//                    softly.assertThat(this.VerifyPlaceHoldertext("placeholder", tolist)).isTrue();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
//        softly.assertAll();
    }

    public boolean verifyAccountAliastext(String accountText, List<String> texts) {
        boolean flag = true;
        //List<String> holders = table.asList(String.class);
        for (String text : texts) {
            if (flag) {
                flag = this.elementIsDisplayed(this.getByusingString(String.format(this.addAccountAlias, accountText, text)));
            } else {
                break;
            }
        }
        return flag;
    }

    public void clickOnODLink(String link) {
        this.waitUntilVisible(By.xpath(String.format(addODLink, link)));
        // this.clickOnElement(By.xpath(String.format(addODLink, link)));
    }

    public void addODLocation(String city) {
        this.clickOnElement(clickOnODTextbox);
        this.enterText(clickOnODTextbox, Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(enterODLocation);
        this.enterText(enterODLocation, city);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);
        this.waitUntilVisible(By.xpath(String.format(this.selectODOption, city)));
        this.clickOnElement(By.xpath(String.format(this.selectODOption, city)));
    }

    public void validatePreferredLocationLocalization(DataTable dataTable) {

        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);

            switch (value) {
                case "Advisories":
                case "Weather":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.homePage.topNavigation, localisedValue)))).isTrue();
                    break;

                case "Display":
                case "Destination":
                case "Last known location":
                case "Map":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.preferredLocnTopToolbar, localisedValue)))).isTrue();
                    break;
                case "List":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.preferredLocnTopToolbar, localisedValue)))).isTrue();
                    // Changing to list view to do further validations
                    this.navigateToView(localisedValue);
                    break;

                case "List.Shipments":
                case "List.Destination":
                case "List.Last known location":
                    this.waitForDOMToLoad(DriverManager.getDrv());
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.shipmentsDestinationLastKnownLocation, localisedValue)))).isTrue();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public boolean verifyDeleteConfirmationPopUpMessagePS() {
        this.findElement(deleteMessagePopUpPS).getText();
        return false;
    }


    public void DeleteFavorite() {
        this.elementIsDisplayed(By.xpath(String.format(this.favoriteDeleteIcon)));
        this.Mouse_MoveToElement_Click(By.xpath(String.format(this.favoriteDeleteIcon)));
    }

    public void SetAsDefultFavorite() {
        this.elementIsDisplayed(By.xpath(String.format(String.valueOf(this.SetasDefToFavorite))));
        this.JavaScriptClick(SetasDefToFavorite);
    }

    public void ClearDefaultFavorite() {
        this.elementIsDisplayed(By.xpath(String.format(String.valueOf(this.ClearDefToFavorite))));
        this.JavaScriptClick(ClearDefToFavorite);
    }


    public boolean validateFavClearOptionStatus(String state) {
        if (state.equalsIgnoreCase("disabled"))
            return this.elementIsDisplayed(By.xpath(this.favClearDefaultDisabled));
        else if (state.equalsIgnoreCase("enabled"))
            return this.elementIsDisplayed(By.xpath(this.favClearDefaultEnabled));
        return false;
    }

    public void clickOnElementButtonofPS(String button) {
        switch (button) {
            case "Cancel":
                this.clickOnElement(By.xpath(cancelButtonPopUpPS));
                break;
            case "Delete":
                this.clickOnElement(By.xpath(deleteFileFromPS));
                break;
            case "Close":
                this.clickOnElement(By.xpath(closeIcon));
                break;
        }
    }

    public boolean verifyFavoriteInList(Map<String, String> columns) {
        boolean flag = false;
        for (String column : columns.keySet()) {
            if (columns.get(column).equalsIgnoreCase("visible")) {
                //  column = column.contains("Delay Reports") || column.contains("Working List") ? column
                //  : column.toUpperCase();
                flag = this.elementIsDisplayed(By.xpath(String.format(this.verifyFavoriteInList, column)),
                        true);
            } else if (columns.get(column).equalsIgnoreCase("invisible")) {
                flag = this.elementIsNotDisplayed(By.xpath(String.format(this.verifyFavoriteInList, column.toUpperCase())));
            }
        }
        return flag;

    }

    public boolean ValidateSubMenu(String key, String message) {
        boolean flag = true;
        switch (key) {
            case "OptionOne":
                String actualHeader = this.getText(deleteOption).trim();
                flag = actualHeader.contains(message);
                break;
            case "OptionTwo":
                String actualHeaderTextOne = this.getText(setAsDefault).trim();
                flag = actualHeaderTextOne.contains(message);
                break;
            case "OptionThree":
                String actualHeaderTextTwo = this.getText(clearDefault).trim();
                flag = actualHeaderTextTwo.contains(message);
                break;
        }
        return flag;
    }

    public boolean VerifyButtonsInKebobMenu(DataTable dataTable) {
        List<String> expValues = dataTable.asList(String.class);
        boolean flag = true;
        for (String button : expValues) {
            if (flag) {
                if (button.contains("Delete"))
                    flag = this.elementIsDisplayed(deleteOption);
                else if (button.contains("Set As Default"))
                    flag = this.elementIsDisplayed(setAsDefault);
                else if (button.contains("Clear default"))
                    flag = this.elementIsDisplayed(clearDefault);
            }
        }
        return flag;
    }

    public void KebobMenuButtons() {
        int del = this.getCount(this.ValdeleteOption);
        int SetDef = this.getCount(this.ValDefault);
        int ClrDef = this.getCount(this.ValClrDefault);
        Assert.assertEquals(3, del+SetDef+ClrDef);
    }

    public void FavName(String FavName, String Action) {
        if(Action.equalsIgnoreCase("visible")){
          Assert.assertEquals(1, this.getCount(By.xpath(String.format(this.ExistanceFavName,FavName))));
        }
        if(Action.equalsIgnoreCase("invisible")){
            Assert.assertEquals(0, this.getCount(By.xpath(String.format(this.ExistanceFavName,FavName))));
        }
    }

    public boolean VerifyWaterMark(String WaterMark) {
        return this.elementIsDisplayed(By.xpath(String.format(advisories_watermark, WaterMark)));
    }

    public void clickOnSearchDrpDwn(String options) {
        this.JavaScriptClick(By.xpath("//div[@class='sr-search']/ul/li[contains(text(),'" + options + "')]"));
    }

    public void verifySlider() {
        String attributeValue = this.getAttributeValue(By.xpath("//div[@class='sr-toggle__label active']"), "class");
        Assert.assertTrue(attributeValue.equals("sr-toggle__label active"));
    }

    public void verifyDropDowns(String val) {
        this.enterText(this.advisories_LocationSearch, val);
        this.commonHelpers.thinkTimer(3000);
        List<WebElement> list = this.findElements(this.advisorydrpdwnoptions);

        for (WebElement el : list) {
            String txt = el.getText();
            Assert.assertTrue(txt.trim().contains(val));
        }
    }

    public void selectFormat(String value) {
        //this.JavaScriptClick(By.id("//input[@id= '"+ value +"']"));
        this.JavaScriptClick(By.xpath("//input[@id= '" + value + "']"));

    }

    public void clickSetAsDefaultFavCheckBox() {
        this.clickOnElement(By.xpath(this.SetAsDefaultFavCheckBox));
    }

    public Boolean SaveFavAsDefault(String favName) {
        Boolean flag = false;
        this.waitUntilNotVisible(this.loadingIndicator);
        JavaScriptClick(By.xpath(this.saveAsFav));
        this.enterText(By.xpath(this.FavNameInput), favName);
        this.clickSetAsDefaultFavCheckBox();
        this.JavaScriptClick(this.viewSaveButton);
        flag = this.elementIsDisplayed(By.xpath(String.format(this.viewSuccessfulMessage, favName.toUpperCase())),

                true);
        this.waitUntilVisible(this.viewSuccessfulMsgCloseButton);
        this.JavaScriptClick(this.viewSuccessfulMsgCloseButton);
        return flag;
    }

    public void clickOnLocationLink(String link) {
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.JavaScriptClick(By.xpath(String.format(Location1, link)));
    }


    public void addLocation(String city) {
        this.JavaScriptClick(enterPrefLocation);
        this.enterText(By.id(String.valueOf(enterPrefLocation)), Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(enterPrefLocation);
        this.enterText(enterPrefLocation, city);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);
        this.waitUntilVisible(By.xpath(String.format(this.selectPrefLocationOption, city)));
        this.JavaScriptClick(By.xpath(String.format(this.selectPrefLocationOption, city)));
    }

    public void clickOnKebobMenuOfExport() {
        this.JavaScriptClick(By.xpath(FavKebobMenu));
    }

    public boolean verifyStandardFavPopUpMessage(String favName) {
        return this.elementIsDisplayed(By.xpath(String.format(this.StandardFavPopUpMessage, favName)));
    }

    public boolean verifyTheDefaultValue(String favName) {
        return this.elementIsDisplayed(By.xpath(String.format(this.defaultValue, favName)));
    }

    public void iValidateDataInSaveasfavoriteByAction(String action) throws IOException {
        if (action.equalsIgnoreCase("save")) {
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Save as favorite", "")));
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Set as Default", "")));
//            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Save", "3")));
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Save", "2")));
        } else if (action.equalsIgnoreCase("cancel")) {
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Cancel", "2")));
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Cancel", "1")));
        } else if (action.equalsIgnoreCase("update")) {
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Save as favorite", "")));
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Update Favorite", "")));
            this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Save", "2")));
        }
    }

    public void clickLocationUntilPopup(String cityName) {

        if (this.findElements(this.mapPopUp).size() >= 1) {
            String txt = this.findElement(this.mapPopUp).getText();
            Assert.assertEquals(true, txt.toLowerCase().contains(cityName.toLowerCase()));
            return;
        }
        commonHelpers.thinkTimer(3000);
        List<WebElement> list = this.findElements(this.locationPin);


        for (WebElement el : list) {
            String city = el.getText();
            JavaScriptClick(el);
            commonHelpers.thinkTimer(3000);
            this.clickLocationUntilPopup(city);
            break;
        }
    }

    public String[][] getUITableData(String advisories) {
        if (advisories.equalsIgnoreCase("OD Pair")) {
            JavaScriptClick(this.advisory_ListMapToggle);
        } else {
            JavaScriptClick(this.advisory_ListMapToggle);
            commonHelpers.thinkTimer(1000);
            JavaScriptClick(this.advisory_ListMapToggle);
        }
        this.waitUntilNotVisible(this.loadingIndicator);

        int rowSize = this.findElements(By.xpath("//div[@col-id='city']")).size();
        int colSize = this.findElements(By.xpath("//div[@role='columnheader']")).size();
        String UIData[][] = new String[rowSize][colSize];
        By tableHeaders = By.xpath("//span[@ref='eText']");
        List<WebElement> headerAry = this.findElements(tableHeaders);
        for (int colheader = 0; colheader < headerAry.size(); colheader++) {
            String value = headerAry.get(colheader).getText();
            UIData[0][colheader] = value;
        }
        List<WebElement> gridData = this.findElements(By.xpath("//div[@role='gridcell']"));
        List<WebElement> risktypeCol = this.findElements(By.xpath("//div[@class='right']"));
        for (int irow = 1; irow < rowSize; irow++) {
            for (int jcol = 0; jcol < colSize; jcol++) {
                if (jcol == 3) {
                    UIData[irow][jcol] = risktypeCol.get(irow - 1).getText();
                    this.Mouse_MoveToElement(risktypeCol.get(irow - 1));
                } else {
                    this.Mouse_MoveToElement(gridData.get((irow - 1) * colSize + jcol));
                    UIData[irow][jcol] = gridData.get((irow - 1) * colSize + jcol).getText();
                }
            }

        }

        return UIData;
    }

    public void verifyDataOnUIAndDownloadedFile(String fileType, String sheetname, String advisories) throws IOException {
        File filpath = this.getLastModified(genericFunctionObject.home + genericFunctionObject.slashBasedOnOs + Constants.downloadFolder + genericFunctionObject.slashBasedOnOs);
        FileInputStream fs = null;
        XSSFWorkbook wb;
        fs = new FileInputStream(filpath.toString());
        wb = new XSSFWorkbook(fs);
        XSSFSheet sheet = wb.getSheet(sheetname);
        int lastrow = sheet.getLastRowNum();
        int lastcol = sheet.getRow(0).getLastCellNum();
        log.info("Last row : " + lastrow);
        String[][] excelData = new String[lastrow + 1][lastcol];

        for (int erow = 0; erow <= lastrow; erow++) {
            Row rb = sheet.getRow(erow);
            for (int ecolumn = 0; ecolumn < lastcol; ecolumn++) {
                Cell cb = rb.getCell(ecolumn);
                excelData[erow][ecolumn] = cb.getStringCellValue();
//                    log.info("Excel data : "+ excelData[erow][ecolumn] );
            }
        }
        String[][] UIDaata = this.getUITableData(advisories);
        try {
            for (int uirow = 0; uirow <= UIDaata.length; uirow++) {
                log.info("Row number : " + uirow);
                for (int uicolumn = 0; uicolumn < lastcol; uicolumn++) {
//                        log.info("excelData: " + excelData[uirow][uicolumn].toLowerCase() + " " + "UIDaata => " + UIDaata[uirow][uicolumn].toLowerCase());
                    Assert.assertEquals(excelData[uirow][uicolumn].toLowerCase(), UIDaata[uirow][uicolumn].toLowerCase());
                }
            }
        } catch (Exception e) {
            log.info("*** Exception occured for while validating data ");

        } finally {
            wb.close();
            fs.close();
        }

    }

    public static File getLastModified(String directoryFilePath) {
        File directory = new File(directoryFilePath);
        File[] files = directory.listFiles(File::isFile);
        long lastModifiedTime = Long.MIN_VALUE;
        File chosenFile = null;
        if (files != null) {
            for (File file : files) {
                if (file.lastModified() > lastModifiedTime) {
                    chosenFile = file;
                    lastModifiedTime = file.lastModified();
                }
            }
        }
        return chosenFile;
    }

    public Boolean selectOrDeselectAdvisoryFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        if(this.elementIsDisplayed(filterChevron)){
            this.JavaScriptClick(this.findElement(filterChevron));
        }
        for (String key : dataFilters.keySet()) {
            this.SelectFilterForShipments(key, dataFilters.get(key).split(":"));
        }
        Boolean checkFilter = false;
        if (cancelOrApply.equalsIgnoreCase(this.apply)) {
            this.JavaScriptClick(
                    this.findElement(this.getByusingString(String.format(this.applyButton, this.applyUpperCase))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "Risk Type Is":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[0], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Risk Type is not displayed", checkFilter);
                            break;
                        case "Date Is":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[1], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Date filter is not displayed", checkFilter);
                            break;
                    }
                    log.info("Date is displayed", dataTable);
                }
            }
        } else if (cancelOrApply.equalsIgnoreCase("cancel")) {
            this.JavaScriptClick(this.findElement(this.filterCancelButton));
        }
        return checkFilter;
    }

    public void SelectFilterForShipments(String status, String[] filterCriteria) {
        for (String filter : filterCriteria) {
            switch (status.split(":")[0]) {
                case "Risk Type":
                    this.clickOnElement(By.xpath(
                            String.format(selectRiskType, filter)));
                    break;
                case "Risk Severity":
                    this.clickOnElement(By.xpath(
                            String.format(selectRiskSeverity, filter)));
                    break;
                case "Date":
                    this.clickOnElement(
                            By.xpath(String.format(selectDate, filter)));
                    this.clickOnElement(
                            By.xpath(String.format(durationInNextDaysDropdownFilter, "3")));
                    break;

            }
        }
    }

    public void RemoveSpecificOneFilterinBubble(DataTable filterstable) {
        this.commonHelpers.thinkTimer(4000);
        List<String> filters = filterstable.asList(String.class);
        for (String filter : filters) {
            if (!Constants.QuickViewCardNames.contains(filter)) {
                filter = WordUtils.capitalizeFully(filter);
            }
            this.JavaScriptClick(
                    this.findElement(
                            this.getByusingString(String.format(this.cancelSpecificFilterItemFromBubble, filter))));
            log.info(String
                    .valueOf(this.getByusingString(String.format(this.cancelSpecificFilterItemFromBubble, filter))));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    public void clickOnKabobIconOfFavorites() {
        this.ScrollIntoView(this.findElement(By.xpath(String.format(kababIcon))));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(By.xpath(String.format(kababIcon)));
    }

    public void clickOnExportDownloadLink() {
        this.ScrollIntoView(this.findElement(By.xpath(String.format(exportDownloadIcon))));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(By.xpath(String.format(exportDownloadIcon)));
    }

    public boolean verifyStateOrTerritoryAreDisplayed(DataTable columnTable) {
        boolean flag = true;
        try {
            List<String> columnNames = columnTable.asList(String.class);
            for (String columnName : columnNames) {
                if (flag) {
                    flag = this.elementIsDisplayed(getByusingString(String.format(verifyStateOrTerritoryValue, columnName)));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error("**EXCEPTION** Something went wrong in validation of state or territory display" + ex.getMessage());
        }
        return flag;
    }

    public boolean verifyRiskTypeAreDisplayed(DataTable columnTable) {
        boolean flag = true;
        try {
            List<String> columnNames = columnTable.asList(String.class);
            for (String columnName : columnNames) {
                if (flag) {
                    flag = this.elementIsDisplayed(getByusingString(String.format(verifyRiskTypeValue, columnName)));
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error("**EXCEPTION** Something went wrong in validation of state or territory display" + ex.getMessage());
        }
        return flag;
    }

    public void verifyDataOnUIAndDownloadedFileCsv(String fileType, String sheetname, String advisories) throws IOException {
        try {
            File filpath = this.getLastModified(genericFunctionObject.home + genericFunctionObject.slashBasedOnOs + Constants.downloadFolder + genericFunctionObject.slashBasedOnOs);
            FileReader fileReader = new FileReader(filpath.toString());
            CSVReader csvReader = new CSVReaderBuilder(fileReader).withSkipLines(0).build();
            List<String[]> allData = csvReader.readAll();
            String[][] data = new String[allData.size()][];
            allData.toArray(data);
            String[][] UIDaata = this.getUITableData(advisories);
            int uirow = 0;
            for (String[] row : data) {
                int uicolumn = 0;
                for (String cell : row) {
                    //log.info("Cell value: "+cell.replace("\uFEFF","").toLowerCase()+" UIData value: "+UIDaata[uirow][uicolumn].toLowerCase());
                    Assert.assertEquals(cell.replace("\uFEFF", "").toLowerCase(), UIDaata[uirow][uicolumn].toLowerCase());
                    uicolumn = uicolumn + 1;
                }
                if (uirow < row.length) {
                    uirow = uirow + 1;
                }
            }
            csvReader.close();
        } catch (Exception e) {
            log.info("Issue with csv: " + e.getMessage());
        }
    }

    public void clickOnApplyButton(String link) {
        this.JavaScriptClick(this.findElement(By.xpath(String.format(ODApplyBtn, link))));
        this.ScrollToTop();
    }

    public void addODPairLocation(String link, String city) {
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.JavaScriptClick(By.xpath(String.format(Location1, link)));
        // this.JavaScriptClick(By.xpath(String.format(Location1)));
        this.enterText(By.xpath(String.format(Location1, link)), Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.enterText(By.xpath(String.format(Location1, link)), city);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);
        this.waitUntilVisible(By.xpath(String.format(this.selectPrefLocationOption, city)));
        this.JavaScriptClick(By.xpath(String.format(this.selectPrefLocationOption, city)));
    }

    public void ODPairLocation(String link, String city) {
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.JavaScriptClick(By.xpath(String.format(Location1, link)));
        this.enterText(By.xpath(String.format(Location1, link)), Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.enterText(By.xpath(String.format(Location1, link)), city);
  }

    public void removeODPairLocation(String link) {
        this.waitUntilVisible(By.xpath(String.format(Location1, link)));
        this.elementClear(By.xpath(String.format(Location1, link)));
        this.commonHelpers.thinkTimer(5000);
    }

    public Boolean selectOrDeselectODFilter(String cancelOrApply, DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        // this.JavaScriptClick(this.findElement(filterChevron));
        for (String key : dataFilters.keySet()) {
            this.SelectFilterForShipments(key, dataFilters.get(key).split(":"));
        }
        Boolean checkFilter = false;
        {
            this.JavaScriptClick(this.findElement(By.xpath(String.format(applyButton, cancelOrApply))));
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "Risk Type Is":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[0], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Risk Type is not displayed", checkFilter);
                            break;
                        case "Date Is":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[1], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Date filter is not displayed", checkFilter);
                            break;
                        case "Risk Severity is":
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[1], dataTable)))
                                    .isDisplayed();
                            Assert.assertTrue("Risk Severity filter is not displayed", checkFilter);
                            break;
                    }

                }
            }
        }
        return checkFilter;
    }

    public boolean validateODFilterSearchAndResult(DataTable table) throws InterruptedException {
        boolean returnFlag = false;
        List<String> filterList = table.asList(String.class);
        String expectedMessage = "No results found.";
        String actualfilterResult = "", expectedFilterResult = "";

        for (String filter : filterList) {
            this.enterText(this.searchForfilterInput, filter);
            Thread.sleep(2000);
            actualfilterResult = this.getText(this.searchForfilterInput);
            if (actualfilterResult.equals(expectedMessage))
                actualfilterResult = this
                        .getText(this.getByusingString(String.format(this.searchForFilterResultText, filter)));
            JavaScriptClick(this
                    .findElement(
                            this.getByusingString(String.format(this.searchForFilterResultText, filter))));

            if (actualfilterResult.equals(expectedFilterResult)) {
                returnFlag = true;
                log.info("Search and result for filter is verified for:" + filter);
            } else {
                log.info("Search or result validation for filter is failing for:" + filter);
                returnFlag = false;
            }
        }
        return returnFlag;
    }

    public boolean validateODFilterSearchTextAndIcon(String expectedPlaceholderText) {
        boolean flag = false;
        if (expectedPlaceholderText.equals("Search for Columns")) {
            String actualPlaceholderText = this.getAttributeValue(searchForColumnInput,
                    "placeholder");
            if ((this.elementIsDisplayed(this.columnSearchIcon))
                    && (this.elementIsDisplayed(this.searchForColumnInput))
                    && actualPlaceholderText.equals(expectedPlaceholderText)) {
                log.info("Placeholder text and search icon is displayed");
                flag = true;
            }
        } else {
            String actualPlaceholderText = this.getAttributeValue(searchForfilterInput,
                    "placeholder");
            if ((this.elementIsDisplayed(this.legacyFilterSearchIcon))
                    && (this.elementIsDisplayed(this.searchForfilterInput))
                    && actualPlaceholderText.equals(expectedPlaceholderText)) {
                log.info("Placeholder text and search icon is displayed");
                flag = true;
            }
        }
        return flag;
    }

    public Boolean ValidateFilterBubble(DataTable dataTable) {
        boolean flag = true;
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).contains("Today")) {
                flag = this.VaidateFilterBubble(key, dataFilters.get(key).split(":"));
            }
            if (!flag)
                break;
        }
        return flag;
    }

    public Boolean VaidateFilterBubble(String status, String[] filterCriteria) {
        String xpath = " ";
        List<Boolean> validationflags = new ArrayList<Boolean>();
        for (int filter = 0; filter < filterCriteria.length; ++filter) {
            if (filter != filterCriteria.length - 1) {
                xpath = filterCriteria[filter];
            } else {
                filterCriteria[filter] = filterCriteria[filter].contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(filterCriteria[filter]).toString().split(",")[0]
                        : filterCriteria[filter];
                xpath = filterCriteria[filter];
            }
            validationflags.add(this.elementIsDisplayed(
                    this.getByusingString(String.format(this.filterBubbleXpath, xpath, status.split("-")[0].trim()))));
        }
        return !validationflags.contains(false);
    }
    public boolean VerifyErrorMsgODPair(String key, String message) {
        boolean flag = true;
        switch (key) {
            case "WrongODPair":
                String actualError = this.getText(ODErrorMessage).trim();
                flag = actualError.contains(message);
                break;
            case "InvalidODPair":
                String actualInvalidError = this.getText(InvalidODErrorMessage).trim();
                flag = actualInvalidError.contains(message);
                break;
            case "OriginRequired":
                String actualOriginError = this.getText(blankOriginErrorMessage).trim();
                log.info(actualOriginError);
                flag = actualOriginError.contains(message);
                break;
            case "DestinationRequired":
                String actualDestinationError = this.getText(blankDestinationErrorMessage).trim();
                log.info(actualDestinationError);
                flag = actualDestinationError.contains(message);
                break;
        }
        return flag;
    }
    public void clickOnlink(String linkText) {
        if ((linkText.equals("Download") && this.commonHelpers.getValuefromContextStore("DownloadType") != null
                && this.commonHelpers.getValuefromContextStore("DownloadType").toString().contains("COMBINED FILES"))) {
            this.ScrollIntoView(findElement(By.xpath(String.format(buttonXpathCombinedFiles, linkText))));
            this.Mouse_MoveToElement(findElement(By.xpath(String.format(buttonXpathCombinedFiles, linkText))));
            this.clickOnElement(By.xpath(String.format(buttonXpathCombinedFiles, linkText)));
        } else {
            this.ScrollIntoView(findElement(By.xpath(String.format(linkXpath, linkText))));
            this.Mouse_MoveToElement(findElement(By.xpath(String.format(linkXpath, linkText))));
            this.JavaScriptClick(By.xpath(String.format(linkXpath, linkText)));
        }
    }
    public Boolean verifyODIcon(String icon, String check) {
        Boolean flag = false;
        String xpath = "";
        int iconCount = 0;
        int totalRowsCount = 0;
        switch (icon) {
            case "Close":
                xpath = "sr-flyout__close";
                totalRowsCount = this.findElements(By.xpath(String.format(this.verifyODPairIcon, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.verifyODPairIcon, xpath))).size();
                break;
            case "AddButton":
                xpath = "Add";
                totalRowsCount = this.findElements(By.xpath(String.format(this.addODPairButton, xpath))).size();
                iconCount = this.findElements(By.xpath(String.format(this.addODPairButton, xpath))).size();
                break;
        }
        if (check.equalsIgnoreCase("Visible")) {
            flag = totalRowsCount == iconCount;
        } else if (check.equalsIgnoreCase("Invisible")) {
            flag = iconCount == 0;
        }

        return flag;
    }

    public Boolean pairODCount(String ODPairResult) {
        log.info(ODPairResult + " in portal = "
                + this.getText(By.xpath(record)));
        return null;
    }
    public String addDaysToTodaysDate(String numberOfDaysToAdd,String format){
        Date currentDate = new Date();
        LocalDateTime localDateTime = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime dateFormat = localDateTime.plusDays(Integer.parseInt(numberOfDaysToAdd));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        String date = dateFormat.format(formatter);
        return date;
    }
    public void selectingDaysAndvalidateDates(String format){
        if(getCount(uncheckedCheckBoxes)==0) {
            for (int iterator = 0; iterator < 4; iterator++) {
                this.selectDropdown(selectDrpDownDays, "text", Integer.toString(iterator + 1));
                String noOfdays = getText(By.xpath(String.format(selectDaysRange, iterator + 1)));
                String todaysdate = addDaysToTodaysDate(Integer.toString(0), format);
                String dateAfter = addDaysToTodaysDate(noOfdays, format);
                String dateRange = todaysdate + " - " + dateAfter;
                String text = getText(dateRangeInUI);
                Assert.assertEquals(dateRange, text);
            }
        }
        else if(getAttributeValue(inputInTheNextCheckBox,"aria-checked").equalsIgnoreCase("[object Object]")){
            for(int iterator=0;iterator<4;iterator++){
                this.selectDropdown(selectDrpDownDays, "text", Integer.toString(iterator+1));
                String noOfdays=getText(By.xpath(String.format(selectDaysRange,iterator+1)));
                String todaysdate=addDaysToTodaysDate(Integer.toString(1),format);
                String dateAfter=addDaysToTodaysDate(noOfdays,format);
                String dateRange=todaysdate+" - "+dateAfter;
                String text=getText(dateRangeInUI);
                Assert.assertEquals(dateRange,text);
            }
        }
        else{
            Assert.assertEquals(getText(dateRangeInUI),addDaysToTodaysDate("0",format));

        }

    }

    public void SelectFilterforAdvisorieswithDate(String cancelOrApply, DataTable dataTable, String date) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            this.SelectFilterForAdvisories(key, dataFilters.get(key).split(":"), date);
        }
        //  Boolean checkFilter;
        this.JavaScriptClick(
                this.findElement(this.getByusingString(String.format(this.ODApplyButton, cancelOrApply))));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollByOffset("0", "50");
          /*  for (String key : dataFilters.keySet()) {
                String[] filters = dataFilters.get(key).split(":");
                for (String filter : filters) {
                    switch (filter) {
                        case "In the next":
                            this.waitUntilNotVisible(this.loadingIndicator);
                            checkFilter = this.findElement(
                                            this.getByusingString(
                                                    String.format(this.bubbleFilters, key.split(":")[0], "Next", date)))
                                    .isDisplayed();
                            Assert.assertTrue("Next day filter is not displayed", checkFilter);
                            break;
                        case "Today":
                            checkFilter = this.elementIsDisplayed(By.xpath(String.format(todayBubbleFilter, key.split("-")[1], "Today")));
                            Assert.assertTrue("today filter is not displayed", checkFilter);
                            break;
                    }
           }
         }*/
    }

    public void SelectFilterForAdvisories(String status, String[] filterCriteria, String inputDate) {
        //this.JavaScriptClick(this.findElement(this.getByusingString(this.buildXpathForString(ParentFilter))));
        for (String filter : filterCriteria) {
            this.JavaScriptClick(this.findElement(this.getByusingString(
                    String.format(this.ODfilterxpath, filter))));
            switch (status.split("-")[0]) {
                case "Ship Date":
                    if (!inputDate.equals("1")) {
                        WebElement dropdownElement = this.findElement(By.xpath(this.shipDateDropdownFilter));
                        dropdownElement.sendKeys(inputDate);
                    }
                    break;
            }
        }
    }
    public void clickOnKebabIcnOfFavorites(String FavoriteName){
        String UpdatedFavoriteName ="";
        if(FavoriteName.contains("Context")) {
            UpdatedFavoriteName = (String) this.commonHelpers.getValuefromContextStore(FavoriteName);
        }
        else{
            UpdatedFavoriteName = FavoriteName;
        }
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollIntoView(this.findElement(By.xpath(String.format(this.kebabIcnBesideFavorites,UpdatedFavoriteName))));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(By.xpath(String.format(this.kebabIcnBesideFavorites,UpdatedFavoriteName)));
    }

    public void addODPairLocationAtIndex(String link, String city,int index) {
        this.waitUntilVisible(By.xpath(String.format(locationInputBoxWithIndex, link, index)));
        this.JavaScriptClick(By.xpath(String.format(locationInputBoxWithIndex, link, index)));
        // this.JavaScriptClick(By.xpath(String.format(Location1)));
        this.enterText(By.xpath(String.format(locationInputBoxWithIndex, link, index)), Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(By.xpath(String.format(locationInputBoxWithIndex, link, index)));
        this.enterText(By.xpath(String.format(locationInputBoxWithIndex, link, index)), city);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);
        this.waitUntilVisible(By.xpath(String.format(this.selectPrefLocationOption, city)));
        this.JavaScriptClick(By.xpath(String.format(this.selectPrefLocationOption, city)));
    }
    public void addOriginAndDestination(String link1,String link2,DataTable table){
        List<List<String>>ODPair=table.asLists();
        if(ODPair.size()==1){
            commonHelpers.thinkTimer(2000);
            this.ScrollToTop();
            List<String> cities = new ArrayList<>();
            cities.add(ODPair.get(0).get(0));
            for (String city : cities) {
                this.addODPairLocation(link1, city);
            }
            commonHelpers.thinkTimer(2000);
            this.ScrollToTop();
            List<String> citiess = new ArrayList<>();
            citiess.add(ODPair.get(0).get(1));
            for (String city : citiess) {
                this.addODPairLocation(link2, city);
            }
            this.commonHelpers.AddToContextStore(ODPair.get(0).get(0),ODPair.get(0).get(1));
        }
        else{
            int index=1;
            for(List<String>entries:ODPair){
                String origin=entries.get(0).toString();
                String destination=entries.get(1).toString();
                commonHelpers.thinkTimer(2000);
                this.ScrollToTop();
                List<String> cities = new ArrayList<>();
                cities.add(origin);
                for (String city : cities) {
                    this.addODPairLocationAtIndex(link1, city,index);
                }
                commonHelpers.thinkTimer(2000);
                this.ScrollToTop();
                List<String> citiess = new ArrayList<>();
                citiess.add(destination);
                for (String city : citiess) {
                    this.addODPairLocationAtIndex(link2, city,index);
                }
                this.commonHelpers.AddToContextStore(origin,destination);
                index++;
                if(index>5) break;
                JavaScriptClick(addODPairLink);
            }
        }
    }
    public void validateOrderOfFlyouts(DataTable table){
        List<List<String>>ODPair=table.asLists();
        int index=1;
        for(List<String>entries:ODPair){
            String origin=entries.get(0).toString();
            String destination=entries.get(1).toString();
            String[]text=getText(By.xpath(String.format(flyOutHeaderTxtAtIndex,index++))).split("/");
            Assert.assertTrue(text[0].contains(origin) && text[1].contains(destination));
        }
    }

    public void validateHeaderAddressWithOriginAndDestination(){
        int countOfFlyoutHeader=getCount(flyOutHeader);
        for(int iter=1;iter<=countOfFlyoutHeader;iter++){
            JavaScriptClick(By.xpath(String.format(plusIcnToExpandFlyOutHeader,iter)));
            String origin=getText(By.xpath(String.format(flyOutHeaderTxtAtIndex,iter))).split("/")[0].split(",")[0].trim();
            String destination=getText(By.xpath(String.format(flyOutHeaderTxtAtIndex,iter))).split("/")[1].split(",")[0].trim();
            Assert.assertTrue("",getText(originHeader).toLowerCase().contains(origin.toLowerCase()));
            Assert.assertTrue("",getText(destinationHeader).toLowerCase().contains(destination.toLowerCase()));
            JavaScriptClick(By.xpath(minusIcnToExpandFlyOutHeader));

        }
    }

    public void clickUntilFlyoutPopUpAndVerify(){
        int ind=0;
        while(ind<5) {
            if(elementIsDisplayed(commonFlyOutXpath)){
                if(elementIsDisplayed(clusteredFlyOutRow)){
                    this.validateHeaderAddressWithOriginAndDestination();
                }
                else if(getAttributeValue(commonFlyOutXpath,"class").contains("no-data")){
                    Assert.assertTrue(this.commonHelpers.getValuefromContextStore(getText(originHeader).split(",")[2].trim()).toString().contains(getText(destinationHeader).split(",")[2].trim()));
                }
                else {
                    Assert.assertTrue(this.commonHelpers.getValuefromContextStore(getText(originHeader).split(",")[2].trim()).toString().contains(getText(destinationHeader).split(",")[2].trim()));

                }
                break;
            }
            else{
                if(getCount(ODClustorPurplePoint)>0){
                    int count=getCount(ODClustorPurplePoint);
                    for(int iter=1;iter<=count;iter++){
                        if(elementIsDisplayed(By.xpath(String.format(ODClustorPurplePointWithIndex,iter)))){
                            JavaScriptClick(By.xpath(String.format(ODClustorPurplePointWithIndex,iter)));
                            break;
                        }
                    }
                }
                else {
                    break;
                }
            }
            ind++;
        }
    }
    public void validateSortingOfServices() {
        String[] serviceswUnsorted = getText(listOfServicesTxt).split(",");
        String[] serviceswSorted = getText(listOfServicesTxt).split(",");
        for (int i = 0; i < serviceswSorted.length; i++) {
            serviceswSorted[i] = serviceswSorted[i].trim();
            serviceswUnsorted[i] = serviceswUnsorted[i].trim();
        }
        java.util.Arrays.sort(serviceswSorted);
        System.out.println(serviceswSorted);
        System.out.println(serviceswUnsorted);
        for (int iter = 0; iter < serviceswSorted.length; iter++) {
            Assert.assertTrue(serviceswSorted[iter] + "==" + serviceswUnsorted[iter], serviceswSorted[iter].equalsIgnoreCase(serviceswUnsorted[iter]));
        }
    }
    public void validateFlyOutExpand(){
        if (elementIsNotDisplayed(this.mapFlyOutPopUp)) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
        else{
            Assert.assertTrue(" Validation for flyout to open",elementIsDisplayed(this.mapFlyOutPopUp));
        }
    }

    public void clickOnCancelOrDeleteElementofDeleteFavorite(String button) {
        switch (button) {
            case "Cancel":
                this.clickOnElement(By.xpath(cancelButtonPopUpPS));
                break;
            case "Delete":
                this.clickOnElement(By.xpath(deleteFileFromPS));
                break;
        }
    }



    public void validatetheMoreArrow(String Action){
        switch (Action) {
            case "downwards":
                Assert.assertEquals(this.getCount(downwards),1);
                break;
            case "upwards":
                Assert.assertEquals(this.getCount(upwards),1);
                break;
        }
    }

    public void validatetheFilterCount(String Action){
        int Bcount = 0;
        int Acount = 0;
        switch (Action) {
            case "Before":
                Bcount = this.getCount(BeforeAction);
                Assert.assertTrue(Bcount > 0);
                break;
            case "After":
                Acount = this.getCount(BeforeAction);
                Assert.assertTrue(Acount > Bcount);
                break;
        }
    }

    public void storeFirstRecord(String name) {
        String firstRecord = this.getText(firstRecordName);
        this.commonHelpers.AddToContextStore(name,firstRecord);
    }

    public void ActioninPreshipmentPopup(String Action){
        switch (Action) {
            case "Save":
                this.JavaScriptClick(this.viewSaveButton);
                this.waitUntilVisible(this.viewSuccessfulMsgCloseButton);
                break;
            case "Close":
                this.waitUntilVisible(this.viewSuccessfulMsgCloseButton);
                this.JavaScriptClick(this.viewSuccessfulMsgCloseButton);
                break;
        }
    }

    public void RemoveFilterBasedonName(String Filtername) {
        this.JavaScriptClick(By.xpath(String.format(this.FilterRemoveforWindSpeedRisk,Filtername)));
        this.waitUntilNotVisible(this.loadingIndicator);
    }


    public void selectFilterWithCritera(DataTable dataTable) {
        Map<String, String> dataFilters = dataTable.asMap(String.class, String.class);
        ScrollByOffset("0", "100");
        this.JavaScriptClick(this.filterButtonDropdown);
        for (String key : dataFilters.keySet()) {
            this.SelectFilterInAdvisory(key, dataFilters.get(key).split(":"));
        }
    }


    public void SelectFilterInAdvisory(String status, String[] filterCriteria) {
        for (String filter : filterCriteria) {
            switch (status.split(":")[0]) {
                case "Risk Type":
                    this.clickOnElement(By.xpath(String.format(selectFilter, "Risk Type")));
                    this.JavaScriptClick(By.xpath(String.format(selectFilter, filter)));
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
                    break;

                case "Date":
                    this.clickOnElement(this.getByusingString(this.buildGenericXpathForString("Date","3")));
                    this.JavaScriptClick(By.xpath(String.format(selectFilter, filter)));
                    this.waitUntilNotVisible(this.loadingIndicatorContains);
                    break;
            }
        }
    }

    public By result = By.xpath("//div[@ref='eCenterContainer']//div[@col-id='stateName']");
    public String KebabLinksEnabled = "//*[contains(text(),\"%s\")]//..//span[contains(@class,'icn')]";
    public String KebabLinksDisabled = "//*[contains(text(),\"%s\")]//..//span[contains(@class,'disabled')]";

    public void validateTheResult(String expectedState){
        int count = this.getCount(this.result);
        List<WebElement> stateRes = this.findElements(result);
        if(count!=0){
            for (int i = 0; i < 2 ; i++) {
                String actualState = this.getText(stateRes.get(i));
                Assert.assertEquals(expectedState.trim().toLowerCase(),actualState.trim().toLowerCase());
            }
        }
    }

    public void validatetheButtonStatus(String linkName,String Status) {
        if (Status.equalsIgnoreCase("disabled"))
            Assert.assertTrue(this.getCount(By.xpath(String.format(this.KebabLinksDisabled,linkName)))==1);
        else if (Status.equalsIgnoreCase("enabled"))
            Assert.assertTrue(this.getCount(By.xpath(String.format(this.KebabLinksEnabled,linkName)))==1);
    }

    public void validateTheLandingPageforKebablinks(String linkName) {
            this.JavaScriptClick(By.xpath(String.format(this.KebabLinksEnabled,linkName)));
    }

    public void clickWeatherAdvisory(String link) {
        this.JavaScriptClick(By.xpath(String.format(this.weatherAltchevronXpath, link)));
    }

    public int getAdvisoryViewCount(String key) {

        if (this.elementIsNotDisplayed(TotalActive)) {
            this.clickOnElement(leftFlyoutChevron);
        }

        By progressbarXpath = By.xpath(String.format(this.progressbarXpath, key));

        switch (key) {
            case "Early":
            case "On Time":
            case "At Risk":
            case "Intervened":
                this.waitUntilVisible(progressbarXpath, 30);
                String viewingCountStr = this.getText(progressbarXpath);
                int viewingCount;
                try {
                    viewingCount = Integer.parseInt(viewingCountStr);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("Viewing count is not a valid integer: " + viewingCountStr);
                }
                this.commonHelpers.AddAdvisoryCountToContextStore(key, viewingCount);
                return viewingCount;

            default:
                throw new IllegalArgumentException("Invalid key: " + key);
        }
    }

}
