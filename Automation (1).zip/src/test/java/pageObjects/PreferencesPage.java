package pageObjects;

import API.ResponseModels.AvailableImageRole;
import API.ResponseModels.Datum;
import API.ResponseModels.FedExAccounts;
import com.google.common.base.CharMatcher;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Preference Page - Shipper/CE Agent.
 */
@Slf4j
public class PreferencesPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public ShipmentOverviewPage shipmentOverviewPage;
    public HomePage homePage;
    /**
     * WebElement with there finding property
     */
    public String mainHeadings = "//div[@class='sr-settings__title' and contains(text(),\"%s\")]";
    public String maineHeadingHelpingText = "//div[@class='sr-settings__helpText' and contains(text(),\"%s\")]";
    public String radioButtons = "//li[@class='sr-settings__role']//label[text()=\"%s\"]";
    public String radioButtonsDefaultlabel = "//li[@class='sr-settings__role']//label[text()=\"%s\"]/span";
    public By settings = By.xpath("//div[@class='sr-settings__title']");
    public By settingsHelpText = By.xpath("//div[@class='sr-settings__helpText']");
    public By dropdownId = By.xpath("//*[@id=\"dropdown\"]");
    public By lastUpdatedAt = By.xpath("//p[@class='sr-aside-timestamp']/span[@class='sr-aside-timestamp__time']");
    public String dropDowns = "//select[@aria-label=\"%s\"]";
    public String dropDownsText = "//select[@aria-label=\"%s\"]/option";
    public String dropDown = "//select[contains(@id,\"%s\")]";
    public String addInOrOutPrefLocation = ".//span[contains(text(),\"%s\")]";
    public By enterPrefLocation = By.xpath("//input[contains(@class,'ng-touched')]");
    public String selectPrefLocationOption = ".//*[contains(text(),\"%s\")]";
    public String addedPrefLocation = "//div[contains(@class,\"%s\")]/descendant::input[@ng-reflect-model=\"%s\"]";
    public String removeFirstPrefLocation = "//div[contains(@class,\"%s\")]/descendant::input[1]/parent::div/following-sibling::div";
    public String prefLocationsCount = "//div[contains(@class,\"%s\")]/div[contains(@class,'sr-search')]";
    public By clickOnPrefLocationTextbox = By.xpath("//div/input[contains(@class,'ng-valid')]");
    public By removePrefLoc = By.xpath("//div[contains(@class,'sr-search-close')]");
    public String addedPrefLocationInAdvList = "//div[@class='sr-card']//*[contains(text(),\"%s\")]";
    public By prefLocationCheckboxState = By
            .xpath("//div[@class='sr-locations']//label/preceding-sibling::input[@type='checkbox']");
    public String prefLocationCheckbox = "//label[contains(text(),\"%s\")]";
    public String isAddPrefCityLinkDisabled = "//span[text()=\"%s\"]/parent::div[contains(@class,'disabled')]";
    public String preferredLocation = "//a[contains(@class,'sr-aside')]/span[contains(text(),\"%s\")]";
    public By preferredLocationsText = By.xpath("//div[@class='sr-locations__title']");
    public By preferredLocationsHelpText = By.xpath("//div[@class='sr-locations__helpText']");
    public By preferredLocationsCheckboxText = By
            .xpath("//div[@class='sr-locations__actionText']//label[@for='actiontype']");
    public String lastKnownLocationOrDestination = "//div[contains(@class,'typeTitle') and contains(text(),\"%s\")]";
    public String addlastKnownLocationOrDestination = "//div[contains(@class,'sr-locations__addText')]//span[text()=\"%s\"]";
    public By locationsLabel = By.xpath("//label[@class='sr-search__label']");
    public String IndicatorXpath = ".//*[contains(text(),\"%s\")]//ancestor::*[@role='row']//*[@col-id=\"%s\"]//div[@class='sr-grid__cell sr-grid__cell--indicator']";
    public String subMenuHeader = ".//div[@class='sr-preference__content']/app-%s/div/div[1]";
    public String companyPreferences = ".//div[contains(text(),\"%s\")]";
    public String accountPreferences = "//*[contains(text(),\"%s\")]";
    public String plusIconPreferences = ".//div[contains(text(),\"%s\")]//span[contains(@class,'plus-icn')]";
    public String accountHeader = "//div[@class='sr-accounts-header']//div//span[contains(text(),\"%s\")]";
    public By filterDateFormat = By.xpath("//li[@class='p-a-3']//p[2]");
    public String imageRoleName = "//label[@for=\"%s\"]";
    public String selectedImageRoleName = "//span[text()=\"%s\"]";
    public String fedexAccountsColumn = "//div[@class='sr-accounts-header__item']//span[contains(text(),\"%s\")]";
    public String columnHeader = "//div[contains(text(),\"%s\")]";
    public By accountSearchIcon = By.xpath(".//*[@class='sr-searchbox__icon right b-l-1']");
    public By accountSearchInput = By.xpath(".//*[@class='sr-searchbox__input']");
    public By roleList = By.xpath("//*[@class='sr-settings-roles']/li");
    public String roleActionMenuBtn = "//label[text()=\"%s\"]/../../..//button[@id='contextMenu-roles']";
    public By companiesTitleUnderFedexAccounts = By.xpath("//div[@class='sr-group-title']");
    public By accountAliasname = By.xpath("// div[@class='ag-center-cols-container']/div/div/app-account-link/div/span");
    public By accounselection=By.xpath("//div[@col-id='accountId' and @role='gridcell']/parent::div[@aria-rowindex='2']");
    public By disableCheckbox=By.xpath(".// input[contains(@type,'checkbox')]");
    public String optionUnderPreference="//select[@id=\"%s\"]//ancestor::app-sr-dropdown/following-sibling::app-sr-dropdown//select[@id=\"%s\"]";
    public String defaultOptionForSetting="//select[@id=\"%s\"]";

   public PreferencesPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
        this.homePage = new HomePage(this.commonHelpers);
    }

    /**
     * Verify SecondaryBar Visibility
     *
     * @param secondarylink
     * @return Boolean
     */
    public boolean CheckElementExist(String secondarylink) {
        this.waitUntilNotVisible(this.loadingIndicator);
        return this.getText(By.xpath(String.format(this.addInOrOutPrefLocation, "Settings"))).contains(secondarylink);
    }

    /**
     * Click on Preferences sub Nav Link
     *
     * @param Name
     * @return
     */
    public boolean ClickOnPreferences(String Name) {
        try {
            this.findElements(By.xpath(buildXpathForString(Name))).get(1).click();
            this.waitUntilNotVisible(this.loadingIndicator);
            return true;
        } catch (Exception e) {
            log.error(" **EXCEPTION** - Error in clicking preferences");
            return false;
        }
    }

    public boolean ValidateScreenElements(DataTable table) {
        boolean flag = true;
        try {
            List<String> PageElements = table.asList(String.class);
            for (String element : PageElements) {
                if (flag) {
                    int index = this.findElements(By.xpath(buildXpathForString(element))).size() - 1;
                    flag = this.findElements(By.xpath(buildXpathForString(element))).get(index).isDisplayed();
                    this.waitUntilNotVisible(this.loadingIndicator);
                } else {
                    break;
                }
            }
        } catch (Exception ex) {
            flag = false;
            log.error(" **EXCEPTION** Issue in validation of Validate ScreenElements" + ex.getMessage());
        }
        return flag;
    }

    /**
     * Click on Secondary option for Preferences *
     *
     * @param OptionName
     * @return Boolean
     */
    public boolean ClickOnSecondaryOptions(String OptionName) {
        boolean flag;
        this.waitUntilNotVisible(this.loadingIndicator);
        flag = this.findElement(By.xpath(String.format(preferredLocation, OptionName))).isDisplayed();

        if (flag) {
            if (OptionName.contains("Automatically create the list based on your shipment history")) {
                String AutoCheckVal = this.findElement(By.id("actiontype")).getAttribute("checked");
                if (AutoCheckVal == null || !AutoCheckVal.contains("true"))
                    this.clickOnElement(By.xpath(String.format(preferredLocation, OptionName)));
            } else {
                this.clickOnElement(By.xpath(String.format(preferredLocation, OptionName)));
            }
        }
        return flag;
    }

    public Boolean ValidateCPPEnablements(String endPointKey) {
        List<Boolean> validationflags = new ArrayList<>();
        int count =0;
        try {
            // for CE user expanding all companies before starting the validation as for
            // internal portal
            // companies are listed and under them we see enablement
            if (this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")) {
                this.findElements(companiesTitleUnderFedexAccounts).stream().skip(1)
                        .forEach(s -> this.clickOnElement(s));
            }
            Response response = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            FedExAccounts fedExAccounts = this.commonHelpers.unMarshall(response.asString(), FedExAccounts.class);
            for (Datum account : fedExAccounts.getData()) {
                if(this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")){
                this.ScrollIntoView(this.findElement(By.xpath(this.buildXpathForString(account.getAccountId()))));
                }
                log.info("Account Id: " + account.getAccountId());
                log.info("Surround Eligibility Type: " + account.getSurroundEligibilityType());
                Boolean flag=  this.elementIsDisplayed(By.xpath(this.buildXpathForString(account.getAccountId())));
                if(!flag)
                {
                    if(count==0) {
                        this.findElement(this.accounselection).click();
                        count ++;
                    }
                    while(!flag)
                    {

                        this.keyBoardEvent(Keys.DOWN);
                        flag=  this.elementIsDisplayed(By.xpath(this.buildXpathForString(account.getAccountId())));

                    }
                }
                validationflags
                        .add(this.elementIsDisplayed(By.xpath(this.buildXpathForString(account.getAccountId()))));
                String[] surroundEligibilityType = account.getSurroundEligibilityType().split(",");
                boolean ifSelectIsThere = false;
                for (String type : surroundEligibilityType) {

                    // if SELECT is there for some account, then other enablements will not be shown
                    // to end user on UI
                    // so skipping those by this flag. whenever select comes.. others would be
                    // skipped
                    if (!ifSelectIsThere) {
                        switch (type.trim()) {
                            case "Monitoring":
                                if (account.getMonitoring())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(
                                            String.format(this.IndicatorXpath, account.getAccountId(), "monitoring"))));
                                break;
                            case "Expedite":
                                if (account.getExpedite())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(
                                            String.format(this.IndicatorXpath, account.getAccountId(), "expedite"))));
                                break;
                            case "On Demand Care":
                                if (account.getOnDemandCare())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "onDemandCare"))));
                                break;
                            case "Contact Recipient":
                                if (account.getContactRecipient())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "contactRecipient"))));
                                break;
                            // will remove this soon as Digital is no longer an option to show
                            case "Digital":
                                if (account.getDigital())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(
                                            String.format(this.IndicatorXpath, account.getAccountId(), "digital"))));
                                break;
                            case "Customer Sep View":
                                if (account.getSepDataVisibleToCustomer())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "customerSepView"))));
                                break;
                            case "Select":
                                ifSelectIsThere = true;
                                if (account.getOnlyDigital())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "onlyDigital"))));
                                break;

                            case "Preferred":
                                if (account.getOnlyMonitored())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "monitoring"))));
                                break;

                            case "Premium":
                                if (account.getPremium())
                                    validationflags.add(this.elementIsDisplayed(By.xpath(
                                            String.format(this.IndicatorXpath, account.getAccountId(), "premium"))));
                                break;

                            case "Operational Visibility":
                                if (account.getSepDataVisibleToCustomer()) {
                                    validationflags
                                            .add(this.elementIsDisplayed(By.xpath(String.format(this.IndicatorXpath,
                                                    account.getAccountId(), "sepDataVisibleToCustomer"))));
                                    // Validating if the the main heading is present
                                    // as its dependent on this if the data is there then only it comes
                                    validationflags.add(this.elementIsDisplayed(getByusingString(
                                            String.format(this.accountHeader, "Operational Visibility"))));
                                }
                                break;

                            case "US Inbound Visibility":
                                if (account.getUsinboundOnly()) {
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "usinboundOnly"))));
                                    // same as Operational Visibility , an additional validation for the header
                                    validationflags.add(this.elementIsDisplayed(getByusingString(
                                            String.format(this.accountHeader, "US Inbound Visibility"))));
                                }
                                break;
                            case "All International":
                                if (account.getAllInternational()) {
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "allInternational"))));
                                    validationflags.add(this.elementIsDisplayed(
                                            getByusingString(String.format(this.accountHeader, "All International"))));
                                }
                                break;
                            case "US Domestic Visibility":
                                if (account.getInternalMonitoring()) {
                                    validationflags
                                            .add(this.elementIsDisplayed(By.xpath(String.format(this.IndicatorXpath,
                                                    account.getAccountId(), "internalMonitoring"))));
                                    validationflags.add(this.elementIsDisplayed(getByusingString(
                                            String.format(this.accountHeader, "US Domestic Visibility"))));
                                }
                                break;
                            case "PA Monitoring":
                                if (account.getPamonitoring()) {
                                    validationflags.add(this.elementIsDisplayed(By.xpath(String
                                            .format(this.IndicatorXpath, account.getAccountId(), "paMonitoring"))));
                                    validationflags.add(this.elementIsDisplayed(
                                            getByusingString(String.format(this.accountHeader, "PA Monitoring"))));
                                }
                                break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in Validate CPP: " + e);
            Assert.fail("Something went wrong in Validate CPP");
        }

        return !validationflags.contains(false);
    }

    /**
     * Function to return true if atleast 5 cities of preferred matched with
     * AllImpactedCities
     *
     * @param preferredListKey
     * @param AllImpactedListKey
     * @return
     */
    public boolean CheckPreferredLocation(String preferredListKey, String AllImpactedListKey) {
        String allimpactedcities = this.commonHelpers.GetValueFromResponseCollection(AllImpactedListKey).asString();
        String preferredcities = this.commonHelpers.GetValueFromResponseCollection(preferredListKey).asString();
        int matchedCount = 0;
        String regex = "\"name\":(.*?),";
        int totalpreferredcities = regexfinder(preferredcities, regex).size();
        ArrayList<String> preferredlist = regexfinder(preferredcities, regex);
        for (int i = 0; i < totalpreferredcities; i++) {
            if (allimpactedcities.contains(preferredlist.get(i).trim())) {
                matchedCount++;
            }
        }
        return matchedCount >= 5;
    }

    /**
     * Return ArrayList based on the regex from the Content
     *
     * @param content
     * @param regex
     * @return
     */
    public ArrayList<String> regexfinder(String content, String regex) {
        Pattern pattern = Pattern.compile(regex);
        ArrayList<String> list = new ArrayList<>();
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            list.add(matcher.group());
        }
        return list;
    }

    /**
     * No Drop down should be blank
     *
     * @return
     */
    public boolean AllDropDownBlankCheck() {
        boolean flag = true;
        List<WebElement> AllDropdown = this.findElements(dropdownId);
        for (WebElement dropdown : AllDropdown) {
            DriverManager.getDrv().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            Select firstdropdown = new Select(dropdown);
            firstdropdown.selectByIndex(0);

            if (dropdown.getText().length() > 0 && dropdown.getText() != null) {
            } else {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Function to check UpdateAt is as per user Preferences UpdateAt should
     * contains DATE FORMAT sample value and if TIMEFORMAT is 24-Hour than AM/PM
     * should be missing.
     *
     * @return
     */
    public boolean CheckUpdateAt() {
        boolean flag = true;
        WebElement UpdatedAt = this.findElement(lastUpdatedAt);
        String actualTime = UpdatedAt.getText();
        log.info("The time UpdatedAt is " + actualTime);
        String lang  = GenericFunction.ReadConfigFile("LANG");
        String timeZone ="";
        if (!lang.equalsIgnoreCase("en-us")) {
            timeZone = GenericFunction.ReadConfigFile("IST_LOCAL");
        } else {
            timeZone = GenericFunction.userTimeZone;
        }
        List<WebElement> AllDropdown = this.findElements(By.cssSelector("select"));
        for (WebElement dropdown : AllDropdown) {
            String caseid;
            String dropdownname = new Select(dropdown).getFirstSelectedOption().getText().replace("(", "").replace(")",
                    "");
            String preference_setting = "";

            if (CharMatcher.is('/').countIn(dropdownname) == 2 || CharMatcher.is('-').countIn(dropdownname) == 2) // &&
                                                                                                                  // dropdownname.contains("MM")
                                                                                                                  // &&
                                                                                                                  // dropdownname.contains("YYYY"))
            {
                caseid = "DATEFORMAT";
                preference_setting = dropdownname.split(" ")[1].trim();
            } else if (dropdownname.contains("-")) // || dropdownname.contains("24-Hour")) {
            {
                caseid = "TIMEFORMAT";
                preference_setting = dropdownname.split("-")[0].trim();
            } else {
                continue; // bypass for Temperature and Distance
            }

            switch (caseid) {
                case "DATEFORMAT":
                    Assertions.assertThat(actualTime)
                            .contains(preference_setting)
                            .contains(timeZone);

                    // flag = actualTime.contains(preference_setting) &&
                    // actualTime.contains(GenericFunction.userTimeZone);
                    break;

                case "TIMEFORMAT":
                    //
                    if (preference_setting.contains("12")) {
                        if (!(actualTime.contains("AM")
                                || actualTime.contains("PM") && actualTime.contains(timeZone))) {
                            Assertions.fail("Actual Time is not right for 12 hours--> " + actualTime);
                        }
                    } else if (preference_setting.contains("24")) {
                        if (!(!actualTime.contains("AM") || !actualTime.contains("PM"))
                                && actualTime.contains(timeZone)) {
                            Assertions.fail("Actual Time is not right for 24 hours format --> " + actualTime);
                        }
                    }
                    break;
                default:
                    Assertions.fail("An option is given which is not right --> " + caseid);
            }
        }
        return flag;
    }

    /**
     * Set the dropdown from selected dropdown
     */
    public void selectDropDown(String option, String inputType) {
        this.selectDropdown(this.getByusingString(String.format(this.dropDown, option)), "value", inputType);
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    /**
     * Set the Last index for Date and Time dropdown
     *
     * @return
     */
    public boolean SetDropDown() {
        boolean flag = true;
        this.waitForDOMToLoad(DriverManager.getDrv());
        List<WebElement> AllDropdown = this.findElements(By.cssSelector("select"));
        for (WebElement dropdown : AllDropdown) {
            DriverManager.getDrv().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            List<WebElement> count = new Select(dropdown).getOptions();
            new Select(dropdown).selectByIndex(count.size() - 1);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
        return flag;
    }

    /**
     * Clicks add preferred location link in preferences based on the input
     *
     * @param link
     */
    public void clickOnAddPreferenceLink(String link) {
        this.waitUntilVisible(By.xpath(String.format(addInOrOutPrefLocation, link)));
        this.clickOnElement(By.xpath(String.format(addInOrOutPrefLocation, link)));
    }

    /**
     * Enters text in preferred location textbox and selects the given option
     *
     * @param city
     */
    public void addPreferredLocation(String city) {
        this.clickOnElement(clickOnPrefLocationTextbox);
        this.enterText(clickOnPrefLocationTextbox, Keys.TAB + "");
        this.ScrollToTop();
        this.waitUntilVisible(enterPrefLocation);
        this.enterText(enterPrefLocation, city);
        city = city.substring(0, 1).toUpperCase() + city.substring(1);
        this.waitUntilVisible(By.xpath(String.format(this.selectPrefLocationOption, city)));
        this.clickOnElement(By.xpath(String.format(this.selectPrefLocationOption, city)));
    }

    /**
     * Verifies whether the added outbound preferred location is updated
     *
     * @param location
     * @return boolean
     */
    public boolean isPreferredLocationAdded(String location, String city) {
        this.waitUntilVisible(By.xpath(String.format(addedPrefLocation, location, city)));
        return this.elementIsDisplayed(By.xpath(String.format(addedPrefLocation, location, city)));
    }

    /**
     * removes the added outbound preferred location based on the given location
     *
     * @param city
     * @return
     */
    public void removePrefLocation(String location, String city) {

        this.waitUntilVisible(By.xpath(String.format(removeFirstPrefLocation, location, city)));
        this.clickOnElement(By.xpath(String.format(removeFirstPrefLocation, location)));
        this.waitUntilNotVisible(By.xpath(String.format(removeFirstPrefLocation, location)));
    }

    /**
     * gets inbound/outbound preferred location count
     *
     * @param
     * @return String
     */
    public int getPrefLocationsCount(String location) {

        this.waitUntilVisible(By.xpath(String.format(prefLocationsCount, location)));
        int count = this.findElements(By.xpath(String.format(prefLocationsCount, location))).size();
        return count;
    }

    /**
     * checks/unchecks the checkbox in preferred locations
     *
     * @param action
     */
    public void performActionOnCheckbox(String action) {
        String actualState = this.findElement(prefLocationCheckboxState).getAttribute("aria-checked").contains("true")
                ? "check"
                : "uncheck";
        String labelText = !GenericFunction.locale.contains(Constants.EN_US)
                ? this.genericFunctionObject
                        .getLocalizedValue("Automatically create the list based on your shipment history")
                : "Automatically create the list based on your shipment history";
        if (!action.equalsIgnoreCase(actualState)) {
            this.clickOnElement(By.xpath(String.format(prefLocationCheckbox, labelText)));
        }
    }

    /**
     * Verifies whether the added city is shown in Advisories > Preferred locaitons
     *
     * @param
     * @return String
     */
    public boolean isAddedPrefCityShownInAdvList(String city) {
        this.scrollVerticallyInternalScrollBarOnPage("class","cdk-virtual-scroll-viewport sr-card-wrapper-cdk cdk-virtual-scroll-orientation-vertical","400");
        if(this.elementIsDisplayed(By.xpath(String.format(addedPrefLocationInAdvList, city)))
                || this.elementIsDisplayed(By.xpath(String.format(addedPrefLocationInAdvList, city.toUpperCase()))))
            return true;
        else {
            // trying to scroll up to see the rest of the options, as at a time all 10 options does not appear
            this.scrollVerticallyInternalScrollBarOnPage("class", "cdk-virtual-scroll-viewport sr-card-wrapper-cdk cdk-virtual-scroll-orientation-vertical", "-700");
            return this.elementIsDisplayed(By.xpath(String.format(addedPrefLocationInAdvList, city)))
                    || this.elementIsDisplayed(By.xpath(String.format(addedPrefLocationInAdvList, city.toUpperCase())));
        }
    }

    /**
     * Verifies whether the add preferred location link is disabled
     *
     * @param
     * @return String
     */
    public boolean isAddPrefCityLinkDisabled(String link) {
        return this.elementIsDisplayed(By.xpath(String.format(isAddPrefCityLinkDisabled, link)));
    }

    public String getPreferencePagesHeader(String subMenu) {
        return this.getText(By.xpath(String.format(this.subMenuHeader, subMenu)));
    }

    public Boolean validateCompanyPreference(String account) {
        return this.elementIsDisplayed(By.xpath(String.format(this.companyPreferences, account)));
    }

    public Boolean validateAccountPreference(String account) {
        return this.elementIsDisplayed(By.xpath(String.format(this.accountPreferences, account)));
    }

    public boolean isPlusIconPresentPreferences(String company) {
        return this.elementIsDisplayed(By.xpath(String.format(this.plusIconPreferences, company)));
    }

    public boolean isHeaderDisplayed(String headerName) {
        return this.elementIsDisplayed(By.xpath(String.format(this.accountHeader, headerName)));
    }

    public void clickPreferencePlusIcon(String company) {
        this.clickOnElement(By.xpath(String.format(this.plusIconPreferences, company)));
    }

    public void getFilterDateFormat() {
        String expectedFilterDate = this.findElement(filterDateFormat).getText();
        WebElement UpdatedAt = this.findElement(lastUpdatedAt);
        String actualTime = UpdatedAt.getText();
        String[] date = actualTime.split(",");
        String actualDate = date[1].replaceAll(" ", "");
        Assert.assertEquals(expectedFilterDate, actualDate);
    }

    public void removePrefLocation() {
        this.clickOnElement(removePrefLoc);
    }

    public void clickImageRole(String imageRole) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(By.xpath(String.format(this.imageRoleName, imageRole)));
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(this.selectedImageRoleName, imageRole))));
        // wait for few second after selecting the image role
        this.commonHelpers.thinkTimer(3000);
    }

    public void validateFedexPreferenceColumnIsPresent(String columnName) {
        Assert.assertTrue(this.elementIsDisplayed(By.xpath(String.format(this.fedexAccountsColumn, columnName))));
    }

    public void validateFedexPreferenceColumnIsNotPresent(String columnName) {
        Assert.assertFalse(this.elementIsDisplayed(By.xpath(String.format(this.fedexAccountsColumn, columnName))));
    }
    public  void verifyAccountAliasName(){
        List<WebElement>listOfAccNoBesideAddAliasBtn=this.findElements(accountAliasname);
        for(WebElement el:listOfAccNoBesideAddAliasBtn){
            String aliasname=el.getText();
            String alias="Add Alias";
            String lang  = GenericFunction.ReadConfigFile("LANG");
            if(!lang.equalsIgnoreCase("en-us")){
                alias=this.genericFunctionObject.getLocalizedValue(alias);
            }
            if(!aliasname.equals(alias) || aliasname.isEmpty() )
            {
                Assert.assertFalse(false);
            }
        }
    }

    public boolean validateHeadersForPreferences(String header1, String header2) {
        String destination = this.findElement(By.xpath(String.format(this.columnHeader, header1))).getText();
        String lastKnownLocn = this.findElement(By.xpath(String.format(this.columnHeader, header2))).getText();
        return destination.equalsIgnoreCase(header1) && lastKnownLocn.equalsIgnoreCase(header2);
    }

    public void searchAccountNumber(String contextStorevariable) throws InterruptedException {
        String accountNumber = this.commonHelpers.getValuefromContextStore(contextStorevariable).toString();
        this.enterText(accountSearchInput, accountNumber);
        this.JavaScriptClick(this.findElement(this.accountSearchIcon));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    public void validateOnlySearchedAccountIsDisplayed(DataTable dataTable) {
        Map<String, String> accounts = dataTable.asMap(String.class, String.class);
        String accountValue;
        for (String account : accounts.keySet()) {
            if (this.commonHelpers.getValuefromContextStore(account) != null) {
                accountValue = account.contains("ContextStore")
                        ? this.commonHelpers.getValuefromContextStore(account).toString()
                        : account;
                if (accounts.get(account).equalsIgnoreCase("isDisplayed")) {
                    Assert.assertTrue("Account is not displayed",
                            this.elementIsDisplayed(By.xpath(String.format(this.accountPreferences, accountValue))));
                } else if (accounts.get(account).equalsIgnoreCase("isNotDisplayed")) {
                    Assert.assertFalse("Account is displayed",
                            this.elementIsDisplayed(By.xpath(String.format(this.accountPreferences, accountValue))));
                }
            }
        }
    }

    public void verifyImageRoles() {
        List<WebElement> actRolesList = this.findElements(this.roleList);
        List<String> actRoles = new ArrayList<>();
        Assert.assertTrue(actRolesList.get(0).getText().contains("(Default)"));
        actRoles.add(actRolesList.get(0).getText().replace("\n(Default)", ""));
        for (int i = 1; i < actRolesList.size(); i++) {
            actRoles.add(actRolesList.get(i).getText());
        }
        // Verify roles sorted alphabetically
        Assert.assertTrue(this.verifyIamgeRolesSortedAlphabetically(true));
        List<List<AvailableImageRole>> expRolesList = (List<List<AvailableImageRole>>) this.commonHelpers
                .getValuefromContextStore("availableImageRoles");
        Assert.assertEquals(actRoles.size(), expRolesList.size());
        for (List<AvailableImageRole> availableImageRoles : expRolesList) {
            AvailableImageRole roleMap = (AvailableImageRole) availableImageRoles;
            String roleName = roleMap.getDisplayName();
            Assert.assertTrue(actRoles.indexOf(roleName) >= 0);
        }
    }

    public void validationspostRoleSelection(String roleName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        List<WebElement> actRoles = this.findElements(this.roleList);
        // Verify roles sorted alphabetically
        Assert.assertTrue(this.verifyIamgeRolesSortedAlphabetically(true));
        // Verify first role is the selected role
        Assert.assertEquals(actRoles.get(0).getText(), roleName);
        // Verify company name/account id is updated as per role
        boolean companyFlag = false;
        Map<String, List<String>> companies = this.shipmentOverviewPage.getSelectedCompanies();
        List<List<AvailableImageRole>> expRolesList = (List<List<AvailableImageRole>>) this.commonHelpers
                .getValuefromContextStore("availableImageRoles");
        for (List<AvailableImageRole> availableImageRoles : expRolesList) {
            AvailableImageRole roleMap = (AvailableImageRole) availableImageRoles;
            String role = roleMap.getDisplayName();
            String roleId = roleMap.getRoleName();
            if (role.equalsIgnoreCase(roleName)) {
                Map<Object, Object> pH = (Map<Object, Object>) this.commonHelpers
                        .getValuefromContextStore("preferredHierarchy");
                Map<Object, Object> companyAH = (Map<Object, Object>) pH.get(roleId);
                Map<Object, Object> companyAHierarchy = (Map<Object, Object>) companyAH
                        .get("companyAndAccountHierarchy");
                for (Object key : companyAHierarchy.keySet()) {
                    List<String> idList = (List<String>) companyAHierarchy.get(key);
                    for (String idName : idList) {
                        for (Object compKey : companies.keySet()) {
                            if (companies.get(compKey).indexOf(idName) >= 0) {
                                companyFlag = true;
                                break;
                            }
                        }
                        if (companyFlag) {
                            break;
                        }
                    }
                }
            }
            if (companyFlag) {
                break;
            }
        }
        Assert.assertTrue(companyFlag);
        // Assert.assertTrue(companies.containsKey(company));
        // Verify the header is displayed with selected role
        Assert.assertTrue(this
                .elementIsDisplayed(this.getByusingString(String.format(this.selectedImageRoleName, roleName)), true));
    }

    public boolean verifyIamgeRolesSortedAlphabetically(boolean skipFirstRole) {
        List<WebElement> actRoles = this.findElements(this.roleList);
        String previous = "";
        if (skipFirstRole) {
            actRoles.remove(0);
        }
        for (WebElement role : actRoles) {
            final String current = role.getText();
            if (current.compareTo(previous) < 0)
                return false;
            previous = current;
        }
        return true;
    }

    public void assignDefaultRole(String roleName) {
        this.clickOnElement(this.getByusingString(String.format(this.roleActionMenuBtn, roleName)));
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(" Set this as a default role ")));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    // localization CODE BEGIN
    public void validateSettingsLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Settings":
                    softly.assertThat(this.getText(this.settings)).isEqualTo(localisedValue);
                    break;

                case "Use the dropdown menus to adjust your settings":
                    softly.assertThat(this.getText(this.settingsHelpText)).isEqualTo(localisedValue);
                    break;

                case "DATE FORMAT":
                    By element = this.getByusingString(String.format(this.dropDowns, localisedValue));
                    softly.assertThat(this.elementIsDisplayed(element)).isTrue();

                    for (WebElement elm : this
                            .findElements(this.getByusingString(String.format(this.dropDownsText, localisedValue)))) {
                        String attribute = elm.getAttribute("value");
                        // removing the extra values to get the standard format value='0: MM/DD/YYYY'
                        attribute = attribute.replaceAll(".: ", "");
                        localisedValue = this.genericFunctionObject.getLocalizedValue(attribute);
                        localisedValue = localisedValue.replaceAll("\\\\", "");
                        softly.assertThat(elm.getText()).contains(localisedValue);
                    }
                    break;

                case "TIME FORMAT":
                    softly.assertThat(this
                            .elementIsDisplayed(this.getByusingString(String.format(this.dropDowns, localisedValue))))
                            .isTrue();
                    for (WebElement elm : this
                            .findElements(this.getByusingString(String.format(this.dropDownsText, localisedValue)))) {
                        String attribute = elm.getAttribute("value");
                        // removing the extra values to get the standard format value="0: 24-Hour"
                        attribute = attribute.replaceAll(".: ", "");
                        localisedValue = this.genericFunctionObject.getLocalizedValue(attribute);
                        softly.assertThat(elm.getText()).contains(localisedValue);
                    }
                    break;

                case "TEMPERATURE":
                    softly.assertThat(this
                            .elementIsDisplayed(this.getByusingString(String.format(this.dropDowns, localisedValue))))
                            .isTrue();
                    for (WebElement elm : this
                            .findElements(this.getByusingString(String.format(this.dropDownsText, localisedValue)))) {
                        String attribute = elm.getAttribute("value");
                        // removing the extra values to get the standard format value="0: Fahrenheit"
                        attribute = attribute.replaceAll(".: ", "");
                        localisedValue = this.genericFunctionObject.getLocalizedValue(attribute);
                        softly.assertThat(elm.getText()).contains(localisedValue);
                    }
                    break;
                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public void validatePreferredLocLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Preferences":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.homePage.topNavigation, localisedValue))))
                            .isTrue();
                    break;

                case "Preferred Locations":
                    softly.assertThat(this.getText(this.preferredLocationsText)).isEqualTo(localisedValue);
                    break;

                case "Add up to 5 last known location and 5 destination preferred locations":
                    softly.assertThat(this.getText(this.preferredLocationsHelpText)).isEqualTo(localisedValue);
                    break;

                case "Automatically create the list based on your shipment history":
                    softly.assertThat(this.getText(this.preferredLocationsCheckboxText)).isEqualTo(localisedValue);
                    break;

                case "LAST KNOWN LOCATION":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.lastKnownLocationOrDestination, localisedValue))))
                            .isTrue();
                    break;

                case "DESTINATION":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.lastKnownLocationOrDestination, localisedValue))))
                            .isTrue();
                    break;

                case "ADD LAST KNOWN LOCATION LOCATION (MAX 5)":
                    softly.assertThat(this.elementIsDisplayed(this
                            .getByusingString(String.format(this.addlastKnownLocationOrDestination, localisedValue))))
                            .isTrue();
                    break;

                case "ADD DESTINATION LOCATION (MAX 5)":
                    softly.assertThat(this.elementIsDisplayed(this
                            .getByusingString(String.format(this.addlastKnownLocationOrDestination, localisedValue))))
                            .isTrue();
                    break;

                case "LOCATION":
                    // checking all 10 elements should have the location word in right format
                    List<WebElement> allLocations = this.findElements(this.locationsLabel);
                    for (WebElement elm : allLocations) {
                        softly.assertThat((this.getText(elm))).contains(localisedValue.toUpperCase());
                    }
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }

    public void validateFedExAccountsLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "PREFERENCES":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.homePage.topNavigation, localisedValue))))
                            .isTrue();
                    break;

                case "FedEx Accounts":
                    softly.assertThat(this.getText(By.xpath(String.format(this.subMenuHeader, "sr-accounts"))))
                            .isEqualTo(localisedValue);
                    break;

                case "ACCOUNTS":
                    softly.assertThat(
                            this.elementIsDisplayed(By.xpath(String.format(this.fedexAccountsColumn, localisedValue))))
                            .isTrue();
                    break;

                case "FEDEX SURROUND ENABLEMENTS":
                    softly.assertThat(
                            this.elementIsDisplayed(By.xpath(String.format(this.accountHeader, localisedValue))))
                            .isTrue();
                    break;

                case "SEARCH BY ACCOUNTS":
                    softly.assertThat(this.findElement(this.accountSearchInput).getAttribute("placeholder"))
                            .isEqualTo(localisedValue);
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }
    // localization CODE END

    public void validateTNTOptions(String visibleOrNotVisible, DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            switch (value) {
                case "Carriers":
                    softly.assertThat(
                            this.elementIsDisplayed(this.getByusingString(String.format(this.mainHeadings, value))))
                            .isTrue();
                    break;

                case "Select Carriers":
                    softly.assertThat(this.elementIsDisplayed(
                            this.getByusingString(String.format(this.maineHeadingHelpingText, value)))).isTrue();
                    break;

                case "FedEx - Shipments that are serviced by FedEx":
                case "TNT - Shipments that are serviced by TNT":
                case "FedEx & TNT - Shipments serviced by both FedEx and TNT":
                    softly.assertThat(
                            this.elementIsDisplayed(this.getByusingString(String.format(this.radioButtons, value))))
                            .isTrue();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        if (visibleOrNotVisible.equalsIgnoreCase("visible")) {
            softly.assertAll();
        } else if (visibleOrNotVisible.equalsIgnoreCase("invisible")) {
            List<Throwable> errors = softly.errorsCollected();
            if (errors.size() == 0) {
                Assertions.fail("There should have been no elements present related to Carrier but they are visible");
            }
        }
    }

    public void validateTNTOptionsSelection(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        for (String value : allValues) {
            this.ScrollToTop();
            this.clickOnElement(this.getByusingString(String.format(this.radioButtons, value)));
            this.waitUntilNotVisible(this.loadingIndicator);
            Assertions
                    .assertThat(
                            this.getText(this.getByusingString(String.format(this.radioButtonsDefaultlabel, value))))
                    .isEqualTo("(Default)");
        }
    }

    public void validationRadioButtionSelection(String option) {
        Assertions.assertThat(this.verifyCheckBoxSelection(option, "checked")).isTrue();
    }

    public boolean verifyOptionUnderPreference(String option,String setting) {
        return this.elementIsDisplayed(By.xpath(String.format(this.optionUnderPreference, setting,option)));

    }

    public boolean verifyDefaultOptionForSetting(String setting,String defaultOption) {
        WebElement selectElement = this.findElement(By.xpath(String.format(this.defaultOptionForSetting, setting)));
       Select select = new Select(selectElement);
         List<WebElement> options = select.getOptions();
        List<String> optionsText = new ArrayList<>();

        for (WebElement option : options) {
            optionsText.add(option.getText());
        }

        return optionsText.contains(defaultOption);

    }

    public void verifyOptionsForSetting(String setting,DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        WebElement selectElement = this.findElement(By.xpath(String.format(this.defaultOptionForSetting, setting)));
        Select select = new Select(selectElement);
        List<WebElement> options = select.getOptions();
        List<String> optionsText = new ArrayList<>();

        for (WebElement option : options) {
            optionsText.add(option.getText());
        }
        Assertions.assertThat(optionsText).containsAll(allValues);
    }


    public void selectOptionFromSetting(String setting,String option){
        WebElement selectElement = this.findElement(By.xpath(String.format(this.defaultOptionForSetting, setting)));
        Select select = new Select(selectElement);
        select.selectByVisibleText(option);
        this.commonHelpers.thinkTimer(5000);
    }
}

