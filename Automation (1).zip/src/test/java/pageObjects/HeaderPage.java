package pageObjects;

import common.CommonHelpers;
import genericfunctions.GenericFunction;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
@Slf4j
public class HeaderPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public By ImageRoleLink = By.xpath(".//*[@class='fdx-u-hidden ce-header-role']//span");
    public String RoleLinks = ".//*[@class='ce-header-role__items']//a[contains(text(),\"%s\")]";
    public By CEDashboardLink = By.xpath(".//*[contains(text(),'CE Dashboard')]");
    public HeaderPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
    }

    public void SelectImageRoleFromConfig() {
        String imageRole = GenericFunction.ReadConfigFile("IMAGEROLE");
        this.JavaScriptClick(this.ImageRoleLink);
        this.JavaScriptClick(By.xpath(String.format(this.RoleLinks, imageRole)));
        this.commonHelpers.thinkTimer(1000);
        this.clickOnElement(CEDashboardLink);
        this.waitUntilVisible(By.xpath(String.format(this.buildXpathForString(imageRole))));
    }

}
