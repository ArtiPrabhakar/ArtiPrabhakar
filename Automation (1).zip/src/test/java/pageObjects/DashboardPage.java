package pageObjects;

import common.CommonHelpers;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;

import java.util.List;

@Slf4j
public class DashboardPage extends SeleniumGenericFunction{
    public CommonHelpers commonHelpers;
    public HomePage homePage;

    public By totalShipments = By.xpath("//div[@class='title']");
    public By allAccounts = By.xpath("//g[@class='contentGrp']//title");

    public DashboardPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.homePage = new HomePage(commonHelpers);
    }

    public void validateBasicHeadersOnAccountSummary(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        this.waitUntilNotVisible(this.loadingIndicator);
        String localisedValue;
        SoftAssertions softly = new SoftAssertions();
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {

                case "Account Summary":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.homePage.topNavigation, localisedValue)))).isTrue();
                    break;

                case "Shipments":
                    this.switchToIframe(0);
                    softly.assertThat(this.getText(totalShipments)).contains(localisedValue);
                    break;

                case "All Accounts":
                    softly.assertThat(this.getText(allAccounts)).contains(localisedValue);
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);
            }

        }
        softly.assertAll();
    }
}
