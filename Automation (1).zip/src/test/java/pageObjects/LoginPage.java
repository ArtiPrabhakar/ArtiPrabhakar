package pageObjects;

import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;

@Slf4j
public class LoginPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public String fedexURL = "https://wwwstress.dmz.idev.fedex.com/content/fedex-com/sites/us/en_us/GDCMTestSites/DICE/Brian-Smith1/Login-page-no-access.html";
    public String fedexTitle = "Login-page-no-access";
    public By welcomeSection = By.xpath("//div[@class='sr-dash-wrapper']//li[@class='sr-dash-info__item']");
    public By detailsButton = By.xpath(".//*[contains(@id,'details-button')]");
    public By proceedtoFedEx = By.xpath(".//a[contains(text(),'fedex')]");
    public By FedExSite = By.xpath(".//a[@class='fxg-header__logo_wrapper fxg-keyboard']");
    public By languageDrpdwn = By.xpath(".//*[@id='dropdownMenu']");
    public String languageSelection = ".//a[contains(text(),\"%s\")]";
    public String HeaderLang = "//ul/div/li//*[contains(text(),\"%s\")]";
    public String FooterLang = ".//footer//*[contains(text(),\"%s\")]";
    public By prodCloseIcon = By.xpath(".//*[contains(@class,'caas-icon--medium')]");
    public By loginButton = By.xpath(".//button[contains(@onclick,'login')]");

    public By loginButtonMainPage = By.xpath(".//a[contains(text(),'Log In')]");
    String url;

    public LoginPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
    }

    public void launchApplication(String url) {
        this.url = this.commonHelpers.GetApplicationUrl(url);
        log.info("Launching the FedEx Surrond portal URL in browser " + this.url);
        try {
            // Localization related redirection
            if(this.url.contains("home.html")) {
                DriverManager.getDrv().navigate().to(this.url);
                this.waitForDOMToLoad(DriverManager.getDrv());
                if(this.url.contains(GenericFunction.locale) && GenericFunction.virtualizationFlag)
                {
                  try {
                      // This code can be changed once we have more languages by making it variable
                      this.JavaScriptClick(this.getByusingString("//span[text()='Français']"));
                  }
                  catch (Exception e)
                  {
                      //todo can be removed later if for all the times we dont see that option
                      log.info(" The option to select the language did not came. Hence did not clicked on it.");
                  }
                }
                this.url = this.commonHelpers.GetApplicationUrl(this.url);

                log.info("Now navigating to  " + this.url);

            }
            this.commonHelpers.thinkTimer(3000);
            DriverManager.getDrv().navigate().to(this.url);
            this.waitForDOMToLoad(DriverManager.getDrv());
        } catch (Exception e) {
            log.error("**EXCEPTION** while navigating to page, hence trying again --> " + e);
            DriverManager.getDrv().navigate().to(this.url);
        }
    }

    public void HitTheUrlWithAppendedInput(String page, String url, String input) {

        this.url = this.commonHelpers.GetApplicationUrl(url);

        if (input.contains("ContextStore-")) {
            input = this.commonHelpers.getValuefromContextStore(input).toString();
        }
        switch (page) {
            case "Nav_Overview":
                this.url = this.url + Constants.Nav_Overview + input;
                break;
            case "Nav_Advisories_Shipments":
                this.url = this.url + Constants.Nav_Advisories_Shipments + input;
                break;
            case "Nav_MyShipments":
                this.url = this.url + Constants.Nav_MyShipments + input;
                break;
            case "Nav_MyShipments_Details":
                this.url = this.url + Constants.Nav_MyShipments_Details + input;
                break;
            case "Nav_Preferences_Setttings":
                this.url = this.url + Constants.Nav_Preferences_Settings + input;
                break;
            case "Nav_Preferences_PreferredLocations":
                this.url = this.url + Constants.Nav_Preferences_PreferredLocations + input;
                break;
            case "MS_SurroundTerms":
                this.url = this.url + Constants.MS_SurroundTerms + input;
                break;
            default:
                break;
        }

        try {
            log.info(this.url);
            DriverManager.getDrv().navigate().to(this.url);
            //this.commonHelpers.thinkTimer(5000);
            this.waitUntilNotVisible(loadingIndicator, 40);
        } catch (Exception e) {
            DriverManager.getDrv().navigate().to(this.url);
            log.error("**EXCEPTION**  " + e);
        }

        log.info("Launching the FedEx Surrond portal URL in browser with appended input ");
    }

    public void NavigateToPage(String page) {
        if (page.equalsIgnoreCase("FedExSite")) {
            this.clickOnElement(FedExSite);
        }
    }

    public void Selectlanguage(String language) {
        this.clickOnElement(this.languageDrpdwn);
        switch (language) {
            case "Spanish":
                this.clickOnElement(
                        this.getByusingString(
                                String.format(this.languageSelection, genericfunctions.Constants.Spanish)));
                break;
            case "English":
                this.clickOnElement(
                        this.getByusingString(
                                String.format(this.languageSelection, genericfunctions.Constants.English)));
                break;
            default:
                break;
        }
    }

    public boolean Validatelanginheader(String language) {
        boolean flag = false;
        switch (language) {
            case "Spanish":
                flag = this.elementIsDisplayed(
                        this.getByusingString(
                                String.format(this.HeaderLang, genericfunctions.Constants.SpanishHeader)));
                break;
            case "English":
                flag = this.elementIsDisplayed(
                        this.getByusingString(
                                String.format(this.HeaderLang, genericfunctions.Constants.EnglishHeader)));
                break;
            default:
                break;
        }
        return flag;
    }

    public boolean Validatelanginfooter(String language) {
        boolean flag = false;
        switch (language) {
            case "Spanish":
                flag = this.elementIsDisplayed(
                        this.getByusingString(
                                String.format(this.FooterLang, genericfunctions.Constants.SpanishFooter)));
                break;
            case "English":
                flag = this.elementIsDisplayed(
                        this.getByusingString(
                                String.format(this.FooterLang, genericfunctions.Constants.EnglishFooter)));
                break;
            default:
                break;
        }
        return flag;
    }

    public void LogintoApp(String id, String pwd, String... module) {
        String AppPersona = (module != null && module.length > 0) ? "CE" : "Shipper";
        switch (AppPersona) {
            case "CE":
                // We check this when multiple cases are executed then we are already logged in
                // so logout button would be visible
                if (!this.elementIsDisplayed(this.CEsignOutLink)) {
                    this.waitUntilNotVisible(this.loadingIndicator);
                    this.waitUntilClickable(this.CEloginLink);
                    log.info("Clicking on login button for CE to open login page ");
                    this.JavaScriptClick(this.CEloginLink);

                    this.waitUntilNotVisible(this.loadingIndicator);
                    this.waitUntilVisible(CEuserIdTB, 120);
                    log.info("Entering username and password ");
                    this.enterText(CEuserIdTB, id);
                    this.enterText(CEpwdTB, pwd);
                    if(elementIsDisplayed(CELoginButton)){
                    this.clickOnElement(CELoginButton);
                    }
                    boolean serverExecution = this.getCEHostExecution();
                    if(!serverExecution) {
                        if (!this.elementIsDisplayed(this.CESelectPush)) {
                            log.info("Clicked on login button ");
                            log.info("Clicking on push notification to be approved");
                            log.info("Clicked on Send push so OTP can be sent.");
                            this.waitUntilNotVisible(this.CESendPush, 70);
                        }
                        else{
                            this.waitUntilVisible(this.CESelectPush);
                            this.clickOnElement(CESelectPush);
                            log.info("Clicked on login button ");
                            log.info("Clicking on push notification to be approved");
                            this.clickOnElement(CESendPush);
                            log.info("Clicked on Send push so OTP can be sent.");
                            this.waitUntilNotVisible(this.CESendPush, 70);
                        }
                    }
                    this.waitUntilVisible(welcomeSection, 120);
                    log.info("Able to see the welcome section");
                    //this.commonHelpers.thinkTimer(4000);
                }
                break;
            case "Shipper":
                this.waitUntilNotVisible(this.loadingIndicator, 60);
                if (GenericFunction.virtualizationFlag) {
                    this.waitUntilVisible(userIdTB, 60);
                    this.commonHelpers.thinkTimer(5000);
                    log.info("** user id Login button is visible now for virtualised login **");
                    log.info("**  Entering credentials to login ** ");
                    if (!this.elementIsDisplayed(userIdTB)) {
                        DriverManager.getDrv().navigate().refresh();
                        this.waitUntilNotVisible(this.loadingIndicator, 400);
                    }
                    this.enterText(userIdTB, id);
                    this.enterText(passwordTB, pwd);
                    log.info("Clicking on login button for virtualised page");
                    this.waitUntilVisible(loginButton,120);
                    this.clickOnElement(loginButton);
                    this.waitUntilVisible(loginButton,120);
                    this.launchApplication("RedirectionURL");
                    this.waitUntilNotVisible(this.loadingIndicator,120);
                }else{
                    log.info("Not using workaround but going via other way - the stress page will come");

                    this.waitUntilVisible(LoginButtonStressPage, 120);
                    this.isElementDisplayed(LoginButtonStressPage,10000,24);
                        this.enterText(userIdStressPage, id);
                        this.enterText(passwordStressPage, pwd);
                        this.clickOnElement(LoginButtonStressPage);
                        log.info("Entered login details successfully");

                    //this.waitUntilNotVisible(LoginButtonStressPage);
                    this.waitUntilNotVisible(this.loadingIndicator, 120);
                    log.info("Clicked on the popup that comes to confirm email id / phone number ");
                    try {
                        this.JavaScriptClick(remindMelater);
                    } catch (Exception e) {
                        log.info("unable to click on remind me later button ");
                    }


                }
//                } else if (DriverManager.getDrv().getCurrentUrl().contains(GenericFunction.locale)) {
//                    this.waitUntilNotVisible(this.loadingIndicator, 120);
//                    if(!this.elementIsPresent(loginButtonMainPage)){
//                        this.JavaScriptClick(loginButtonMainPage);
//                        this.isElementDisplayed(LoginButtonStressPage,10000,24);
//                    }
//                    this.waitUntilVisible(LoginButtonStressPage);
//                    log.info("Now Stress page is visible");
//                    log.info("Clicked on login stress page");
//                        this.enterText(userIdStressPage, id);
//                        this.enterText(passwordStressPage, pwd);
//                        this.clickOnElement(LoginButtonStressPage);
//                    log.info("Entered login details successfully");
//                    //this.waitUntilNotVisible(LoginButtonStressPage);
//                    this.waitUntilNotVisible(this.loadingIndicator);
//                    log.info("Clicked on the popup that comes to confirm email id / phone number ");
//                    try {
//                        this.JavaScriptClick(remindMelater);
//                    } catch (Exception e) {
//                        log.info("unable to click on remind me later button ");
//                    }
//                }
//                else {
//                    log.info("Not using workaround but going via other way - the stress page will come");
//                    this.waitUntilNotVisible(this.loadingIndicator);
//                    log.info("Waiting for stress page before entering login details");
//                    this.waitUntilVisible(loginLinksurround, 120);
//                    log.info("Now Stress page is visible");
//                    if(!this.elementIsPresent(loginButtonMainPage)){
//                        DriverManager.getDrv().navigate().refresh();
//                        log.info("*** Refreshing the Login Page *********");
////                        this.waitUntilNotVisible(this.loadingIndicator, 60);
//                        this.waitUntilVisible(loginLinksurround, 60);
//                        this.isElementDisplayed(loginLinksurround,10000,24);
//                    }
////                    this.clickOnElement(loginButtonMainPage);
//                    this.clickOnElement(loginLinksurround);
//
//                    this.waitUntilVisible(LoginButtonStressPage, 120);
//                    this.isElementDisplayed(LoginButtonStressPage,10000,24);
////                    log.info("Clicked on login stress page");
////                    this.waitUntilVisible(LoginButtonStressPage);
////                    if(this.elementIsPresent(userIdStressPage)) {
//                        this.enterText(userIdStressPage, id);
//                        this.enterText(passwordStressPage, pwd);
//                        this.clickOnElement(LoginButtonStressPage);
//                        log.info("Entered login details successfully");
////                    }else{
////                        log.info("******* Skipped Login Credentials");
////                    }
////                    this.enterText(userIdStressPage, id);
////                    this.enterText(passwordStressPage, pwd);
////                    this.clickOnElement(LoginButtonStressPage);
//
//                    //this.waitUntilNotVisible(LoginButtonStressPage);
//                    this.waitUntilNotVisible(this.loadingIndicator, 120);
//                    log.info("Clicked on the popup that comes to confirm email id / phone number ");
//                    try {
//                        this.JavaScriptClick(remindMelater);
//                    } catch (Exception e) {
//                        log.info("unable to click on remind me later button ");
//                    }
//                }

                    // when virtualization is off, we have to redirect to correct URL
                    if (!GenericFunction.virtualizationFlag) {
                        // Since the System always opens FDXQA, so we have to redirect to appropriate environment
                        this.launchApplication("RedirectionURL");

                        // local temporary fix for localization when virtualization is off
                       if(DriverManager.getDrv().getCurrentUrl().contains(GenericFunction.locale.toLowerCase()))
                       {
                           log.info("We will do redirection to env");
                           //this.waitForDOMToLoad(DriverManager.getDrv());
                           //DriverManager.getDrv().navigate().to("https://www.fedex.com/"+ GenericFunction.locale +"/home.html");
                           //this.waitForDOMToLoad(DriverManager.getDrv());
                           DriverManager.getDrv().navigate().to("https://"+ GenericFunction.ENV_LOCALIZATION+".origin.surround.fedex.com/dashboard");
                           this.waitForDOMToLoad(DriverManager.getDrv());
                       }
                    }
                    if (GenericFunction.ENV.equalsIgnoreCase("PROD")) {
                        if (this.elementIsDisplayed(prodCloseIcon))
                            this.clickOnElement(prodCloseIcon);
                    }
                }
                //this.waitUntilNotVisible(this.loadingIndicator, 30);
                //this.waitForDOMToLoad(DriverManager.getDrv()Manager.getDrv());
        }


    /**
     * function to wait until wwwdstress page is visible when virtualization is
     * false
     */
    public void WaitForStressPage() {
        //int waitTime = GenericFunction.TIMEOUT;
        int waitTime = 20;
        while (waitTime >= 0
                && !(this.GetCurrentBrowserURL().contains("stress.dmz") && this.waitUntilVisible(loginLinksurround, 30))) {
            this.commonHelpers.thinkTimer(1000);
            waitTime--;
        }
    }

    /**
     * function to check the redirect that page title and url can be used to check
     * other case like wwwdstress etc.
     *
     * @param SITENAME
     * @return
     */
    public boolean RedirectURL(String SITENAME) {
        boolean flag = true;
        String title = DriverManager.getDrv().getTitle();
        String currentURL = DriverManager.getDrv().getCurrentUrl();

        SITENAME = SITENAME.toLowerCase();
        switch (SITENAME) {
            case "fedexsite":
                flag = (title.contains(fedexTitle));
                flag = (flag && fedexURL.contains(currentURL));
                break;

        }
        return flag;
    }
}
