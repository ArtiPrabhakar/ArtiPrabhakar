package pageObjects;


import API.ResponseModels.CEdashboard;
import common.CommonHelpers;
import genericfunctions.Constants;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
@Slf4j
public class CEDashboard extends SeleniumGenericFunction {

    public CommonHelpers commonHelpers;
    public ShipmentOverviewPage shipmentOverviewPage;
    public String DashboardCountXpath = ".//*[contains(text(),\"%s\")]//ancestor::div[@role='row']//*[@col-id=\"%s\"]";
    public String plannedDeliveriesColId = "plannedDeliveries";
    public String companyNameColId = "companyName";
    public String lateColId = "late";
    public String recipCallsColId = "recipientCallsNeedToBeMade";
    public String atRiskColId = "atRisk";
    public String maxValueinColumns = ".//*[@role='gridcell' and @col-id=\"%s\"]//*[(text()=\"%s\")]";
    public String headersXpath = ".//*[@aria-rowindex='1']//*[contains(text(),\"%s\")]";
    public By companyListResults = By.xpath(".//*[@col-id='companyName']");
    public String dashboardCount = "//a[text()=\"%s\"]/ancestor::div[@role='row']/div[contains(@col-id,\"%s\")]";
    public By getViewCount = By.xpath(".//div[contains(text(),'Viewing:')]");
    public By ceDashBoardOption = By.xpath("//span[contains(text(),'CE Dashboard')]");
    public String dashOutforDelivery = "//div[contains(@col-id,\"%s\") and @role='gridcell']";
    public String filterBubbleXpath = "//*[@class='sr-pill__label']//span[contains(text(),\"%s\")]/parent::div/span[contains(text(),'%s:')]";
    public String dashBoardOption = "//span[contains(text(),\"%s\")]";
    public String ascOrderArrow = "//div[@class='ag-cell-label-container ag-header-cell-sorted-asc']//span[contains(text(),\"%s\")]";
    public String descOrderArrow = "//div[@class='ag-cell-label-container ag-header-cell-sorted-desc']//span[contains(text(),\"%s\")]";
    public By watchedListIcon = By.xpath("//div[@col-id='isWatched' and @role='gridcell']//div/div");

    public CEDashboard(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
    }

    public Boolean ValidateNumbersInDashboard() throws Exception {
        this.waitUntilNotVisible(this.loadingIndicator);
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Dashboard");
        List<CEdashboard> companies = this.commonHelpers.unMarshall(resp, CEdashboard[].class);
        List<Boolean> flags = new ArrayList<>();
        for (CEdashboard board : companies) {
            if (!flags.contains(false)) {
                // Planned Deliveries count validation
                flags.add(this.elementIsDisplayed(this.getByusingString(
                        String.format(DashboardCountXpath, board.getCompanyName(), plannedDeliveriesColId))));
                // Moderate Risk count validation
                flags.add(this.elementIsDisplayed(
                        this.getByusingString(String.format(DashboardCountXpath, board.getCompanyName(), lateColId))));
                // Receipent calls count validation
                flags.add(this.elementIsDisplayed(this.getByusingString(
                        String.format(DashboardCountXpath, board.getCompanyName(), recipCallsColId))));
                // AtRisk count validation
                flags.add(this.elementIsDisplayed(this
                        .getByusingString(String.format(DashboardCountXpath, board.getCompanyName(), atRiskColId))));
            } else {
                break;
            }
        }
        return !flags.contains(false);
    }

    public Boolean ValidateColumnHeaders(DataTable columnHeaders) {
        boolean flag = false;
        List<String> expectedHeaders = columnHeaders.asList(String.class);
        for (String header : expectedHeaders) {
            flag = this.elementIsDisplayed(this.getByusingString(String.format(this.headersXpath, header)));
            if (!flag) {
                break;
            }
        }
        return flag;
    }

    public Boolean ValidateSortofColumns(DataTable columnHeaders) throws Exception {
        boolean flag = true;
        String UImaxValue = "";
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_Dashboard");
        List<CEdashboard> companies = this.commonHelpers.unMarshall(resp, CEdashboard[].class);
        List<String> Headers = columnHeaders.asList(String.class);
        ArrayList<Integer> apiValues = new ArrayList();
        ArrayList listOfCompany = new ArrayList();
        for (String header : Headers) {
            this.clickOnElement(this.getByusingString(this.buildXpathForString(header)));
            this.clickOnElement(this.getByusingString(this.buildXpathForString(header)));
            apiValues.clear();
            if (flag) {
                switch (header) {
                    case "Company Name":
                        for (CEdashboard company : companies) {
                            listOfCompany.add(company.getCompanyName());
                        }
                        Collections.sort(listOfCompany);
                        UImaxValue = this.getText(this.getByusingString(String.format(maxValueinColumns,
                                this.companyNameColId, listOfCompany.get(listOfCompany.size() - 1))));
                        break;

                    case "OUT FOR DELIVERY":
                        for (CEdashboard company : companies) {
                            apiValues.add(company.getPlannedDeliveries());
                        }
                        Collections.sort(apiValues);
                        UImaxValue = this.getText(this.getByusingString(String.format(maxValueinColumns,
                                this.plannedDeliveriesColId, apiValues.get(apiValues.size() - 1))));
                        break;
                    case "Moderate Risk":
                        for (CEdashboard company : companies) {
                            apiValues.add(company.getLate());
                        }
                        Collections.sort(apiValues);
                        UImaxValue = this.getText(this.getByusingString(
                                String.format(maxValueinColumns, this.lateColId, apiValues.get(apiValues.size() - 1))));
                        break;
                    case "Recipient Calls Need To Be Made":
                        for (CEdashboard company : companies) {
                            apiValues.add(company.getRecipientCallsNeedToBeMade());
                        }
                        UImaxValue = this.getText(this.getByusingString(
                                String.format(maxValueinColumns, this.recipCallsColId,
                                        apiValues.get(apiValues.size() - 1))));
                        break;
                    case "AT RISK":
                        for (CEdashboard company : companies) {
                            apiValues.add(company.getAtRisk());
                        }
                        UImaxValue = this
                                .getText(this.getByusingString(String.format(maxValueinColumns, this.atRiskColId,
                                        apiValues.get(apiValues.size() - 1))));
                        break;
                }
                if (header.equals("Company Name")) {
                    flag = (UImaxValue).equals((listOfCompany.get(listOfCompany.size() - 1)));
                } else {
                    flag = Integer.parseInt(UImaxValue) == (apiValues.get(apiValues.size() - 1));
                }

            } else {
                break;
            }
        }
        return flag;
    }

    /**
     * Funtion for Checking more than 1 company present in DashBoard or not
     *
     * @return - true / false
     */
    public boolean CheckforMorethanOneCompany() {
        int TrackingIDsCount = this.findElements(companyListResults).size() - 1;
        log.info("Total Companies in CE: " + TrackingIDsCount);
        this.commonHelpers.AddToContextStore("TotalCompanies", "" + TrackingIDsCount);
        return TrackingIDsCount > 1;
    }

    /**
     * Validates dashboard count based on company and column name
     *
     * @return - true / false
     */
    public boolean ValidateDashboardNumbers(String company, DataTable columns) {
        ArrayList<Boolean> Validationflags = new ArrayList<>();
        List<String> columnsList = columns.asList(String.class);
        for (String column : columnsList) {
            this.StoreAndClickDashboardCount(company, column);
            Validationflags.add(this.ValidateViewCountWithDashboard(column));

            // filter bubble validation
            Validationflags.add(this.shipmentOverviewPage.VerifyFilterBubbleVisibility(column));
            this.NavigateToPreviousPageOfBrowser();
        }
        return !Validationflags.contains(false);
    }

    public boolean ValidateViewCountWithDashboard(String column) {
        if (this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            return true;
        } else {
            return this.commonHelpers.AssertCountswithCorrection(this.shipmentOverviewPage.getViewCount(),
                    Integer.valueOf(this.commonHelpers.getValuefromContextStore(column).toString()));
        }
    }

    /**
     * Stores count in context store
     */
    public void StoreAndClickDashboardCount(String company, String column) {
        company = this.commonHelpers.getValuefromContextStore(company).toString();
        String columnId = "";
        switch (column) {
            case "OUT FOR DELIVERY":
                columnId = "plannedDeliveries";
                break;
            case "MODERATE RISK":
                columnId = "late";
                break;
            case "RECIPIENT CALLS NEED TO BE MADE":
                columnId = "recipientCallsNeedToBeMade";
                break;
            case "AT RISK":
                columnId = "atRisk";
                break;
        }
        int count = Integer.parseInt(
                this.findElement(By.xpath(String.format(dashboardCount, company, columnId))).getAttribute("innerText"));
        this.commonHelpers.AddToContextStore(column, count);
        if (count > 0) {
            this.clickOnElement(By.xpath(String.format(dashboardCount, company, columnId)));
            this.waitUntilNotVisible(this.loadingIndicator);
            if (this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
                this.commonHelpers.removeKeyinContextStore(Constants.skipSteps);

        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    public void clickDashboardColumnValues(String columnOption) {
        List<WebElement> results = null;
        String coulmnID = null;
        switch (columnOption) {
            case "OUT FOR DELIVERY":
                coulmnID = "plannedDeliveries";
                results = this.findElements(By.xpath(String.format(dashOutforDelivery, coulmnID)));
                break;
            case "Moderate Risk":
                coulmnID = "late";
                results = this.findElements(By.xpath(String.format(dashOutforDelivery, coulmnID)));
                break;
            case "Recipient Calls Need To Be Made":
                coulmnID = "recipientCallsNeedToBeMade";
                results = this.findElements(By.xpath(String.format(dashOutforDelivery, coulmnID)));
                break;
            case "AT RISK":
                coulmnID = "atRisk";
                results = this.findElements(By.xpath(String.format(dashOutforDelivery, coulmnID)));
                break;
        }
        for (WebElement result : results) {
            String data = result.getText();
            if (!Objects.equals(data, "0")) {
                clickOnElement(By.xpath(String.format(dashOutforDelivery, coulmnID)));
                break;
            }
        }
        Assert.assertTrue("The Filter bubble is not displayed", this.verifyStatusFilter("STATUS", columnOption));
    }

    public boolean verifyStatusFilter(String status, String bubble) {
        boolean checkFilter = false;
        this.waitUntilNotVisible(this.loadingIndicator,50);
        if (status.equalsIgnoreCase("STATUS")) {
            checkFilter = this.findElement(this.getByusingString(String.format(this.filterBubbleXpath, bubble, status)))
                    .isDisplayed();
        }
        return checkFilter;
    }

    public void clickDashBoard(DataTable dataTable, String order) {
        List<String> dataOptions = dataTable.asList(String.class);
        for (String key : dataOptions) {
            if (order.equalsIgnoreCase("Ascending")) {
                this.JavaScriptClick(this.findElement(By.xpath(String.format(dashBoardOption, key))));
                Assert.assertTrue("Records Not sorted in Ascending",
                        this.findElement(By.xpath(String.format(ascOrderArrow, key))).isDisplayed());
            } else if (order.equalsIgnoreCase("Descending")) {
                this.DoubleClickElement(this.findElement(By.xpath(String.format(dashBoardOption, key))));
                Assert.assertTrue("Records Not sorted in Descending",
                        this.findElement(By.xpath(String.format(descOrderArrow, key))).isDisplayed());
            }
        }
    }

    public boolean verifyOrderSelection() {
        List<WebElement> wathedList = this.findElements(watchedListIcon);
        boolean flag = false;
        for (WebElement ele : wathedList) {
            flag = ele.getAttribute("class").equalsIgnoreCase("company-star-icn filled");
        }
        return flag;
    }
}
