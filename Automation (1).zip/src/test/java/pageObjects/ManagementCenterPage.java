package pageObjects;

import common.CommonHelpers;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.assertj.core.util.Arrays;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDefinitions.TestAPI;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static genericfunctions.GenericFunction.slashBasedOnOs;
import static org.junit.Assert.assertEquals;
@Slf4j
public class ManagementCenterPage extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public By firstCompanyInRightPane = By.xpath("//mat-tree/mat-tree-node[1]");
    public By addNewButton = By.xpath("//span[text()='Add New']");
    public By enterWorkGroupName = By.xpath("//div[text()='Add New Work Group ']/parent::div//input");
    public By saveButton = By.xpath("//button[contains(text(),'Save')]");
    public String groupCreationSuccessPopUp = "//div[contains(text(),'%s successfully created.')]";
    public By closeButton = By.xpath("//button[contains(text(),'Close')]");
    public By groupUpdateSuccessPopUp = By.xpath("//div[contains(text(),'Updated successfully')]");
    public String companySelectionInRightPane = "//mat-tree/mat-tree-node/div/div/label[@for=\"%s\"]";
    public String companyExpansionOrCollapseInRightPane = "//mat-tree/mat-tree-node[@role='group'][%s]//span[2]";
    public String workgroupExpansionOrCollapseInLeftPane = "//span[text()=\"%s\"]/preceding-sibling::span";
    public String workgroupVisibility = "//ul/li//span[text()=\"%s\"]";
    public By assignButton = By.xpath("//button[contains(text(),'Assign')]");
    public String accountsUnderCompanyInLeftPane = "//span[text()=\"%s\"]/ancestor::div[@class='sr-group']//li/span[text()=\"%s\"]";
    public By lastCommentTextbox = By.xpath("//textarea");
    public By acknowledgeCheckbox = By.xpath("//div[contains(text(),'Add New Last Comment')]/parent::div//input/../label");
    public By errorMsg = By.xpath("//*[contains(@class,'message--error')]");
    public By filePath = By.xpath("//*[@id='file']");
    public By uploadPopUp = By.xpath("//*[contains(@class,'sr-modal__title')]");
    public String groupsTitleString = "//div[contains(text(),'Groups')]";
    public By searchInfoTooltip = By.xpath("//*[contains(@class,'accounts-info')]//*[@class='sr-account__tooltip-desc']");
    public By groupAccpuntsCompniesList = By.xpath("//span[@class='edit-icn']/../preceding-sibling::div/span[2] | //*[@class='edit-icn']/../preceding-sibling::div/span[@class='white-wrap']");

    public String expandGroupByName = "//*[contains(text(),\"%s\")]/preceding-sibling::span";
    public String workGroupCompanies = "//*[contains(text(),\"%s\")]/../../following-sibling::div//li[not(contains(@class,'sr-work-groups__account'))]//span[@class='white-wrap']";
    public String elementOnUi = "//*[contains(text(),\"%s\")]";
    public By selectedCompaniesChevron = By.xpath("//*[contains(@class,'selected-closed')]//span[contains(@class,'dropdown')]");
    public String accounts = "//label[contains(text(),\"%s\")]/../../../following-sibling::mat-tree-node[contains(@class,'open')]//label";
    public By unassignedAccountsChevron = By.xpath("//*[contains(@class,'mat-tree')]//span[contains(@class,'dropdown')]");
    public By workgroupName = By.xpath("//input[@aria-describedby='Work Group Name']");
    public String editDeleteWorkGroup = "//*[contains(text(),\"%s\")]/preceding-sibling::span/../following-sibling::div//span[contains(@class,'%s-icn')]";
    public By removeWorkGroupPopUpMsg = By.xpath("//*[@class='sr-modal__message']");
    public String wgRegion = "(//*[@id='region'])[%s]";
    public By enterCompanyName = By.xpath("//div[text()='Add New Company ']/parent::div//input");
    public By globalEntityNumber = By.xpath("//input[@name='globalEntityNumber']");
    public By compniesList = By.xpath("//*[@class='edit-icn']/../preceding-sibling::div/span[2]");
    public String companyAccounts = "//*[contains(text(),\"%s\")]/../../following-sibling::div//li";
    public String search = "//*[contains(text(),\"%s\")]/../following-sibling::div/div/input[@class='sr-searchbox__input']";
    public String fileUpdateStatus = "//*[contains(text(),\"%s\")]/../../../preceding-sibling::div//a[@class]";
    public By lastCommentMaxLength = By.xpath("//*[@class='sr-note-info']/span");
    public By searchlastComment = By.xpath("//input[@class='sr-searchbox__input']");
    public By selectedTab = By.xpath("//a[contains(@class,'menu active')]");
    public By uploadHistoryColumns = By.xpath("//div[@role='columnheader']//span[contains(@class,'cell-text')]");
    public By helpTextUploadHistory = By.xpath("//div[contains(@class,'upload-history-grid')]/div");
    public String columnId = "//div[@col-id=\"%s\"]//div[contains(@class,'sr-grid')]";
    public String searchGroupAccountCompanies = "//input[@class='sr-searchbox__input'][@placeholder=\"%s\"]";
    TestAPI apiCall;
    public ManagementCenterPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.apiCall = new TestAPI(this.commonHelpers);
    }

    /**
     * Function will create a workgroup with the given name in the management center
     *
     * @param label
     */
    public boolean CreateWorkgroup(String label, DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        boolean flag = false;
        String region = data.get("region");
        this.clickOnElement(addNewButton);
        this.enterText(enterWorkGroupName, label.split(",")[0]);
        this.selectDropdown(By.xpath(String.format(this.wgRegion, "2")), "text", region);
        this.clickOnElement(saveButton);
        if (label.contains("Existing")) {
            flag = this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("Work Group name already exists for the chosen region.")));
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
            label = label.replace(",Existing", "");
        } else {
            flag = this.elementIsDisplayed(By.xpath(String.format(groupCreationSuccessPopUp, label)), true);
            this.clickOnElement(closeButton);
        }
        String selectedRegion = this.getSelectedDropdownValue(By.xpath(String.format(this.wgRegion, "1")));
        if (selectedRegion.equals(region)) {
            this.ExpandWorkGroup(label);
        }
        if (data.containsKey("companies")) {
            this.AssignCompaniesToWorkGroup(table);
        }
        return flag;
    }

    /**
     * Function will validate whether a workgroup exists
     *
     * @param label
     */
    public boolean ValidateWorkgroupVisibility(String label) {
        boolean flag;
        flag = this.elementIsDisplayed(By.xpath(String.format(workgroupVisibility, label)), true);
        return flag;
    }

    public void ExpandWorkGroup(String workgroup) {
        this.clickOnElement(By.xpath(String.format(workgroupExpansionOrCollapseInLeftPane, workgroup)));
    }

    public void CollapseWorkGroup(String workgroup) {
        this.clickOnElement(By.xpath(workgroupExpansionOrCollapseInLeftPane));
    }

    public void AssignCompaniesToWorkGroup(DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        String[] companyList = data.get("companies").split(",");
        List<Object> columnTable = Arrays.asList(companyList);
        for (Object company : columnTable) {
            this.clickOnElement(By.xpath(String.format(companySelectionInRightPane, company.toString())));
        }
        this.ClickOnAssignButton();
    }

    public void ClickOnAssignButton() {
        this.clickOnElement(assignButton);
    }

    public boolean VerifyAccountsUnderCompanyInLeftPane(DataTable table) {
        ArrayList<Boolean> flagList = new ArrayList<>();
        Map<String, String> columnTable = table.asMap(String.class, String.class);
        for (String company : columnTable.keySet()) {
            for (String account : columnTable.get(company).split(",")) {
                flagList.add(this
                        .elementIsDisplayed(By.xpath(String.format(accountsUnderCompanyInLeftPane, company, account))));
            }
        }
        return !flagList.contains(false);
    }

    /**
     * Function will create a comment with the given name in the management center
     */
    public void createComment(String comment) {
        this.commonHelpers.AddToContextStore("commentNew", comment);
        this.clickOnElement(addNewButton);
        if (this.commonHelpers.verifyKeyInContextStore("comment")) {
            comment = (String) this.commonHelpers.getValuefromContextStore("comment");
        } else {
            this.commonHelpers.AddToContextStore("comment", comment);
        }
        this.enterText(lastCommentTextbox, comment);
        this.clickOnElement(acknowledgeCheckbox);
        this.clickOnElement(saveButton);
        try {
            String errMsg = this.getText(this.errorMsg);
            if (!errMsg.equals("")) {
                assertEquals("Error Message", "This comment already exists, please review the existing comments.", errMsg);
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Comments Added Succesfully");
        }

    }

    public void uploadFileForBulkGroup(String fileName) {
        String filePathToUpload = "";
        filePathToUpload = GenericFunction.home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        this.fileUpload(filePath, filePathToUpload + fileName);
    }

    public void verifyFileUploadPopUp(String uploadType, String fileName) {
        List<WebElement> elms = this.findElements(this.uploadPopUp);
        switch (uploadType) {
            case "Failed":
                Assert.assertEquals(Constants.fileUploadPopupHeader, elms.get(0).getText());
                Assert.assertEquals(Constants.fileUploadErrorMsg, elms.get(1).getText());
                Assert.assertTrue("File Name in Upload Failed popup", elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText(fileName)), false));
                break;
            case "Succesfull":
                Assert.assertTrue(this.elementIsDisplayed(this.removeWorkGroupPopUpMsg, true));
                break;
            default:
                log.error(" **EXCEPTION** : Upload status operation not applicable");
                Assert.fail("Upload status operation not applicable");
        }
    }

    public void verifyMappedCompaniesAccounts(String workgroupName, String companyName) {
        this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, workgroupName)));
        List<WebElement> companyList = this.findElements(this.getByusingString(String.format(this.workGroupCompanies, workgroupName)));
        this.apiCall.getWorkGroupCompnies(workgroupName);
        Map<String, Object> groupDetails = (Map<String, Object>) this.commonHelpers.getValuefromContextStore("company");
        //Verify Mapped companies with group
        for (WebElement company : companyList) {
            Assert.assertTrue("Company Mapped to Group", groupDetails.containsKey(company.getText()));
        }
        this.findElements(this.getByusingString(String.format(this.expandGroupByName, companyName))).get(0).click();
        List<String> accountIds = (List<String>) groupDetails.get(companyName);
        List<WebElement> accountIdsUi = this.findElements(this.getByusingString(String.format(this.elementOnUi, companyName) + "/../../following-sibling::div[@class='body']//li"));
        //Verify mapped accounts with companies
        for (WebElement accountId : accountIdsUi) {
            Assert.assertTrue("Account Id for company in group", accountIds.indexOf(accountId.getText()) >= 0);
        }
        //Verify ascending order for account ids
        Assert.assertTrue(this.verifyAlphabeticalSorting(accountIdsUi));
        //Verify Delete button for company name     
        Assert.assertTrue(this.findElements(By.xpath(String.format(this.elementOnUi, companyName) + "/../following-sibling::div//span")).get(0).isDisplayed());

    }

    public void verifyPurpleDotOnSelectedUnAssignedAccounts(String color) {
        List<WebElement> elmList = this.findElements(this.selectedCompaniesChevron);
        if (color.equals("")) {
            elmList = this.findElements(this.unassignedAccountsChevron);
        }
        for (WebElement webElement : elmList) {
            this.ScrollIntoView(webElement);
            String company = webElement.getAttribute("aria-label").replace("toggle ", "");
            webElement.click();
            List<WebElement> accounts = this.findElements(this.getByusingString(String.format(this.accounts, company.replace("'", ""))));
            for (WebElement account : accounts) {
                String accountId = account.getAttribute("for");
                if (color.equals("")) {
                    Assert.assertTrue("Purple Dot on Account", this.elementIsNotDisplayed(this.getByusingString(this.getXPathforCheckboxWithText(accountId) + "/span")));
                } else {
                    boolean accountAssigned = this.verifyCheckBoxSelection(accountId, "checked");
                    if (accountAssigned) {
                        Assert.assertEquals(this.getElementCssProperty(this.getByusingString(this.getXPathforCheckboxWithText(accountId) + "/span"), "background-color"), color);
                    } else {
                        Assert.assertTrue("Purple Dot on Account", this.elementIsNotDisplayed(this.getByusingString(this.getXPathforCheckboxWithText(accountId) + "/span")));
                    }
                }
            }
            webElement.click();
        }
    }

    public List<String> verifyWorkGroupCompanyAccount(String type, String name) {
        List<WebElement> elemList = new ArrayList<>();
        List<String> elemTextList = new ArrayList<>();
        switch (type) {
            case "Group":
                elemList = this.findElements(this.groupAccpuntsCompniesList);
                break;
            case "Company":
                this.expandWorkgroup(name);
                elemList = this.findElements(By.xpath(String.format(this.workGroupCompanies, name)));
                break;
            case "Accounts":
                elemList = this.findElements(By.xpath(String.format(this.accounts, name)));
                break;
            case "Companies":
                elemList = this.findElements(this.compniesList);
                break;
            case "Companies Accounts":
                elemList = this.findElements(By.xpath(String.format(this.companyAccounts, name)));
                break;
        }
        for (WebElement webElement : elemList) {
            elemTextList.add(webElement.getText());
        }
        return elemTextList;
    }

    public void workGroupOperation(String groupName, String operation, DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        this.expandWorkgroup(groupName.split(":")[0]);
        if (operation.contains(":")) {
            operation = operation.split(":")[0];
        }
        switch (operation) {
            case "Assign":
                if (this.commonHelpers.verifyKeyInContextStore("SelectedCompanies")) {
                    List<String> assignedCompanies = (List<String>) this.commonHelpers.getValuefromContextStore("SelectedCompanies");
                    for (String comp : assignedCompanies) {
                        this.clickOnElement(this.getByusingString(this.getXPathforCheckboxWithText(comp)));
                    }
                } else {
                    this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Show unassigned accounts only") + "/..//label"));
                    List<WebElement> unassignedCompanies = this.findElements(this.unassignedAccountsChevron);
                    String company = unassignedCompanies.get(0).getAttribute("aria-label").replace("toggle ", "");
                    this.clickOnElement(this.getByusingString(this.getXPathforCheckboxWithText(company)));
                    this.commonHelpers.AddToContextStore("NewlyAssignedCompny", company);
                }
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Assign ")));
                break;
            case "Delete":
                String companyToDelete = "";
                if (this.commonHelpers.verifyKeyInContextStore("NewlyAssignedCompny")) {
                    companyToDelete = (String) this.commonHelpers.getValuefromContextStore("NewlyAssignedCompny");

                }
                List<Object> compniesToDelete = Arrays.asList(data.get("companies").split(","));
                for (Object company : compniesToDelete) {
                    this.deleteCompany(groupName, company.toString());
                }
                break;
            case "Clear All-Cancel":
                List<String> selectedCompanies = this.verifyWorkGroupCompanyAccount("Company", groupName);
                this.commonHelpers.AddToContextStore("SelectedCompanies", selectedCompanies);
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Clear All ")));
                break;
            case "Clear All-Remove":
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Clear All ")));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Remove")));
                break;
            case "Remove All":
                this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, groupName)));
                this.expandWorkgroup(groupName);
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Remove All ")));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Remove All")));
                break;
            case "Delete Company":
                this.clickOnElement(this.getByusingString(String.format(this.editDeleteWorkGroup, groupName, "delete")));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Delete")));
                break;
            case "Edit":
                String oldGroup = groupName.split(":")[0];
                String newgroup = "";
                this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, oldGroup)));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(oldGroup)));
                this.clickOnElement(this.getByusingString(String.format(this.editDeleteWorkGroup, oldGroup, "edit")));
                if (data.containsKey("name")) {
                    oldGroup = groupName;
                    newgroup = data.get("newWorkGroup");
                    this.enterText(this.workgroupName, newgroup);
                }
                if (data.containsKey("region")) {
                    this.selectDropdown(By.xpath(String.format(this.wgRegion, "2")), "text", data.get("region"));
                }
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Save ")));
                break;
        }
    }

    public void expandWorkgroup(String workGroupName) {
        String classAtrbt = this.getAttributeValue(this.getByusingString(String.format(this.expandGroupByName, workGroupName)), "class");
        if (!classAtrbt.contains("minus-icn")) {
            this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, workGroupName)));
        }
    }

    public void deleteWorkGroup(String workgroup) {
        this.clickOnElement(this.getByusingString(String.format(this.editDeleteWorkGroup, workgroup, "delete")));
        this.clickOnLastElement(this.getXPathforAnyElementWithText("Delete"));
    }

    public void AssignAccountsToCompanies(DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        String[] accountList = data.get("accounts").split(",");
        List<Object> columnTable = Arrays.asList(accountList);
        for (Object account : columnTable) {
            this.clickOnElement(this.getByusingString(this.getXPathforCheckboxWithText(account.toString())));
        }
        this.ClickOnAssignButton();
    }

    /**
     * Function will create a company with the given name in the management center
     *
     * @param label
     */
    public void CreateCompany(String label) {
        String globalEntityNumber = RandomStringUtils.randomNumeric(12);
        this.clickOnElement(addNewButton);
        List<WebElement> textbox = this.findElements(enterCompanyName);
        this.enterText(textbox.get(0), label);
        this.enterText(textbox.get(1), globalEntityNumber);
        this.clickOnElement(saveButton);
        this.clickOnElement(closeButton);
        this.commonHelpers.AddToContextStore("GlobalEntityNumber", globalEntityNumber);
        this.commonHelpers.AddToContextStore("Company", label);
    }

    public void searchCompany(String company) {
        this.enterText(this.getByusingString(String.format(this.search, "COMPANIES")), company);
        this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, company)));
    }

    public void verifyGroupsInRegion(String expRegion, DataTable table) {
        Map<String, String> groupsData = table.asMap(String.class, String.class);
        List<String> groupList = verifyWorkGroupCompanyAccount("Group", "");
        if (groupsData.get("groupList").equals("all")) {
            if (groupList.size() > 0) {
                for (String group : groupList) {
                    Assert.assertEquals(expRegion, this.getSelectedRegion(group));
                }
            } else {
                log.info("No Groups available for Selected region:" + expRegion);
            }
        } else {
            Assert.assertEquals(expRegion, this.getSelectedRegion(groupsData.get("groupList")));
        }
        if (expRegion.equals("NO REGION")) {
            Assert.assertEquals(0, groupList.size());
        }

    }

    public String getSelectedRegion(String group) {
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(group)));
        this.clickOnElement(this.getByusingString(String.format(this.editDeleteWorkGroup, group, "edit")));
        String region = this.getSelectedDropdownValue(By.xpath(String.format(this.wgRegion, "2")));
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
        return region;
    }

    public void deleteCompany(String wg, String company) {
        this.expandWorkgroup(wg);
        this.clickOnElement(this.getByusingString(String.format(this.editDeleteWorkGroup, company, "delete")));
        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Remove")));
    }

    public void searchComment(String comnt) {
        this.enterText(this.searchlastComment, comnt);
    }

    public List<WebElement> getColumnDataForUploadhistory(String column) {
        String colId = "";
        switch (column) {
            case "Upload Date/Time":
                colId = "uploadedDateTime";
                break;
            case "User":
                colId = "userName";
                break;
            case "Upload Result":
                colId = "status";
                break;
            case "Uploaded File":
                colId = "inputFileName";
                break;
            default:
                log.error("**Unable to find the case for option");
                Assert.fail("Unable to find the case for option");
        }
        return this.findElements(By.xpath(String.format(this.columnId, colId)));
    }

    public void verifyuploadHistory(String operation, DataTable table) throws IOException {
        Map<String, String> data = table.asMap(String.class, String.class);
        String file = data.get("file").contains("ContextStore") ? (String) this.commonHelpers.getValuefromContextStore(data.get("file")) : data.get("file");
        String actualTime = new SimpleDateFormat("hh:mm a z, dd-MM-YYYY").format(new Date(System.currentTimeMillis()));
        String userId = (String) this.commonHelpers.getValuefromContextStore("CE");
        String userLink = this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText(userId)), "href");
        String date = this.getColumnDataForUploadhistory("Upload Date/Time").get(0).getText();
        Assert.assertEquals(actualTime, date);
        Assert.assertTrue(this.getColumnDataForUploadhistory("User").get(0).getText().contains(userId));
        Assert.assertEquals(userLink, Constants.userRefLink + userId);
        String actResult = this.getColumnDataForUploadhistory("Upload Result").get(0).getText();
        for (int i = 1; i < 120; i++) {
            actResult = this.getColumnDataForUploadhistory("Upload Result").get(0).getText();
            if (actResult.equals("Pending") && !operation.equals("Pending")) {
                this.commonHelpers.thinkTimer(1000);
            } else {
                break;
            }
        }
        Assert.assertEquals(operation, actResult);
        Assert.assertEquals(file, this.getColumnDataForUploadhistory("Uploaded File").get(0).getText());
        this.clickOnElement(By.xpath(this.GetxpathForLink(file)));
        Assert.assertTrue("File is not downloaded", this.genericFunctionObject.isFileDownloaded(file, true));
    }

    public void verifyPropertiesForSelectedGroup(String groupName, String color) {
        By locator = this.getByusingString(this.getXPathforAnyElementWithText(groupName) + "/../../..");
        Assert.assertEquals("Element is not Highlighted in purple color", this.getElementCssProperty(locator, "border-bottom-color"), color);
        Assert.assertTrue("Workgroup is not selected", this.getAttributeValue(locator, "class").contains("active"));
    }

    public void searchWorkgroupCompany(String name, String searchType) {
        if (searchType.equals("Groups")) {
            this.enterText(this.getByusingString(String.format(this.searchGroupAccountCompanies, "Search Groups / Accounts / Companies")), name);
        } else {
            this.enterText(this.getByusingString(String.format(this.searchGroupAccountCompanies, "Search Accounts / Companies")), name);
        }
    }

    public void removeWorkGroupSelection(String workGroupName) {
        commonHelpers.thinkTimer(2000);
        String classAtrbt = this.getAttributeValue(this.getByusingString(String.format(this.expandGroupByName, workGroupName)), "class");
        if (!classAtrbt.contains("minus-icn")) {
            this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, workGroupName)));
        }
        this.clickOnElement(this.getByusingString(String.format(this.expandGroupByName, workGroupName)));
    }


}