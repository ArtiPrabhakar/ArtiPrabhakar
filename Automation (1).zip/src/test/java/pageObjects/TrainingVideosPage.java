package pageObjects;

import common.CommonHelpers;
import common.DriverManager;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
@Slf4j
public class TrainingVideosPage extends SeleniumGenericFunction {

    public CommonHelpers commonHelpers;
    public By CentralHeading = By.xpath("//app-training-videos//div[@class='sr-section__head']/div[@class='sr-section__title']");
    public By CentralHeadingHelpText = By.xpath("//app-training-videos//div[@class='sr-section__head']/div[@class='sr-section__helpText']");
    public String VideosHeading = "(//app-training-videos//div[@class='sr-group']//label)[%s]";
    public String videoToggleExpand = "(//app-training-videos//div[contains(@class,'toggle-icn')])[%s]";
    public String videoToggleCollapse = "//app-training-videos//div[@class='sr-aside__list-item-toggle toggle-icn up']";
    public By playButtonAtCentre = By.xpath("//div[@class='videoHOlder']/a[@data-plugin-name='largePlayBtn']");
    public String videoControls = "//div[@class='controlsContainer']//*[@data-plugin-name=\"%s\"]";
    public String[] videoControlsOptions = {"playPauseBtn", "volumeControl", "currentTimeLabel", "durationLabel", "fullScreenBtn", "logo", "playbackRateSelector", "closedCaptions"};

    public TrainingVideosPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
    }

    public void validateHeading(String heading) {
        assertThat(this.findElement(CentralHeading).getText())
                .withFailMessage("Heading for Training Videos is not correct")
                .isEqualTo(heading);
    }

    public void validateHeadingHelpText(String helpText) {
        assertThat(this.findElement(CentralHeadingHelpText).getText())
                .withFailMessage("Helping text under Training Videos is not matching")
                .isEqualTo(helpText);
    }

    public void validateVideoHeadings(DataTable table) {
        List<String> vHeadings = table.asList(String.class);
        String heading;
        for (int i = 1; i <= 6; i++) {
            heading = this.findElement(By.xpath(String.format(VideosHeading, i))).getText();
            assertThat(vHeadings)
                    .withFailMessage("Video heading are not matching under Training Videos")
                    .contains(heading);
        }
    }


    public void validateVideoControls(DataTable videoSections) throws InterruptedException {
        List<String> vSections = videoSections.asList(String.class);

        int i = 1;
        for (String section : vSections) {
            log.info("Validating the section " + section);
            // open the nth video
            this.findElement(By.xpath(String.format(videoToggleExpand, i))).click();

            //this.switchToIframe(section);
            WebElement element=this.findElement(By.xpath("//iframe[@id=\""+section+"\"]"));
            DriverManager.getDrv().switchTo().frame(element);
            log.info("Switch to iframe element --> "+section);
            Thread.sleep(8000);

            // Wait until play button is visible
            if(i==1) {
                log.info ("Only for first section we are putting a longer wait time");
                this.waitUntilVisible(this.getByusingString(String.format(videoControls, "playPauseBtn")),30);
            }


            // verify all control options are listed for it
            for (String option : videoControlsOptions) {
                log.info("Validating the option - " + option);
                assertThat(this.elementIsDisplayed(By.xpath(String.format(videoControls, option))))
                        .withFailMessage("Control " + option + " <--- is not visible for section -->" + section)
                        .isTrue();
            }
            this.switchToParentIframe();

            // closing the section
            this.findElement(By.xpath(videoToggleCollapse)).click();
            i++;

        }
    }
}
