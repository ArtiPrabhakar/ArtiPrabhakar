package pageObjects;

import API.ResponseModels.CEdashboard;
import common.CommonHelpers;
import common.DriverManager;
import genericfunctions.API_GenericFun;
import genericfunctions.Constants;
import genericfunctions.DateTimeUtils;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;
import stepDefinitions.TestAPI;

import java.io.IOException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
public class DownloadCenterPage extends SeleniumGenericFunction {
    public static List<WebElement> rows;
    public CommonHelpers commonHelpers;
    public GenericFunction genericFuncObj;

    public String downloadCenterTitle = "//div[@class='sr-section__title']";
    public String availableReports = "//div[@class='sr-download-center__title']";
    public String cellHeadersText = "//span[contains(text(),\"%s\")]";
    public String clearOrDownloadButtonText = ".//button[text()=\"%s\"]";
    public String clearOrDownloadButtonText2 = ".//button[contains(text(),\"%s\")]";
    public String downloadLeftFooterText = "//div[@class='sr-section__footer__left']";

    public DownloadCenterPage(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.genericFuncObj = new GenericFunction();
    }

    // localization CODE BEGIN
    public void validateDownloadCenterLocalization(DataTable dataTable) {
        List<String> allValues = dataTable.asList(String.class);
        SoftAssertions softly = new SoftAssertions();
        String localisedValue;
        this.waitForDOMToLoad(DriverManager.getDrv());
        for (String value : allValues) {
            localisedValue = this.genericFunctionObject.getLocalizedValue(value);
            switch (value) {
                case "Downloads":
                    softly.assertThat(this.getText(By.xpath(this.downloadCenterTitle))).isEqualTo(localisedValue);
                    break;

                case "Available Reports":
                    String availableReportsString = this.getText(By.xpath(this.availableReports));
                    String availableReportsText = availableReportsString.split(" ")[0] + " " + availableReportsString.split(" ")[1];
                    softly.assertThat(availableReportsText).isEqualTo(localisedValue);
                    break;

                case "Reports":
                    String reportsXpath = "("+ String.format(this.cellHeadersText, localisedValue) +")[3]";
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(reportsXpath))).isTrue();
                    break;

                case "Report Date":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.cellHeadersText, localisedValue)))).isTrue();
                    break;

                case "Last Download":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.cellHeadersText, localisedValue)))).isTrue();
                    break;

                case "File Size":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.cellHeadersText, localisedValue)))).isTrue();
                    break;

                case "Clear":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.clearOrDownloadButtonText, localisedValue)))).isTrue();
                    break;

                case "Download":
                    softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.clearOrDownloadButtonText, localisedValue)))).isTrue();
                    break;

                case "Download Max 30 Files":
                    String maxDownload = this.getText(By.xpath(this.downloadLeftFooterText));
                    String maxDownloadText = maxDownload.substring(2);
                    softly.assertThat(maxDownloadText).isEqualTo(localisedValue);
                    break;

                case "No Rows To Show":
                    String availCountOnPage = this.getText(By.xpath(this.availableReports));
                    availCountOnPage = availCountOnPage.length() > 2 ? availCountOnPage.substring(availCountOnPage.length() - 2).trim()
                        : availCountOnPage;
                    int displayedCountPage = Integer.parseInt(availCountOnPage);
                    if(displayedCountPage == 0)
                        softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.cellHeadersText, localisedValue)))).isTrue();
                    else
                        softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.cellHeadersText, localisedValue)))).isFalse();
                    break;

                default:
                    Assertions.fail("There is a value passed which is not expected --> " + value);

            }

        }
        softly.assertAll();
    }
    // localization CODE END

}
