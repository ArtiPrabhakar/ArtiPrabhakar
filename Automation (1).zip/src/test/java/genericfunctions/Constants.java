package genericfunctions;

import API.ResponseModels.QuickViewCardsPreference;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All final Application constants should be stored in this file
 */
public class Constants {

    public static String appDashboard = ".//app-dashboard";
    public static String PlannedDeliveriesText = "These shipments are expected to arrive today.";
    public static String PlannedNextFewDaysText = "These shipments are moving and expected to arrive on time in the next few days.";
    public static String DBCollectionLink = "/dbs/%s/colls/%s";
    public static String DBDocumentLink = "/dbs/%s/colls/%s/docs/%s";
    public static String SOPINTERVENED = "We followed the SOP for shipments requiring extra attention.";
    public static String Spanish = "Español";
    public static String English = "English";
    public static String EN_US = "en-us";
    public static String EN_CA = "en-ca";
    public static String FR_CA = "fr-ca";
    public static String stringWithDifferentLang = "Référence use below one when bug is resolved";
    // public static String stringWithDifferentLang = "Référence N° Expédié à Reçu
    // Sélectionner Numéro Adresse de l'expéditeur Pays/territoire de le";
    public static String XSRFCookie = "XSRF-TOKEN=";
    public static String XSRFHeader = "X-XSRF-TOKEN";
    public static String SpanishHeader = "Envíos";
    public static String EnglishHeader = "Tracking";
    public static String SpanishFooter = "Empleos";
    public static String EnglishFooter = "About FedEx";
    public static String downloadFolder = "Downloads";
    public static String fileNameForShipment = "FedEx_Surround";
    public static String fileNameDate = "MMM-DD-YYYY";
    public static String fileExtension = "csv";
    public static String Prediction = "PREDICTION";
    public static String InterventionStatus = "INTERVENTION STATUS";
    public static String DeliveryStatus = "SCHEDULED DELIVERY";
    public static String DeliveredTime = "DELIVERED TIME";
    public static String Intransit = "ESTIMATED SCHEDULED DELIVERY";
    public static String Exception = "Exception";
    public static String From = "From";
    public static String To = "To";
    public static String SupportLink = "mailto: FedExSurroundSupport@fedex.com ?subject=FedEx Surround Support";
    public static String maxAccountErrorMsg = "Selection cannot exceed 250 accounts";
    public static String noAccountSelectedMsg = "Select either Companies/Accounts or Groups";

    public static List<String> ServiceLabels = Arrays.asList("SERVICE TYPE", "SURROUND ELIGIBILITY", "TERMS",
            "SPECIAL HANDLING", "SHIPPER REFERENCE", "PAYER ACCOUNT #", "SHIPPER ACCOUNT #",
            "MASTER TRACKING NUMBER", "PURCHASE ORDER #", "DEPARTMENT #",
            "CUSTOMER EXCEPTION REQUEST NUMBER (CER)", "DELIVERY ATTEMPTS", "DOOR TAG NUMBER(S)",
            "INVOICE NUMBER", "SENSOR");
    public static List<String> TimeStampScheduled = Arrays.asList("LABEL CREATED", "SHIP DATE", "STANDARD TRANSIT",
            "SCHEDULED DELIVERY");
    public static List<String> InternationalStatus = Arrays.asList("usExportApproved", "clearanceInProgress",
            "clearanceDelay",
            "internationalShipmentRelease");
    public static List<String> NonInternationalStatus = Arrays.asList("deliveryException", "weHaveYourPackage",
            "onTheWay", "labelCreated", "outForDelivery", "shipmentException", "delayStatus");
    public static List<String> TimeStampDelivered = Arrays.asList("LABEL CREATED", "SHIP DATE", "STANDARD TRANSIT");
    public static List<String> PackageLabels = Arrays.asList("FROM", "TO", "DIMENSIONS", "PACKAGING TYPE", "WEIGHT",
            "TOTAL SHIPMENT WEIGHT", "TOTAL PIECES");
    public static List<String> EndpointsNotinConsole = Arrays.asList("FedEx_UserAccounts", "MS_Preferences_user",
            "CE_CSRFToken", "MS_CSRFToken", "MS_Shipments_Details", "CE_Shipments_Details",
            "CE_CompanyHierarchy", "MS_User_Views");
    public static List<String> EndpointsNotXSRF = Arrays.asList("FedEx_UserInfo", "CE_CSRFToken");
    public static int defaultColumncount = 13;
    public static int defaultColumncountCE = 19;
    public static List<String> ShipperLogins = Arrays.asList("CaterUser1", "CaterUser2", "MedUser1", "MedUser2",
            "RocheUser1", "RocheUser2", "LabUser1", "LabUser2", "DPTest2", "l4user030");
    public static List<String> defaultColumnMyShipmentForShipper = Arrays.asList("TRACKING NUMBER", "STATUS",
            "COMMIT TIMER", "DATE DELIVERED", "PACKAGE DELAY STATUS", "PACKAGE RISK REASON",
            "RECIP COMPANY", "RECIP CONTACT NAME", "REFERENCE",
            "SCHEDULED DELIVERY DATE", "SCHEDULED DELIVERY TIME BY", "SUPPORT UPDATE", "SHIPPER NAME",
            "SHIPPER ACCOUNT NUMBER", "LAST KNOWN LOCATION", "WEATHER IMPACTED");
    public static List<String> defaultColumnMyShipmentForCE = Arrays.asList("TRACKING NUMBER", "STATUS",
            "COMMIT TIME", "DATE DELIVERED", "DELIVERY TIME", "FEDEX COMPANY", "DELAY STATUS",
            "DELAY REASON", "INTERVENTION STATUS", "RECIP COMPANY", "RECIP CONTACT NAME",
            "RECIPIENT CONTACT NUMBER/EMAIL", "REFERENCE", "SCHEDULED DELIVERY DATE",
            "SCHEDULED DELIVERY TIME BY", "SHIPPER NAME", "SHIPPER ACCOUNT NUMBER", "SHIPPER COMPANY",
            "SHIPPER CONTACT PHONE", "LAST KNOWN LOCATION", "LAST COMMENT", "LAST COMMENT ON",
            "COMMENT", "STATUS DETAIL");
    public static List<String> inactiveShipmentStatusList = Arrays.asList("Ready for Pickup", "Delivered",
            "Shipment Cancelled by sender");
    public static String trackingNoCol = "TRACKING NUMBER";
    public static int defaultColumnInShipment = 12;
    public static int defaultColumnInShipper = 2;
    public static int defaultColumnInRecipient = 2;
    public static int defaultColumnInShipmentCE = 15;
    public static int defaultColumnInShipperCE = 4;
    public static int defaultColumnInRecipientCE = 3;
    public static int RandomNumberLimit = 10000;
    public static String VirtualbaseURL = "VIRTUALISEDLOGINAPI";
    public static String baseURL = "_Base_URL";
    public static String CEbaseURL = "_CEBase_URL";
    public static String DBName = "DATABASENAME";
    public static String portalURL = "_PORTAL_URL";
    public static String reDirectionURL = "_REDIRECTION_URL";
    public static String CEportalURL = "_CEPORTAL_URL";
    public static String inprogressQChighlght = "inProgress";
    public static String outfordeliveryQChighlght = "outForDelivery";
    public static String monitoredQChighlght = "monitored";
    public static String allexceptionsQChighlght = "allExceptions";
    public static String deliveryExceptionsQChighlght = "deliveryExceptions";
    public static String atRiskQChighlght = "atRisk";
    public static String delayedQChighlght = "delay";
    public static String earlyQChighlght = "early";
    public static String noCommitQChighlght = "noCommit";
    public static String nearCommitQChighlght = "nearCommit";
    public static String pastCommitQChighlght = "preCommit";
    public static String ipdShipmentsQCHighlight = "ipdShipments";
    public static String clearanceDelayQCHighlight = "clearanceDelay";
    public static String customsClearanceQCHighlight = "customsClearance";
    public static String intervenedQCHighlight = "intervened";
    public static String returningToShipperQCHighlight = "returningToShipper";

    // Append these with the URL to hit the page directly
    public static String Nav_Overview = "dashboard";
    public static String Nav_Advisories_Shipments = "advisories/weather";
    // public static String Nav_Advisories_PreferredLocations = "";
    // public static String Nav_Advisories_WeatherForecast = "";
    public static String Nav_MyShipments = "shipments/listview?filterStateId=1";
    public static String Nav_MyShipments_Details = "shipments/";
    public static String Nav_Preferences_Settings = "preferences/settings";
    public static String Nav_Preferences_PreferredLocations = "preferences/preferredlocations";
    public static String MS_SurroundTerms = "surround-terms";
    public static String APIDateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static String APIDateTimeFormatwithoutMillis = "yyyy-MM-dd'T'HH:mm:ss";
    public static String APIDateFormat = "yyyy-MM-dd";
    public static String UIDateFormat = "M/d/yyyy";
    public static String UITimeFormat = "hh:mm a";
    public static String CommentBoxText = "These shipments are moving and expected to arrive on time in the next few days,and piece type is MPS1";
    public static String CaseIDText = "These shipments are moving and expected2";
    public static String skipSteps = "skipRemainingSteps";
    public static String EditColumnsCheckboxAttribute = "aria-checked";
    public static String ShipmentHeaderColIndex = "aria-colindex";
    // Static Queries
    // All Enablements
    public static String AllEnablements = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // only Monitored
    public static String Monitoring = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // Expedite + Monitor
    public static String ExpediteMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // Intervention + Monitor
    public static String InterventionMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // CallReceipent + Monitor
    public static String CallReceipMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // Intervention + CallReceipent + Monitor
    public static String InterCallRecepMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // Intervention + Expedite + Monitor
    public static String ExpeInterMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    // Expedite + CallReceipent + Monitor
    public static String ExpeCallReceipMonitor = "where c.documentType='accountDetailsExtension' "
            + "AND (IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_MONITORING']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_EXPEDITE']) AND "
            + "IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_CALL_RECIPIENT']) AND "
            + "NOT IS_DEFINED (c['accountExtensions']['cppPayload']['FEDEX_SURROUND_INTERVENTION']))";
    public static String deleteCommentConfirmationMessage = "Are you sure you want to delete this comment?";

    // user2 surround eligibility Account Ids Mock
    public static String AllEnablementsAcc = "669096658";
    public static String MonitoringAcc = "669096631";
    public static String ExpediteMonitorAcc = "669096615";
    public static String InterventionMonitorAcc = "669096593";
    public static String CallReceipMonitorAcc = "669096690";
    public static String InterCallRecepMonitorAcc = "669096739";
    public static String ExpeInterMonitorAcc = "669096755";
    public static String ExpeCallReceipMonitorAcc = "669096712";

    // user2 Account Ids Mock
    public static List<String> User2AccIds = Arrays.asList("669096593", "669096615", "669096631", "669096658",
            "669096674", "669096690", "669096712", "669096739", "669096755", "669096771");
    public static List<String> User1AccIds = Arrays.asList("669096399", "669096410", "669096437", "669096453",
            "669096470");// monitored accountd for MedUser1
    // public static List<String> User2AccIds = Arrays.asList("669096593");
    public static String getAllAccountForCompany = "where c.documentType = 'accountDetailsExtension' AND c.accountExtensions.globalEntity.globalEntityNumber = ";
    public static String getoutforDelivery = "AND c['shipmentExtensions']['externalStatus'] = 'Out for delivery' AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String inProgress = "AND c['shipmentExtensions']['externalStatus'] = 'In transit' AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String atRisk1 = "AND c.riskProfile.delayPredictions.categoryInternal='Moderate Risk' AND NOT IS_DEFINED(c['shipmentExtensions']['isShipmentActive'])";
    public static String atRisk2 = "AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String allExceptions = "AND c['payload']['statuses']['movement']['code'] in ('DE','SE') AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String deliveryExceptions = "AND c['payload']['statuses']['movement']['code'] in ('DE') AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String monitored = "AND c['shipmentExtensions']['isShipmentActive'] = true";
    public static String priorityAlert = "AND (ARRAY_CONTAINS(c['payload']['core']['service']['handling-code'], '15') OR ARRAY_CONTAINS(c['payload']['core']['service']['handling-code'], '37'))";
    // Filter available Values
    public static List<String> NAKScanFilters = Arrays.asList("No", "Yes", "ASTRA ONLY", "DELIVERY HANDLING",
            "DEST AIRPORT", "DEST CNTY", "DEST LOC", "DEST SRG", "GSS", "ILS", "INCOMPATIBLE FORM",
            "INTL/DOM", "ITAR", "MOVE DAYS", "PREFIX", "PRODUCT", "SPECIAL HANDLING");
    public static List<String> ShipmentStatusFilters = Arrays.asList("Delivered", "Shipment Exception",
            "Delivery Exception", "We have your package", "On the way", "Label Created", "Out for Delivery",
            "Ready for Pickup", "Shipment Cancelled by Sender", "Scheduled Delivery Date");
    public static List<String> LatestFXEventFilters = Arrays.asList("SOPS", "SIPS", "SRS", "SAS", "SDR", "PKGC",
            "STAT", "PUP", "HLD", "HOPS", "VANS", "CONS", "HIPS", "DCON", "LTE", "ASN", "BAT", "LBL",
            "MPOD", "POD", "SRD", "ROPS", "CUST", "RIPS", "REV", "HIT", "PUX", "DEX", "DDEX", "REX", "COD",
            "CODX", "HAL", "ODA", "NSLM/ASGN", "FEX", "HEX", "MIS", "MIS(II)", "EXP", "PEXP", "EXP(AUTO)",
            "GNSL", "TDE", "FSS", "MDD", "MDE1(ORIG)", "MDE1(DEL)", "MDE1(UPD)", "MDE2(UPD)", "MDE3(DESC)",
            "AG67", "CR66", "TN77", "INTS", "ECCO", "CDE", "NOI", "APS", "PABA", "OVRD", "LBL2(ASTRA)",
            "BTCH", "PMDE", "COMM", "CASH", "CER/NPQ", "MPS", "SPLY", "SEC", "FICH", "TMCD", "CNFM", "PHOD",
            "CCRP", "STS", " POF / SRND ", "NED", "NOI", "Contract", "Commit", "PSP", "Post Buster", "NATB",
            "DSP", "Relationship", "TFR", "PAA", " 2D Barcode ", "Shipment Merge", "Service Disruption",
            "Document", "DTG Notification", "Arrival", "ReRoute", "Route Update", "NAK", "AltLineHaul",
            "Customs Clearance");
    public static List<String> IndustryVerticalFilterOptions = Arrays.asList("IV:LIFENET_HCO", "SENSEAWARE-ID",
            "COORDHUTRIP", "IV:CA_HEALTHCARE", "IV:CRITICAL_HEALTHCARE");
    public static List<String> AllShipmentsColumns = Arrays.asList("commitTimer", "fedExOriginLocation",
            "scheduledDeliveryDate", "weatherImpacted", "cerCodes", "packageRiskReason",
            "fedExDestinationLocation", "lastCommentOn", "lastKnownLocation", "scheduledDeliveryTimeBy",
            "statusDetail", "recipPostal", "recipState");
    public static List<String> DelayReportsColumns = Arrays.asList("lastComment", "scheduledDeliveryDate",
            "shipDate", "status", "cerCodes", "cerNumbers",
            "packageRiskReason", "lastKnownLocation", "reference", "serviceType",
            "specialHandiling", "shipperCity", "shipperName", "shipperAddress", "shipperCompany",
            "shipperPostal", "shipperState", "recipAddress", "recipCity", "recipContactName",
            "recipCompany", "recipPostal", "recipState");
    public static List<String> WorkingListColumns = Arrays.asList("commitTimer", "fedExOriginLocation",
            "lastComment", "scheduledDeliveryDate", "shipDate", "cerNumbers",
            "cerCodes", "packageRiskReason", "fedExDestinationLocation", "lastCommentOn",
            "lastKnownLocation", "scheduledDeliveryTimeBy", "serviceType", "specialHandiling",
            "statusDetail", "recipPostal", "recipState");
    public static List<String> ServiceTypeFilters = Arrays.asList("FedEx 1Day Freight", "FedEx 2Day",
            "FedEx 2Day A.M", "FedEx 2Day Freight", "FedEx 3Day Freight", "FedEx Express Saver",
            "FedEx First Overnight", "FedEx First Overnight Freight", "FedEx Ground", "FedEx Home Delivery",
            "FedEx Priority Overnight", "FedEx Standard Overnight");
    public static List<String> Min3CharactersFilters = Arrays.asList("shippedTo", "Recip Contact Name",
            "invoiceNumber", "latestEvent");
    public static List<String> SearchBarFilters = Arrays.asList("Shipper Information", "Package Type",
            "Recipient Information", "FedEx Destination Location", "FedEx Origin Location", "Total Pieces",
            "Bill To Account", "Shipment Information", "Shipper Account Number", "Shipper City",
            "Shipper Company", "Shipper Country/ Territory", "Shipper Name", "Shipper Postal",
            "Shipper State/Province", "Shipper State", "Recipient City", "Recipient Company Name",
            "Recipient Contact Name", "Recipient Postal", "Recipient State",
            "Recipient State/Province", "Last Known City", "Last Known Country/ Territory", "Last Known State",
            "Last Known State/Province", "Department Number", "CER Type", "Vessel CONS", "Invoice Number",
            "Container ID", "Latest FXE Event", "Purchase Order Number", "Flight Number", "Last Known Ramp",
            "Last Known FedEx Facility", "Industry Vertical", "Service Type",
            "Reference", "Shipper Reference", "Delivered To", "Received By", "Last Primary Event",
            "Master Tracking Number","Origin State/Province");
    public static List<String> OptionFilters = Arrays.asList("FedEx Company", "Intervention Type",
            "Return to Shipper", "Service Type", "Signature Available", "Weather Status",
            "Delivery Prediction", "Intervention Status", "Shipment Status");
    public static String SearchDefaultText = "Use search field to search by the specified attribute.";
    public static String SuggestTextTwoLetter = "Please provide 2-letter abbreviation.";
    public static String SuggestTextThreeLetter = "Please provide 3-letter abbreviation.";
    public static String SuggestTextThreeCharacters = "Please provide the first 3-characters";
    public static String SuggestTextThreeLetterCERType = "Please provide the first 3 letters of the CER type.";
    public static JSONObject EmptyPayload = new JSONObject("{}");
    public static List<String> EndPointsWithEmptyPayload = Arrays.asList("MS_Advisories_weather",
            "MS_FedEx_Accounts", "MS_Shipments_AtRiskWeather", "MS_Shipments_OnTimeWeather",
            "MS_Shipments_TotalActive", "MS_Shipments_ActiveWeather", "MS_Shipments_WeatherIntervened");
    public static String NoResultsFound = "No results found.";
    public static String ConsecutiveSpecialCharactersNotAllowed = "Consecutive special characters are not allowed";
    public static String VesselConsLink = "(.//*[@href='https://myapps-wtc01.secure.fedex.com/consreport/explorer/ConsSearchResults.jsp?consid=%s'])[1]";
    public static List<String> SuggestTextTwoLetterFilters = Arrays.asList("Shipper State/Province",
            "Shipper Country/ Territory", "Last Known Country/ Territory", "Last Known State/Province",
            "Recipient Country/ Territory", "Recipient State/Province");
    public static List<String> SuggestTextThreeLetterFilters = Arrays.asList("Recipient City", "Last Known City",
            "Shipper City");
    public static List<String> SuggestTextThreeCharacterFilters = Arrays.asList("Last Known FedEx Facility");
    public static List<String> SuggestTextThreeLetterCERTypeFilter = Arrays.asList("CER Type");
    // Tooltips Content
    public static String ShipmentSpecificTip = "Shipment specific application will show data for the current tracking number on this page";
    public static String GenericTip = "Generic tools are internal and external resources that could provide additional details.";
    public static List<String> ShipmentSpecificToolLabels = Arrays.asList("CaseEBS", "SenseAware ID Dashboard",
            "eOps");
    public static List<String> GenericToolLabels = Arrays.asList("CONS reports", "FOIS", "SenseAware.com", "THOR",
            "TRIPS", "Weight And Balance", "Workbench","Global Cold Chain Contingency Services");
    public static List<String> ShipmentSpecificToolContent = Arrays.asList(
            "Case Enterprise Business Service (CaseEBS or cebs) is the case management system Customer Support reps use to create and manage FedEx Express cases. User must request access and login with LDAP.",
            "SenseAware ID will provide real time awareness of a package location throughout the package lifecycle within the FedEx Network. Login with LDAP.",
            "eOps (Enterprise Operational Portal) was created to allow users to access multiple applications from one location, and to assist with management of security for those applications. Login with LDAP.");
    public static List<String> GenericToolContent = Arrays.asList(
            "CONS searches CONS number as well as origin and destination with date range and consolidation type. Login with LDAP.",
            "Flight Operations Information System (FOIS) provides flight, aircraft and airline detail. User must request access and log in with LDAP.",
            "SenseAware is consisted of GPS device and a robust online platform to track real time location, temperature, humidity, shock, geofence, light detection and pressure. Log in is unique credentials (non-FCL, non-LDAP).",
            "Total Hub Ops Resource (THOR) complies hub data, directories and other resources. Home page and most links do not require LDAP.",
            "The Route Information Program (TRIP)/Vehicle Communications and tracking system (VCom) is a software package designed to help FedEx Express plan and control their overall trucking operations. Login with LDAP.",
            "Weight & Balance on Workbench is used by FedEx Express Operations to assign ULD position on aircraft. Training materials available, must have access to workbench in order to see weight & balance. For workbench, login with LDAP.",
            "FedEx Express internal site for all air operations needs. User must request access then login in with LDAP.",
            "Global Cold Chain Contingency Services is a user-friendly environment for finding cold chain information and capability for FedEx hubs and major sort locations.");

    public static List<String> GenericToolLinks = Arrays.asList(
            "http://aoc-memhub-s02.corp.ds.fedex.com/Thor/",
            "http://hronline.gpe.fedex.com/trainingdevelopment/td1505/wb_muse/index.html",
            "http://prh88565.prod.fedex.com:7001/trip/",
            "http://techops.fedex.com/default.asp?PageID=D7AA9A2C-E5FC-40B6-B35A-0EEC07914A1E",
            "https://fois.lhsprod.fedex.com:7002/foisweb/ApplicationsMenu.jsp",
            "https://myapps-wtc01.secure.fedex.com/consreport/explorer/",
            "https://myfedex.sharepoint.com/teams/GlobalColdChainContingencyServices/SitePages/Home.aspx",
            "https://sa.test.senseaware.com/web/wsawui/index.html#!login/index");



    // Company names in endpoints
    public static List<String> CompanyNameEndpoints = Arrays.asList("CE_Advisories_weather",
            "CE_Shipments_Overview",
            "CE_User_Views", "CE_GET_Views", "CE_FedEx_Accounts");
    public static Map<String, String> ExternalLinks = new HashMap<String, String>() {
        {
            put("Quick Help", "https://wwwtest.fedex.com/en-us/surround/faq.html#quick-help");
            put("Contact Us", "mailto:FedExSurroundSupport@fedex.com?subject=FedEx Surround Support");
            put("What's New", "https://wwwtest.fedex.com/en-us/surround/faq.html#whats-new");
        }
    };

    public static List<String> CEDefaultColumns = Arrays.asList("trackingNumber",
            "isWatched",
            "isPayer",
            "cerCodes",
            "commitTimer",
            "scheduledDeliveryDate",
            "scheduledDeliveryTimeBy",
            "lastKnownLocation",
            "fedExOriginLocation",
            "fedExDestinationLocation",
            "recipPostal",
            "recipState",
            "packageRiskReason",
            "weatherImpacted",
            "statusDetail",
            "lastCommentOn");
    public static List<String> CustomerDefaultColumns = Arrays.asList("isWatched",
            "trackingNumber",
            "isPayer",
            "status",
            "commitTimer",
            "packageDelayStatus",
            "dateDelivered",
            "packageRiskReason",
            "recipCompany",
            "recipContactName",
            "reference",
            "scheduledDeliveryDate",
            "scheduledDeliveryTimeBy",
            "shipperName",
            "shipperAccountNumber",
            "lastKnownLocation",
            "weatherImpacted");
    public static List<String> CEAllColumns = Arrays.asList("isWatched", "trackingNumber", "status", "commitTimer",
            "dateDelivered", "deliveryTime", "fedExCompany", "packageDelayStatus", "packageRiskReason",
            "lastCommentOn", "recipCompany", "recipContactName",
            "recipientContactNumberOrEmail", "reference", "scheduledDeliveryDate",
            "scheduledDeliveryTimeBy", "shipperAccountNumber", "shipperCompany", "shipperContactPhone",
            "shipperName", "lastKnownLocation", "shippedBy", "shipperAddress", "shipperCity",
            "shipperCountryOrTerritory", "shipperPostal", "shipperState", "appointmentDelivery",
            "billOfLading", "codRemittanceNumber", "commodityInformation", "dateAttemptedDelivery",
            "departmentNumber", "destPieceCount", "dimensionalWtKg", "dimensionalWtLb", "documentAvailable",
            "invoiceNumber", "masterTrackingNumber", "noOfPackages", "origPieceCount", "packageDimsCm",
            "packageDimsIn", "packageType", "partnerCarrierNbr", "pkgWtKg",
            "pkgWtLbs", "purchaseOrderNumber", "relationship", "returnAuthorizationName", "returnReason",
            "returnToShipperTrkNo", "serviceType", "shipDate", "signatureAvailable", "specialHandling",
            "standardTransitDate", "standardTransitTimeBy", "tendered", "totalNumberOfHandlingUnits",
            "totalWtKg", "totalWtLbs", "deliveredTo", "receivedBy", "recipAddressQty", "recipAddress",
            "recipCity", "recipCountryOrTerritory", "recipPostal", "recipState", "shippedTo",
            "addressCorrection", "clearancereleasereceived", "dimension", "doortagnumbers",
            "proofOfDeliverySignature", "rma", "shipperReference", "billToAccount", "fedExOriginLocation",
            "fedExDestinationLocation", "reference", "personalNotesMessage", "podException",
            "exceptionReason", "supportUpdate", "lastComment", "senseAwareJourneyId", "industryVerticalName",
            "deliveryAttempts", "cerCount", "workgroups");
    public static List<String> CEAllShipment = Arrays.asList("isWatched", "trackingNumber", "status",
            "dateDelivered", "commitTimer", "deliveryTime", "fedExCompany", "packageDelayStatus",
            "packageRiskReason", "lastCommentOn", "interventionStatus", "reference",
            "scheduledDeliveryDate", "scheduledDeliveryTimeBy", "lastKnownLocation", "appointmentDelivery",
            "billOfLading", "codRemittanceNumber", "commodityInformation", "dateAttemptedDelivery",
            "departmentNumber", "destPieceCount", "dimensionalWtKg", "dimensionalWtLb", "documentAvailable",
            "invoiceNumber", "masterTrackingNumber", "noOfPackages", "origPieceCount", "packageDimsCm",
            "packageDimsIn", "packageType", "interventionReason", "partnerCarrierNbr", "pkgWtKg",
            "pkgWtLbs", "purchaseOrderNumber", "relationship", "returnAuthorizationName", "returnReason",
            "returnToShipperTrkNo", "serviceType", "shipDate", "signatureAvailable", "specialHandling",
            "standardTransitDate", "standardTransitTimeBy", "tendered", "totalNumberOfHandlingUnits",
            "totalWtKg", "totalWtLbs", "addressCorrection", "clearancereleasereceived", "dimension",
            "doortagnumbers", "proofOfDeliverySignature", "rma", "shipperReference", "fedExOriginLocation",
            "fedExDestinationLocation", "reference", "personalNotesMessage");
    public static List<String> CEAllShipper = Arrays.asList("isWatched", "trackingNumber", "shipperAccountNumber",
            "shipperCompany", "shippedBy", "shipperAddress", "shipperCity", "shipperCountryOrTerritory",
            "shipperPostal", "shipperState", "shipperContactPhone", "shipperName", "billToAccount");
    public static List<String> CEAllRecipient = Arrays.asList("isWatched", "trackingNumber", "shipperAccountNumber",
            "shipperCompany", "shippedBy", "shipperAddress", "shipperCity", "shipperCountryOrTerritory",
            "shipperPostal", "shipperState", "shipperContactPhone", "shipperName", "billToAccount");
    public static List<String> CustomerAllColumns = Arrays.asList("isWatched", "trackingNumber", "status",
            "dateDelivered", "packageDelayStatus", "packageRiskReason",
            "recipCompany", "recipContactName", "reference", "scheduledDeliveryDate",
            "scheduledDeliveryTimeBy", "shipperName", "shipperAccountNumber", "shipperCompany", "shippedBy",
            "shipperAddress", "shipperCity", "shipperCountryOrTerritory", "shipperPostal", "shipperState",
            "shipperContactPhone", "appointmentDelivery", "billOfLading", "codRemittanceNumber",
            "commodityInformation", "dateAttemptedDelivery", "departmentNumber", "destPieceCount",
            "deliveryTime", "dimensionalWtKg", "dimensionalWtLb", "documentAvailable", "fedExCompany",
            "invoiceNumber", "lastKnownLocation", "masterTrackingNumber", "noOfPackages", "origPieceCount",
            "packageDimsCm", "packageDimsIn", "packageType", "partnerCarrierNbr",
            "pkgWtKg", "pkgWtLbs", "purchaseOrderNumber", "relationship", "returnAuthorizationName",
            "returnReason", "returnToShipperTrkNo", "serviceType", "shipDate", "signatureAvailable",
            "specialHandling", "standardTransitDate", "standardTransitTimeBy", "tendered",
            "totalNumberOfHandlingUnits", "totalWtKg", "totalWtLbs", "deliveredTo", "receivedBy",
            "recipAddressQty", "recipAddress", "recipCity", "recipCountryOrTerritory", "recipPostal",
            "recipState", "recipientContactNumberOrEmail", "shippedTo", "addressCorrection",
            "clearancereleasereceived", "dimension", "doortagnumbers", "proofOfDeliverySignature", "rma",
            "shipperReference", "billToAccount", "reference", "personalNotesMessage");
    public static String Contactus = "mailto:%s?subject=%s(TrackingID:%s)";
    public static Map<String, String> ExceptionalFilterBubble = new HashMap<String, String>() {
        {
            put("Not Weather Impacted", "Not Impacted");
            put("Weather Impacted", "Impacted");
            put("Select All", "ALL");
        }
    };
    public static List<String> QuickViewCardNames = Arrays.asList("SenseAware ID", "Shipper Country/ Territory",
            "FedEx Destination Location", "FedEx Origin Location", "Recipient Country/ Territory",
            "CER Status", "Recipient State/Province", "Shipper State/Province",
            "Last Known State/Province", "Case Number", "NAK Scan", "RMA", "Returning to Shipper",
            "Personal Note", "POD Exception", "Exception Reason", "Support Update",
            "Proof of Delivery Picture", "SenseAware Mobile", "SenseAware ID Status", "FedEx 1Day Freight", "Case Count",
            "Bill To (Transportation)", "Workgroup");
    public static String CustomerReturnTrckLabel = "Return Tracking Number  ";
    public static String MapRefreshText = "Map will refresh in";
    public static String signatureDoneBy = "Signed for by: Signature on File";
    public static String UpdatedTimeMap = "Updated";
    public static List<String> ActiveStatuses = Arrays.asList("Label created", "We have your package", "On the way",
            "Out for delivery", "Shipment Exception",
            "Delivery Exception", "Delay",
            "US Export Approved", "Clearance in Progress", "Clearance Delay",
            "International Shipment Release");

    public static List<String> ActiveStatusesDomestic = Arrays.asList("Label created", "We have your package",
            "On the way",
            "Out for delivery", "Shipment Exception",
            "Delivery Exception", "Delay");
    public static List<String> SubMenuModules = Arrays.asList("Advisories", "Preferences", "CE Preferences",
            "Dashboard", "Sustainability");
    public static String ImageRoleName = "fedexsurround_test_ceadmin_access_app3536507";
    public static String IRDisplayName = "Test - Customer Experience Workload Management";
    public static String Nav_Advisories = "Advisories";
    public static String Nav_Sustainability = "Sustainability";
    public static String Nav_Dashboard = "Dashboard";
    public static String Nav_Preferences = "Preferences";
    public static String Nav_CE_Preferences = "CE Preferences";
    public static String Nav_SubMenu_Sustainability = "Metrics";

    public static String Nav_SubMenu_Shipments = "Shipments";
    public static String Nav_SubMenu_Settings = "Settings";
    public static String Nav_SubMenu_ActiveShipments = "Active Shipments";
    public static String WhatsNew_Title = "FedEx Surround Has Been Updated";
    public static String WhatsNew_Sub_Title = "There have been improvements made to FedEx Surround, to view these updates and learn follow the link below";
    public static String WhatsNew_View_Button = "VIEW WHATS NEW";
    public static String WhatsNew_Close_Button = "CLOSE";
    public static List<String> QuickViewCardXpaths = Arrays.asList("Out For Delivery", "On the way", "At Risk",
            "All Exceptions", "Delivery Exceptions", "SenseAware ID", "Intervened");
    public static List<String> DigitalQuickViewCardXpaths = Arrays.asList("Out For Delivery", "On the way",
            "At Risk", "All Exceptions", "Delivery Exceptions", "SenseAware ID", "Select");
    public static List<String> HybridlQuickViewCardXpaths = Arrays.asList("Out For Delivery", "On the way",
            "At Risk", "All Exceptions", "Delivery Exceptions", "SenseAware ID", "Intervened",
            "Select", "Shipment Exceptions", "Delay", "Customs Clearance", "IPD Shipments", "Clearance Delay",
            "Early",
            "Near commit", "No commit", "Past commit");
    public static List<String> StaticContentinManageCards = Arrays.asList("Manage Quick View Cards",
            "Choose up to 8 cards to appear at the top of your shipment list.",
            "Values shown in these cards represent the shipments that are actively moving in the FedEx network and match the card criteria.",
            "Change Quick View Card Layout",
            "You can have up to 8 cards in your dashboard. Rearrange your cards by dragging and dropping them below.");
    public static List<String> cerTypes = Arrays.asList("Delivery Issue", "Customer Support",
            "Disputes Delivery", "Package received in error", "Shipment not delivered", "Missing contents",
            "Shipment Not Delivered", "Package Received in Error", "Missing Contents");
    public static QuickViewCardsPreference[] allQuickViewCardsSet1 = { new QuickViewCardsPreference() {
        {
            setStatus("delay");
            setText("Delay");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("intervened");
            setText("Intervened");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digital");
            setText("Select");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("senseAwareId");
            setText("SenseAware ID");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("atRisk");
            setText("At Risk");
            setSeqNo(8);
        }
    } };
    public static QuickViewCardsPreference[] allQuickViewCardsSet2 = { new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("atRisk");
            setText("At Risk");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("noCommit");
            setText("No commit");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("senseAwareId");
            setText("SenseAware ID");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("outForDelivery");
            setText("Out For Delivery");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("shipmentExceptions");
            setText("Shipment Exceptions");
            setSeqNo(8);
        }
    } };
    public static QuickViewCardsPreference[] allQuickViewCardsSet3 = { new QuickViewCardsPreference() {
        {
            setStatus("delay");
            setText("Delay");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("outForDelivery");
            setText("Out For Delivery");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digital");
            setText("Select");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("senseAwareId");
            setText("SenseAware ID");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("atRisk");
            setText("At Risk");
            setSeqNo(8);
        }
    } };
    public static QuickViewCardsPreference[] allQuickViewCardsSet4 = { new QuickViewCardsPreference() {
        {
            setStatus("noCommit");
            setText("No commit");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digitalTestview");
            setText("Digital Testview");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digital");
            setText("Select");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("customsClearance");
            setText("Customs Clearance");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("ipdShipments");
            setText("IPD Shipments");
            setSeqNo(8);
        }
    } };

    public static QuickViewCardsPreference[] allQuickViewCardsSet5 = { new QuickViewCardsPreference() {
        {
            setStatus("intervened  ");
            setText("Intervened");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("nearCommit");
            setText("Near commit");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("noCommit");
            setText("No commi");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("customsClearance");
            setText("Customs Clearance");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("early");
            setText("Early");
            setSeqNo(8);
        }
    } };

    public static QuickViewCardsPreference[] allQuickViewCardsSet6 = { new QuickViewCardsPreference() {
        {
            setStatus("preCommit");
            setText("Past commit");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("intervened");
            setText("Intervened");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digital");
            setText("Select");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("outForDelivery");
            setText("Out For Delivery");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("senseAwareId");
            setText("SenseAware ID");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("atRisk");
            setText("At Risk");
            setSeqNo(8);
        }
    } };
    public static QuickViewCardsPreference[] allQuickViewCardsSet7 = { new QuickViewCardsPreference() {
        {
            setStatus("noCommit");
            setText("No commit");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("clearanceDelay");
            setText("Clearance Delay");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");
            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("priorityAlert");
            setText("Priority Alert");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("customsClearance");
            setText("Customs Clearance");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("ipdShipments");
            setText("IPD Shipments");
            setSeqNo(8);
        }
    } };

    public static QuickViewCardsPreference[] allQuickViewCardsSet8 = { new QuickViewCardsPreference() {
        {
            setStatus("shipmentExceptions");
            setText("Shipment Exceptions");
            setSeqNo(1);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("atRisk");
            setText("At Risk");
            setSeqNo(2);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("onTheWay");
            setText("On the way");

            setSeqNo(3);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("allExceptions");
            setText("All Exceptions");
            setSeqNo(4);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("outForDelivery");
            setText("Out For Delivery");
            setSeqNo(5);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("digital");
            setText("Select");
            setSeqNo(6);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("intervened");
            setText("Intervened");
            setSeqNo(7);
        }
    }, new QuickViewCardsPreference() {
        {
            setStatus("deliveryExceptions");
            setText("Delivery Exception");
            setSeqNo(8);
        }
    } };

    public static String FilterFromAdvisoryPage = "filterFromAdvisoryPage";
    public static String FilterFromShipmentPage = "filterFromShipmentPage";
    public static String HoverStateAttribute = "focus-visible ag-header-active";
    public static String DelayedIconColor = "icon_red";
    public static String EarlyIconColor = "icon_purple";
    public static String PastCommitIconColor = "Icon_Past_Commit";
    public static String MonitoredIconColor = "monitored_icon_purple";
    public static String AllExceptionsIconColor = "Exeception_icon_red";
    public static String IpdShipmentsIconColor = "ipd_icon_purple";
    public static String ClearanceDelayIconColor = "Exeception_icon_red_new";
    public static String CustomsClearanceIconColor = "customs_icon_purple";
    public static String SearchPlaceHolder = "Search   e.g. New York or Ontario";
    public static String SearchStatePlaceHolder = "Search   e.g. NY or CA";
    public static String SearchCountryPlaceHolder = "Search   e.g. US or CA";
    public static List<String> CerNumber = Arrays.asList("Yes", "No", "Specific Case Number");
    public static String SearchContainerIdDefaultText = "Search e.g. 123";
    public static String SearchLastKnownRampDefaultText = "Search e.g. 123";
    public static String SearchLastKnownFedExFacilityDefaultText = "Search e.g. ABC";
    public static String SpecialHandling = "Special Handling";
    public static String SearchSpecialHandlingPlaceHolder = "Search";
    public static String ShipmentCommentDelayInTransit = "Delayed in transit. Staged to move on next available flight. Will provide further updates";
    public static String ShipmentCommentExpectDeliveryToday = "Expect delivery today by end of day";
    public static String ShipmentCommentExpectDeliveryNext = "Expect next business day delivery";
    public static String ShipmentCommentInterventionExpectDeliveryToday = "Intervention request submitted. Expect delivery today by end of day";
    public static String ShipmentCommentInterventionExpectNextBusiness = "Intervention request submitted. Expect next business day delivery";
    public static String ShipmentCommentMonitoringForUpdates = "Monitoring for updates";
    public static String ShipmentCommentNationalServiceDisruption = "National service disruption. Will provide updates as available.";
    public static String ShipmentCommentRequestReattempt = "Requested Reattempt";
    public static String ShipmentCommentServiceUpgradeRequested = "Service upgrade requested";
    public static String SuggestTextThreeLetterShipperReference = "Please provide the first 3 characters of Shipment Information";
    public static String SearchShipperReferencePlaceHolder = "Search";
    public static String SenseawareLinkUrl = "https://iot-edge-mobile.app.paas.fedex.com/app-said-search-associated-shipment?associatedShipment=%s";
    public static String SenseawareJourneyIdLinkUrl = "https://sa.test.senseaware.com/web/wsawui/#!details/journey/%s";
    public static String SenseawareJourneyIdLinkUrlWithoutJourneyId = "https://sa.test.senseaware.com/web/wsawui/#!details/journey/";
    public static String SenseawareURL = "https://sa.test.senseaware.com/web/wsawui/index.html#!login/index";
    public static String CERLink = "https://cebs.prod.fedex.com/prweb/PRAuth/PurpleID?pyActivity=Data-Portal.EBSShowDesktop&caseID=";
    public static String CaseEbsHeader = "Sign in with your account to access Case EBS-SP";
    public static String fileUploadErrorMsg = "Your upload has failed. Please upload a valid CSV file.";
    public static String fileUploadPopupHeader = "Upload Failed";
    public static String groupsHederMsg = "Manage your work groups by selecting a group name first. You can add companies and accounts to that group from the right-hand side.";
    public static String searchAccountInfo = "564378435 Purple dot indicates that the account is currently in one or more groups";
    public static String purpleColor = "#4d148c";
    public static String redColor = "#de002e";
    public static String randomWorkGroup = "all companies workgroup";
    public static String randomWgCompany = "AbbVie, Inc.";
    public static String editWorkGroupSubTitle = "Please provide a unique name for your work group";
    public static String removeWorkGroupMsg = "You are about to remove all Companies and Accounts from “%s”, are you sure?";
    public static String deleteWorkGroup = "You are about to delete “%s”, are you sure?";
    public static String sensorMobileJourney = "SenseAware Mobile Journey ID %s";
    public static String preferredLocationNotSet = "You currently don't have a preferred location set Please set your location preference at "
            + "nonprod"+ ".origin.surround.fedex.com/preferences/preferredlocations";
    public static String helpTextUploadHistory = "Table above shows the bulk uploads completed in last 14 days";
    public static String userRefLink = "https://hr-directory.prod.fedex.com/PeopleDirectory?Search=";

    public static List<String> NotToBeLocalised = Arrays.asList("SenseAware ID","Types SenseAware ID","FedEx(MD) Surround");
    public static String emailBody="You have been signed up to receive email notifications through FedEx Surround.";
    public static String emailMessage="A new shipment report, %s, from Surround is available for your review.";


    public static Map<String, String> caseChangedLocalised = new HashMap<String, String>() {
        {
            put("TYPES D’ENVOI", "Type d'envoi");

        }
    };



}
