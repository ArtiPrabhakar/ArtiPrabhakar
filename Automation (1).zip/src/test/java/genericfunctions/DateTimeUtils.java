package genericfunctions;


import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

@Slf4j
public class DateTimeUtils {

    GenericFunction genericFunction = new GenericFunction();;

    public String isDate(String date, String ipDateFormat, String opDateFormat) {

        if (ipDateFormat.contains("DD") || ipDateFormat.contains("YYYY")) {
            ipDateFormat = ipDateFormat.replace("DD", "dd");
            ipDateFormat = ipDateFormat.replace("YYYY", "yyyy");
        }

        if (opDateFormat.contains("DD") || opDateFormat.contains("YYYY")) {
            opDateFormat = opDateFormat.replace("DD", "dd");
            opDateFormat = opDateFormat.replace("YYYY", "yyyy");
        }

        SimpleDateFormat outputFormat = new SimpleDateFormat(opDateFormat);
        SimpleDateFormat inputFormat = new SimpleDateFormat(ipDateFormat);

        String outputText = null;
        try {
            Date date12 = inputFormat.parse(date);
            outputText = outputFormat.format(date12);
        } catch (Exception e) {
            log.error("**EXCEPTION** in isDate() validation");
            e.printStackTrace();
        }
        return outputText;
    }

    /**
     * This function is for removing 0 in Month or date-
     *
     * @param dateFormat- date Format
     * @param date-       date u want to remove zer for month or date
     * @param pos-        used if the date contains day //Monday, Tuesday, Send it
     *                    as zero if there is no day in date
     * @return expected pattern
     */
    public String RemoveZeroInDate(String dateFormat, String date, int pos, String selector) {
        int position = 0;
        String newDate;
        if (selector.equalsIgnoreCase("M")) {
            position = pos + dateFormat.split("M")[0].length();
        } else if (selector.equalsIgnoreCase("D")) {
            position = pos + dateFormat.split("D")[0].length();
        }
        // monthCount = monthCount + scanEventApi.get("date").split(" ")[0].length() +
        // 1;
        if (date.charAt(position) == '0') {
            StringBuilder sb = new StringBuilder(date);
            newDate = sb.deleteCharAt(position).toString();
        } else {
            newDate = date;
        }
        return newDate;
    }

    public String changeDateFormat(String dateInp, String inputFormat, String outputFormaString,
                                   String replaceZeroInDate) {
        String outputText;
        outputText = this.isDate(dateInp, inputFormat, outputFormaString);
        if (replaceZeroInDate.contains("M")) {
            outputText = this.RemoveZeroInDate(outputFormaString, outputText, 0, "M");
        }
        if (replaceZeroInDate.contains("D")) {
            outputText = this.RemoveZeroInDate(outputFormaString, outputText, 0, "D");
        }
        return outputText;
    }

    public Date stringToDate(String date, String format) {
        try {
            Date date1 = new SimpleDateFormat(format).parse(date);
            return date1;
        } catch (Exception e) {
            return null;
        }
    }

    public void setTimeZone(String zone) {
        String idName = "";
        String locn = "";
        switch (zone) {
            case "GMT":
                idName = "GMT Standard Time";
                locn = "Europe/London";
                break;
            case "PST":
                idName = "Pacific Standard Time";
                locn = "America/Los_Angeles";
                break;
            case "CST":
                idName = "Central Standard Time";
                locn = "America/Chicago";
                break;
            case "EST":
                idName = "Eastern Standard Time";
                locn = "America/New_York";
                break;
            default:
                idName = "India Standard Time";
                locn = "Asia/Calcutta";
                break;
        }
        String command = "\"tzutil /s " + "\"" + idName + "\"" + "\"";
        if (GenericFunction.OS.contains("window")) {
            this.genericFunction.runCommand(command);
        } else {
            command = "timedatectl set-timezone " + idName;
            this.genericFunction.runCommand(command);
        }
        System.setProperty("user.timezone", locn);
        TimeZone.setDefault(null);
        log.info("Current Time Zone:" + TimeZone.getDefault());
    }
    /**
     * This function is for converting Date to a specific pattern -
     *
     * @param pattern- required pattern
     * @param day      is optional paramter
     * @return expected pattern
     */
    public String setDateFormat(String date, String pattern, boolean... day) {
        if (pattern.contains("DD") || pattern.contains("YYYY")) {
            pattern = pattern.replace("DD", "dd");
            pattern = pattern.replace("YYYY", "yyyy");

        }
        if (day.length > 0 && day[0]) {
            pattern = "EEEE, " + pattern;
        }
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        String newDate = null;
        try {
            newDate = formatter.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newDate;
    }



}
