package genericfunctions;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVWriter;
import common.DriverManager;
import common.JSONHelpers;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.assertj.core.api.Assertions;
import org.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import stepDefinitions.Hooks;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class GenericFunction {

    public static String ENV_SETUP_CONFIG_FILE = "envsetup.properties";
    public static String CONFIG_FILE = "";
    public static String APICONFIG_FILE = "";
    public static String RESOURCEMAPPER_FILE = "masterResourcesMapper.properties";
    public static String JSON_FILE = "";
    public static String JSON_META_FILE = "";
    public static String JSON_META_FILE_NAME = "userMetadata";
    public static JsonPath jsonPath;
    // Trying to read from pipeline config file
    public static String locale = System.getProperty("LOCALE");
    public static String language = "";
    public static String country = "";
    public static Properties prop = new Properties();
    public static String OS = System.getProperty("os.name");
    public static String home = System.getProperty("user.home");
    public static String userName = System.getProperty("user.name");
    public static String userTimeZonePlace = System.getProperty("user.timezone");
    public static String userTimeZone = "";
    public static String userDir = System.getProperty("user.dir");
    public static String ENV = System.getProperty("ENV");
    public static String PORTAL = "";
    public static String ENV_LOCALIZATION = System.getProperty("ENV_LOCALIZATION");
    public static Properties prop1 = new Properties();
    public static Properties prop2 = new Properties();
    public static Properties resourceMapperProp = new Properties();
    public static Boolean ElementHighlighter;
    public static int TIMEOUT;
    public static Object jsonDocumentMeta;
    public static Object jsonDocumentTranslation;
    public static String slashBasedOnOs;
    public static boolean virtualizationFlag;
    public static String TESTCASE_STATUS = "";

    static {
        // to handle localisation different characters
        System.setProperty("file.encoding", "UTF-8");

        if (OS.toLowerCase().contains("window")) {
            slashBasedOnOs = "\\";
        } else {
            slashBasedOnOs = "/";
        }

        ENV_SETUP_CONFIG_FILE = userDir + slashBasedOnOs + "config" + slashBasedOnOs + ENV_SETUP_CONFIG_FILE;

        // Property File Name updated as per Environment File //
        try {
            prop.load(new FileInputStream(ENV_SETUP_CONFIG_FILE));
            CONFIG_FILE = prop.getProperty("configfilename");
            APICONFIG_FILE = prop.getProperty("apiconfigfilename");
        } catch (Exception e) {
            log.error("Exception in reading config File " + e);
        }

        CONFIG_FILE = userDir + slashBasedOnOs + "config" + slashBasedOnOs + CONFIG_FILE;
        APICONFIG_FILE = userDir + slashBasedOnOs + "config" + slashBasedOnOs + APICONFIG_FILE;
        RESOURCEMAPPER_FILE = userDir + slashBasedOnOs + "config" + slashBasedOnOs + RESOURCEMAPPER_FILE;

        try {
            prop1.load(new FileInputStream(CONFIG_FILE));
            prop2.load(new FileInputStream(APICONFIG_FILE));
            resourceMapperProp.load(new FileInputStream(RESOURCEMAPPER_FILE));
            if (ENV == null) {
                ENV = prop1.getProperty("ENV");
            }
            // When you are running in pipeline then localised env = env value passed
            else {
                ENV_LOCALIZATION = ENV;
            }
            // for local running, we can pick from property file
            if (ENV_LOCALIZATION == null) {
                ENV_LOCALIZATION = prop1.getProperty("ENV_LOCALIZATION");
            }

            // Picking the Json language as per locale mentioned in Config File
            if(locale == null) {
                locale = prop1.getProperty("LANG");
                language = locale.split("-")[0];
                country = locale.split("-")[1].toUpperCase();
            }
            else
            {
                language = System.getProperty("LOCALE").split("-")[0];
                country = System.getProperty("LOCALE").split("-")[1];
            }

            JSON_FILE = userDir + slashBasedOnOs + "src" + slashBasedOnOs + "test" + slashBasedOnOs + "resources"
                    + slashBasedOnOs + "translation" + slashBasedOnOs + locale + "-template.json";
            JSON_META_FILE = userDir + slashBasedOnOs + "src" + slashBasedOnOs + "test" + slashBasedOnOs + "resources"
                    + slashBasedOnOs + "translation" + slashBasedOnOs + JSON_META_FILE_NAME + ".json";

            ElementHighlighter = Boolean.valueOf(prop1.getProperty("ElementHighlighter"));
            TIMEOUT = Integer.parseInt(prop1.getProperty("TIMEOUT"));
            LoadResourceJson();
        } catch (Exception e) {

            Assertions.fail(
                    "**EXCEPTION** Error while reading propertyfile from Config/APICONFIG/OBJECTREPO File With exception: "
                            + e);
        }

        String pattern = "z"; // HH is 24 hours format
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale(language, country));
        userTimeZone = simpleDateFormat.format(new Date());

        String virtualization = System.getProperty("VIRTUALIZATION");
        virtualizationFlag = virtualization == null
                ? Boolean.parseBoolean(GenericFunction.ReadConfigFile("VIRTUALIZATION"))
                : Boolean.parseBoolean(virtualization);
        log.info("** VIRTUALIZATION flag is passed as " + virtualizationFlag);

    }

    public String fileName = null;

    /**
     * Read Specific Key from Mentioned ConfigFile
     *
     * @param Key Key whose value we need
     * @return Value
     * @author SHIVAM
     */

    public static String ReadConfigFile(String Key) {
        String Value = "";
        try {
            Value = prop1.getProperty(Key);
            if (Value == null || Value.length() == 0)
                Value = prop2.getProperty(Key);
            if (Value == null)
                log.error("Getting null value for this Key Please Check the key : " + Key);
        } catch (Exception e) {
            log.error(
                    " **EXCEPTION** Error while reading key --> " + Key
                            + " <-- from property file Config/APICONFIG/OBJECTREPO File With exception: " + e);
        }
        return Value;
    }

    public static void LoadResourceJson() {

        try {
            // JSONParser parser = new JSONParser();
            log.info("File Path for language translation - " + JSON_FILE);
            log.info("File Path for meta translation - " + JSON_META_FILE);

            // Object obj = parser.parse(new FileReader(JSON_FILE));
            // jsonObject = (JSONObject) obj;
            // jsP = JsonPath.read(jsonObject.toString());
            String translationFile = new String(Files.readAllBytes(Paths.get(JSON_FILE)));
            String metaDataFile = new String(Files.readAllBytes(Paths.get(JSON_META_FILE)));

            jsonDocumentTranslation = Configuration.defaultConfiguration().jsonProvider().parse(translationFile);
            jsonDocumentMeta = Configuration.defaultConfiguration().jsonProvider().parse(metaDataFile);

        } catch (Exception e) {
            log.error("**EXCEPTION** Loading locale specific json file failed due to " + e);
        }

    }

    public List<String> getLocalizedValue(List<String> list) {
        ArrayList<String> localisedList = new ArrayList<>();
        for (String s : list) {
            localisedList.add(getLocalizedValue(s));
        }
        return localisedList;
    }

    public String getLocalizedValue(String key) {
        if (!Hooks.customerTestCase) {
            return key;
        }
        String resxKey; // = specialKeyCheck(key);
        String value = null;
        log.info("Converting --> " + key + " <----Value to localized Value");
        // if (resxKey == null)
        if(Constants.NotToBeLocalised.contains(key))
        {
            log.info("The Key will not be localised as its a brand name or a special key");
            return key;
        }

        resxKey = resourceMapperProp.getProperty(key);

        // else
        // return resxKey;
        log.info("Mapped Key Resource is --> " + resxKey);
        try {
            if (resxKey.contains("locale")) {
                resxKey = String.format(resxKey, locale);
                value = JsonPath.read(jsonDocumentMeta, resxKey).toString();
                value = value.replace("[\"", "");
                value = value.replace("\"]", "");
            } else {

                value = JsonPath.read(jsonDocumentTranslation, resxKey);
            }

            log.info("Localized Value from mapped resource is --> " + value);
            log.info("______________________________________");

        } catch (Exception e) {
            log.error("**EXCEPTION** Failed while reading the value " + resxKey + " with exception as " + e);
            Assertions.fail("Not able to read the value from any of the translations json file ");

        }
        return value;
    }

    public String specialKeyCheck(String key) {
        String value;
        switch (key) {
            case "FedEx® Surround": {
                value = key;
                break;
            }
            default:
                value = null;
                break;
        }
        return value;
    }

    public String[] getFilesFromLocation(String filename, String... directory) throws IOException {
        String downloadPath = null;

        try {
            if (directory != null && directory.length > 0) {
                downloadPath = directory[0];
            } else {
                downloadPath = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;
            }
            log.info("Download path: ---> " + downloadPath);
        } catch (Exception e) {
            log.error("**EXCEPTION** Download path:" + downloadPath + "\n" + e);
        }
        File dir = new File(downloadPath);
        log.info("Directory is " + dir);
        String[] dir_contents;
        String[] files;
        if (GenericFunction.OS.toLowerCase().contains("window")) {
            dir_contents = dir.list();
            log.info("Directory has these files " + Arrays.stream(dir_contents).toArray().toString());
            return dir_contents;
        } else {
            log.info("Trying to list files in the directory");
            files = dir.list();
            return files;
        }
    }

    // public void deleteFilefrom(String filename) throws IOException {
    // String[] dir_contents = getFilesFromLocation(filename);
    // String downloadPath = home + slashBasedOnOs + Constants.downloadFolder +
    // slashBasedOnOs;
    // if(OS.toLowerCase().contains("window")) {
    // for (int i = 0; i < dir_contents.length; i++) {
    // if (dir_contents[i].contains(filename))
    // Files.delete(Paths.get(downloadPath + dir_contents[i]));
    // }
    // }
    // }

    public void deleteFilefrom(String filename) throws IOException {
        String downloadPath = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;
        if (OS.toLowerCase().contains("window")) {
            String[] dir_contents = getFilesFromLocation(filename);
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains(filename)) {
                    Files.delete(Paths.get(downloadPath + dir_contents[i]));
                    log.info("Succesfully deleted file " + dir_contents[i]);
                }
            }
        } else {
            String deleteFileCommand = "find " + downloadPath + " -type f -name \"*" + filename + "*\" -exec rm {} \\;";
            runCommand(deleteFileCommand);
        }
    }

    public boolean isFileDownloaded() throws IOException {
        boolean flag = false;
        String fileName = Constants.fileNameForShipment;
        String[] dir_contents = getFilesFromLocation(fileName);
        if (dir_contents == null || dir_contents.length == 0) {
            flag = false;
        }
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].contains(fileName)) {
                flag = true;
                this.fileName = dir_contents[i];
                break;
            }
        }
        return flag;
    }

    public List<String> readCSVHeader() throws IOException {
        Reader reader = null;

        List<String> header = new ArrayList<String>();
        // read the file
        String folder;
        String fileName = this.fileName;

        if (fileName == null) {
            fileName = Constants.fileNameForShipment;
        }
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        String[] dir_contents = getFilesFromLocation(fileName);
        try {

            for (int i = 0; i < dir_contents.length; i++)
            {
                if(dir_contents[i].contains("csv")) {

                    if (dir_contents[i].contains(fileName)) {

                        fileName = dir_contents[i];
                        reader = Files.newBufferedReader(Paths.get(folder, fileName));
                        log.info("CSV Extension"+fileName);
                        break;


                    }

                }
            }
            CSVParser csvParser = new CSVParser(reader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withAllowMissingColumnNames());
            for (String headerName : csvParser.getHeaderMap().keySet()) {
                if (headerName != null || !headerName.isEmpty())
                    header.add(headerName.toUpperCase());
            }
            csvParser.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return header;
    }

    public Map<String, String> readCSVRecord(String coulmnName, String columnValue, ArrayList<String> header)
            throws IOException {
        Reader reader = null;
        List<CSVRecord> records;
        Map<String, String> actualRecord = new HashMap<>();
        // read the file
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder;

        String fileName = this.fileName;
        String[] dir_contents = getFilesFromLocation(fileName);
        try {
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains(fileName)) {
                    reader = Files.newBufferedReader(Paths.get(folder, dir_contents[i]));
                    break;
                }
            }
            CSVParser csvParser = new CSVParser(reader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withAllowMissingColumnNames());
            records = csvParser.getRecords();
            for (CSVRecord csvRecord : records) {
                if (csvRecord.get(coulmnName).equals(columnValue)) {
                    for (String headerCol : header) {
                        actualRecord.put(headerCol, csvRecord.get(headerCol));
                    }
                    break;
                }
            }
            csvParser.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return actualRecord;
    }

    /**
     * This function is for converting Column Name as per the alignment - for ex -
     * SHIPPER POSTAL -> Shipper Postal
     *
     * @param str
     * @return
     */
    public String convert(String str) {
        if (str.equalsIgnoreCase("FEDEX COMPANY")) {
            return "FedEx Company";
        } else {
            String[] words = str.split(" ");
            String capitalizeWord = "";
            for (String w : words) {
                String afterfirst = "";
                if (w.contains("/")) {
                    String beforeChar = w.split("/")[0];
                    beforeChar = beforeChar.charAt(0) + beforeChar.substring(1).toLowerCase();
                    String afterChar = w.split("/")[1];
                    afterChar = afterChar.charAt(0) + afterChar.substring(1).toLowerCase();
                    afterfirst = beforeChar + "/" + afterChar;
                } else {
                    afterfirst = Character.toUpperCase(w.charAt(0)) + w.substring(1).toLowerCase();
                }
                capitalizeWord = capitalizeWord + afterfirst + " ";
            }
            return capitalizeWord.trim();
        }
    }

    /**
     * This function is for getting column data from csv and maspping it with
     * Tracking number
     *
     * @param columnName- required column name
     */
    public Map<String, String> getColumnDataFromFile(String columnName) throws IOException {
        Reader reader = null;
        String columnData;
        String trackingNumber;
        List<CSVRecord> records;
        Map<String, String> actualRecord = new HashMap<>();
        // read the file
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        String fileName = Constants.fileNameForShipment;
        String[] dir_contents = getFilesFromLocation(fileName);
        try {
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains(fileName)) {
                   // reader = Files.newBufferedReader(Paths.get(folder, dir_contents[i]), StandardCharsets.UTF_8);
                     reader = new BufferedReader(new InputStreamReader(new
                     FileInputStream(folder+dir_contents[i]),StandardCharsets.UTF_8));

                    break;
                }
            }
            CSVParser csvParser = new CSVParser(reader,
                    CSVFormat.DEFAULT.withFirstRecordAsHeader().withAllowMissingColumnNames());

            // CSVFormat.DEFAULT.withFirstRecordAsHeader().withAllowMissingColumnNames());
            records = csvParser.getRecords();
            for (CSVRecord csvRecord : records) {

                if(columnName.equalsIgnoreCase("Tracking Number")){
                    columnData = csvRecord.get(0);
                }else {
                    columnData = csvRecord.get(columnName);
                }
                // Map the data with Tracking number
                trackingNumber = csvRecord.get(0);
                actualRecord.put(trackingNumber, columnData);
            }
            csvParser.close();
        } catch (IOException e) {
            log.error("**EXCEPTION** Problem while reading the csv");
            e.printStackTrace();
        }
        return actualRecord;
    }

    public String getValueFromExcel(String sheetName, int rowNum, int column) {
        log.info("SheetName is " + sheetName);
        log.info("Rownum is    " + rowNum);
        log.info("column is    " + column);
        FileInputStream fs = null;
        XSSFWorkbook wb;
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        String fileName = Constants.fileNameForShipment;
        log.info("We will read the file " + folder + fileName);
        String value = null;
        try {
            log.info("Trying to get the files from location");
            String[] dir_contents = getFilesFromLocation(fileName);
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains(fileName)) {
                    log.info("File is found in the directory " + dir_contents[i]);
                    fileName = dir_contents[i];
                    break;
                }
            }
            log.info("Trying to read the excel file - " + fileName);
            fs = new FileInputStream(new File(folder + fileName));
            wb = new XSSFWorkbook(fs);
            XSSFSheet sheet = wb.getSheet(sheetName);
            Row row = sheet.getRow(rowNum);
            Cell cell = row.getCell(column);
            value = cell.getStringCellValue();
            log.info("Value read from the " + rowNum + "  is equal to " + value);
        } catch (Exception e1) {
            log.error("**EXCEPTION** while reading excel");
            e1.printStackTrace();
        }
        try {
            log.info("Closing the file now ");
            fs.close();
        } catch (IOException e) {
            log.error("**EXCEPTION** while closing excel file");
            e.printStackTrace();
        }
        return value;

    }

    public int getRecordsCountInDownLoadedFile(String fileType) throws IOException {
        Map<String, String> fileData = this.getColumnDataFromFile("Tracking Number");
        return fileData.size();
    }

    public Map<String, String> getValuesFromExcel(String sheetName, int column) {
        FileInputStream fs = null;
        XSSFWorkbook wb;
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        String fileName = Constants.fileNameForShipment;
        String value = null;
        Map<String, String> data = new HashMap<>();
        try {
            String[] dir_contents = getFilesFromLocation(fileName);
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains(fileName)) {
                    fileName = dir_contents[i];
                    break;
                }
            }
            fs = new FileInputStream(new File(folder + fileName));
            wb = new XSSFWorkbook(fs);
            XSSFSheet sheet = wb.getSheet(sheetName);
            int totalRows = sheet.getLastRowNum();

            for (int i = 0; i <= totalRows; i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    Cell keyCell = row.getCell(0);
                    String key = keyCell.getStringCellValue();
                    Cell cell = row.getCell(column - 1);
                    if (cell != null) {
                        value = cell.getStringCellValue();
                    } else {
                        value = null;
                    }
                    data.put(key, value);
                }
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        try {
            fs.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public List<String> getColumnsList(String sheetName) {
        FileInputStream fs;
        XSSFWorkbook wb;
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;


        String fileName = Constants.fileNameForShipment;
        List<String> columnList = new ArrayList<>();
        try {
            String[] dir_contents = getFilesFromLocation(fileName);
            for (int i = 0; i < dir_contents.length; i++) {
                if (dir_contents[i].contains("xlsx")) {
                    if (dir_contents[i].contains(fileName)) {
                        fileName = dir_contents[i];
                        log.info("Excel Extension" + fileName);
                        break;
                    }
                }
            }

            fs = new FileInputStream(new File(folder + fileName));


            wb = new XSSFWorkbook(fs);
            XSSFSheet sheet = wb.getSheet(sheetName);
            Row row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                columnList.add(row.getCell(i).getStringCellValue().toUpperCase());
            }
            try {
                fs.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e1) {
            log.info("Excel Extension" + fileName);
            e1.printStackTrace();
        }

        return columnList;
    }

    public static Path getLatestFile() {
        try {

            String fileName = Constants.fileNameForShipment;
            String folderPath = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;
            // Create a Path object representing the download folder
            Path folder = Paths.get(folderPath);
            // List all files in the folder and sort them by last modified time in descending order
            Path latestFile = Files.list(folder)
                    .filter(Files::isRegularFile)
                    .max(Comparator.comparingLong(f -> f.toFile().lastModified()))
                    .orElse(null);
            if (latestFile.toString().contains(fileName)) {
                return latestFile;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public Map<String, List<String>> getCompleteColumnData(String sheetName) {
        FileInputStream fs;
        XSSFWorkbook wb;
        String folder;
        folder = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;
        String fileName = Constants.fileNameForShipment;
        String value;
        List<String> columnList = new ArrayList<>();
        Map<String, List<String>> data = new HashMap<>();
        try {
            String[] dir_contents = getFilesFromLocation(fileName);
//            for (int i = 0; i < dir_contents.length; i++) {
//                if (dir_contents[i].contains(fileName)) {
//                    fileName = dir_contents[i];
//                    break;
//                }
//            }

            Path filename =this.getLatestFile();
            String filepath = filename.toString();
            fs = new FileInputStream(new File(filepath));
            wb = new XSSFWorkbook(fs);
            XSSFSheet sheet = wb.getSheet(sheetName);
            // Get all columns
            Row row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                columnList.add(row.getCell(i).getStringCellValue());
            }
            // Iterate over each row and column
            int totalRows = sheet.getLastRowNum();
            for (int j = 0; j < columnList.size(); j++) {
                String columnIdName = columnList.get(j);
                List<String> columnListValues = new ArrayList<>();
                for (int i = 0; i <= totalRows; i++) {
                    row = sheet.getRow(i);
                    if (row != null) {
                        Cell cell = row.getCell(j);
                        if (cell != null) {
                            value = cell.getStringCellValue();
                        } else {
                            value = null;
                        }
                        if (!value.equals(columnIdName)) {
                            columnListValues.add(value);
                        }

                    }
                }
                data.put(columnIdName, columnListValues);
            }
            try {
                fs.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        return data;
    }

    public void createCsvFile(String[] headers, String fileName) {
        String filePath = "";
        filePath = home + slashBasedOnOs + Constants.downloadFolder + slashBasedOnOs;

        File file = new File(filePath + fileName);
        try (FileWriter outputfile = new FileWriter(file)) {
            CSVWriter writer = new CSVWriter(outputfile);
            writer.writeNext(headers);
            writer.close();
        } catch (Exception e) {
            log.error("Exception while creating csv file");
        }

    }

    public void createCsvFileWithData(String[] headers, String[] data, String fileName) {
        String filePath = "";
        if (OS.toLowerCase().contains("window")) {
            filePath = home + "\\" + Constants.downloadFolder + "\\";
        } else {
            filePath = home + "/" + Constants.downloadFolder + "/";
        }
        File file = new File(filePath + fileName);
        try (FileWriter outputfile = new FileWriter(file)) {

            CSVWriter writer = new CSVWriter(new FileWriter(file), ',',
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);
            writer.writeNext(headers);
            if (data.length > 0) {
                for (String string : data) {
                    writer.writeNext(string.split(","));
                }
            } else {
                writer.writeNext(data);
            }

            log.info("CSV file is created at " + file.getPath());
            writer.close();
        } catch (Exception e) {
            log.error("Exception while creating csv file");
        }
    }

    public boolean isFileDownloaded(String fileName, boolean deleteFile) throws IOException {
        boolean flag = false;
        String[] dir_contents = getFilesFromLocation(fileName);
        if (dir_contents == null || dir_contents.length == 0) {
            flag = false;
        }
        for (int i = 0; i < dir_contents.length; i++) {
            if (dir_contents[i].contains(fileName)) {
                flag = true;
                this.fileName = dir_contents[i];
                if (deleteFile) {
                    this.deleteFilefrom(this.fileName);
                }
                break;
            }
        }

        return flag;
    }

    public void runCommand(String command) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder();
            if (OS.toLowerCase().contains("window")) {
                processBuilder.command("cmd.exe", "/c", command);
            } else {
                processBuilder.command("bash", "-c", command);
            }
            log.info("Command to Execute is:" + command);
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }

            int exitVal = process.waitFor();
            if (exitVal == 0) {
                log.info("Successfully Executed command");
                log.info(String.valueOf(output));
            } else {
                log.error(" ** EXCEPTION** Unable to execute command, exit code is " + exitVal);
            }
            reader.close();
        } catch (Exception e) {
            log.error("**EXCEPTION** Unable to execute command");
            e.printStackTrace();
        }
    }

    public static void retrieveToken(){
        try {
            JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
            String token = (String) js.executeScript(String.format("return window.sessionStorage.getItem('%s');", "okta-token-storage"));
            JSONObject listObj = JSONHelpers.StringtoJObject(token);
            JSONObject listObj1 = (JSONObject) listObj.get("accessToken");
//            log.info("Token:" + token);
//            log.info("listObj1:" + listObj1.get("accessToken"));
            System.setProperty("CETOKEN", listObj1.get("accessToken").toString());
        }catch(Exception e){
            log.info("**************** Failed to retrieve the Token with token : " + e.getMessage());
        }
    }

    public static boolean containsConsecutiveSpecialCharacters(String inputString) {
        String pattern = "[!@#$%^&*()_+\\-=\\[\\]{}\\\\|;:'\",.<>/?]{2,}";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(inputString);
        return matcher.find();
    }



}