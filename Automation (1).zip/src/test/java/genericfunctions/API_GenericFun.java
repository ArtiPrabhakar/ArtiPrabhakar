package genericfunctions;

import API.RequestModels.Login;
import API.ResponseModels.LoginCookieOutputVO;
import API.ResponseModels.VirtualizedResp;
import common.CommonHelpers;
import common.HttpClientFactory;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.json.simple.parser.JSONParser;
import pageObjects.SeleniumGenericFunction;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Slf4j

public class API_GenericFun extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    Response response = null;
    String RESOURCEPATH;
    String PROXYIP;
    String PORT;
    String PAYLOAD;
    int StatusCode;
    String ResponseDescription;
    String TOKENBASEPATH;
    HttpClientFactory httpClientFactory;

    public API_GenericFun(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.httpClientFactory = new HttpClientFactory();

    // Below two lines should be commented when VIRTUALIZATION is true
        this.commonHelpers.AddToContextStore("VIRTUALIZATION", GenericFunction.virtualizationFlag);

        if(!GenericFunction.PORTAL.equalsIgnoreCase("CE")) {
            this.GenerateBearerToken();
            this.SetCustomHeaders();

            // this.keyVaultHelpers.SetAppConfigKeys();
            this.SetTokenBasePath();
        }

    }

    public void GenerateBearerToken() {
        if (!this.commonHelpers.verifyKeyInContextStore("accessToken")) {
            this.SetResourceParam();
            this.SetTokenBasePath();

//            Boolean virtualizationFlag;
//            String virtualization = System.getProperty("VIRTUALIZATION");
//            virtualizationFlag = virtualization == null
//                    ? Boolean.parseBoolean(GenericFunction.ReadConfigFile("VIRTUALIZATION"))
//                    : Boolean.parseBoolean(virtualization);
//            log.info("** VIRTUALIZATION flag is passed as " + virtualizationFlag);
//            this.commonHelpers.AddToContextStore("VIRTUALIZATION", GenericFunction.virtualizationFlag);

            if (!GenericFunction.virtualizationFlag) {
                this.SetCustomFormParams();
                response = this.httpClientFactory.HTTPPOST(this.commonHelpers.FORMPARAM,
                        this.TOKENBASEPATH + this.RESOURCEPATH);
            } else {
                this.SetVirtualFormParams();
                response = this.httpClientFactory.HTTPPOST(this.commonHelpers.FORMPARAM,
                        GenericFunction.ReadConfigFile("VIRTUALISEDLOGINAPI") + this.RESOURCEPATH);
            }
            this.commonHelpers.AddToResponseCollection("Bearertoken", response);
            this.setAccessToken();
        }
    }

    public void SetCookies(String userId) {
        try {
            if (!this.commonHelpers.HEADERPARAM.containsValue(this.commonHelpers.HEADERPARAM.get("Cookie"))
                    && !userId.equalsIgnoreCase("CE")) {
                Login login = new Login();
                login.setUserName(this.commonHelpers.getValuefromContextStore(userId).toString());
                login.setPassword(this.commonHelpers.getValuefromContextStore("password").toString());
                // log.info("Login Post object: " +
                // this.commonHelpers.Marshall(login));
                response = this.httpClientFactory.HTTPPOST(this.commonHelpers.HEADERPARAM,
                        this.commonHelpers.Marshall(login), GenericFunction.ReadConfigFile("LOGINAPI")
                                + this.commonHelpers.endPointCollection.get("FedEx_Login"));
                this.commonHelpers.HEADERPARAM.put("Cookie", this.TransformCookie(response.cookies()));
                this.WhenIMakegetCall("MS_CSRFToken");
                response = this.commonHelpers.GetValueFromResponseCollection("MS_CSRFToken");
                this.commonHelpers.HEADERPARAM.put(Constants.XSRFHeader, response.cookies().get("XSRF-TOKEN"));
                this.UpdateCookie();
            } else if (!this.commonHelpers.HEADERPARAM.containsValue(this.commonHelpers.HEADERPARAM.get("Cookie"))
                    && userId.equalsIgnoreCase("CE")) {
                this.WhenIMakegetCall("CE_CSRFToken");
                response = this.commonHelpers.GetValueFromResponseCollection("CE_CSRFToken");
                this.commonHelpers.HEADERPARAM.put(Constants.XSRFHeader, response.cookies().get("XSRF-TOKEN"));
                this.commonHelpers.HEADERPARAM.put("Cookie", this.TransformCookie(response.cookies()));

            }
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in SetCookies method : " + e.getMessage());
        }

    }

    public void SetVirtualizedCookies(String userContext) throws Exception {
        Login login = new Login();
        login.setUserName(this.commonHelpers.getValuefromContextStore(userContext).toString());
        login.setPassword(this.commonHelpers.getValuefromContextStore("password").toString());
        // log.info("Login Post object: " +
        // this.commonHelpers.Marshall(login));
        response = this.httpClientFactory.HTTPPOST(this.commonHelpers.HEADERPARAM, this.commonHelpers.Marshall(login),
                GenericFunction.ReadConfigFile("VIRTUALISEDLOGINAPI")
                        + this.commonHelpers.endPointCollection.get("VIRTUAL_Login"));
        this.commonHelpers.AddToResponseCollection("VIRTUAL_Login", response);
        VirtualizedResp virtualizedResp = this.commonHelpers.unMarshall(response.asString(), VirtualizedResp.class);
        this.commonHelpers.HEADERPARAM.put("Cookie", this.TransformVirtualCookie(virtualizedResp));
        this.WhenIMakegetCall("MS_CSRFToken");
        response = this.commonHelpers.GetValueFromResponseCollection("MS_CSRFToken");
        this.commonHelpers.HEADERPARAM.put(Constants.XSRFHeader, response.cookies().get("XSRF-TOKEN"));
        this.UpdateCookie();
        this.commonHelpers.AddToContextStore("UserContext", "Shipper");
    }

    public void UpdateCookie() {
        this.commonHelpers.HEADERPARAM.put("Cookie", this.commonHelpers.HEADERPARAM.get("Cookie") + ";"
                + Constants.XSRFCookie + this.commonHelpers.HEADERPARAM.get(Constants.XSRFHeader));
    }

    public String CompanyAccountMapping(String company, List<String> accounts) {
        String companyAcc = "{\"" + company + "\"";
        companyAcc += ":";
        int counter = 0;
        companyAcc += "[";
        for (String account : accounts) {
            if (counter == accounts.size() - 1) {
                companyAcc += "\"" + account + "\"]}";
            } else {
                companyAcc += "\"" + account + "\",";
                counter++;
            }
        }
        log.info("Company Account Hierarchy: " + companyAcc);
        return companyAcc;
    }

    public void setQueryParams(Map<String, String> queryParams) {
        this.commonHelpers.QUERYPARAM.clear();
        queryParams = this.Setquerys(queryParams);
        for (String param : queryParams.keySet()) {
            this.commonHelpers.QUERYPARAM.put(param, queryParams.get(param));
        }
    }

    public HashMap<String, String> Setquerys(Map<String, String> queryParams) {
        HashMap<String, String> querys = new HashMap<String, String>();
        for (String param : queryParams.keySet()) {
            querys.put(param,
                    queryParams.get(param).contains("ContextStore-")
                            ? this.commonHelpers.getValuefromContextStore(queryParams.get(param)).toString()
                            : queryParams.get(param));
        }
        return querys;
    }

    public String TransformCookie(Map<String, String> cookie) {
        StringBuilder sBuilder = new StringBuilder();
        int counter = 0;
        for (String cke : cookie.keySet()) {
            sBuilder.append(
                    counter == cookie.size() - 1 ? cke + "=" + cookie.get(cke) : cke + "=" + cookie.get(cke) + ";");
            counter++;
        }
        log.info("Cookie: " + sBuilder);
        return sBuilder.toString();
    }

    public String TransformVirtualCookie(VirtualizedResp virtualizedResp) {
        StringBuilder sBuilder = new StringBuilder();
        LoginCookieOutputVO cookie = virtualizedResp.getOutput().getLoginCookieOutputVO();
        sBuilder.append("fdx_login=" + cookie.getFclCookie() + ";" + "fcl_fname=" + cookie.getNameCookie() + ";"
                + "fcl_contactname=" + cookie.getContactNameCookie() + ";" + "fcl_uuid=" + cookie.getUuidCookie());
        log.info("Virtualized Cookie: " + sBuilder);
        return sBuilder.toString();
    }

    public void setAccessToken() {
        Response resp = this.commonHelpers.GetValueFromResponseCollection("Bearertoken");
        this.commonHelpers.AddToContextStore("accessToken", this.commonHelpers.jsonHelpers.GetValueFromResp(resp,
                this.commonHelpers.jsonPathRepository.AccessToken));

    }

    public void SetCustomHeaders() {
        if (!this.commonHelpers.verifyKeyinContextStore("UserContext")) {
            this.commonHelpers.HEADERPARAM.put("Authorization",
                    String.format("Bearer %s", this.commonHelpers.getValuefromContextStore("accessToken").toString()));
            this.commonHelpers.HEADERPARAM.put("X-locale", "en_US");
            this.commonHelpers.HEADERPARAM.put("X-loggedin", "true");
            this.commonHelpers.HEADERPARAM.put("X-clientid", "WCDO");
            this.commonHelpers.HEADERPARAM.put("X-version", "1.0");
            // Added as some of the APIs are failing
            this.commonHelpers.HEADERPARAM.put("Accept", "application/json");
            this.commonHelpers.HEADERPARAM.put("Content-Type", "application/json");
        }
    }

    public void SetCustomFormParams() {
        this.commonHelpers.FORMPARAM.put("grant_type", "client_credentials");
        if (!GenericFunction.ENV.equalsIgnoreCase("PROD")) {
            this.commonHelpers.FORMPARAM.put("client_id", "l7xxd80e8de78a1241499e33de7876b1a03f");
            this.commonHelpers.FORMPARAM.put("client_secret", GenericFunction.ReadConfigFile("SEC"));
        } else {
            this.commonHelpers.FORMPARAM.put("client_id", "l7xx474b79016a4d4ec5a60bf7a7e5e7e6fe");
            this.commonHelpers.FORMPARAM.put("client_secret", GenericFunction.ReadConfigFile("SEC"));
        }
    }

    public void SetVirtualFormParams() {
        this.commonHelpers.FORMPARAM.put("grant_type", "client_credentials");
        this.commonHelpers.FORMPARAM.put("client_id", "12345678");
        this.commonHelpers.FORMPARAM.put("client_secret", "");
    }

    public void WhenIMakegetCall(String endPointKey, String... trackingId) {
        if (Constants.EndpointsNotXSRF.contains(endPointKey)) {
            this.commonHelpers.HEADERPARAM.remove(Constants.XSRFHeader);
        }
        String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey, trackingId);
        response = this.httpClientFactory.HTTPGET(this.commonHelpers.HEADERPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        log.info("------------------------");
        log.info("**** GET Request ***** ");
        log.info("RESOURCEURI --> " + endPointKey);
        //if (!Constants.EndpointsNotinConsole.contains(endPointKey))
        log.info("Status code for the endpointkey: " + finalEndPoint + " : " + response.getStatusCode());
        //log.info("Response for the endpointkey: " + endPointKey + " : " + response.asString());

        this.commonHelpers.AddToResponseCollection(endPointKey, response);
        //Resend 1 time if api is still sending 500 error as shipment details is not stable
        if(response.getStatusCode() != 200)
        {
         this.commonHelpers.thinkTimer(2000);
         response = this.httpClientFactory.HTTPGET(this.commonHelpers.HEADERPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        }
        Assertions.assertThat(response.getStatusCode())
                .withFailMessage("\nResponse code is not 200 but --> " + response.getStatusCode()
                + "\nResponse for the endpointkey: " + endPointKey + " : " + response.asString()
                + "\nHeader Param for the endpointkey: " + this.commonHelpers.HEADERPARAM
                + "\nResource URI is " + this.SetPersonaBasePath(endPointKey).concat(finalEndPoint)
                )
                .isEqualTo(200);
    }

    public String SetPersonaBasePath(String endPointKey) {
        String basePath = "";
        switch (endPointKey.split("_")[0]) {
            case "FedEx":
                basePath = this.TOKENBASEPATH;
                break;
            case "MS":
                basePath = this.commonHelpers.BASEPATH;
                break;
            case "CE":
                basePath = this.commonHelpers.CEBASEPATH;
                break;
            case "VIRTUAL":
                basePath = this.commonHelpers.VIRTUALBASEPATH;
                break;
        }
        return basePath;
    }

    public void PostCallwithQueryparms(String endPointKey) {
        String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey);
        if(endPointKey.contains("MS_Shipments_Search")) {
            this.commonHelpers.HEADERPARAM.put("Content-Type", "application/json");
        }
        response = this.httpClientFactory.HTTPPOST(this.commonHelpers.HEADERPARAM, this.commonHelpers.QUERYPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        log.info("RESOURCEURI --> " + this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        log.info("QueryParam is -->  " + this.commonHelpers.QUERYPARAM);
        log.info("HeaderParam is -->  " + this.commonHelpers.HEADERPARAM);
        log.info("Response code for POST Request is --> " + response.getStatusCode());
        // for debugging you can uncomment
        //log.info("Response Body for POST Request is --> " + response.getBody().asString());

        Assertions.assertThat(response.getStatusCode())
                .withFailMessage("\nResponse code is not 200 but --> " + response.getStatusCode()
                        + "\nResponse for the endpointkey: " + endPointKey + " : " + response.asString()
                        + "\nHeader Param for the endpointkey: " + this.commonHelpers.HEADERPARAM
                        + "\nResource URI is " + this.SetPersonaBasePath(endPointKey).concat(finalEndPoint)
                )
                .isEqualTo(200);
        this.commonHelpers.AddToResponseCollection(endPointKey, response);
    }

    public void PostCallwithQueryparmsandPayload(String endPointKey) throws Exception {
        String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey);
        String reqPayload = this.commonHelpers.Marshall(this.commonHelpers.GetrequestPayload(endPointKey));
        response = this.httpClientFactory.HTTPPOST(this.commonHelpers.HEADERPARAM, reqPayload,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint), this.commonHelpers.QUERYPARAM);
        //log.info("Response for the endpointkey: " + finalEndPoint + ":" + response.asString());
        this.commonHelpers.AddToResponseCollection(endPointKey, response);
    }

    public void GetCallwithQueryparms(String endPointKey) {
        String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey);
        response = this.httpClientFactory.HTTPGET(this.commonHelpers.HEADERPARAM, this.commonHelpers.QUERYPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        log.info("----------------------GET CALL----------------------------------------------");
        this.commonHelpers.AddToResponseCollection(endPointKey, response);
        Assertions.assertThat(response.getStatusCode())
                .withFailMessage("\nResponse code is not 200 but --> " + response.getStatusCode()
                +"\nResponse for the endpointkey: " + this.SetPersonaBasePath(endPointKey).concat(finalEndPoint)
                +"\nHeaderParam is : " + this.commonHelpers.HEADERPARAM
                +"\nQueryParam is : " + this.commonHelpers.QUERYPARAM
                +"\n Response as String : " + response.asString())
                .isEqualTo(200);
    }

    public void DeleteWatchlistwithQueryparms(String endPointKey, String id) {
        String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey).concat("/" + id);
        response = this.httpClientFactory.HTTPDELETE(this.commonHelpers.HEADERPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        //log.info("Response for the endpointkey: " + endPointKey + ":" + response.asString());
        this.commonHelpers.AddToResponseCollection(endPointKey, response);
    }

    public void DeleteComment(String endPointKey, String id, String shipmentId) {
        String finalEndPoint = String.format(this.commonHelpers.EndPointHelper(endPointKey), shipmentId, id);
        log.info("Final endpoint: " + finalEndPoint);
        response = this.httpClientFactory.HTTPDELETE(this.commonHelpers.HEADERPARAM,
                this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
        //log.info("Response for the endpointkey: " + endPointKey + ":" + response.asString());
        this.commonHelpers.AddToResponseCollection(endPointKey, response);
    }

    public void SetCEHeaderParams() {
        this.commonHelpers.HEADERPARAM.clear();
        String CE_Token = System.getProperty("CETOKEN");

        // if not running from pipeline reading it locally
        CE_Token = CE_Token == null ? GenericFunction.ReadConfigFile("CE_TOKEN") : CE_Token;

        // replacing Bearer space in case you have passed it
        CE_Token = CE_Token.replace("Bearer ", "");
        log.info("Got the CE Token from config file: ");
        this.commonHelpers.HEADERPARAM.put("Authorization", String.format("Bearer %s", CE_Token));
        this.commonHelpers.AddToContextStore("UserContext", "CE");
    }

    public void SetShipperHeaderParams() {
        this.commonHelpers.HEADERPARAM.clear();
        this.commonHelpers.HEADERPARAM.put("Authorization",
                String.format("Bearer %s", this.commonHelpers.getValuefromContextStore("accessToken")));
        this.commonHelpers.AddToContextStore("UserContext", "Shipper");
    }

    public void WhenIMakepostCall(String endPointKey) {
        try {
            log.info("POST CALL for API with endpoint: " + endPointKey);
            String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey);
            String reqPayload = "";
            if (Constants.EndPointsWithEmptyPayload.contains(endPointKey)) {
                reqPayload = Constants.EmptyPayload.toString();
            } else {
                reqPayload = this.commonHelpers.Marshall(this.commonHelpers.GetrequestPayload(endPointKey));
            }
            if (this.commonHelpers.verifyKeyInContextStore("workgroupIdList")) {
                reqPayload = reqPayload.replace("workGroupIdList", "workgroupIdList");
            }
            // you can uncomment below while debugging
            //log.info("Payload for the POST CALL for API is \n " + reqPayload);
            response = this.httpClientFactory.HTTPPOST(this.commonHelpers.HEADERPARAM,
                    reqPayload,
                    this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
            // you can uncomment below while debugging
            log.info("*** POST Request *** ");
            log.info("URI is " + endPointKey);
            //log.info("Payload is  is " + reqPayload);
            //log.info("Response for the API is \n " + response.getBody().asString());
            this.commonHelpers.AddToResponseCollection(endPointKey, response);
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in WhenIMakepostCall method : " + e.getMessage());
        }
    }

    public void WhenIMakeputCall(String endPointKey, String... contextStorevars) {
        try {
            String finalEndPoint = this.commonHelpers.EndPointHelper(endPointKey, contextStorevars);
            log.info("----------------------------------------------");
            log.info("Request for the endpointkey: " + endPointKey);
            response = this.httpClientFactory.HTTPPUT(this.commonHelpers.HEADERPARAM,
                    this.commonHelpers.Marshall(this.commonHelpers.GetrequestPayload(endPointKey)),
                    this.SetPersonaBasePath(endPointKey).concat(finalEndPoint));
            this.commonHelpers.AddToResponseCollection(endPointKey, response);
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in WhenIMakepostCall method : " + e.getMessage());
        }
    }

    public void SetResourceParam() {
        this.RESOURCEPATH = "/auth/oauth/v2/token";
    }

    public void SetTokenBasePath() {
        String env = GenericFunction.ENV;

        this.TOKENBASEPATH = GenericFunction
                .ReadConfigFile(env.equalsIgnoreCase("PROD") ? "PROD_LOGINAPI" : "LOGINAPI");
    }

    public String PutMethod(String Parameters) {
        int StatusCode = 201;
        String ResponseDescription = "Updated";

        // parse Parameter //

        // Create REST Assured call for PUT //

        // update Status Code and Response Description//

        return "Code:" + StatusCode + "_Description:" + ResponseDescription;
    }

    public String DeleteMethod(String Parameters) {
        int StatusCode = 202;
        String ResponseDescription = "Accepted";

        // parse Parameter //

        // Create REST Assured call for DELETE //

        // update Status Code and Response Description//

        return "Code:" + StatusCode + "_Description:" + ResponseDescription;
    }

    public String ReadJSON(File F) {
        JSONParser jsonParser = new JSONParser();
        String Value = "";
        try (FileReader reader = new FileReader(F)) {
            // Read JSON file
            Object obj = jsonParser.parse(reader);

            Value = obj.toString();
        } catch (Exception e) {
            log.error("**EXCEPTION** while reading JSON");
        }
        return Value;

    }
}
