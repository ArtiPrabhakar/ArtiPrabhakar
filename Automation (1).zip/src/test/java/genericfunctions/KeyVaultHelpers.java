package genericfunctions;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.authentication.KeyVaultCredentials;
import com.microsoft.azure.keyvault.models.SecretBundle;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This class is required to fetch values from keyvault by using clientId and
 * Client secret.
 */
public class KeyVaultHelpers {

    GenericFunction genericFunction;
    String KeyVaultUri;
    String ClientId;
    String ClientSecret;
    KeyVaultClient client;

    /**
     * Making the connection to keyvault by using the vault URI, ClientID and Client
     * Secret
     *
     * @return = KeyVault client
     */

    public KeyVaultClient SetAppConfigKeys() {
        try {
            this.KeyVaultUri = GenericFunction.ReadConfigFile("KEYVAULT_URI");
            this.ClientId = GenericFunction.ReadConfigFile("CLIENT_ID");
            this.ClientSecret = GenericFunction.ReadConfigFile("CLIENT_SECRET");
            this.client = new KeyVaultClient(new ClientSecretKeyVaultCredential(this.ClientId, this.ClientSecret));

        } catch (Exception e) {
            e.printStackTrace();
        }

        return this.client;
    }

    /**
     * This method returns the value of the secret from keyVault
     *
     * @param secretName = name of the secret in keyvault
     * @return = Value of the secret present in keyVault
     */
    public String getValuefromKeyVault(String secretName) {
        SecretBundle secret = this.client.getSecret(this.KeyVaultUri, secretName);
        return secret.value();
    }

    public class ClientSecretKeyVaultCredential extends KeyVaultCredentials {
        private String clientId;
        private String clientKey;

        public ClientSecretKeyVaultCredential(String clientId, String clientKey) {
            this.clientId = clientId;
            this.clientKey = clientKey;
        }

        @Override
        public String doAuthenticate(String authorization, String resource, String scope) {
            AuthenticationResult token = getAccessTokenFromClientCredentials(authorization, resource, clientId,
                    clientKey);
            return token.getAccessToken();
        }

        private AuthenticationResult getAccessTokenFromClientCredentials(String authorization, String resource,
                                                                         String clientId, String clientKey) {
            AuthenticationContext context = null;
            AuthenticationResult result = null;
            ExecutorService service = null;
            try {
                service = Executors.newFixedThreadPool(1);
                context = new AuthenticationContext(authorization, false, service);
                ClientCredential credentials = new ClientCredential(clientId, clientKey);
                Future<AuthenticationResult> future = context.acquireToken(resource, credentials, null);
                result = future.get();
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                service.shutdown();
            }

            if (result == null) {
                throw new RuntimeException("authentication result was null");
            }
            return result;
        }
    }

}
