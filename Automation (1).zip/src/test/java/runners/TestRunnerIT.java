package runners;

import API.RequestModels.TestResult;
import com.google.gson.Gson;
import common.ADOHelpers;
import common.Singleton;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


@RunWith(Cucumber.class)
@CucumberOptions(features = {"src/test/resources"}, glue = {"stepDefinitions"}, tags = {"@TESTCASE="}

        , strict = true

        // This brings steps visible on left side when we run from test runner
        , stepNotifications = true,

        // tags = {"@Sprint1A"},
        plugin = {
                  "pretty",
                  "json:./../artifacts/cucumber-html-reports/cucumber.json",
                  "html:./../artifacts/cucumber-html-reports",
                  "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                  "rerun:./../artifacts/failedrerun.txt"
        }

)

@Slf4j
public class TestRunnerIT {

    @After
    public void afterScenario() {
        log.info("Scenario ran complete");
    }

    @AfterClass
    public static void writeExtentReport() {
        ADOHelpers.updateTestPlan();
        createTestResultJson("SUITEID1");
        //createTestResultJson("SUITEID2");
    }

    public static void createTestResultJson(String SuiteID) {
        TestResult result = new TestResult();

        boolean suiteIdFlag;
        String suiteId = System.getProperty(SuiteID);
        suiteIdFlag = suiteId != null;
        if (suiteIdFlag) {
            result.setSuiteId(Integer.parseInt(suiteId));
        } else {
            result.setSuiteId(1);
        }

        result.setTestCases(Singleton.getInstance().getTestCases());
        Gson gson = new Gson();
        String json = gson.toJson(result);
        if (SuiteID.equals("SUITEID1")) {
            createJsonFile(json, "TestResult1");
        }
        //if (SuiteID.equals("SUITEID2")) {
            // not needed for now but can be in future as we have just 1 test suite as of now
            //createJsonFile(json, "TestResult2");
        //}
    }

    public static void createJsonFile(String json, String FileName) {
        try {

            FileWriter myWriter = new FileWriter( "target/"+FileName + ".json");
            myWriter.write(json);
            myWriter.close();
            log.info("Successfully wrote to the file " + FileName + ".json");
        } catch (IOException e) {
            log.error(" **EXCEPTION** An error occurred while creating the TestResult.json ");
            e.printStackTrace();
        }
        log.info("Reports/logs would be created under artifacts folder which is one level above the Automation folder. ");
    }

}