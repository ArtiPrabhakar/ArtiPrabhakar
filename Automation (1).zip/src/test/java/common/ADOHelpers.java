package common;

import API.RequestModels.Syncer;
import API.RequestModels.TestCase;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import constants.JsonPathRepository;
import genericfunctions.GenericFunction;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ADOHelpers extends CommonHelpers {

    public static void updateTestPlan() {
        boolean flag = Boolean.parseBoolean(GenericFunction.ReadConfigFile("UPDATEADO"));
        if (flag) {
            TestPlanUpdate();
        }
    }

    public static void TestPlanUpdate() {
        try {
            int testCasesCount = 0;
            List<TestCase> testCases = new ArrayList<TestCase>();
            JSONArray array = JSONHelpers.StringtoJArray(
                    JSONHelpers.ReadJSON(new File(GenericFunction.userDir + "..\\artifacts\\cucumber.json")));
            testCasesCount = array.getJSONObject(0).getJSONArray("elements").length();
            ReadContext ctx = JsonPath.parse(
                    JSONHelpers.ReadJSON((new File(GenericFunction.userDir + "..\\artifacts\\cucumber.json"))));
            for (int i = 0; i < testCasesCount; ++i) {
                List<String> Statuslst = ctx
                        .read(String.format(JsonPathRepository.testcaseStepStatus, i));
                TestCase testCase = new TestCase();
                String TCId = ctx.read(String.format(JsonPathRepository.testcasename, i)).toString()
                        .split("=")[1].substring(0, 5);
                testCase.setTestCaseId(Integer.parseInt(TCId));
                testCase.setOutcome(Statuslst.contains("failed") ? "Failed" : "Passed");
                testCases.add(testCase);
            }
            Syncer syncer = new Syncer();
            syncer.setTestCases(testCases);
            String syncerPayload = new ObjectMapper().configure(SerializationFeature.FAIL_ON_SELF_REFERENCES, false)
                    .writeValueAsString(syncer);
            JSONObject obj = JSONHelpers.StringtoJObject(syncerPayload);
            FileWriter file = new FileWriter(GenericFunction.userDir + "..\\artifacts\\TCSyncer.json");
            file.write(obj.toString());
            file.close();
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in TestPlanUpdate: " + e.getMessage());
        }

    }

}