package common;

import com.jayway.jsonpath.JsonPath;
import genericfunctions.GenericFunction;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.File;
import java.io.FileReader;

/**
 * JSONHelpers class used fof having the methods which are releated to the json
 * readers
 */
@Slf4j

public class JSONHelpers {

    /**
     * Read end point collection.json file in initialisation time
     *
     * @return = Content of the file
     */
    public static String GetFileContent() {
        String FileLocation;
        String OS = GenericFunction.OS;
        if (OS.toLowerCase().contains("window"))
            FileLocation = GenericFunction.userDir + "\\src\\test\\java\\constants\\EndPointCollection.json";
        else
            FileLocation = GenericFunction.userDir + "/src/test/java/constants/EndPointCollection.json";

        File file = new File(FileLocation);
        return ReadJSON(file);
    }

    /**
     * Read content of the file when name of the file is passed
     *
     * @return = Content of the file
     */
    public static String GetFileContent(String testDataFilename) {
        String FileLocation;

        if (GenericFunction.OS.toLowerCase().contains("window"))
            FileLocation = GenericFunction.userDir + "\\src\\test\\java\\constants\\" + testDataFilename;
        else
            FileLocation = GenericFunction.userDir + "/src/test/java/constants/" + testDataFilename;

        File file = new File(FileLocation);

        return ReadJSON(file);
    }

    /**
     * ReadJson method will read the content from the file and return the content of
     * the file as String
     *
     * @param F = File location
     * @return = Content of the file as String
     */

    public static String ReadJSON(File F) {
        JSONParser jsonParser = new JSONParser();
        String Value = "";
        try (FileReader reader = new FileReader(F)) {
            // Read JSON file
            Object obj = jsonParser.parse(reader);

            Value = obj.toString();
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in ReadJson method: " + e.getMessage());
        }
        return Value;
    }

    public static JSONObject StringtoJObject(String jsonContent) {
        return new JSONObject(jsonContent);
    }

    public static JSONArray StringtoJArray(String jsonContent) {
        return new JSONArray(jsonContent);
    }

    /**
     * GetValueFromResp method will return the response as string when HTTPResponse
     * object is passed as parameter to method
     *
     * @param response = HTTP Response object
     * @param key      = Any key in the json object
     * @return = value for the key in the json object
     */
    public <T> T GetValueFromResp(Response response, String key) {
        String responseString = response.asString();
        return JsonPath.parse(responseString).read(key);
    }

}