package common;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;

import java.util.HashMap;

/**
 * HttpClientFactory class is having the overloaded methods for API methods
 */
@Slf4j
public class HttpClientFactory extends CommonHelpers {
    Response response = null;

    /**
     * HTTPGET method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // Header param
    public Response HTTPGET(HashMap<String, String> HEADERPARAM, String RESOURCEURI) {
        try {
            if (HEADERPARAM.size() > 0) {
//                log.info("Requesting GET with Header and Query Parameter for endPoint: " + RESOURCEURI);
//                log.info("Size for Header Parameters --> " + HEADERPARAM.size());

                response = RestAssured.given().when().headers(HEADERPARAM).get(RESOURCEURI);
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in the HTTPGET method: " + e.getMessage());
        }

        return response;
    }

    /**
     * HTTPGET method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param QUERYPARAM  = query parameters
     * @param HEADERPARAM = Required Headers for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // Header param
    public Response HTTPGET(HashMap<String, String> HEADERPARAM, HashMap<String, String> QUERYPARAM,
                            String RESOURCEURI) {
        try {
            log.info("Requesting GET with Header and Query Parameter");
            response = RestAssured.given().when().headers(HEADERPARAM).queryParams(QUERYPARAM).get(RESOURCEURI);

        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in the HTTPGET method: " + e.getMessage());
        }

        return response;
    }

    /**
     * HTTPGET method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // QueryParam and Header param are empty
    public Response HTTPGET(String RESOURCEURI) {
        log.info("Requesting GET with Header and Query Parameter");
        response = RestAssured.given().when().get(RESOURCEURI);
        //log.info("Response :" + response.asString());
        log.info("Status Code:" + response.getStatusCode());
        return response;
    }

    /**
     * HTTPPOST method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param FORMPARAM   = Required Form Parameters for the API
     * @param PAYLOAD     = Required payload for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // FormParam, headerparam and payload
    public Response HTTPPOST(HashMap<String, String> HEADERPARAM, HashMap<String, String> FORMPARAM, String PAYLOAD,
                             String RESOURCEURI) {
        if (HEADERPARAM.size() > 0 && FORMPARAM.size() > 0 && PAYLOAD.length() > 2) {
            log.info("Requesting POST Call with Header , Form and Payload");
            response = RestAssured.given().contentType(ContentType.URLENC.withCharset("UTF-8")).when()
                    .headers(HEADERPARAM).formParams(FORMPARAM).body(PAYLOAD).post(RESOURCEURI);
        }
        return response;
    }

    /**
     * HTTPPOST method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param RESOURCEURI = End point URL of the API
     * @return
     */
    // Query param and header param
    public Response HTTPPOST(HashMap<String, String> HEADERPARAM, HashMap<String, String> QUERYPARAM,
                             String RESOURCEURI) {
        log.info("Requesting POST Call with Header and Form parameter");
        response = RestAssured
                 .given()
                 //.contentType(ContentType.URLENC.withCharset("UTF-8"))
                 .when()
                 .headers(HEADERPARAM)
                 .queryParams(QUERYPARAM)
                 .post(RESOURCEURI);
        return response;
    }

    /**
     * HTTPPOST method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param PAYLOAD     = Required payload for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // Header and payload //
    public Response HTTPPOST(HashMap<String, String> HEADERPARAM, String PAYLOAD, String RESOURCEURI,
                             HashMap<String, String> QUERYPARAM) {
        log.info("Requesting POST Call with Header, Query Parameters and Payload");
        response = RestAssured.given().contentType(ContentType.JSON).when().headers(HEADERPARAM).queryParams(QUERYPARAM)
                .body(PAYLOAD)
                .post(RESOURCEURI);

        return response;
    }

    /**
     * HTTPPOST method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param PAYLOAD     = Required payload for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // Header and payload //
    public Response HTTPPOST(HashMap<String, String> HEADERPARAM, String PAYLOAD, String RESOURCEURI) {
        log.info("Requesting POST Call with Header and Payload");
        response = RestAssured.given().contentType(ContentType.JSON).when().headers(HEADERPARAM).body(PAYLOAD)
                .post(RESOURCEURI);
        log.info("RESOURCEURI --> " + RESOURCEURI);

        if(!String.valueOf(response.getStatusCode()).equalsIgnoreCase("200")){
            for(int requestCnt = 1;requestCnt<=3;requestCnt++){
                response = RestAssured.given().contentType(ContentType.JSON).when().headers(HEADERPARAM).body(PAYLOAD)
                        .post(RESOURCEURI);
                log.info("ATTEMPT : " + requestCnt);

                if(String.valueOf(response.getStatusCode()).equalsIgnoreCase("200")){
                    break;
                }
            }
        }

        // for debugging you can uncomment
        //log.info("Response Body for POST Request is --> " + response.getBody().asString());

        Assertions.assertThat(response.getStatusCode())
                .withFailMessage("Response code is not 200 but --> " + response.getStatusCode()
                        + "\n Response Body for POST Request is --> " + response.getBody().asString()
                        + "\n Payload is -->  " + PAYLOAD
                        + "\n HeaderParam is -->  " + HEADERPARAM
                )
                .isEqualTo(200);


        return response;
    }

    public Response HTTPPUT(HashMap<String, String> HEADERPARAM, String PAYLOAD, String RESOURCEURI) {
        if (PAYLOAD.length() > 2) {
            log.info("***** PUT Call ******** --> ");
            log.info("RESOURCEURI --> " + RESOURCEURI);
            response = RestAssured
                    .given().contentType(ContentType.JSON)
                    .when().headers(HEADERPARAM).body(PAYLOAD)
                    .put(RESOURCEURI);


            Assertions.assertThat(response.getStatusCode())
                    .withFailMessage("Status code of PUT Call is not 200 but --> " + response.getStatusCode()
                    +"Response for the PUT request is --> " + response.getBody().asString()
                    +"Payload for the PUT request is --> " + PAYLOAD
                    +"Headers for the PUT request is --> " + HEADERPARAM
                    )
                    .isEqualTo(200);
        }
        return response;
    }

    /**
     * HTTPPOST method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param FORMPARAM   = Required Form Parameters for the API
     * @param RESOURCEURI = End point URL of the API @return= Response to the API
     */
    // No Header No Payload
    public Response HTTPPOST(HashMap<String, String> FORMPARAM, String RESOURCEURI) {
        response = RestAssured.given().contentType(ContentType.URLENC.withCharset("UTF-8")).when().formParams(FORMPARAM)
                .post(RESOURCEURI);
        return response;
    }

    /**
     * HTTPDELETE method which will return the response of the API when below fields
     * are passed to the function
     *
     * @param HEADERPARAM = Required Headers for the API
     * @param RESOURCEURI = End point URL of the API
     * @return = Response to the API
     */
    // Header param
    public Response HTTPDELETE(HashMap<String, String> HEADERPARAM, String RESOURCEURI) {
        try {
            if (HEADERPARAM.size() > 0) {
                log.info("Requesting GET with Header and Query Parameter");
                log.info(String.valueOf(HEADERPARAM.size()));

                response = RestAssured.given().when().headers(HEADERPARAM).delete(RESOURCEURI);
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in the HTTPGET method: " + e.getMessage());
        }

        return response;
    }

}