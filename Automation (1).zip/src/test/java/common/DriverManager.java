package common;

import genericfunctions.GenericFunction;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j

public class DriverManager {
    private static WebDriver driver;
    private static ThreadLocal<WebDriver> drv = new ThreadLocal<>();

    public static WebDriver getDrv()
    {
        String Browser = GenericFunction.ReadConfigFile("BROWSER");

        if(drv.get()==null)
        {
            switch (Browser) {
                case "CHROME":
                    ChromeOptions options = new ChromeOptions();
                    options.setPageLoadStrategy(PageLoadStrategy.NORMAL);

                    // options.setExperimentalOption("debuggerAddress","localhost:9222");
                    if (GenericFunction.OS.contains("Window")) {
                        log.info(" We are running the build in the windows environment");
                        // options.addArguments("--disable-dev-shm-usage");
                        // options.addArguments("--no-sandbox");
                        // options.addArguments("--remote-debugging-port=9222");
                         options.addArguments("--headless=new");
                        // options.addArguments("--window-size=1920,1080");

                    } else {
                        // Check that Bash should run to set this value //
                        // CurrentDir = "/usr/bin/chromedriver";
                        log.info(" We are running the build in the linux environment");
                        Map<String, Object> prefs = new HashMap<>();
                        prefs.put("download.default_directory", "/root/Downloads");
                        options.setExperimentalOption("prefs", prefs);
                        options.addArguments("--disable-dev-shm-usage");
                        options.addArguments("--no-sandbox");
                        options.addArguments("--remote-debugging-port=9222");
                        options.addArguments("--headless=new");
                        // options.addArguments("--kiosk");
                        options.addArguments("--lang=" + GenericFunction.locale);

                    }
                    options.setBrowserVersion("115");
                    options.addArguments("--window-size=1920,1080");
                    options.addArguments("--incognito");
                    options.addArguments("--start-maximized");
//                    options.addArguments("--disable-geolocation");
//                    options.addArguments("--ignore-certificate-errors");
                    options.addArguments("--deny-permission-prompts");

                    driver = new ChromeDriver(options);
                    break;
                case "EDGE":
                    driver = new EdgeDriver();
                    break;
                case "FF":
                    driver = new FirefoxDriver();
                    break;
                default:
                    log.info("Invalid Choice");
                    Assertions.fail("Wrong browser is passed in the config file");
                    break;
            }
            if (GenericFunction.OS.contains("Window")) {
                driver.manage().window().maximize();
            }else {
                driver.manage().window().setSize(new Dimension(1920, 1080));
            }
            drv.set(driver);
        }

        return drv.get();
    }

    public static void setDrv(WebDriver driverRef)
    {
        drv.set(driverRef);
    }

    public static void unload()
    {
        drv.remove();
    }

}
