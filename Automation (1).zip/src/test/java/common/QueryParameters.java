package common;

import common.CosmosHelpers.FilterClause;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;

public class QueryParameters {
    public List<Pair<FilterClause, Pair<String, Object>>> QueryParams;

    public QueryParameters() {
        this.QueryParams = new ArrayList<Pair<FilterClause, Pair<String, Object>>>();
    }

    public List<Pair<FilterClause, Pair<String, Object>>> getQueryParams() {
        return this.QueryParams;
    }

    public void setQueryParams(List<Pair<FilterClause, Pair<String, Object>>> queryParams) {
        this.QueryParams = queryParams;
    }

    /**
     * This method will add the query parameters which passed as parameters to the
     * existing list
     */
    public void AddQueryParams(FilterClause clauseType, String key, Object value) {
        this.QueryParams.add(Pair.of(clauseType, Pair.of(key, value)));
    }
}