package common;

import API.CosmosModels.Fusion;
import API.CosmosModels.InsightDetails;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.microsoft.azure.documentdb.Document;
import com.microsoft.azure.documentdb.FeedResponse;
import constants.JsonPathRepository;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONObject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * CommonHelpers class is used to hold values which is used across the
 * application, hence this class instance is passed in all the page objected to
 * fetch the values
 */
@Slf4j
public class CommonHelpers {
    private final HashMap<String, Object> requestPayLoadCollection = new HashMap<>();
    private final HashMap<String, Response> responseCollection = new HashMap<>();
    private final HashMap<String, Object> contextStore = new HashMap<>();
    public String appUrl="";
    public JSONHelpers jsonHelpers;
    public JsonPathRepository jsonPathRepository;
    public Map<String, String> endPointCollection;
    public String BASEPATH;
    public String CEBASEPATH;
    public String VIRTUALBASEPATH;
    public String DATABASENAME;
    public HashMap<String, String> FORMPARAM = new HashMap<String, String>();
    public HashMap<String, String> HEADERPARAM = new HashMap<String, String>();
    public HashMap<String, String> QUERYPARAM = new HashMap<String, String>();

    public CommonHelpers() {
        this.jsonHelpers = new JSONHelpers();
        this.jsonPathRepository = new JsonPathRepository();
        this.CEBASEPATH = SetCEBasePath();
        this.BASEPATH = SetBasePath();
        this.DATABASENAME = SetDBName();
        this.VIRTUALBASEPATH = SetVirtualName();
        this.endPointCollection = new Gson().fromJson(JSONHelpers.GetFileContent(),
                new TypeToken<HashMap<String, String>>() {
                }.getType());
    }

    /**
     * Method which will set the CE BaseURL based on the environment
     *
     * @return = String which is basepath for the CE API's
     */
    public static String SetCEBasePath() {
        String env = GenericFunction.ENV;
        String host = "";
        host = GenericFunction.ReadConfigFile(env + Constants.CEbaseURL);
        return host;
    }

    /**
     * Method which will set the BaseURL based on the environment
     *
     * @return = String which is basepath for the API's
     */
    public static String SetBasePath() {
        String env = GenericFunction.ENV;
        String host = "";
        host = GenericFunction.ReadConfigFile(env + Constants.baseURL);
        return host;
    }

    /**
     * Method which will set the DB Name based on the environment
     *
     * @return = String which is basepath for the API's
     */
    public static String SetDBName() {
        String env = GenericFunction.ENV;
        String dataBaseName = "";
        dataBaseName = GenericFunction.ReadConfigFile(env + Constants.DBName);
        return dataBaseName;
    }

    public static String SetVirtualName() {
        return GenericFunction.ReadConfigFile(Constants.VirtualbaseURL);
    }

    /**
     * This function will add API response to Response collection
     *
     * @param key   = Name of the key in which we want to store the response
     * @param value = API response
     */
    public void AddToResponseCollection(String key, Response value) {
        this.responseCollection.put(key, value);
    }

    public String EndPointHelper(String endPointKey, String... contextStorevars) {
        if (Constants.CompanyNameEndpoints.contains(endPointKey)) {
            return String.format(this.endPointCollection.get(endPointKey),
                    this.getValuefromContextStore("CompanyCode"));
        } else if (endPointKey.contains("_Shipments_Details") || endPointKey.contains("CE_AddComment")
                || endPointKey.contains("_GlobalCities")) {
            if (contextStorevars != null && contextStorevars.length > 0) {
                if (contextStorevars[0].contains("ContextStore"))
                    return String.format(this.endPointCollection.get(endPointKey),
                            this.getValuefromContextStore(contextStorevars[0]).toString());
                else
                    return String.format(this.endPointCollection.get(endPointKey), contextStorevars[0]);
            }
        }
        return this.endPointCollection.get(endPointKey);
    }

    public String GetDatefromAPI(String dateandTime, String component, String timeZone, String pattern)
            throws ParseException {
        SimpleDateFormat inputFormatter;
        String scanTZ = String.format("-%s", dateandTime.substring(dateandTime.length() - 5));
        // if date time contains millis
        if (dateandTime.length() >= 29) {
            inputFormatter = new SimpleDateFormat(Constants.APIDateTimeFormat);
        } else if (dateandTime.length() <= 10) {
            inputFormatter = new SimpleDateFormat(Constants.APIDateFormat);
        } else {
            inputFormatter = new SimpleDateFormat(Constants.APIDateTimeFormatwithoutMillis);
        }
        inputFormatter.setTimeZone(TimeZone.getTimeZone(String.format("GMT%s", scanTZ)));
        Date date = inputFormatter.parse(dateandTime);
        log.info(inputFormatter.format(date));
        String converteddate = inputFormatter.format(date);
        if (!scanTZ.equalsIgnoreCase(timeZone)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            // Here you set to your timezone
            inputFormatter.setTimeZone(TimeZone.getTimeZone(String.format("GMT%s", timeZone)));
            converteddate = inputFormatter.format(calendar.getTime());
        }
        if (component.equalsIgnoreCase("DATE")) {
            return converteddate.split("T")[0];
        } else if (component.equalsIgnoreCase("TIME") && dateandTime.length() <= 10) {
            return "";
        } else {
            return converteddate.split("T")[1].substring(0, 5);
        }

    }

    public Date StringToDate(String dob, String format) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        Date date = formatter.parse(dob);
        return date;
    }

    /**
     * This function will add API request to Request collection
     *
     * @param key   = Name of the key in which we want to store the request
     * @param value = Request payload
     */
    public void AddToRequestPayloadCollection(String key, Object value) {
        this.requestPayLoadCollection.put(key, value);
    }

    public Object GetrequestPayload(String endPointkey) {
        return this.requestPayLoadCollection.get(endPointkey);
    }

    /**
     * This function will return API response when key is passed
     *
     * @param ContextStoreKey = Key to search in response collection
     * @return = API response which is present in the colletion
     */
    public Response GetValueFromResponseCollection(String ContextStoreKey) {
        return this.responseCollection.get(ContextStoreKey);
    }

    /**
     * Generic store which is used to store values for the context of scenario
     *
     * @param key   = Name of the key in which we want to store the content
     * @param value = Value which is stored in the context store will be returned
     *              based on the key
     */
    public void AddToContextStore(String key, String value) {
        this.contextStore.put(key, value);
    }

    /**
     * Generic store which is used to store values for the context of scenario
     *
     * @param key   = Name of the key in which we want to store the content
     * @param value = Value which is stored in the context store will be returned
     *              based on the key
     */
    public void AddToContextStore(String key, Object value) {
        if (key.equalsIgnoreCase("skipRemainingSteps")) {
            log.warn(" *WARNING* - Some steps would get skipped for this test case. Data Dependency Count:");
        }
        this.contextStore.put(key, value);
    }

    public Object getValuefromContextStore(String key) {
        return this.contextStore.get(key.replace("ContextStore-", ""));
    }

    public boolean verifyKeyinContextStore(String key) {
        if(key.equalsIgnoreCase(Constants.skipSteps)){
            if(contextStore.containsKey(key)){
                GenericFunction.TESTCASE_STATUS="NotExecuted";
                log.warn(" Setting testtcase status to NotExecuted in method 1" );
            }
        }
        return this.contextStore.containsKey(key);
    }

    public void removeKeyinContextStore(String key) {
        this.contextStore.remove(key);
    }

    /**
     * unMarshall is the one which converts the string json to class object
     *
     * @param <T>    = Generic class which is required to convert the json string to
     *               mentioned class
     * @param json   = json value which is required to convert to class
     * @param class1 = Required class object which we want to convert
     * @return = object of the class in which user provided
     * @throws Exception
     */
    public <T> T unMarshall(String json, Class<T> class1) throws Exception {
        return new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).readValue(json,
                class1);
    }

    /**
     * This method will convert an object to String by serialization feature
     *
     * @param obj any class object
     * @return String format of the object
     * @throws Exception
     */
    public String Marshall(Object obj) throws Exception {
        return new ObjectMapper().setSerializationInclusion(Include.NON_NULL)
                .configure(SerializationFeature.FAIL_ON_SELF_REFERENCES, false)
                .writeValueAsString(obj);
    }

    /**
     * This method will convert an array response to a List of Objects
     *
     * @param resp   Response u want to convert
     * @param class1 Class to be used for Conversion
     * @return List of Response Object
     * @throws Exception
     */
    public <T> List<T> unMarshall(Response resp, Class<T[]> class1) throws Exception {
        return Arrays.asList(new Gson().fromJson(resp.asString(), class1));
    }

    /**
     * This method will convert the datetime zone format to specific format
     *
     * @param dateTimeZone = "2020-10-01T11:00:00-07:00"
     * @param context      = Date or Time
     */
    public String TransformDatetoFormatPipe(String dateTimeZone, String context) {
        if (context.equalsIgnoreCase("date")) {
            return this.GetAPIwithUIformat(context, dateTimeZone.split("T")[0]);
        } else {
            return this.GetAPIwithUIformat(context, dateTimeZone.split("T")[1].split("-")[0]);
        }
    }

    /**
     * This method will retunr date and time in a specific format which is as per UI
     *
     * @param context  = Date or time
     * @param dateTime = Date or Time (yyyy-MM-dd or hh:mm:ss)
     * @return
     */
    public String GetAPIwithUIformat(String context, String dateTime) {
        if (context.equalsIgnoreCase("date")) {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(Constants.APIDateFormat, Locale.ENGLISH);
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(Constants.UIDateFormat, Locale.ENGLISH);
            LocalDate date = LocalDate.parse(dateTime, inputFormatter);
            return outputFormatter.format(date);
        } else {
            LocalTime t = LocalTime.parse(dateTime);
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(Constants.UITimeFormat, Locale.ENGLISH);
            return t.format(outputFormatter);
        }

    }

    public int GenerateRandomNumber(int maxLimit) {
        Random rand = new Random();
        return rand.nextInt(maxLimit);
    }

    public String generateRandomString(int maxChar) {
        return RandomStringUtils.randomAlphanumeric(maxChar);
    }

    public String GetAccIdsofSurroundEligibility(String surroundEligibilityType) {
        String user = this.getValuefromContextStore("UserContext").toString();
        String accountId = "";
        if (user.equalsIgnoreCase("user2")) {
            switch (surroundEligibilityType) {
                case "AllEnablements":
                    accountId = Constants.AllEnablementsAcc;
                    break;
                case "Monitoring":
                    accountId = Constants.MonitoringAcc;
                    break;
                case "ExpediteMonitor":
                    accountId = Constants.ExpediteMonitorAcc;
                    break;
                case "InterventionMonitor":
                    accountId = Constants.InterventionMonitorAcc;
                    break;
                case "CallReceipMonitor":
                    accountId = Constants.CallReceipMonitorAcc;
                    break;
                case "InterCallRecepMonitor":
                    accountId = Constants.InterCallRecepMonitorAcc;
                    break;
                case "ExpeInterMonitor":
                    accountId = Constants.ExpeInterMonitorAcc;
                    break;
                case "ExpeCallReceipMonitor":
                    accountId = Constants.ExpeCallReceipMonitorAcc;
                    break;
            }
        }
        return accountId;
    }

    public List<String> SetCosmosResptoList(FeedResponse<Document> queryResults, String selectType) throws Exception {
        List<String> IdsList = new ArrayList();
        // List<Document> documents = queryResults.getQueryIterable().toList();
        if (selectType.equalsIgnoreCase("c.shipmentId"))
            for (Document doc : queryResults.getQueryIterable()) {
                IdsList.add(new JSONObject(doc.toJson()).getString("shipmentId"));
                // IdsList.add(doc.toJson());
            }
        return IdsList;
    }

    public void SetCosmosToContextStore(String document, String selectType) throws Exception {
        JSONObject obj = new JSONObject(document);
        if (selectType.equalsIgnoreCase("count")) {
            this.AddToContextStore("DBQueryCount", obj.getInt("_aggregate"));
        } else {
            String docType = obj.getString("documentType");
            switch (docType) {
                case "insightDetails":
                    InsightDetails insightDetails = this.unMarshall(document, InsightDetails.class);
                    this.AddToContextStore("DBShipmentId", insightDetails.getShipmentId());
                    this.AddToContextStore("DBTrackingNumber", insightDetails.getShipmentKey().getTrackId());
                    break;
                case "Fusion":
                    Fusion fusion = this.unMarshall(document, Fusion.class);
                    this.AddToContextStore("DBShipmentId", fusion.getShipmentId());
                    this.AddToContextStore("DBTrackingNumber", fusion.getShipmentKey().getTrackId());
                    break;
            }
        }
    }

    public void thinkTimer(long milliseconds) {
        try {
            log.info("Waiting for " + milliseconds + " milliseconds");
            Thread.sleep(milliseconds);
        } catch (Exception e) {
            log.error("**EXCEPTION** in thinkTimer " + e);
        }
    }

    public boolean isGUID(String guid) {
        boolean flag = false;
        try {
            UUID.fromString(guid);
            flag = true;
        } catch (Exception e) {
            log.error("**EXCEPTION** while genering uuid " + e);
        }
        return flag;
    }

    public List<String> SetMockAccIds(String userContext) {
        String user = this.getValuefromContextStore("UserContext").toString().toLowerCase();
        List<String> accountIds = null;
        switch (user) {
            case "user2":
                accountIds = Constants.User2AccIds;
            case "user1":
                accountIds = Constants.User1AccIds;
        }
        return accountIds;
    }

    public String GetApplicationUrl(String url) {
        String env = GenericFunction.ENV;
        String language = GenericFunction.locale;
        String env_localization = GenericFunction.ENV_LOCALIZATION;
        boolean virtualizationFlag = Boolean
                .parseBoolean(getValuefromContextStore("VIRTUALIZATION").toString());
        log.info("########################## virtualizationFlag "+ virtualizationFlag);
        if (url.equalsIgnoreCase("CompanyPortal")) {
            if(virtualizationFlag) {
                appUrl = GenericFunction.ReadConfigFile(env + Constants.portalURL);
            }else{
                appUrl = GenericFunction.ReadConfigFile("STRESS_URL");
            }
        } else if (url.equalsIgnoreCase("RedirectionURL")) {
            if(url.contains("home.html") || appUrl.contains(GenericFunction.locale)) { // localization URL
                {
                    appUrl = GenericFunction.ReadConfigFile(env_localization + Constants.reDirectionURL) ;
                }
              //  isItLocalizationTest=true;
            }
//            else if(isItLocalizationTest)
//               appUrl = GenericFunction.ReadConfigFile(env_localization + Constants.reDirectionURL);
            else
               appUrl = GenericFunction.ReadConfigFile(env + Constants.reDirectionURL);
        } else if (url.equalsIgnoreCase("CECompanyPortal")) {
            appUrl = GenericFunction.ReadConfigFile(env + Constants.CEportalURL);
        } else if (url.equalsIgnoreCase("CompanyPortalLocale")) {
            // This is a workaround and need to removed later
            if(!GenericFunction.virtualizationFlag)
                appUrl = "https://wwwstress.dmz.idev.fedex.com/secure-login/" + language + "/#/login-credentials";
            else {
                //appUrl = (GenericFunction.ReadConfigFile(env_localization + Constants.portalURL)) + "?locale=" + language;
                appUrl = GenericFunction.ReadConfigFile("LANGUAGE_CHANGE_URL");
                appUrl = appUrl.replace("en-us",language);
            }
        }
        // If its a URL which is for localization
        // we may have to redirect to a different environment as localization can have a different environment
        else if (url.contains("home.html")) {
            appUrl = GenericFunction.ReadConfigFile(env_localization + Constants.reDirectionURL.replaceAll("/dashboard","")) ;
        }

        log.info("The URL to be used is " + appUrl);

        return appUrl;
    }

    public Boolean verifyKeyInContextStore(String key) {
        if(key.equalsIgnoreCase(Constants.skipSteps)){
            if(contextStore.containsKey(key)){
                GenericFunction.TESTCASE_STATUS="NotExecuted";
                log.warn(" Setting testtcase status to NotExecuted in method 2" );
            }
        }
        return this.contextStore.containsKey(key.contains("ContextStore") ? key.replace("ContextStore-", "") : key);
    }

    public boolean AssertCountswithCorrection(int expectedCount, int actualCount) {
        boolean flag = false;
        int correctionValue = Integer.parseInt(GenericFunction.ReadConfigFile("CountCorrection"));
        if (expectedCount - correctionValue <= actualCount && actualCount <= expectedCount + correctionValue) {
            flag = true;
            return flag;
        }
        log.error("The actualCount is " + actualCount + "\nThe expected count is " + expectedCount);
        return flag;
    }

    public boolean CompareTwoLists(List<Object> filterFromAdvisoryPage, List<Object> filterFromShipmentPage) {
        boolean flag = filterFromAdvisoryPage.equals(filterFromShipmentPage);
        return flag;
    }

    public void removeRequestPayloadCollection(String key) {
        this.requestPayLoadCollection.remove(key);
    }

    public void AddAdvisoryCountToContextStore(String key, int value) {
        if (key.equalsIgnoreCase("skipRemainingSteps")) {
            log.warn(" *WARNING* - Some steps would get skipped for this test case. Data Dependency Count:");
        }
        this.contextStore.put(key, value);
    }

    public Object getAdvisoryCountValuefromContextStore(String key) {
        Object value = this.contextStore.get(key);
        if (value instanceof Integer) {
            return (Integer) value;
        } else {
            throw new IllegalArgumentException("The value in context store for key '" + key + "' is not an Integer.");
        }
    }

}
