package common;

import com.microsoft.azure.documentdb.*;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Slf4j
public class CosmosHelpers {
    private final String SelectTop1From = "SELECT top 1 * FROM ";
    private final String SelectFrom = "SELECT * FROM ";
    private final String SelectValueCount = "SELECT VALUE COUNT(1) FROM ";
    private final String SelectTop1Account = "SELECT TOP 1 c.accountId FROM ";
    private final String SelectShipmentId = "SELECT c.shipmentId FROM ";
    private final String SelectAllAccount = "SELECT c.accountId, c.isSurroundEnabled FROM ";
    private final String SelectMonitoredAccount = "SELECT c.accountId FROM ";

    CommonHelpers commonHelpers;
    DocumentClient documentClient;
    String environment;
    FeedOptions queryOptions;
    QueryParameters queryParameters;

    ConnectionPolicy policy;

    public CosmosHelpers(CommonHelpers commonHelpers) {
        this.commonHelpers = commonHelpers;
        this.environment = GenericFunction.ENV;
        this.policy = new ConnectionPolicy();
        this.queryOptions = new FeedOptions();
        this.documentClient = GetDocumentClient();
    }

    /**
     * This will create the document client based on the cosmos URI and primary key
     *
     * @return instance of the document client
     */
    public DocumentClient GetDocumentClient() {
        this.policy.setConnectionMode(ConnectionMode.Gateway);
        this.policy.setMaxPoolSize(1000);
        this.documentClient = new DocumentClient(this.GetAccountURI(), this.GetPrimaryKey(), this.policy,
                ConsistencyLevel.Session);
        return this.documentClient;
    }

    /**
     * This method will fetch the account URI of the cosmos DB based on the
     * environment selected for execution
     *
     * @return
     */
    public String GetAccountURI() {
        return GenericFunction.ReadConfigFile(this.environment + "DBURI");
    }

    /**
     * This method will return the primary key of the cosmos DB based on the
     * environment
     *
     * @return
     */
    public String GetPrimaryKey() {
        return GenericFunction.ReadConfigFile(this.environment + "PRIMARYKEY");
    }

    /**
     * This method will set the Feed options which is passed to cosmos queries
     */
    public void SetFeedOptions() {
        this.queryOptions.setPageSize(-1);
        this.queryOptions.setEnableCrossPartitionQuery(true);
    }

    /**
     * This method will query the DB and collection based on the query which is
     * passed as parameters
     *
     * @param databaseName    = Name of the database to query the documents
     * @param collectionName  = Name of the collection to query the documents
     * @param queryParameters = Query to find documents in collection
     * @return List of queried documents
     */
    public FeedResponse<Document> ReadDocumentFromDb(String databaseName, String collectionName,
                                                     QueryParameters queryParameters, String select) {
        String selectType = "";
        if (select.equalsIgnoreCase("top 1")) {
            selectType = SelectTop1From;
        } else if (select.equalsIgnoreCase("count")) {
            selectType = SelectValueCount;
        } else if (select.equalsIgnoreCase("selectAll")) {
            selectType = SelectFrom;
        } else if (select.equalsIgnoreCase("c.shipmentId")) {
            selectType = SelectShipmentId;
        } else if (select.contains("accountId")) {
            selectType = SelectMonitoredAccount;
        }

        String filterQuery = selectType + collectionName + " c " + this.FilterQueryBuilder(queryParameters.QueryParams);
        String collectionLink = String.format(Constants.DBCollectionLink, databaseName, collectionName);
        this.SetFeedOptions();
        log.info("Running SQL query..." + filterQuery);
        return this.documentClient.queryDocuments(collectionLink, filterQuery, this.queryOptions);
    }

    public FeedResponse<Document> ReadDocumentFromDbForStaticQuery(String databaseName, String collectionName,
                                                                   QueryParameters queryParameters, String select, String queryType) {
        String selectType = "";
        String staticQuery = "";
        if (select.equalsIgnoreCase("top 1 account")) {
            selectType = SelectTop1Account;
        }

        switch (queryType) {
            case "AllEnablements":
                staticQuery = Constants.AllEnablements;
                break;
            case "Monitoring":
                staticQuery = Constants.Monitoring;
                break;
            case "ExpediteMonitor":
                staticQuery = Constants.ExpediteMonitor;
                break;
            case "InterventionMonitor":
                staticQuery = Constants.InterventionMonitor;
                break;
            case "CallReceipMonitor":
                staticQuery = Constants.CallReceipMonitor;
                break;
            case "InterCallRecepMonitor":
                staticQuery = Constants.InterCallRecepMonitor;
                break;
            case "ExpeInterMonitor":
                staticQuery = Constants.ExpeInterMonitor;
                break;
            case "ExpeCallReceipMonitor":
                staticQuery = Constants.ExpeCallReceipMonitor;
                break;
        }
        String filterQuery = selectType + collectionName + " c " + staticQuery;
        String collectionLink = String.format(Constants.DBCollectionLink, databaseName, collectionName);
        this.SetFeedOptions();
        log.info("Running SQL query for query type = " + queryType + " ... " + filterQuery);
        return this.documentClient.queryDocuments(collectionLink, filterQuery, this.queryOptions);
    }

    /**
     * Create Quick View Indicator Query and get the FeedOption as response
     */
    public FeedResponse<Document> ReadDocumentFromDbCE(String databaseName, String collectionName,
                                                       QueryParameters queryParameters, String select, String parameter) {
        String selectType = "";
        String staticQuery = "";
        select = select.replaceAll("cosmos-", "");
        switch (select) {
            case "c.accountId":
                selectType = SelectAllAccount;
                staticQuery = Constants.getAllAccountForCompany + "'" + parameter + "'";
                break;

            case "OUT FOR DELIVERY":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.getoutforDelivery;
                break;

            case "IN TRANSIT":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.inProgress;
                break;

            case "AT RISK1":
                selectType = SelectFrom;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.atRisk1;
                break;

            case "AT RISK":
                selectType = SelectValueCount;
                String atRisk1Contents = (String) this.commonHelpers.getValuefromContextStore("cosmos-AT RISK1");
                staticQuery = " AND c.shipmentId IN ( " + atRisk1Contents + ") " + Constants.atRisk2;
                break;

            case "ALL EXCEPTIONS":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.allExceptions;
                break;

            case "DELIVERY EXCEPTION":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.deliveryExceptions;
                break;

            case "MONITORED":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.monitored;
                break;

            case "PRIORITY ALERT":
                selectType = SelectValueCount;
                staticQuery = " AND c.accountId in ( " + parameter + ") " + Constants.priorityAlert;
                break;

        }
        FeedOptions queryOptions = new FeedOptions();
        queryOptions.setEnableCrossPartitionQuery(true);

        String filterQuery = selectType + collectionName + " c " + this.FilterQueryBuilder(queryParameters.QueryParams)
                + staticQuery;
        String collectionLink = String.format(Constants.DBCollectionLink, databaseName, collectionName);
        this.SetFeedOptions();
        log.info("Running SQL query for query type = \n " + filterQuery);

        return this.documentClient.queryDocuments(collectionLink, filterQuery, this.queryOptions);
    }

    /**
     * This method is used to delete the documents from collection
     *
     * @param databaseName    = Name of the database in which we want to delete
     *                        docments from
     * @param collectionName  = Name of the collection in which we want to delete
     *                        docments from
     * @param queryParameters = Query to find documents in collection
     * @param partitionKey    = Container partition key
     */
    public void DeleteDocumentFromDb(String databaseName, String collectionName, QueryParameters queryParameters,
                                     String partitionKey) {
        try {
            String filterQuery = SelectFrom + collectionName + " c "
                    + this.FilterQueryBuilder(queryParameters.QueryParams);
            String collectionLink = String.format(Constants.DBCollectionLink, databaseName, collectionName);
            this.SetFeedOptions();
            log.info("Running SQL query..." + filterQuery);
            FeedResponse<Document> documents = this.documentClient.queryDocuments(collectionLink, filterQuery,
                    this.queryOptions);
            for (Document document : documents.getQueryIterable()) {
                RequestOptions requestOptions = new RequestOptions();
                requestOptions.setPartitionKey(new PartitionKey(partitionKey));
                JSONObject documentToBeDeleted = JSONHelpers.StringtoJObject(document.toString());
                String docLink = String.format(Constants.DBDocumentLink, databaseName, collectionName,
                        documentToBeDeleted.getString("id"));
                this.documentClient.deleteDocument(docLink, requestOptions);
                log.info("Successfully deleted document :" + documentToBeDeleted);
            }

        } catch (Exception ex) {
            log.info("Failed to delete document from Db. Exception : " + ex.getMessage());
        }
    }

    /**
     * This method is used to create an array of documents in provided db and
     * collection
     *
     * @param databaseName   = Name of the database in which we want to create
     *                       documents
     * @param collectionName = Name of the database in which we want to create
     *                       documents
     * @param jsonFileNames  = Array of json file need to add in DB
     */
    public void CreateDocumentToDb(String databaseName, String collectionName, String[] jsonFileNames) {
        try {
            String collectionLink = String.format(Constants.DBCollectionLink, databaseName, collectionName);
            for (String jsonFile : jsonFileNames) {
                String jsonContent = JSONHelpers.GetFileContent(jsonFile);
                this.documentClient.createDocument(collectionLink, JSONHelpers.StringtoJObject(jsonContent),
                        new RequestOptions(), true);
                log.info(String.format("Created Family %s", jsonContent));
            }

        } catch (Exception e) {
            log.error("**EXCEPTION** Failed to create document from Db. Exception : " + e.getMessage());
        }
    }

    /**
     * This method is used for buidling the cosmos query when Query parameters are
     * passed as the argument to the method
     *
     * @param queryParameters
     * @return A well formed query
     */
    public String FilterQueryBuilder(List<Pair<FilterClause, Pair<String, Object>>> queryParameters) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(queryParameters.size() > 0 ? "where" : "");
        for (Pair<FilterClause, Pair<String, Object>> arguments : queryParameters) {
            Pair<String, Object> kvp = arguments.getValue();
            if (queryParameters.indexOf(arguments) != 0 && arguments.getKey() != FilterClause.OrderBy) {
                stringBuilder.append(" and");
            }

            switch (arguments.getKey()) {
                case Default:
                    if (kvp.getValue().getClass().getTypeName().contains("String")) {
                        stringBuilder.append(" " + kvp.getKey() + "=\"" + kvp.getValue() + "\"");
                    } else if (kvp.getValue().getClass().getTypeName().contains("Boolean")) {
                        stringBuilder.append(" " + kvp.getKey() + "=" + kvp.getValue().toString().toLowerCase());
                    } else {
                        stringBuilder.append(" " + kvp.getKey() + "=" + kvp.getValue());
                    }
                    break;
                case Contains:
                    stringBuilder.append(" contains (" + kvp.getKey() + ", '" + kvp.getValue() + "')");
                    break;
                case In:
                    stringBuilder.append(" " + kvp.getKey() + " IN (" + kvp.getValue() + ")");
                    break;
                case OrderBy:
                    stringBuilder = queryParameters.size() == 1 ? new StringBuilder() : stringBuilder.append(" ");
                    stringBuilder.append("order by " + kvp.getKey());
                    break;
                default:
                    break;
            }
        }
        return stringBuilder.toString();
    }

    public QueryParameters TransformQueryParams(DataTable table) {
        Map<String, Object> params = table.asMap(String.class, Object.class);
        params = this.TransformquerytoBoolean(params);
        queryParameters = new QueryParameters();
        for (String param : params.keySet()) {
            switch (param.split("-")[0].toUpperCase()) {
                case "WHERE":
                    if (params.get(param).toString().contains("ContextStore")) {
                        this.queryParameters.AddQueryParams(FilterClause.Default, param.split("-")[1],
                                this.commonHelpers.getValuefromContextStore(params.get(param).toString()));
                    } else {
                        this.queryParameters.AddQueryParams(FilterClause.Default, param.split("-")[1],
                                params.get(param));
                    }
                    break;
                case "IN":
                    if (params.get(param).toString().contains("ContextStore")) {
                        this.queryParameters.AddQueryParams(FilterClause.In, param.split("-")[1],
                                this.TransformListtoString(params.get(param).toString()).toString());
                    } else {
                        this.queryParameters.AddQueryParams(FilterClause.In, param.split("-")[1], params.get(param));
                    }
                    break;
            }
        }
        return queryParameters;
    }

    public Map<String, Object> TransformquerytoBoolean(Map<String, Object> params) {
        Map<String, Object> temp = new HashMap();
        for (String param : params.keySet()) {
            if (params.get(param).toString().contains("Boolean")) {
                temp.put(param, Boolean.parseBoolean(params.get(param).toString().split("-")[1]));
            } else {
                temp.put(param, params.get(param));
            }
        }
        return temp;
    }

    public StringBuilder TransformListtoString(String ContextStoreKey) {
        StringBuilder sBuilder = new StringBuilder();
        if (ContextStoreKey.contains("-")) {
            List<String> accounts = Arrays
                    .asList(this.commonHelpers.getValuefromContextStore(ContextStoreKey).toString().replaceAll("'", "").split(","));
            int counter = 0;
            for (String account : accounts) {
                sBuilder.append(counter == accounts.size() - 1 ? "'" + account.replace("[", "").replace("]", "").trim() + "'" : "'" + account.replace("]", "").replace("[", "").trim() + "',");
                counter++;
            }
            log.info("Ids mapped for " + ContextStoreKey + " : " + sBuilder);
        }
        return sBuilder;
    }

    /**
     * This enums are used to form the query of the cosmos DB Default = Where
     * Contains = Contains, In = In as condtion , OrderBy = we can set by asc or
     * desc
     */
    public enum FilterClause {
        Default, Contains, In, OrderBy
    }

}
