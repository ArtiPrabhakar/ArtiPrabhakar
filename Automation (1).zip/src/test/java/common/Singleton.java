package common;

import API.RequestModels.TestCase;

import java.util.ArrayList;
import java.util.List;

public class Singleton {

    private static Singleton instance = null;
    private final List<TestCase> list;

    private Singleton() {
        list = new ArrayList<>();
    }

    // static method to create instance of Singleton class 
    public static Singleton getInstance() {
        if (instance == null)
            instance = new Singleton();

        return instance;
    }

    public void addTestCase(TestCase testCase) {
        list.add(testCase);
    }

    public List<TestCase> getTestCases() {
        return list;
    }

}
