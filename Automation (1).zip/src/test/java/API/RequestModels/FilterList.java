package API.RequestModels;

import java.util.List;

public class FilterList {

    private String field;
    private String displayField;
    private String displayText;
    private List<String> valueList;
    private String type;
    private Boolean isType;
    private Boolean isAdvanceSearch;
    private DateOptions dateOptions;
    private TimeOptions timeOptions;
    private Boolean pastOptions;

    public Boolean getIsType() {
        return isType;
    }

    public void setIsType(Boolean isType) {
        this.isType = isType;
    }

    public Boolean getIsAdvanceSearch() {
        return isAdvanceSearch;
    }

    public void setIsAdvanceSearch(Boolean isAdvanceSearch) {
        this.isAdvanceSearch = isAdvanceSearch;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getDisplayField() {
        return displayField;
    }

    public void setDisplayField(String displayField) {
        this.displayField = displayField;
    }

    public String getDisplayText() {
        return displayText;
    }

    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }

    public List<String> getValueList() {
        return valueList;
    }

    public void setValueList(List<String> valueList) {
        this.valueList = valueList;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public DateOptions getDateOptions() {
        return dateOptions;
    }

    public void setDateOptions(DateOptions dateOptions) {
        this.dateOptions = dateOptions;
    }

    public TimeOptions getTimeOptions() {
        return timeOptions;
    }

    public void setTimeOptions(TimeOptions timeOptions) {
        this.timeOptions = timeOptions;
    }

    public Boolean getPastOptions() {
        return pastOptions;
    }

    public void setPastOptions(Boolean pastOptions) {
        this.pastOptions = pastOptions;
    }

}