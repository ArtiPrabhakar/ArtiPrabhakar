package API.RequestModels;

import java.util.List;

public class Syncer {
    private List<TestCase> testCases = null;

    public List<TestCase> getTestCases() {
        return testCases;
    }

    public void setTestCases(List<TestCase> testCases) {
        this.testCases = testCases;
    }
}
