package API.RequestModels;

import net.minidev.json.JSONObject;

import java.util.List;

public class ShipmentsOverview {
    public CompanyAndAccountHierarchy companyAndAccountHierarchy;
    private List<FilterList> filterList;
    private List<SortList> sortList;
    private List<String> workgroupIdList;
    private Boolean withCredentials = true;
    private String company = null;
    private Integer currentPage;
    private Integer pageSize;
    private JSONObject data;
    private String context;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public List<FilterList> getFilterList() {
        return filterList;
    }

    public void setFilterList(List<FilterList> filterList) {
        this.filterList = filterList;
    }

    public List<SortList> getSortList() {
        return sortList;
    }

    public void setSortList(List<SortList> sortList) {
        this.sortList = sortList;
    }

    public Boolean getWithCredentials() {
        return withCredentials;
    }

    public void setWithCredentials(Boolean withCredentials) {
        this.withCredentials = withCredentials;
    }

    public CompanyAndAccountHierarchy getCompanyAndAccountHierarchy() {
        return companyAndAccountHierarchy;
    }

    public void setCompanyAndAccountHierarchy(CompanyAndAccountHierarchy companyAndAccountHierarchy2) {
        this.companyAndAccountHierarchy = companyAndAccountHierarchy2;
    }

    public void setData() {
        JSONObject obj = new JSONObject();
        this.data = obj;
    }

    public JSONObject getData() {
        return data;
    }

    public List<String> getWorkGroupIdList() {
        return workgroupIdList;
    }

    public void setWorkGroupIdList(List<String> wgList) {
        this.workgroupIdList = wgList;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }
}