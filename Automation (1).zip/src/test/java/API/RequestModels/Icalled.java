package API.RequestModels;

public class Icalled {
    private Object shipper = null;
    private Recipient recipient;
    private Object station = null;
    private Object hub = null;
    private Object dispatch = null;
    private Object coldChain = null;
    private Object sameDay = null;
    private Object other = null;

    public Object getShipper() {
        return shipper;
    }

    public void setShipper(Object shipper) {
        this.shipper = shipper;
    }

    public Recipient getRecipient() {
        return recipient;
    }

    public void setRecipient(Recipient recipient) {
        this.recipient = recipient;
    }

    public Object getStation() {
        return station;
    }

    public void setStation(Object station) {
        this.station = station;
    }

    public Object getHub() {
        return hub;
    }

    public void setHub(Object hub) {
        this.hub = hub;
    }

    public Object getDispatch() {
        return dispatch;
    }

    public void setDispatch(Object dispatch) {
        this.dispatch = dispatch;
    }

    public Object getColdChain() {
        return coldChain;
    }

    public void setColdChain(Object coldChain) {
        this.coldChain = coldChain;
    }

    public Object getSameDay() {
        return sameDay;
    }

    public void setSameDay(Object sameDay) {
        this.sameDay = sameDay;
    }

    public Object getOther() {
        return other;
    }

    public void setOther(Object other) {
        this.other = other;
    }
}
