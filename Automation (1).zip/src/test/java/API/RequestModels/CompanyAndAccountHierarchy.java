package API.RequestModels;

import java.util.List;

public class CompanyAndAccountHierarchy {

    private List<String> _15603293 = null;
    private List<String> _485741156 = null;
    private List<String> _485742173 = null;
    private List<String> _485745989 = null;
    private List<String> _485745991 = null;
    private List<String> _485749199 = null;
    private List<String> _485753302 = null;
    private List<String> _485754005 = null;
    private List<String> _487306828 = null;
    private List<String> _487391329 = null;
    private List<String> _487498888 = null;
    private List<String> _487611274 = null;
    private List<String> _487744819 = null;
    private List<String> _487787769 = null;
    private List<String> _488361650 = null;
    private List<String> _488845782 = null;
    private List<String> _489228602 = null;
    private List<String> _498152523 = null;
    private List<String> _547768362 = null;
    private List<String> _547805127 = null;
    private List<String> _548113473 = null;
    private List<String> _548125754 = null;
    private List<String> _945001317 = null;
    private List<String> _15603285 = null;
    private List<String> _15603286 = null;
    private List<String> _485746320 = null;
    private List<String> _487729027 = null;
    private List<String> _488553000 = null;
    private List<String> _535513198 = null;
    private List<String> _547793267 = null;
    private List<String> _548101873 = null;
    private List<String> _594086340 = null;
    private List<String> _735792590 = null;
    private List<String> _1560328515 = null;
    private List<String> _15603291 = null;
    private List<String> _15603292 = null;
    private List<String> _485741828 = null;
    private List<String> _485742359 = null;
    private List<String> _485746318 = null;
    private List<String> _485749219 = null;
    private List<String> _485750106 = null;
    private List<String> _488429390 = null;
    private List<String> _488592194 = null;
    private List<String> _488869928 = null;
    private List<String> _507172181 = null;
    private List<String> _547742372 = null;
    private List<String> _563404126 = null;
    private List<String> _568021877 = null;
    private List<String> _936747281 = null;
    private List<String> _937225319 = null;
    private List<String> _485741181 = null;
    private List<String> _485741808 = null;
    private List<String> _485742239 = null;
    private List<String> _485746367 = null;
    private List<String> _485749829 = null;
    private List<String> _485750469 = null;
    private List<String> _487088482 = null;
    private List<String> _488110157 = null;
    private List<String> _488235236 = null;
    private List<String> _547967511 = null;
    private List<String> _564018453 = null;
    private List<String> _606793051 = null;
    private List<String> _782892307 = null;
    private List<String> _1038371633 = null;
    private List<String> _506323887 = null;
    private List<String> _581980166 = null;
    private List<String> _223346297 = null;
    private List<String> _264243718 = null;

    public List<String> get485741181() {
        return _485741181;
    }

    public void set485741181(List<String> _485741181) {
        this._485741181 = _485741181;
    }

    public List<String> get485741808() {
        return _485741808;
    }

    public void set485741808(List<String> _485741808) {
        this._485741808 = _485741808;
    }

    public List<String> get485742239() {
        return _485742239;
    }

    public void set485742239(List<String> _485742239) {
        this._485742239 = _485742239;
    }

    public List<String> get485746367() {
        return _485746367;
    }

    public void set485746367(List<String> _485746367) {
        this._485746367 = _485746367;
    }

    public List<String> get485749829() {
        return _485749829;
    }

    public void set485749829(List<String> _485749829) {
        this._485749829 = _485749829;
    }

    public List<String> get485750469() {
        return _485750469;
    }

    public void set485750469(List<String> _485750469) {
        this._485750469 = _485750469;
    }

    public List<String> get487088482() {
        return _487088482;
    }

    public void set487088482(List<String> _487088482) {
        this._487088482 = _487088482;
    }

    public List<String> get488110157() {
        return _488110157;
    }

    public void set488110157(List<String> _488110157) {
        this._488110157 = _488110157;
    }

    public List<String> get488235236() {
        return _488235236;
    }

    public void set488235236(List<String> _488235236) {
        this._488235236 = _488235236;
    }

    public List<String> get547967511() {
        return _547967511;
    }

    public void set547967511(List<String> _547967511) {
        this._547967511 = _547967511;
    }

    public List<String> get564018453() {
        return _564018453;
    }

    public void set564018453(List<String> _564018453) {
        this._564018453 = _564018453;
    }

    public List<String> get606793051() {
        return _606793051;
    }

    public void set606793051(List<String> _606793051) {
        this._606793051 = _606793051;
    }

    public List<String> get782892307() {
        return _782892307;
    }

    public void set782892307(List<String> _782892307) {
        this._782892307 = _782892307;
    }

    public List<String> get1038371633() {
        return _1038371633;
    }

    public void set1038371633(List<String> _1038371633) {
        this._1038371633 = _1038371633;
    }

    public List<String> get15603291() {
        return _15603291;
    }

    public void set15603291(List<String> _15603291) {
        this._15603291 = _15603291;
    }

    public List<String> get15603292() {
        return _15603292;
    }

    public void set15603292(List<String> _15603292) {
        this._15603292 = _15603292;
    }

    public List<String> get485741828() {
        return _485741828;
    }

    public void set485741828(List<String> _485741828) {
        this._485741828 = _485741828;
    }

    public List<String> get485742359() {
        return _485742359;
    }

    public void set485742359(List<String> _485742359) {
        this._485742359 = _485742359;
    }

    public List<String> get485746318() {
        return _485746318;
    }

    public void set485746318(List<String> _485746318) {
        this._485746318 = _485746318;
    }

    public List<String> get485749219() {
        return _485749219;
    }

    public void set485749219(List<String> _485749219) {
        this._485749219 = _485749219;
    }

    public List<String> get485750106() {
        return _485750106;
    }

    public void set485750106(List<String> _485750106) {
        this._485750106 = _485750106;
    }

    public List<String> get488429390() {
        return _488429390;
    }

    public void set488429390(List<String> _488429390) {
        this._488429390 = _488429390;
    }

    public List<String> get488592194() {
        return _488592194;
    }

    public void set488592194(List<String> _488592194) {
        this._488592194 = _488592194;
    }

    public List<String> get488869928() {
        return _488869928;
    }

    public void set488869928(List<String> _488869928) {
        this._488869928 = _488869928;
    }

    public List<String> get507172181() {
        return _507172181;
    }

    public void set507172181(List<String> _507172181) {
        this._507172181 = _507172181;
    }

    public List<String> get547742372() {
        return _547742372;
    }

    public void set547742372(List<String> _547742372) {
        this._547742372 = _547742372;
    }

    public List<String> get563404126() {
        return _563404126;
    }

    public void set563404126(List<String> _563404126) {
        this._563404126 = _563404126;
    }

    public List<String> get568021877() {
        return _568021877;
    }

    public void set568021877(List<String> _568021877) {
        this._568021877 = _568021877;
    }

    public List<String> get936747281() {
        return _936747281;
    }

    public void set936747281(List<String> _936747281) {
        this._936747281 = _936747281;
    }

    public List<String> get937225319() {
        return _937225319;
    }

    public void set937225319(List<String> _937225319) {
        this._937225319 = _937225319;
    }

    public List<String> get15603293() {
        return _15603293;
    }

    public void set15603293(List<String> _15603293) {
        this._15603293 = _15603293;
    }

    public List<String> get485741156() {
        return _485741156;
    }

    public void set485741156(List<String> _485741156) {
        this._485741156 = _485741156;
    }

    public List<String> get485742173() {
        return _485742173;
    }

    public void set485742173(List<String> _485742173) {
        this._485742173 = _485742173;
    }

    public List<String> get485745989() {
        return _485745989;
    }

    public void set485745989(List<String> _485745989) {
        this._485745989 = _485745989;
    }

    public List<String> get485745991() {
        return _485745991;
    }

    public void set485745991(List<String> _485745991) {
        this._485745991 = _485745991;
    }

    public List<String> get485749199() {
        return _485749199;
    }

    public void set485749199(List<String> _485749199) {
        this._485749199 = _485749199;
    }

    public List<String> get485753302() {
        return _485753302;
    }

    public void set485753302(List<String> _485753302) {
        this._485753302 = _485753302;
    }

    public List<String> get485754005() {
        return _485754005;
    }

    public void set485754005(List<String> _485754005) {
        this._485754005 = _485754005;
    }

    public List<String> get487306828() {
        return _487306828;
    }

    public void set487306828(List<String> _487306828) {
        this._487306828 = _487306828;
    }

    public List<String> get487391329() {
        return _487391329;
    }

    public void set487391329(List<String> _487391329) {
        this._487391329 = _487391329;
    }

    public List<String> get487498888() {
        return _487498888;
    }

    public void set487498888(List<String> _487498888) {
        this._487498888 = _487498888;
    }

    public List<String> get487611274() {
        return _487611274;
    }

    public void set487611274(List<String> _487611274) {
        this._487611274 = _487611274;
    }

    public List<String> get487744819() {
        return _487744819;
    }

    public void set487744819(List<String> _487744819) {
        this._487744819 = _487744819;
    }

    public List<String> get487787769() {
        return _487787769;
    }

    public void set487787769(List<String> _487787769) {
        this._487787769 = _487787769;
    }

    public List<String> get488361650() {
        return _488361650;
    }

    public void set488361650(List<String> _488361650) {
        this._488361650 = _488361650;
    }

    public List<String> get488845782() {
        return _488845782;
    }

    public void set488845782(List<String> _488845782) {
        this._488845782 = _488845782;
    }

    public List<String> get489228602() {
        return _489228602;
    }

    public void set489228602(List<String> _489228602) {
        this._489228602 = _489228602;
    }

    public List<String> get498152523() {
        return _498152523;
    }

    public void set498152523(List<String> _498152523) {
        this._498152523 = _498152523;
    }

    public List<String> get547768362() {
        return _547768362;
    }

    public void set547768362(List<String> _547768362) {
        this._547768362 = _547768362;
    }

    public List<String> get547805127() {
        return _547805127;
    }

    public void set547805127(List<String> _547805127) {
        this._547805127 = _547805127;
    }

    public List<String> get548113473() {
        return _548113473;
    }

    public void set548113473(List<String> _548113473) {
        this._548113473 = _548113473;
    }

    public List<String> get548125754() {
        return _548125754;
    }

    public void set548125754(List<String> _548125754) {
        this._548125754 = _548125754;
    }

    public List<String> get945001317() {
        return _945001317;
    }

    public void set945001317(List<String> _945001317) {
        this._945001317 = _945001317;
    }

    public List<String> get15603285() {
        return _15603285;
    }

    public void set15603285(List<String> _15603285) {
        this._15603285 = _15603285;
    }

    public List<String> get15603286() {
        return _15603286;
    }

    public void set15603286(List<String> _15603286) {
        this._15603286 = _15603286;
    }

    public List<String> get485746320() {
        return _485746320;
    }

    public void set485746320(List<String> _485746320) {
        this._485746320 = _485746320;
    }

    public List<String> get487729027() {
        return _487729027;
    }

    public void set487729027(List<String> _487729027) {
        this._487729027 = _487729027;
    }

    public List<String> get488553000() {
        return _488553000;
    }

    public void set488553000(List<String> _488553000) {
        this._488553000 = _488553000;
    }

    public List<String> get535513198() {
        return _535513198;
    }

    public void set535513198(List<String> _535513198) {
        this._535513198 = _535513198;
    }

    public List<String> get547793267() {
        return _547793267;
    }

    public void set547793267(List<String> _547793267) {
        this._547793267 = _547793267;
    }

    public List<String> get548101873() {
        return _548101873;
    }

    public void set548101873(List<String> _548101873) {
        this._548101873 = _548101873;
    }

    public List<String> get594086340() {
        return _594086340;
    }

    public void set594086340(List<String> _594086340) {
        this._594086340 = _594086340;
    }

    public List<String> get735792590() {
        return _735792590;
    }

    public void set735792590(List<String> _735792590) {
        this._735792590 = _735792590;
    }

    public List<String> get1560328515() {
        return _1560328515;
    }

    public void set1560328515(List<String> _1560328515) {
        this._1560328515 = _1560328515;
    }

    public List<String> get506323887() {
        return _506323887;
    }

    public void set506323887(List<String> _506323887) {
        this._506323887 = _506323887;
    }

    public List<String> get581980166() {
        return _581980166;
    }

    public void set581980166(List<String> _581980166) {
        this._581980166 = _581980166;
    }

    public void set223346297(List<String> accountId) {
        this._223346297 = _223346297;
    }
    public List<String> get223346297() {
        return _223346297;
    }

    public void set264243718(List<String> accountId) {
        this._264243718 = _264243718;
    }
}