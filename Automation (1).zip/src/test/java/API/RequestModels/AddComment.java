package API.RequestModels;

public class AddComment {
    private String shipmentId;
    private Object documentType = null;
    private Comment comment;
    private Icalled icalled;
    private InternalComment internalComment;
    private String id;

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Object getDocumentType() {
        return documentType;
    }

    public void setDocumentType(Object documentType) {
        this.documentType = documentType;
    }

    public Comment getComment() {
        return comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
    }

    public Icalled getIcalled() {
        return icalled;
    }

    public void setIcalled(Icalled icalled) {
        this.icalled = icalled;
    }

    public InternalComment getInternalComment() {
        return internalComment;
    }

    public void setInternalComment(InternalComment internalComment) {
        this.internalComment = internalComment;
    }

}
