package API.RequestModels;

import java.util.List;

public class View {

    private Object id;
    private String name;
    private List<String> columnList = null;
    private List<SortList> sortList = null;
    private List<FilterList> filterList = null;
    private List<SearchFilterList> searchFilterList = null;
    private List<QuickViewList> quickViewList = null;
    private List<Object> columnDetailList = null;
    private Boolean defaultView;
    private Boolean shared;

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<String> columnList) {
        this.columnList = columnList;
    }

    public List<SortList> getSortList() {
        return sortList;
    }

    public void setSortList(List<SortList> sortList) {
        this.sortList = sortList;
    }

    public List<FilterList> getFilterList() {
        return filterList;
    }

    public void setFilterList(List<FilterList> filterList) {
        this.filterList = filterList;
    }

    public List<SearchFilterList> getSearchFilterList() {
        return searchFilterList;
    }

    public void setSearchFilterList(List<SearchFilterList> searchFilterList) {
        this.searchFilterList = searchFilterList;
    }

    public List<QuickViewList> getQuickViewList() {
        return quickViewList;
    }

    public void setQuickViewList(List<QuickViewList> quickViewList) {
        this.quickViewList = quickViewList;
    }

    public List<Object> getColumnDetailList() {
        return columnDetailList;
    }

    public void setColumnDetailList(List<Object> columnDetailList) {
        this.columnDetailList = columnDetailList;
    }

    public Boolean getDefaultView() {
        return defaultView;
    }

    public void setDefaultView(Boolean defaultView) {
        this.defaultView = defaultView;
    }

    public Boolean getShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

}