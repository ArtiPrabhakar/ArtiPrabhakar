package API.RequestModels;

public class InternalComment {

}
