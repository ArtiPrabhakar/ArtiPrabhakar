package API.RequestModels;

import java.util.List;

public class DefaultHierarchy {

    private CompanyAndAccountHierarchy companyAndAccountHierarchy;
    private List<Object> workgroups = null;

    public CompanyAndAccountHierarchy getCompanyAndAccountHierarchy() {
        return companyAndAccountHierarchy;
    }

    public void setCompanyAndAccountHierarchy(CompanyAndAccountHierarchy companyAndAccountHierarchy) {
        this.companyAndAccountHierarchy = companyAndAccountHierarchy;
    }

    public List<Object> getWorkgroups() {
        return workgroups;
    }

    public void setWorkgroups(List<Object> workgroups) {
        this.workgroups = workgroups;
    }

}