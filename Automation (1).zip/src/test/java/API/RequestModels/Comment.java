package API.RequestModels;

public class Comment {
    private String message;
    private Object lastUpdatedTimeStamp;
    private Object createdDateTimeStamp;
    private boolean isRepeatLastComment;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getLastUpdatedTimeStamp() {
        return lastUpdatedTimeStamp;
    }

    public void setLastUpdatedTimeStamp(Object lastUpdatedTimeStamp) {
        this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
    }

    public Object getCreatedDateTimeStamp() {
        return createdDateTimeStamp;
    }

    public void setCreatedDateTimeStamp(Object createdDateTimeStamp) {
        this.createdDateTimeStamp = createdDateTimeStamp;
    }

    public boolean getIsisRepeatLastComment() {
        return isRepeatLastComment;
    }

    public void setIsRepeatLastComment(String flag) {
        boolean flagToSet = !flag.equalsIgnoreCase("false");
        this.isRepeatLastComment = flagToSet;
    }
}
