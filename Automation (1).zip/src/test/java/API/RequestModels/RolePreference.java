package API.RequestModels;

import API.ResponseModels.DefaultImageRole;
import API.ResponseModels.SelectedImageRole;

public class RolePreference {
    private SelectedImageRole selectedImageRole;
    private DefaultImageRole defaultImageRole;

    public SelectedImageRole getSelectedImageRole() {
        return selectedImageRole;
    }

    public void setSelectedImageRole(SelectedImageRole selectedImageRole) {
        this.selectedImageRole = selectedImageRole;
    }

    public DefaultImageRole getDefaultImageRole() {
        return defaultImageRole;
    }

    public void setDefaultImageRole(DefaultImageRole defaultImageRole) {
        this.defaultImageRole = defaultImageRole;
    }
}
