package API.ResponseModels;

public class Other {
    private String callStatus;
    private String caseStatue;
    private String calledOther;
    private String caseId;

    public String getCallStatus() {
        return callStatus;
    }

    public void setCallStatus(String callStatus) {
        this.callStatus = callStatus;
    }

    public String getCaseStatue() {
        return caseStatue;
    }

    public void setCaseStatue(String caseStatue) {
        this.caseStatue = caseStatue;
    }

    public String getCalledOther() {
        return calledOther;
    }

    public void setCalledOther(String calledOther) {
        this.calledOther = calledOther;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

}
