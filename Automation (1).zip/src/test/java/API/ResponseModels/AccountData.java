package API.ResponseModels;

public class AccountData {

    private BillToAndShipperAccounts data = null;
    private String currentPageNumber = null;
    private String totalPages = null;

    public BillToAndShipperAccounts getData() {
        return data;
    }

    public void setAccounts(BillToAndShipperAccounts data) {
        this.data = data;
    }

    public String getCurrentPageNumber() {
        return currentPageNumber;
    }

    public void setCurrentPageNumber(String currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public String getTotalPageNumber() {
        return totalPages;
    }

    public void setTotalPageNumber(String totalPages) {
        this.totalPages = totalPages;
    }
}