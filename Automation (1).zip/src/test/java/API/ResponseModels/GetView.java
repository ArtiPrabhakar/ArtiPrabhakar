package API.ResponseModels;

import API.RequestModels.FilterList;
import API.RequestModels.QuickViewList;
import API.RequestModels.SearchFilterList;
import API.RequestModels.SortList;

import java.util.List;

public class GetView {

    private String id;
    private String name;
    private Object globalEntityNumber;
    private List<String> columnList;
    private List<Object> columnDetailList = null;
    private List<SortList> sortList;
    private List<FilterList> filterList;
    private List<QuickViewList> quickViewList;
    private List<SearchFilterList> searchFilterList;
    private Boolean monitoredEnabledFlag;
    private Boolean watchListEnabledFlag;
    private Boolean defaultView;
    private String imageRole;
    private String enablementType;
    private Boolean shared;
    private String userId;
    private  String viewType;
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Object> getColumnDetailList() {
        return columnDetailList;
    }

    public void setColumnDetailList(List<Object> columnDetailList) {
        this.columnDetailList = columnDetailList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getGlobalEntityNumber() {
        return globalEntityNumber;
    }

    public void setGlobalEntityNumber(Object globalEntityNumber) {
        this.globalEntityNumber = globalEntityNumber;
    }

    public List<String> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<String> columnList) {
        this.columnList = columnList;
    }

    public List<SortList> getSortList() {
        return sortList;
    }

    public void setSortList(List<SortList> sortList) {
        this.sortList = sortList;
    }

    public List<FilterList> getFilterList() {
        return filterList;
    }

    public void setFilterList(List<FilterList> filterList) {
        this.filterList = filterList;
    }

    public List<QuickViewList> getQuickViewList() {
        return quickViewList;
    }

    public void setQuickViewList(List<QuickViewList> quickViewList) {
        this.quickViewList = quickViewList;
    }

    public List<SearchFilterList> getSearchFilterList() {
        return searchFilterList;
    }

    public void setSearchFilterList(List<SearchFilterList> searchFilterList) {
        this.searchFilterList = searchFilterList;
    }

    public Boolean getMonitoredEnabledFlag() {
        return monitoredEnabledFlag;
    }

    public void setMonitoredEnabledFlag(Boolean monitoredEnabledFlag) {
        this.monitoredEnabledFlag = monitoredEnabledFlag;
    }

    public Boolean getWatchListEnabledFlag() {
        return watchListEnabledFlag;
    }

    public void setWatchListEnabledFlag(Boolean watchListEnabledFlag) {
        this.watchListEnabledFlag = watchListEnabledFlag;
    }

    public Boolean getDefaultView() {
        return defaultView;
    }

    public void setDefaultView(Boolean defaultView) {
        this.defaultView = defaultView;
    }

    public String getImageRole() {
        return imageRole;
    }

    public void setImageRole(String imageRole) {
        this.imageRole = imageRole;
    }

    public String getEnablementType() {
        return enablementType;
    }

    public void setEnablementType(String enablementType) {
        this.enablementType = enablementType;
    }

    public Boolean getShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getviewType() {
        return viewType;
    }

    public void setviewType(String id) {
        this.viewType = viewType;
    }
}
