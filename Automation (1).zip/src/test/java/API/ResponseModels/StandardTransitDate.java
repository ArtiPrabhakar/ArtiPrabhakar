package API.ResponseModels;

public class StandardTransitDate {
    private String stdTransitDate;
    private String displayStdTransitDate;

    // Getter Methods

    public String getStdTransitDate() {
        return stdTransitDate;
    }

    public void setStdTransitDate(final String stdTransitDate) {
        this.stdTransitDate = stdTransitDate;
    }

    // Setter Methods

    public String getDisplayStdTransitDate() {
        return displayStdTransitDate;
    }

    public void setDisplayStdTransitDate(final String displayStdTransitDate) {
        this.displayStdTransitDate = displayStdTransitDate;
    }
}