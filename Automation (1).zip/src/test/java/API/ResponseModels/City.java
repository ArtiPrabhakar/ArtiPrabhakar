package API.ResponseModels;

import java.util.List;

public class City {

    private String name;
    private Float latitude;
    private Float longitude;
    private String stateName;
    private Integer inbound;
    private Integer outbound;
    private Integer totalCount;
    private Object weather;
    private String zipCode;
    private String country;
    private List<CityStatus> cityStatuses = null;
    private WeatherForecasts weatherForecasts;
    private List<WeatherAlert> weatherAlerts = null;
    private Boolean weatherAffected;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getLatitude() {
        return latitude;
    }

    public void setLatitude(Float latitude) {
        this.latitude = latitude;
    }

    public Float getLongitude() {
        return longitude;
    }

    public void setLongitude(Float longitude) {
        this.longitude = longitude;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public Integer getInbound() {
        return inbound;
    }

    public void setInbound(Integer inbound) {
        this.inbound = inbound;
    }

    public Integer getOutbound() {
        return outbound;
    }

    public void setOutbound(Integer outbound) {
        this.outbound = outbound;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Object getWeather() {
        return weather;
    }

    public void setWeather(Object weather) {
        this.weather = weather;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public List<CityStatus> getCityStatuses() {
        return cityStatuses;
    }

    public void setCityStatuses(List<CityStatus> cityStatuses) {
        this.cityStatuses = cityStatuses;
    }

    public WeatherForecasts getWeatherForecasts() {
        return weatherForecasts;
    }

    public void setWeatherForecasts(WeatherForecasts weatherForecasts) {
        this.weatherForecasts = weatherForecasts;
    }

    public List<WeatherAlert> getWeatherAlerts() {
        return weatherAlerts;
    }

    public void setWeatherAlerts(List<WeatherAlert> weatherAlerts) {
        this.weatherAlerts = weatherAlerts;
    }

    public Boolean getWeatherAffected() {
        return weatherAffected;
    }

    public void setWeatherAffected(Boolean weatherAffected) {
        this.weatherAffected = weatherAffected;
    }
}