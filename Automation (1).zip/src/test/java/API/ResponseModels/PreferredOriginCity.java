package API.ResponseModels;

public class PreferredOriginCity {

    private Integer cityId;
    private String cityName;
    private String stateInitial;
    private String countryInitial;

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getStateInitial() {
        return stateInitial;
    }

    public void setStateInitial(String stateInitial) {
        this.stateInitial = stateInitial;
    }

    public String getCountryInitial() {
        return countryInitial;
    }

    public void setCountryInitial(String countryInitial) {
        this.countryInitial = countryInitial;
    }

}