package API.ResponseModels;

import java.util.List;

public class FedExAccounts {

    private List<Datum> data = null;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

}