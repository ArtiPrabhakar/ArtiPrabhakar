package API.ResponseModels;

import java.util.List;

public class RecipientAddress {
    private List<String> streetLines = null;
    private String city;
    private String stateOrProvinceCode;
    private String postalCode;
    private String countryCode;
    private boolean residential;

    // Getter Methods

    public List<String> getStreetLines() {
        return streetLines;
    }

    public void setStreetLines(final List<String> streetLines) {
        this.streetLines = streetLines;
    }

    public String getCity() {
        return city;
    }

    public void setCity(final String city) {
        this.city = city;
    }

    public String getStateOrProvinceCode() {
        return stateOrProvinceCode;
    }

    public void setStateOrProvinceCode(final String stateOrProvinceCode) {
        this.stateOrProvinceCode = stateOrProvinceCode;
    }

    // Setter Methods

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(final String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(final String countryCode) {
        this.countryCode = countryCode;
    }

    public boolean getResidential() {
        return residential;
    }

    public void setResidential(final boolean residential) {
        this.residential = residential;
    }
}