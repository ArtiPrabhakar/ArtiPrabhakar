package API.ResponseModels;

import java.util.List;

public class BillToAndShipperAccounts {

    private List<String> accounts = null;
    //private List<String> shipperAccounts = null;

    public List<String> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<String> accounts) {
        this.accounts = accounts;
    }

}