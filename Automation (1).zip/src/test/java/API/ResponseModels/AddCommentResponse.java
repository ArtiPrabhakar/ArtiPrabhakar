package API.ResponseModels;

public class AddCommentResponse {
    private String shipmentId;
    private String id;
    private Comment comment;
    private Long unixFusionMessageCreationTimestamp;
    private Long unixCommentLastUpdatedTimestamp;
    private Long unixCommentMessageCreationTimestamp;

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Comment getComment() {
        return comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
    }

    public Long getUnixFusionMessageCreationTimestamp() {
        return unixFusionMessageCreationTimestamp;
    }

    public void setUnixFusionMessageCreationTimestamp(Long unixFusionMessageCreationTimestamp) {
        this.unixFusionMessageCreationTimestamp = unixFusionMessageCreationTimestamp;
    }

    public Long getUnixCommentLastUpdatedTimestamp() {
        return unixCommentLastUpdatedTimestamp;
    }

    public void setUnixCommentLastUpdatedTimestamp(Long unixCommentLastUpdatedTimestamp) {
        this.unixCommentLastUpdatedTimestamp = unixCommentLastUpdatedTimestamp;
    }

    public Long getUnixCommentMessageCreationTimestamp() {
        return unixCommentMessageCreationTimestamp;
    }

    public void setUnixCommentMessageCreationTimestamp(Long unixCommentMessageCreationTimestamp) {
        this.unixCommentMessageCreationTimestamp = unixCommentMessageCreationTimestamp;
    }
}
