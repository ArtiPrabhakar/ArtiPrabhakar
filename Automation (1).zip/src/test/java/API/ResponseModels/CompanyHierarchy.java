package API.ResponseModels;

import java.util.List;

public class CompanyHierarchy {

    private String companyName;
    private String companyCode;
    private List<String> accountId = null;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public List<String> getAccountId() {
        return accountId;
    }

    public void setAccountId(List<String> accountId) {
        this.accountId = accountId;
    }

}
