package API.ResponseModels;

public class ShipmentRelationship {

    private String trackingNumber;
    private String relationshipTypeCode;
    private String carrier;
    private String trackIdQualifier;

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getRelationshipTypeCode() {
        return relationshipTypeCode;
    }

    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTrackIdQualifier() {
        return trackIdQualifier;
    }

    public void setTrackIdQualifier(String trackIdQualifier) {
        this.trackIdQualifier = trackIdQualifier;
    }

}
