package API.ResponseModels;

public class StandardTransitTimeWindow {
    private String displayStdTransitTimeEnd;

    // Getter Methods

    public String getDisplayStdTransitTimeEnd() {
        return displayStdTransitTimeEnd;
    }

    // Setter Methods

    public void setDisplayStdTransitTimeEnd(final String displayStdTransitTimeEnd) {
        this.displayStdTransitTimeEnd = displayStdTransitTimeEnd;
    }
}