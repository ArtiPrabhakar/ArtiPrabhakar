package API.ResponseModels;

import lombok.Data;

@Data
public class FeatureFlags {
    private boolean workgroupDataProcessorEnabled;
    private boolean preferencesMetaDataProcessorEnabled;
    private boolean senseAwareMobileEnabled;
    private boolean workGroupBulkProcessFeatureEnabled;
    private boolean productCenterBulkProcessFeatureEnabled;
    private boolean egpsOktaEnabled;
    private boolean unMaskAccountNumbersEnabled;
    private boolean sustainabilityFeatureEnabled;
    private boolean specialHandlingFeatureEnabled;
    private boolean kalturaTrainingVideosEnabled;
    private boolean weatherAdvisoryAdxReadEnabled;
    private boolean tntFeatureEnabled;
    private boolean localizationEnabled;
    private boolean scheduledDeliveryDateDestTZ;
}
