package API.ResponseModels;

public class Permissions {

}