package API.ResponseModels;

public class Accounts {
    private String accountId;
    private String surroundEligibilityType;
    private Boolean monitoring;
    private Boolean digital;
    private Boolean expedite;
    private Boolean iot;
    private Boolean onDemandCare;
    private Boolean contactRecipient;
    private Boolean onlyMonitored;
    private Boolean customerSepView;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSurroundEligibilityType() {
        return surroundEligibilityType;
    }

    public void setSurroundEligibilityType(String surroundEligibilityType) {
        this.surroundEligibilityType = surroundEligibilityType;
    }

    public Boolean getMonitoring() {
        return monitoring;
    }

    public void setMonitoring(Boolean monitoring) {
        this.monitoring = monitoring;
    }

    public Boolean getDigital() {
        return digital;
    }

    public void setDigital(Boolean digital) {
        this.digital = digital;
    }

    public Boolean getCustomerSepView() {
        return customerSepView;
    }

    public void setCustomerSepView(Boolean customerSepView) {
        this.customerSepView = customerSepView;
    }

    public Boolean getExpedite() {
        return expedite;
    }

    public void setExpedite(Boolean expedite) {
        this.expedite = expedite;
    }

    public Boolean getIot() {
        return iot;
    }

    public void setIot(Boolean iot) {
        this.iot = iot;
    }

    public Boolean getOnDemandCare() {
        return onDemandCare;
    }

    public void setOnDemandCare(Boolean onDemandCare) {
        this.onDemandCare = onDemandCare;
    }

    public Boolean getContactRecipient() {
        return contactRecipient;
    }

    public void setContactRecipient(Boolean contactRecipient) {
        this.contactRecipient = contactRecipient;
    }

    public Boolean getOnlyMonitored() {
        return onlyMonitored;
    }

    public void setOnlyMonitored(Boolean onlyMonitored) {
        this.onlyMonitored = onlyMonitored;
    }
}
