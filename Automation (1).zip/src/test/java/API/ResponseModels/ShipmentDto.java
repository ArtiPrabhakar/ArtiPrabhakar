package API.ResponseModels;

import java.util.List;

public class ShipmentDto {
    private String accountId;
    private String id;
    private String shipmentId;
    private Object trackingId;
    private String shipperAccountNumber;
    private String shippedBy;
    private String shipperAddress;
    private String shipperCity;
    private String shipperCompany;
    private String shipperCountyOrTerritory;
    private EstimatedDeliveryDate estimatedDeliveryDate;
    private String shipperName;
    private String shipperPostal;
    private String shipperState;
    private String shipperContactPhone;
    private Object addressCorrection;
    private Object appointmentDelivery;
    private Object billOfLading;
    private String billToAccount;
    private String codRemittanceNumber;
    private Object commodityInformation;
    private Object dateAttemptedDelivery;
    private String dateDelivered;
    private String deliveryTime;
    private Object departmentNumber;
    private Object departmentNumbersList;
    private Object destPieceCount;
    private String dimension;
    private Object dimensionalWtKg;
    private Object dimensionalWtLb;
    private Object direction;
    private Object documentAvailable;
    private Object doortagnumbers;
    private Object doorTagNumbersList;
    private String estimatedDeliveryDay;
    private String estimatedDeliveryTimeWindow;
    private Object edtWindowStart;
    private Object edtWindowEnd;
    private String fedExCompany;
    private String invoiceNumber;
    private List<String> invoiceNumberList = null;
    private String lastKnownLocation;
    private String masterTrackingNumber;
    private String noOfPackages;
    private Object origPieceCount;
    private String packageDelayStatus;
    private Object packageDimsCm;
    private String packageDimsIn;
    private List<History> history = null;
    private Object packageInterceptStatus;
    private String packageType;
    private Object partnerCarrierNbr;
    private Object pkgWtKg;
    private String pkgWtLbs;
    private String proofOfDeliverySignature;
    private String purchaseOrderNumber;
    private List<String> purchaseOrderNumberList = null;
    private String reference;
    private List<String> referenceList = null;
    private String relationship;
    private Object returnAuthorizationName;
    private Object returnReason;
    private Object returnToShipperTrkNo;
    private String scheduledDeliveryDate;
    private String scheduledDeliveryTimeBy;
    private String commitTimer;
    private String serviceType;
    private String shipDate;
    private Object shipperReference;
    private Object shipperReferenceList;
    private String signatureAvailable;
    private List<String> specialHandlingList = null;
    private String specialHandling;
    private String standardTransitDate;
    private String standardTransitTimeBy;
    private String status;
    private String statusCode;
    private Object statusWithDetails;
    private Object statusPrediction;
    private Object statusPredictionDetails;
    private String tendered;
    private Object terms;
    private String totalNumberOfHandlingUnits;
    private Object totalWtKg;
    private String totalWtLbs;
    private String trackingNumber;
    // private Object serviceCommitTime;
    private String deliveredTo;
    private String receivedBy;
    private Object recipAddressQty;
    private String recipAddress;
    private String recipCity;
    private String recipCompany;
    private String recipContactName;
    private String recipCountryOrTerritory;
    private String recipPostal;
    private String recipState;
    private String recipientContactNumberOrEmail;
    private String shippedTo;
    private Boolean surroundEnabled;
    private String surroundEnabledType;
    private Object shipperSurroundEligibility;
    private Object customerExceptionRequestNumber;
    private Object deliveryAttempts;
    private Object displayTotalWeight;
    private Object displayPackageWeight;
    private String packageRiskReason;
    private InterventionLog interventionLog;
    private Object interventionStatus;
    private Object interventionReason;
    private String interventionRecommendation;
    private String packageDetailedRiskReason;
    private String lastUpdatedTime;
    private List<ShipmentRelationship> shipmentRelationships = null;
    private List<MultiPieceShipment> multiPieceShipments = null;
    private String packageDimsLengthIn;
    private String packageDimsWidthIn;
    private String packageDimsHeightIn;
    private Object packageDimsLengthCm;
    private Object packageDimsWidthCm;
    private Object packageDimsHeightCm;
    private Object rma;
    private String utcOffset;
    private ShipmentSpecificExternalUrl shipmentSpecificExternalUrl;
    private ShipmentGenericExternalUrl shipmentGenericExternalUrl;
    private String fedExOriginLocation;
    private String fedExDestinationLocation;
    private Object cerIdentifier;
    private Boolean isReturnShipmentIdAvailable;
    private String senseAwareIdSerial;
    private Boolean isSenseAwareId;
    private String senseAwareIdDeviceStatuses;
    private List<ScanHistory> scanHistory;
    private List<Comment> comments = null;
    private List<Inquiry> inquiries = null;
    private String exceptionReason;
    private String cerNumbers;
    private String cerCodes;
    private String cerStatus;
    private Boolean isIntervened;
    private String coreBusinessEntitiesOriginLocationAddressCountry;
    private String coreBusinessEntitiesDestinationLocationAddressCountry;
    private String serviceDescCode;
    private String shipperRegion;
    private String recipRegion;
    private List<Object> brokerAddressLines = null;
    private List<Object> brokerCompanyTelephones = null;
    private List<Object> brokerPersonTelephones = null;
    private Boolean sepDataVisibleToCustomer;
    private Boolean onlyMonitored;
    private Boolean onlyDigital;
    private Object personalNotesMessage;
    private Object podException;
    private Object supportUpdate;
    private Object lastComment;
    private Object senseAwareJourneyId;
    private Object senseAwareIdStatus;
    private Object industryVerticalName;
    private String cerCount;
    private String scheduledDeliveryDateDestTZ;
    private String workgroups;

    public String getExceptionReason() {
        return exceptionReason;
    }

    public void setExceptionReason(String exceptionReason) {
        this.exceptionReason = exceptionReason;
    }

    public List<Inquiry> getInquiries() {
        return inquiries;
    }

    public void setInquiries(List<Inquiry> inquiries) {
        this.inquiries = inquiries;
    }

    public String getCerNumbers() {
        return cerNumbers;
    }

    public void setCerNumbers(String cerNumbers) {
        this.cerNumbers = cerNumbers;
    }

    public String getCerCodes() {
        return cerCodes;
    }

    public void setCerCodes(String cerCodes) {
        this.cerCodes = cerCodes;
    }

    public String getCerStatus() {
        return cerStatus;
    }

    public void setCerStatus(String cerStatus) {
        this.cerStatus = cerStatus;
    }

    public Boolean getIsIntervened() {
        return isIntervened;
    }

    public void setIsIntervened(Boolean isIntervened) {
        this.isIntervened = isIntervened;
    }

    public String getCoreBusinessEntitiesOriginLocationAddressCountry() {
        return coreBusinessEntitiesOriginLocationAddressCountry;
    }

    public void setCoreBusinessEntitiesOriginLocationAddressCountry(
            String coreBusinessEntitiesOriginLocationAddressCountry) {
        this.coreBusinessEntitiesOriginLocationAddressCountry = coreBusinessEntitiesOriginLocationAddressCountry;
    }

    public String getCoreBusinessEntitiesDestinationLocationAddressCountry() {
        return coreBusinessEntitiesDestinationLocationAddressCountry;
    }

    public void setCoreBusinessEntitiesDestinationLocationAddressCountry(
            String coreBusinessEntitiesDestinationLocationAddressCountry) {
        this.coreBusinessEntitiesDestinationLocationAddressCountry = coreBusinessEntitiesDestinationLocationAddressCountry;
    }

    public String getServiceDescCode() {
        return serviceDescCode;
    }

    public void setServiceDescCode(String serviceDescCode) {
        this.serviceDescCode = serviceDescCode;
    }

    public String getShipperRegion() {
        return shipperRegion;
    }

    public void setShipperRegion(String shipperRegion) {
        this.shipperRegion = shipperRegion;
    }

    public String getRecipRegion() {
        return recipRegion;
    }

    public void setRecipRegion(String recipRegion) {
        this.recipRegion = recipRegion;
    }

    public List<Object> getBrokerAddressLines() {
        return brokerAddressLines;
    }

    public void setBrokerAddressLines(List<Object> brokerAddressLines) {
        this.brokerAddressLines = brokerAddressLines;
    }

    public List<Object> getBrokerCompanyTelephones() {
        return brokerCompanyTelephones;
    }

    public void setBrokerCompanyTelephones(List<Object> brokerCompanyTelephones) {
        this.brokerCompanyTelephones = brokerCompanyTelephones;
    }

    public List<Object> getBrokerPersonTelephones() {
        return brokerPersonTelephones;
    }

    public void setBrokerPersonTelephones(List<Object> brokerPersonTelephones) {
        this.brokerPersonTelephones = brokerPersonTelephones;
    }

    public Boolean getSepDataVisibleToCustomer() {
        return sepDataVisibleToCustomer;
    }

    public void setSepDataVisibleToCustomer(Boolean sepDataVisibleToCustomer) {
        this.sepDataVisibleToCustomer = sepDataVisibleToCustomer;
    }

    public Boolean getOnlyMonitored() {
        return onlyMonitored;
    }

    public void setOnlyMonitored(Boolean onlyMonitored) {
        this.onlyMonitored = onlyMonitored;
    }

    public Boolean getOnlyDigital() {
        return onlyDigital;
    }

    public void setOnlyDigital(Boolean onlyDigital) {
        this.onlyDigital = onlyDigital;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public EstimatedDeliveryDate getEstimatedDeliveryDate() {
        return estimatedDeliveryDate;
    }

    public void setEstimatedDeliveryDate(EstimatedDeliveryDate estimatedDeliveryDate) {
        this.estimatedDeliveryDate = estimatedDeliveryDate;
    }

    public Object getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(Object trackingId) {
        this.trackingId = trackingId;
    }

    public String getShipperAccountNumber() {
        return shipperAccountNumber;
    }

    public void setShipperAccountNumber(String shipperAccountNumber) {
        this.shipperAccountNumber = shipperAccountNumber;
    }

    public String getShippedBy() {
        return shippedBy;
    }

    public void setShippedBy(String shippedBy) {
        this.shippedBy = shippedBy;
    }

    public String getShipperAddress() {
        return shipperAddress;
    }

    public void setShipperAddress(String shipperAddress) {
        this.shipperAddress = shipperAddress;
    }

    public String getShipperCity() {
        return shipperCity;
    }

    public void setShipperCity(String shipperCity) {
        this.shipperCity = shipperCity;
    }

    public Object getShipperCompany() {
        return shipperCompany;
    }

    public void setShipperCompany(String shipperCompany) {
        this.shipperCompany = shipperCompany;
    }

    public String getShipperCountyOrTerritory() {
        return shipperCountyOrTerritory;
    }

    public void setShipperCountryOrTerritory(String shipperCountryOrTerritory) {
        this.shipperCountyOrTerritory = shipperCountryOrTerritory;
    }

    public String getShipperName() {
        return shipperName;
    }

    public void setShipperName(String shipperName) {
        this.shipperName = shipperName;
    }

    public String getShipperPostal() {
        return shipperPostal;
    }

    public void setShipperPostal(String shipperPostal) {
        this.shipperPostal = shipperPostal;
    }

    public String getShipperState() {
        return shipperState;
    }

    public void setShipperState(String shipperState) {
        this.shipperState = shipperState;
    }

    public String getShipperContactPhone() {
        return shipperContactPhone;
    }

    public void setShipperContactPhone(String shipperContactPhone) {
        this.shipperContactPhone = shipperContactPhone;
    }

    public Object getAddressCorrection() {
        return addressCorrection;
    }

    public void setAddressCorrection(Object addressCorrection) {
        this.addressCorrection = addressCorrection;
    }

    public Object getAppointmentDelivery() {
        return appointmentDelivery;
    }

    public void setAppointmentDelivery(Object appointmentDelivery) {
        this.appointmentDelivery = appointmentDelivery;
    }

    public Object getBillOfLading() {
        return billOfLading;
    }

    public void setBillOfLading(Object billOfLading) {
        this.billOfLading = billOfLading;
    }

    public String getBillToAccount() {
        return billToAccount;
    }

    public void setBillToAccount(String billToAccount) {
        this.billToAccount = billToAccount;
    }

    public String getCodRemittanceNumber() {
        return codRemittanceNumber;
    }

    public void setCodRemittanceNumber(String codRemittanceNumber) {
        this.codRemittanceNumber = codRemittanceNumber;
    }

    public Object getCommodityInformation() {
        return commodityInformation;
    }

    public void setCommodityInformation(Object commodityInformation) {
        this.commodityInformation = commodityInformation;
    }

    public Object getDateAttemptedDelivery() {
        return dateAttemptedDelivery;
    }

    public void setDateAttemptedDelivery(Object dateAttemptedDelivery) {
        this.dateAttemptedDelivery = dateAttemptedDelivery;
    }

    public String getDateDelivered() {
        return dateDelivered;
    }

    public void setDateDelivered(String dateDelivered) {
        this.dateDelivered = dateDelivered;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public Object getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(Object departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public Object getDepartmentNumbersList() {
        return departmentNumbersList;
    }

    public void setDepartmentNumbersList(Object departmentNumbersList) {
        this.departmentNumbersList = departmentNumbersList;
    }

    public Object getDestPieceCount() {
        return destPieceCount;
    }

    public void setDestPieceCount(Object destPieceCount) {
        this.destPieceCount = destPieceCount;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public Object getDimensionalWtKg() {
        return dimensionalWtKg;
    }

    public void setDimensionalWtKg(Object dimensionalWtKg) {
        this.dimensionalWtKg = dimensionalWtKg;
    }

    public Object getDimensionalWtLb() {
        return dimensionalWtLb;
    }

    public void setDimensionalWtLb(Object dimensionalWtLb) {
        this.dimensionalWtLb = dimensionalWtLb;
    }

    public Object getDirection() {
        return direction;
    }

    public void setDirection(Object direction) {
        this.direction = direction;
    }

    public Object getDocumentAvailable() {
        return documentAvailable;
    }

    public void setDocumentAvailable(Object documentAvailable) {
        this.documentAvailable = documentAvailable;
    }

    public Object getDoortagnumbers() {
        return doortagnumbers;
    }

    public void setDoortagnumbers(Object doortagnumbers) {
        this.doortagnumbers = doortagnumbers;
    }

    public Object getDoorTagNumbersList() {
        return doorTagNumbersList;
    }

    public void setDoorTagNumbersList(Object doorTagNumbersList) {
        this.doorTagNumbersList = doorTagNumbersList;
    }

    public String getEstimatedDeliveryDay() {
        return estimatedDeliveryDay;
    }

    public void setEstimatedDeliveryDay(String estimatedDeliveryDay) {
        this.estimatedDeliveryDay = estimatedDeliveryDay;
    }

    public String getEstimatedDeliveryTimeWindow() {
        return estimatedDeliveryTimeWindow;
    }

    public void setEstimatedDeliveryTimeWindow(String estimatedDeliveryTimeWindow) {
        this.estimatedDeliveryTimeWindow = estimatedDeliveryTimeWindow;
    }

    public Object getEdtWindowStart() {
        return edtWindowStart;
    }

    public void setEdtWindowStart(Object edtWindowStart) {
        this.edtWindowStart = edtWindowStart;
    }

    public Object getEdtWindowEnd() {
        return edtWindowEnd;
    }

    public void setEdtWindowEnd(Object edtWindowEnd) {
        this.edtWindowEnd = edtWindowEnd;
    }

    public String getFedExCompany() {
        return fedExCompany;
    }

    public void setFedExCompany(String fedExCompany) {
        this.fedExCompany = fedExCompany;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public List<String> getInvoiceNumberList() {
        return invoiceNumberList;
    }

    public void setInvoiceNumberList(List<String> invoiceNumberList) {
        this.invoiceNumberList = invoiceNumberList;
    }

    public String getLastKnownLocation() {
        return lastKnownLocation;
    }

    public void setLastKnownLocation(String lastKnownLocation) {
        this.lastKnownLocation = lastKnownLocation;
    }

    public String getMasterTrackingNumber() {
        return masterTrackingNumber;
    }

    public void setMasterTrackingNumber(String masterTrackingNumber) {
        this.masterTrackingNumber = masterTrackingNumber;
    }

    public String getNoOfPackages() {
        return noOfPackages;
    }

    public void setNoOfPackages(String noOfPackages) {
        this.noOfPackages = noOfPackages;
    }

    public Object getOrigPieceCount() {
        return origPieceCount;
    }

    public void setOrigPieceCount(Object origPieceCount) {
        this.origPieceCount = origPieceCount;
    }

    public String getPackageDelayStatus() {
        return packageDelayStatus;
    }

    public void setPackageDelayStatus(String packageDelayStatus) {
        this.packageDelayStatus = packageDelayStatus;
    }

    public Object getPackageDimsCm() {
        return packageDimsCm;
    }

    public void setPackageDimsCm(Object packageDimsCm) {
        this.packageDimsCm = packageDimsCm;
    }

    public String getPackageDimsIn() {
        return packageDimsIn;
    }

    public void setPackageDimsIn(String packageDimsIn) {
        this.packageDimsIn = packageDimsIn;
    }

    public List<History> getHistory() {
        return history;
    }

    public void setHistory(List<History> history) {
        this.history = history;
    }

    public Object getPackageInterceptStatus() {
        return packageInterceptStatus;
    }

    public void setPackageInterceptStatus(Object packageInterceptStatus) {
        this.packageInterceptStatus = packageInterceptStatus;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public Object getPartnerCarrierNbr() {
        return partnerCarrierNbr;
    }

    public void setPartnerCarrierNbr(Object partnerCarrierNbr) {
        this.partnerCarrierNbr = partnerCarrierNbr;
    }

    public Object getPkgWtKg() {
        return pkgWtKg;
    }

    public void setPkgWtKg(Object pkgWtKg) {
        this.pkgWtKg = pkgWtKg;
    }

    public String getPkgWtLbs() {
        return pkgWtLbs;
    }

    public void setPkgWtLbs(String pkgWtLbs) {
        this.pkgWtLbs = pkgWtLbs;
    }

    public String getProofOfDeliverySignature() {
        return proofOfDeliverySignature;
    }

    public void setProofOfDeliverySignature(String proofOfDeliverySignature) {
        this.proofOfDeliverySignature = proofOfDeliverySignature;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public List<String> getPurchaseOrderNumberList() {
        return purchaseOrderNumberList;
    }

    public void setPurchaseOrderNumberList(List<String> purchaseOrderNumberList) {
        this.purchaseOrderNumberList = purchaseOrderNumberList;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public List<String> getReferenceList() {
        return referenceList;
    }

    public void setReferenceList(List<String> referenceList) {
        this.referenceList = referenceList;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public Object getReturnAuthorizationName() {
        return returnAuthorizationName;
    }

    public void setReturnAuthorizationName(Object returnAuthorizationName) {
        this.returnAuthorizationName = returnAuthorizationName;
    }

    public Object getReturnReason() {
        return returnReason;
    }

    public void setReturnReason(Object returnReason) {
        this.returnReason = returnReason;
    }

    public Object getReturnToShipperTrkNo() {
        return returnToShipperTrkNo;
    }

    public void setReturnToShipperTrkNo(Object returnToShipperTrkNo) {
        this.returnToShipperTrkNo = returnToShipperTrkNo;
    }

    public String getScheduledDeliveryDate() {
        return scheduledDeliveryDate;
    }

    public void setScheduledDeliveryDate(String scheduledDeliveryDate) {
        this.scheduledDeliveryDate = scheduledDeliveryDate;
    }

    public String getScheduledDeliveryTimeBy() {
        return scheduledDeliveryTimeBy;
    }

    public void setScheduledDeliveryTimeBy(String scheduledDeliveryTimeBy) {
        this.scheduledDeliveryTimeBy = scheduledDeliveryTimeBy;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getShipDate() {
        return shipDate;
    }

    public void setShipDate(String shipDate) {
        this.shipDate = shipDate;
    }

    public Object getShipperReference() {
        return shipperReference;
    }

    public void setShipperReference(Object shipperReference) {
        this.shipperReference = shipperReference;
    }

    public Object getShipperReferenceList() {
        return shipperReferenceList;
    }

    public void setShipperReferenceList(Object shipperReferenceList) {
        this.shipperReferenceList = shipperReferenceList;
    }

    public String getSignatureAvailable() {
        return signatureAvailable;
    }

    public void setSignatureAvailable(String signatureAvailable) {
        this.signatureAvailable = signatureAvailable;
    }

    public List<String> getSpecialHandlingList() {
        return specialHandlingList;
    }

    public void setSpecialHandlingList(List<String> specialHandlingList) {
        this.specialHandlingList = specialHandlingList;
    }

    public String getSpecialHandling() {
        return specialHandling;
    }

    public void setSpecialHandling(String specialHandling) {
        this.specialHandling = specialHandling;
    }

    public String getStandardTransitDate() {
        return standardTransitDate;
    }

    public void setStandardTransitDate(String standardTransitDate) {
        this.standardTransitDate = standardTransitDate;
    }

    public String getStandardTransitTimeBy() {
        return standardTransitTimeBy;
    }

    public void setStandardTransitTimeBy(String standardTransitTimeBy) {
        this.standardTransitTimeBy = standardTransitTimeBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public Object getStatusWithDetails() {
        return statusWithDetails;
    }

    public void setStatusWithDetails(Object statusWithDetails) {
        this.statusWithDetails = statusWithDetails;
    }

    public Object getStatusPrediction() {
        return statusPrediction;
    }

    public void setStatusPrediction(Object statusPrediction) {
        this.statusPrediction = statusPrediction;
    }

    public Object getStatusPredictionDetails() {
        return statusPredictionDetails;
    }

    public void setStatusPredictionDetails(Object statusPredictionDetails) {
        this.statusPredictionDetails = statusPredictionDetails;
    }

    public String getTendered() {
        return tendered;
    }

    public void setTendered(String tendered) {
        this.tendered = tendered;
    }

    public Object getTerms() {
        return terms;
    }

    public void setTerms(Object terms) {
        this.terms = terms;
    }

    public String getTotalNumberOfHandlingUnits() {
        return totalNumberOfHandlingUnits;
    }

    public void setTotalNumberOfHandlingUnits(String totalNumberOfHandlingUnits) {
        this.totalNumberOfHandlingUnits = totalNumberOfHandlingUnits;
    }

    public Object getTotalWtKg() {
        return totalWtKg;
    }

    public void setTotalWtKg(Object totalWtKg) {
        this.totalWtKg = totalWtKg;
    }

    public String getTotalWtLbs() {
        return totalWtLbs;
    }

    public void setTotalWtLbs(String totalWtLbs) {
        this.totalWtLbs = totalWtLbs;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    // public Object getServiceCommitTime() {
    // return serviceCommitTime;
    // }

    // public void setServiceCommitTime(Object serviceCommitTime) {
    // this.serviceCommitTime = serviceCommitTime;
    // }

    public String getDeliveredTo() {
        return deliveredTo;
    }

    public void setDeliveredTo(String deliveredTo) {
        this.deliveredTo = deliveredTo;
    }

    public String getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(String receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Object getRecipAddressQty() {
        return recipAddressQty;
    }

    public void setRecipAddressQty(Object recipAddressQty) {
        this.recipAddressQty = recipAddressQty;
    }

    public String getRecipAddress() {
        return recipAddress;
    }

    public void setRecipAddress(String recipAddress) {
        this.recipAddress = recipAddress;
    }

    public String getRecipCity() {
        return recipCity;
    }

    public void setRecipCity(String recipCity) {
        this.recipCity = recipCity;
    }

    public String getRecipCompany() {
        return recipCompany;
    }

    public void setRecipCompany(String recipCompany) {
        this.recipCompany = recipCompany;
    }

    public String getRecipContactName() {
        return recipContactName;
    }

    public void setRecipContactName(String recipContactName) {
        this.recipContactName = recipContactName;
    }

    public String getRecipCountryOrTerritory() {
        return recipCountryOrTerritory;
    }

    public void setRecipCountryOrTerritory(String recipCountryOrTerritory) {
        this.recipCountryOrTerritory = recipCountryOrTerritory;
    }

    public String getRecipPostal() {
        return recipPostal;
    }

    public void setRecipPostal(String recipPostal) {
        this.recipPostal = recipPostal;
    }

    public String getRecipState() {
        return recipState;
    }

    public void setRecipState(String recipState) {
        this.recipState = recipState;
    }

    public String getRecipientContactNumberOrEmail() {
        return recipientContactNumberOrEmail;
    }

    public void setRecipientContactNumberOrEmail(String recipientContactNumberOrEmail) {
        this.recipientContactNumberOrEmail = recipientContactNumberOrEmail;
    }

    public String getShippedTo() {
        return shippedTo;
    }

    public void setShippedTo(String shippedTo) {
        this.shippedTo = shippedTo;
    }

    public Boolean getSurroundEnabled() {
        return surroundEnabled;
    }

    public void setSurroundEnabled(Boolean surroundEnabled) {
        this.surroundEnabled = surroundEnabled;
    }

    public String getSurroundEnabledType() {
        return surroundEnabledType;
    }

    public void setSurroundEnabledType(String surroundEnabledType) {
        this.surroundEnabledType = surroundEnabledType;
    }

    public Object getShipperSurroundEligibility() {
        return shipperSurroundEligibility;
    }

    public void setShipperSurroundEligibility(Object shipperSurroundEligibility) {
        this.shipperSurroundEligibility = shipperSurroundEligibility;
    }

    public Object getCustomerExceptionRequestNumber() {
        return customerExceptionRequestNumber;
    }

    public void setCustomerExceptionRequestNumber(Object customerExceptionRequestNumber) {
        this.customerExceptionRequestNumber = customerExceptionRequestNumber;
    }

    public Object getDeliveryAttempts() {
        return deliveryAttempts;
    }

    public void setDeliveryAttempts(Object deliveryAttempts) {
        this.deliveryAttempts = deliveryAttempts;
    }

    public Object getDisplayTotalWeight() {
        return displayTotalWeight;
    }

    public void setDisplayTotalWeight(Object displayTotalWeight) {
        this.displayTotalWeight = displayTotalWeight;
    }

    public Object getDisplayPackageWeight() {
        return displayPackageWeight;
    }

    public void setDisplayPackageWeight(Object displayPackageWeight) {
        this.displayPackageWeight = displayPackageWeight;
    }

    public String getPackageRiskReason() {
        return packageRiskReason;
    }

    public void setPackageRiskReason(String packageRiskReason) {
        this.packageRiskReason = packageRiskReason;
    }

    public InterventionLog getInterventionLog() {
        return interventionLog;
    }

    public void setInterventionLog(InterventionLog interventionLog) {
        this.interventionLog = interventionLog;
    }

    public Object getInterventionStatus() {
        return interventionStatus;
    }

    public void setInterventionStatus(Object interventionStatus) {
        this.interventionStatus = interventionStatus;
    }

    public Object getInterventionReason() {
        return interventionReason;
    }

    public void setInterventionReason(Object interventionReason) {
        this.interventionReason = interventionReason;
    }

    public String getInterventionRecommendation() {
        return interventionRecommendation;
    }

    public void setInterventionRecommendation(String interventionRecommendation) {
        this.interventionRecommendation = interventionRecommendation;
    }

    public String getPackageDetailedRiskReason() {
        return packageDetailedRiskReason;
    }

    public void setPackageDetailedRiskReason(String packageDetailedRiskReason) {
        this.packageDetailedRiskReason = packageDetailedRiskReason;
    }

    public String getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(String lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public List<ShipmentRelationship> getShipmentRelationships() {
        return shipmentRelationships;
    }

    public void setShipmentRelationships(List<ShipmentRelationship> shipmentRelationships) {
        this.shipmentRelationships = shipmentRelationships;
    }

    public List<MultiPieceShipment> getMultiPieceShipments() {
        return multiPieceShipments;
    }

    public void setMultiPieceShipments(List<MultiPieceShipment> multiPieceShipments) {
        this.multiPieceShipments = multiPieceShipments;
    }

    public String getPackageDimsLengthIn() {
        return packageDimsLengthIn;
    }

    public void setPackageDimsLengthIn(String packageDimsLengthIn) {
        this.packageDimsLengthIn = packageDimsLengthIn;
    }

    public String getPackageDimsWidthIn() {
        return packageDimsWidthIn;
    }

    public void setPackageDimsWidthIn(String packageDimsWidthIn) {
        this.packageDimsWidthIn = packageDimsWidthIn;
    }

    public String getPackageDimsHeightIn() {
        return packageDimsHeightIn;
    }

    public void setPackageDimsHeightIn(String packageDimsHeightIn) {
        this.packageDimsHeightIn = packageDimsHeightIn;
    }

    public Object getPackageDimsLengthCm() {
        return packageDimsLengthCm;
    }

    public void setPackageDimsLengthCm(Object packageDimsLengthCm) {
        this.packageDimsLengthCm = packageDimsLengthCm;
    }

    public Object getPackageDimsWidthCm() {
        return packageDimsWidthCm;
    }

    public void setPackageDimsWidthCm(Object packageDimsWidthCm) {
        this.packageDimsWidthCm = packageDimsWidthCm;
    }

    public Object getPackageDimsHeightCm() {
        return packageDimsHeightCm;
    }

    public void setPackageDimsHeightCm(Object packageDimsHeightCm) {
        this.packageDimsHeightCm = packageDimsHeightCm;
    }

    public String getCommitTimer() {
        return commitTimer;
    }

    public void setCommitTimer(String commitTimer) {
        this.commitTimer = commitTimer;
    }

    public Object getRma() {
        return rma;
    }

    public void setRma(Object rma) {
        this.rma = rma;
    }

    public String getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(String utcOffset) {
        this.utcOffset = utcOffset;
    }

    public ShipmentSpecificExternalUrl getShipmentSpecificExternalUrl() {
        return shipmentSpecificExternalUrl;
    }

    public void setShipmentSpecificExternalUrl(ShipmentSpecificExternalUrl shipmentSpecificExternalUrl) {
        this.shipmentSpecificExternalUrl = shipmentSpecificExternalUrl;
    }

    public ShipmentGenericExternalUrl getShipmentGenericExternalUrl() {
        return shipmentGenericExternalUrl;
    }

    public void setShipmentGenericExternalUrl(ShipmentGenericExternalUrl shipmentGenericExternalUrl) {
        this.shipmentGenericExternalUrl = shipmentGenericExternalUrl;
    }

    public String getFedExOriginLocation() {
        return fedExOriginLocation;
    }

    public void setFedExOriginLocation(String fedExOriginLocation) {
        this.fedExOriginLocation = fedExOriginLocation;
    }

    public String getFedExDestinationLocation() {
        return fedExDestinationLocation;
    }

    public void setFedExDestinationLocation(String fedExDestinationLocation) {
        this.fedExDestinationLocation = fedExDestinationLocation;
    }

    public Object getCerIdentifier() {
        return cerIdentifier;
    }

    public void setCerIdentifier(Object cerIdentifier) {
        this.cerIdentifier = cerIdentifier;
    }

    public Boolean getIsReturnShipmentIdAvailable() {
        return isReturnShipmentIdAvailable;
    }

    public void setIsReturnShipmentIdAvailable(Boolean isReturnShipmentIdAvailable) {
        this.isReturnShipmentIdAvailable = isReturnShipmentIdAvailable;
    }

    public Boolean getIsSenseAwareId() {
        return isSenseAwareId;
    }

    public void setIsSenseAwareId(Boolean isSenseAwareId) {
        this.isSenseAwareId = isSenseAwareId;
    }

    public String getSenseAwareIdSerial() {
        return senseAwareIdSerial;
    }

    public void setSenseAwareIdSerial(String senseAwareIdSerial) {
        this.senseAwareIdSerial = senseAwareIdSerial;
    }

    public String getSenseAwareIdDeviceStatuses() {
        return senseAwareIdDeviceStatuses;
    }

    public void setSenseAwareIdDeviceStatuses(String senseAwareIdDeviceStatuses) {
        this.senseAwareIdDeviceStatuses = senseAwareIdDeviceStatuses;
    }

    public List<ScanHistory> getScanHistory() {
        return scanHistory;
    }

    public void setScanHistory(List<ScanHistory> scanHistory) {
        this.scanHistory = scanHistory;
    }

    public Object getPersonalNotesMessage() {
        return personalNotesMessage;
    }

    public void setPersonalNotesMessage(Object personalNotesMessage) {
        this.personalNotesMessage = personalNotesMessage;
    }

    public Object getPodException() {
        return podException;
    }

    public void setPodException(Object podException) {
        this.podException = podException;
    }

    public Object getSupportUpdate() {
        return supportUpdate;
    }

    public void setSupportUpdate(Object supportUpdate) {
        this.supportUpdate = supportUpdate;
    }

    public Object getLastComment() {
        return lastComment;
    }

    public void setLastComment(Object lastComment) {
        this.lastComment = lastComment;
    }

    public Object getSenseAwareJourneyId() {
        return senseAwareJourneyId;
    }

    public void setSenseAwareJourneyId(Object senseAwareJourneyId) {
        this.senseAwareJourneyId = senseAwareJourneyId;
    }

    public Object getSenseAwareIdStatus() {
        return senseAwareIdStatus;
    }

    public void setSenseAwareIdStatus(Object senseAwareIdStatus) {
        this.senseAwareIdStatus = senseAwareIdStatus;
    }

    public Object getIndustryVerticalName() {
        return industryVerticalName;
    }

    public void setIndustryVerticalName(Object industryVerticalName) {
        this.industryVerticalName = industryVerticalName;
    }

    public String getCerCount() {
        return cerCount;
    }

    public void setCerCount(String cerCount) {
        this.cerCount = cerCount;
    }

    public String getScheduledDeliveryDateDestTZ() {
        return scheduledDeliveryDateDestTZ;
    }

    public void setScheduledDeliveryDateDestTZ(String scheduledDeliveryDateDestTZ) {
        this.scheduledDeliveryDateDestTZ = scheduledDeliveryDateDestTZ;
    }

    public String getWorkgroup() {
        return workgroups;
    }

    public void setWorkgroup(String workgroups) {
        this.workgroups = workgroups;
    }

}