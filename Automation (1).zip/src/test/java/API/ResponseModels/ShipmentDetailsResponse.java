package API.ResponseModels;

import java.util.List;

public class ShipmentDetailsResponse {

    private String accountId;
    private String id;
    private String shipmentId;
    private Object trackingId;
    private String shipperAccountNumber;
    private String shippedBy;
    private String shipperAddress;
    private String shipperCity;
    private String shipperCompany;
    private String shipperCountryOrTerritory;
    private String shipperName;
    private String shipperPostal;
    private String shipperState;
    private String shipperContactPhone;
    private Object addressCorrection;
    private Object appointmentDelivery;
    private Object billOfLading;
    private String billToAccount;
    private String codRemittanceNumber;
    private String latestVesselCONS;
    private String latestFlightNumber;
    private Object commodityInformation;
    private Object damagedPackage;
    private Object dateAttemptedDelivery;
    private String dateDelivered;
    private String deliveryTime;
    private Object departmentNumber;
    private Object departmentNumbersList;
    private Object destPieceCount;
    private String dimension;
    private Object dimensionalWtKg;
    private Object dimensionalWtLb;
    private Object direction;
    private Object documentAvailable;
    private Object doortagnumbers;
    private Object doorTagNumbersList;
    private String estimatedDeliveryDay;
    private String estimatedDeliveryTimeWindow;
    private String edtWindowStart;
    private String edtWindowEnd;
    private String fedExCompany;
    private Object invoiceNumber;
    private Object invoiceNumberList;
    private String lastKnownLocation;
    private String lastKnownLocationState;
    private Object masterTrackingNumber;
    private String noOfPackages;
    private Object origPieceCount;
    private String packageDelayStatus;
    private Object packageDimsCm;
    private String packageDimsIn;
    private List<History> history = null;
    private Object packageInterceptStatus;
    private String packageType;
    private Object partnerCarrierNbr;
    private Object pkgWtKg;
    private Object pkgWtLbs;
    private Object proofOfDeliverySignature;
    private String purchaseOrderNumber;
    private List<String> purchaseOrderNumberList = null;
    private String reference;
    private List<String> referenceList = null;
    private String industryVerticalName;
    private Object relationship;
    private Object returnAuthorizationName;
    private Object returnReason;
    private Object returnToShipperTrkNo;
    private Object scheduledDeliveryDate;
    private Object scheduledDeliveryTimeBy;
    private String commitTimer;
    private String serviceType;
    private String shipDate;
    private Object shipperReference;
    private Object shipperReferenceList;
    private Object signatureAvailable;
    private List<String> specialHandlingList = null;
    private String specialHandling;
    private String standardTransitDate;
    private String standardTransitTimeBy;
    private String status;
    private String statusCode;
    private Object statusWithDetails;
    private Object statusPrediction;
    private Object statusPredictionDetails;
    private String tendered;
    private Object terms;
    private String totalNumberOfHandlingUnits;
    private Object totalWtKg;
    private Object totalWtLbs;
    private String trackingNumber;
    private Object serviceCommitTime;
    private String deliveredTo;
    private Object receivedBy;
    private Object recipAddressQty;
    private String recipAddress;
    private String recipCity;
    private String recipCompany;
    private String recipContactName;
    private String recipCountryOrTerritory;
    private String recipPostal;
    private String recipState;
    private String recipientContactNumberOrEmail;
    private String shippedTo;
    private Boolean surroundEnabled;
    private String surroundEnabledType;
    private Object shipperSurroundEligibility;
    private Object customerExceptionRequestNumber;
    private Object deliveryAttempts;
    private Object displayTotalWeight;
    private Object displayPackageWeight;
    private Object packageRiskReason;
    private InterventionLog interventionLog;
    private String interventionStatus;
    private String interventionReason;
    private String interventionRecommendation;
    private Object packageDetailedRiskReason;
    private String lastUpdatedTime;
    private List<ShipmentRelationship> shipmentRelationships = null;
    private Object multiPieceShipments;
    private String packageDimsLengthIn;
    private String packageDimsWidthIn;
    private String packageDimsHeightIn;
    private Object packageDimsLengthCm;
    private Object packageDimsWidthCm;
    private Object packageDimsHeightCm;
    private Object rma;
    private String utcOffset;
    private Object shipmentSpecificExternalUrl;
    private Object shipmentGenericExternalUrl;
    private String fedExOriginLocation;
    private String fedExDestinationLocation;
    private Object cerIdentifier;
    private Object payload;
    private List<Comment> comments = null;
    private String lastCommentOn;
    private Boolean isWatched;
    private Boolean isPayer;
    private Boolean isIntervened;
    private Boolean isShipper;
    private String returnShipment;
    private Boolean isSenseAwareId;
    private String senseAwareIdDeviceStatuses;
    private Boolean isReturnShipmentIdAvailable;
    private List<ScanHistory> scanHistory;
    private String cerNumbers;
    private String latestContainerId;
    private String latestEvent;
    private String latestScanDatetime;
    private String latestPrimaryEvent;
    private String lastKnownRamp;
    private Object lastKnownFedexFacility;
    private Object personalNotesMessage;
    private Object podException;
    private Object exceptionReason;
    private Object supportUpdate;
    private Object lastComment;
    private Object senseAwareJourneyId;
    private Object senseAwareIdStatus;
    private Object commodities;
    private String serviceDescCode;
    private String labelCreatedDate;
    private String cerCount;
    private String scheduledDeliveryDateTimeBy;
    private String coldStorageTemperatureMinC;
    private String coldStorageTemperatureMaxC;
    private String dryIceAddedKgs;
    private String dryIceAddedLbs;
    private String gelPackQuantity;
    private String scheduledDeliveryDateDestTZ;
    private Object workgroups;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Object getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(Object trackingId) {
        this.trackingId = trackingId;
    }

    public String getShipperAccountNumber() {
        return shipperAccountNumber;
    }

    public void setShipperAccountNumber(String shipperAccountNumber) {
        this.shipperAccountNumber = shipperAccountNumber;
    }

    public String getShippedBy() {
        return shippedBy;
    }

    public void setShippedBy(String shippedBy) {
        this.shippedBy = shippedBy;
    }

    public String getShipperAddress() {
        return shipperAddress;
    }

    public void setShipperAddress(String shipperAddress) {
        this.shipperAddress = shipperAddress;
    }

    public String getShipperCity() {
        return shipperCity;
    }

    public void setShipperCity(String shipperCity) {
        this.shipperCity = shipperCity;
    }

    public String getShipperCompany() {
        return shipperCompany;
    }

    public void setShipperCompany(String shipperCompany) {
        this.shipperCompany = shipperCompany;
    }

    public String getShipperCountryOrTerritory() {
        return shipperCountryOrTerritory;
    }

    public void setShipperCountryOrTerritory(String shipperCountryOrTerritory) {
        this.shipperCountryOrTerritory = shipperCountryOrTerritory;
    }

    public String getShipperName() {
        return shipperName;
    }

    public void setShipperName(String shipperName) {
        this.shipperName = shipperName;
    }

    public String getShipperPostal() {
        return shipperPostal;
    }

    public void setShipperPostal(String shipperPostal) {
        this.shipperPostal = shipperPostal;
    }

    public String getShipperState() {
        return shipperState;
    }

    public void setShipperState(String shipperState) {
        this.shipperState = shipperState;
    }

    public String getShipperContactPhone() {
        return shipperContactPhone;
    }

    public void setShipperContactPhone(String shipperContactPhone) {
        this.shipperContactPhone = shipperContactPhone;
    }

    public Object getAddressCorrection() {
        return addressCorrection;
    }

    public void setAddressCorrection(Object addressCorrection) {
        this.addressCorrection = addressCorrection;
    }

    public Object getAppointmentDelivery() {
        return appointmentDelivery;
    }

    public void setAppointmentDelivery(Object appointmentDelivery) {
        this.appointmentDelivery = appointmentDelivery;
    }

    public Object getBillOfLading() {
        return billOfLading;
    }

    public void setBillOfLading(Object billOfLading) {
        this.billOfLading = billOfLading;
    }

    public String getBillToAccount() {
        return billToAccount;
    }

    public void setBillToAccount(String billToAccount) {
        this.billToAccount = billToAccount;
    }

    public String getCodRemittanceNumber() {
        return codRemittanceNumber;
    }

    public void setCodRemittanceNumber(String codRemittanceNumber) {
        this.codRemittanceNumber = codRemittanceNumber;
    }

    public Object getCommodityInformation() {
        return commodityInformation;
    }

    public void setCommodityInformation(Object commodityInformation) {
        this.commodityInformation = commodityInformation;
    }

    public Object getCommodities() {
        return commodities;
    }

    public void setCommodities(Object commodities) {
        this.commodities = commodities;
    }

    public Object getDateAttemptedDelivery() {
        return dateAttemptedDelivery;
    }

    public void setDateAttemptedDelivery(Object dateAttemptedDelivery) {
        this.dateAttemptedDelivery = dateAttemptedDelivery;
    }

    public String getDateDelivered() {
        return dateDelivered;
    }

    public void setDateDelivered(String dateDelivered) {
        this.dateDelivered = dateDelivered;
    }

    public String getLatestVesselCONS() {
        return latestVesselCONS;
    }

    public void setLatestVesselCONS(String latestVesselCONS) {
        this.latestVesselCONS = latestVesselCONS;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public Object getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(Object departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public Object getDepartmentNumbersList() {
        return departmentNumbersList;
    }

    public void setDepartmentNumbersList(Object departmentNumbersList) {
        this.departmentNumbersList = departmentNumbersList;
    }

    public Object getDestPieceCount() {
        return destPieceCount;
    }

    public void setDestPieceCount(Object destPieceCount) {
        this.destPieceCount = destPieceCount;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public Object getDimensionalWtKg() {
        return dimensionalWtKg;
    }

    public void setDimensionalWtKg(Object dimensionalWtKg) {
        this.dimensionalWtKg = dimensionalWtKg;
    }

    public Object getDimensionalWtLb() {
        return dimensionalWtLb;
    }

    public void setDimensionalWtLb(Object dimensionalWtLb) {
        this.dimensionalWtLb = dimensionalWtLb;
    }

    public Object getDirection() {
        return direction;
    }

    public void setDirection(Object direction) {
        this.direction = direction;
    }

    public Object getDocumentAvailable() {
        return documentAvailable;
    }

    public void setDocumentAvailable(Object documentAvailable) {
        this.documentAvailable = documentAvailable;
    }

    public Object getDoortagnumbers() {
        return doortagnumbers;
    }

    public void setDoortagnumbers(Object doortagnumbers) {
        this.doortagnumbers = doortagnumbers;
    }

    public Object getDoorTagNumbersList() {
        return doorTagNumbersList;
    }

    public void setDoorTagNumbersList(Object doorTagNumbersList) {
        this.doorTagNumbersList = doorTagNumbersList;
    }

    public String getEstimatedDeliveryDay() {
        return estimatedDeliveryDay;
    }

    public void setEstimatedDeliveryDay(String estimatedDeliveryDay) {
        this.estimatedDeliveryDay = estimatedDeliveryDay;
    }

    public String getEstimatedDeliveryTimeWindow() {
        return estimatedDeliveryTimeWindow;
    }

    public void setEstimatedDeliveryTimeWindow(String estimatedDeliveryTimeWindow) {
        this.estimatedDeliveryTimeWindow = estimatedDeliveryTimeWindow;
    }

    public String getEdtWindowStart() {
        return edtWindowStart;
    }

    public void setEdtWindowStart(String edtWindowStart) {
        this.edtWindowStart = edtWindowStart;
    }

    public String getEdtWindowEnd() {
        return edtWindowEnd;
    }

    public void setEdtWindowEnd(String edtWindowEnd) {
        this.edtWindowEnd = edtWindowEnd;
    }

    public String getFedExCompany() {
        return fedExCompany;
    }

    public void setFedExCompany(String fedExCompany) {
        this.fedExCompany = fedExCompany;
    }

    public Object getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Object invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Object getInvoiceNumberList() {
        return invoiceNumberList;
    }

    public void setInvoiceNumberList(Object invoiceNumberList) {
        this.invoiceNumberList = invoiceNumberList;
    }

    public String getLastKnownLocation() {
        return lastKnownLocation;
    }

    public void setLastKnownLocation(String lastKnownLocation) {
        this.lastKnownLocation = lastKnownLocation;
    }

    public String getLastKnownLocationState() {
        return lastKnownLocationState;
    }

    public void setLastKnownLocationState(String lastKnownLocationState) {
        this.lastKnownLocationState = lastKnownLocationState;
    }

    public Object getMasterTrackingNumber() {
        return masterTrackingNumber;
    }

    public void setMasterTrackingNumber(Object masterTrackingNumber) {
        this.masterTrackingNumber = masterTrackingNumber;
    }

    public String getNoOfPackages() {
        return noOfPackages;
    }

    public void setNoOfPackages(String noOfPackages) {
        this.noOfPackages = noOfPackages;
    }

    public Object getOrigPieceCount() {
        return origPieceCount;
    }

    public void setOrigPieceCount(Object origPieceCount) {
        this.origPieceCount = origPieceCount;
    }

    public String getPackageDelayStatus() {
        return packageDelayStatus;
    }

    public void setPackageDelayStatus(String packageDelayStatus) {
        this.packageDelayStatus = packageDelayStatus;
    }

    public Object getPackageDimsCm() {
        return packageDimsCm;
    }

    public void setPackageDimsCm(Object packageDimsCm) {
        this.packageDimsCm = packageDimsCm;
    }

    public String getPackageDimsIn() {
        return packageDimsIn;
    }

    public void setPackageDimsIn(String packageDimsIn) {
        this.packageDimsIn = packageDimsIn;
    }

    public List<History> getHistory() {
        return history;
    }

    public void setHistory(List<History> history) {
        this.history = history;
    }

    public Object getPackageInterceptStatus() {
        return packageInterceptStatus;
    }

    public void setPackageInterceptStatus(Object packageInterceptStatus) {
        this.packageInterceptStatus = packageInterceptStatus;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public Object getPartnerCarrierNbr() {
        return partnerCarrierNbr;
    }

    public void setPartnerCarrierNbr(Object partnerCarrierNbr) {
        this.partnerCarrierNbr = partnerCarrierNbr;
    }

    public Object getPkgWtKg() {
        return pkgWtKg;
    }

    public void setPkgWtKg(Object pkgWtKg) {
        this.pkgWtKg = pkgWtKg;
    }

    public Object getPkgWtLbs() {
        return pkgWtLbs;
    }

    public void setPkgWtLbs(Object pkgWtLbs) {
        this.pkgWtLbs = pkgWtLbs;
    }

    public Object getProofOfDeliverySignature() {
        return proofOfDeliverySignature;
    }

    public void setProofOfDeliverySignature(Object proofOfDeliverySignature) {
        this.proofOfDeliverySignature = proofOfDeliverySignature;
    }

    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public String getLatestFlightNumber() {
        return latestFlightNumber;
    }

    public void setLatestFlightNumber(String latestFlightNumber) {
        this.latestFlightNumber = latestFlightNumber;
    }

    public List<String> getPurchaseOrderNumberList() {
        return purchaseOrderNumberList;
    }

    public void setPurchaseOrderNumberList(List<String> purchaseOrderNumberList) {
        this.purchaseOrderNumberList = purchaseOrderNumberList;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public List<String> getReferenceList() {
        return referenceList;
    }

    public void setReferenceList(List<String> referenceList) {
        this.referenceList = referenceList;
    }

    public String getIndustryVerticalName() {
        return industryVerticalName;
    }

    public void setIndustryVerticalName(String industryVerticalName) {
        this.industryVerticalName = industryVerticalName;
    }

    public Object getRelationship() {
        return relationship;
    }

    public void setRelationship(Object relationship) {
        this.relationship = relationship;
    }

    public Object getReturnAuthorizationName() {
        return returnAuthorizationName;
    }

    public void setReturnAuthorizationName(Object returnAuthorizationName) {
        this.returnAuthorizationName = returnAuthorizationName;
    }

    public Object getReturnReason() {
        return returnReason;
    }

    public void setReturnReason(Object returnReason) {
        this.returnReason = returnReason;
    }

    public Object getReturnToShipperTrkNo() {
        return returnToShipperTrkNo;
    }

    public void setReturnToShipperTrkNo(Object returnToShipperTrkNo) {
        this.returnToShipperTrkNo = returnToShipperTrkNo;
    }

    public Object getScheduledDeliveryDate() {
        return scheduledDeliveryDate;
    }

    public void setScheduledDeliveryDate(Object scheduledDeliveryDate) {
        this.scheduledDeliveryDate = scheduledDeliveryDate;
    }

    public Object getScheduledDeliveryTimeBy() {
        return scheduledDeliveryTimeBy;
    }

    public void setScheduledDeliveryTimeBy(Object scheduledDeliveryTimeBy) {
        this.scheduledDeliveryTimeBy = scheduledDeliveryTimeBy;
    }

    public String getCommitTimer() {
        return commitTimer;
    }

    public void setCommitTimer(String commitTimer) {
        this.commitTimer = commitTimer;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getShipDate() {
        return shipDate;
    }

    public void setShipDate(String shipDate) {
        this.shipDate = shipDate;
    }

    public Object getShipperReference() {
        return shipperReference;
    }

    public void setShipperReference(Object shipperReference) {
        this.shipperReference = shipperReference;
    }

    public Object getShipperReferenceList() {
        return shipperReferenceList;
    }

    public void setShipperReferenceList(Object shipperReferenceList) {
        this.shipperReferenceList = shipperReferenceList;
    }

    public Object getSignatureAvailable() {
        return signatureAvailable;
    }

    public void setSignatureAvailable(Object signatureAvailable) {
        this.signatureAvailable = signatureAvailable;
    }

    public List<String> getSpecialHandlingList() {
        return specialHandlingList;
    }

    public void setSpecialHandlingList(List<String> specialHandlingList) {
        this.specialHandlingList = specialHandlingList;
    }

    public String getSpecialHandling() {
        return specialHandling;
    }

    public void setSpecialHandling(String specialHandling) {
        this.specialHandling = specialHandling;
    }

    public String getStandardTransitDate() {
        return standardTransitDate;
    }

    public void setStandardTransitDate(String standardTransitDate) {
        this.standardTransitDate = standardTransitDate;
    }

    public String getStandardTransitTimeBy() {
        return standardTransitTimeBy;
    }

    public void setStandardTransitTimeBy(String standardTransitTimeBy) {
        this.standardTransitTimeBy = standardTransitTimeBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public Object getStatusWithDetails() {
        return statusWithDetails;
    }

    public void setStatusWithDetails(Object statusWithDetails) {
        this.statusWithDetails = statusWithDetails;
    }

    public Object getStatusPrediction() {
        return statusPrediction;
    }

    public void setStatusPrediction(Object statusPrediction) {
        this.statusPrediction = statusPrediction;
    }

    public Object getStatusPredictionDetails() {
        return statusPredictionDetails;
    }

    public void setStatusPredictionDetails(Object statusPredictionDetails) {
        this.statusPredictionDetails = statusPredictionDetails;
    }

    public String getTendered() {
        return tendered;
    }

    public void setTendered(String tendered) {
        this.tendered = tendered;
    }

    public Object getTerms() {
        return terms;
    }

    public void setTerms(Object terms) {
        this.terms = terms;
    }

    public String getTotalNumberOfHandlingUnits() {
        return totalNumberOfHandlingUnits;
    }

    public void setTotalNumberOfHandlingUnits(String totalNumberOfHandlingUnits) {
        this.totalNumberOfHandlingUnits = totalNumberOfHandlingUnits;
    }

    public Object getTotalWtKg() {
        return totalWtKg;
    }

    public void setTotalWtKg(Object totalWtKg) {
        this.totalWtKg = totalWtKg;
    }

    public Object getTotalWtLbs() {
        return totalWtLbs;
    }

    public void setTotalWtLbs(Object totalWtLbs) {
        this.totalWtLbs = totalWtLbs;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public Object getServiceCommitTime() {
        return serviceCommitTime;
    }

    public void setServiceCommitTime(Object serviceCommitTime) {
        this.serviceCommitTime = serviceCommitTime;
    }

    public String getDeliveredTo() {
        return deliveredTo;
    }

    public void setDeliveredTo(String deliveredTo) {
        this.deliveredTo = deliveredTo;
    }

    public Object getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Object receivedBy) {
        this.receivedBy = receivedBy;
    }

    public Object getRecipAddressQty() {
        return recipAddressQty;
    }

    public void setRecipAddressQty(Object recipAddressQty) {
        this.recipAddressQty = recipAddressQty;
    }

    public String getRecipAddress() {
        return recipAddress;
    }

    public void setRecipAddress(String recipAddress) {
        this.recipAddress = recipAddress;
    }

    public String getRecipCity() {
        return recipCity;
    }

    public void setRecipCity(String recipCity) {
        this.recipCity = recipCity;
    }

    public String getRecipCompany() {
        return recipCompany;
    }

    public void setRecipCompany(String recipCompany) {
        this.recipCompany = recipCompany;
    }

    public String getRecipContactName() {
        return recipContactName;
    }

    public void setRecipContactName(String recipContactName) {
        this.recipContactName = recipContactName;
    }

    public String getRecipCountryOrTerritory() {
        return recipCountryOrTerritory;
    }

    public void setRecipCountryOrTerritory(String recipCountryOrTerritory) {
        this.recipCountryOrTerritory = recipCountryOrTerritory;
    }

    public String getRecipPostal() {
        return recipPostal;
    }

    public void setRecipPostal(String recipPostal) {
        this.recipPostal = recipPostal;
    }

    public String getRecipState() {
        return recipState;
    }

    public void setRecipState(String recipState) {
        this.recipState = recipState;
    }

    public String getRecipientContactNumberOrEmail() {
        return recipientContactNumberOrEmail;
    }

    public void setRecipientContactNumberOrEmail(String recipientContactNumberOrEmail) {
        this.recipientContactNumberOrEmail = recipientContactNumberOrEmail;
    }

    public String getShippedTo() {
        return shippedTo;
    }

    public void setShippedTo(String shippedTo) {
        this.shippedTo = shippedTo;
    }

    public Boolean getSurroundEnabled() {
        return surroundEnabled;
    }

    public void setSurroundEnabled(Boolean surroundEnabled) {
        this.surroundEnabled = surroundEnabled;
    }

    public String getSurroundEnabledType() {
        return surroundEnabledType;
    }

    public void setSurroundEnabledType(String surroundEnabledType) {
        this.surroundEnabledType = surroundEnabledType;
    }

    public Object getShipperSurroundEligibility() {
        return shipperSurroundEligibility;
    }

    public void setShipperSurroundEligibility(Object shipperSurroundEligibility) {
        this.shipperSurroundEligibility = shipperSurroundEligibility;
    }

    public Object getCustomerExceptionRequestNumber() {
        return customerExceptionRequestNumber;
    }

    public void setCustomerExceptionRequestNumber(Object customerExceptionRequestNumber) {
        this.customerExceptionRequestNumber = customerExceptionRequestNumber;
    }

    public Object getDeliveryAttempts() {
        return deliveryAttempts;
    }

    public void setDeliveryAttempts(Object deliveryAttempts) {
        this.deliveryAttempts = deliveryAttempts;
    }

    public Object getDisplayTotalWeight() {
        return displayTotalWeight;
    }

    public void setDisplayTotalWeight(Object displayTotalWeight) {
        this.displayTotalWeight = displayTotalWeight;
    }

    public Object getDisplayPackageWeight() {
        return displayPackageWeight;
    }

    public void setDisplayPackageWeight(Object displayPackageWeight) {
        this.displayPackageWeight = displayPackageWeight;
    }

    public Object getPackageRiskReason() {
        return packageRiskReason;
    }

    public void setPackageRiskReason(Object packageRiskReason) {
        this.packageRiskReason = packageRiskReason;
    }

    public InterventionLog getInterventionLog() {
        return interventionLog;
    }

    public void setInterventionLog(InterventionLog interventionLog) {
        this.interventionLog = interventionLog;
    }

    public String getInterventionStatus() {
        return interventionStatus;
    }

    public void setInterventionStatus(String interventionStatus) {
        this.interventionStatus = interventionStatus;
    }

    public String getInterventionReason() {
        return interventionReason;
    }

    public void setInterventionReason(String interventionReason) {
        this.interventionReason = interventionReason;
    }

    public String getInterventionRecommendation() {
        return interventionRecommendation;
    }

    public void setInterventionRecommendation(String interventionRecommendation) {
        this.interventionRecommendation = interventionRecommendation;
    }

    public Object getPackageDetailedRiskReason() {
        return packageDetailedRiskReason;
    }

    public void setPackageDetailedRiskReason(Object packageDetailedRiskReason) {
        this.packageDetailedRiskReason = packageDetailedRiskReason;
    }

    public String getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(String lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public List<ShipmentRelationship> getShipmentRelationships() {
        return shipmentRelationships;
    }

    public void setShipmentRelationships(List<ShipmentRelationship> shipmentRelationships) {
        this.shipmentRelationships = shipmentRelationships;
    }

    public Object getMultiPieceShipments() {
        return multiPieceShipments;
    }

    public void setMultiPieceShipments(Object multiPieceShipments) {
        this.multiPieceShipments = multiPieceShipments;
    }

    public String getPackageDimsLengthIn() {
        return packageDimsLengthIn;
    }

    public void setPackageDimsLengthIn(String packageDimsLengthIn) {
        this.packageDimsLengthIn = packageDimsLengthIn;
    }

    public String getPackageDimsWidthIn() {
        return packageDimsWidthIn;
    }

    public void setPackageDimsWidthIn(String packageDimsWidthIn) {
        this.packageDimsWidthIn = packageDimsWidthIn;
    }

    public String getPackageDimsHeightIn() {
        return packageDimsHeightIn;
    }

    public void setPackageDimsHeightIn(String packageDimsHeightIn) {
        this.packageDimsHeightIn = packageDimsHeightIn;
    }

    public Object getPackageDimsLengthCm() {
        return packageDimsLengthCm;
    }

    public void setPackageDimsLengthCm(Object packageDimsLengthCm) {
        this.packageDimsLengthCm = packageDimsLengthCm;
    }

    public Object getPackageDimsWidthCm() {
        return packageDimsWidthCm;
    }

    public void setPackageDimsWidthCm(Object packageDimsWidthCm) {
        this.packageDimsWidthCm = packageDimsWidthCm;
    }

    public Object getPackageDimsHeightCm() {
        return packageDimsHeightCm;
    }

    public void setPackageDimsHeightCm(Object packageDimsHeightCm) {
        this.packageDimsHeightCm = packageDimsHeightCm;
    }

    public Object getRma() {
        return rma;
    }

    public void setRma(Object rma) {
        this.rma = rma;
    }

    public String getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(String utcOffset) {
        this.utcOffset = utcOffset;
    }

    public Object getShipmentSpecificExternalUrl() {
        return shipmentSpecificExternalUrl;
    }

    public void setShipmentSpecificExternalUrl(Object shipmentSpecificExternalUrl) {
        this.shipmentSpecificExternalUrl = shipmentSpecificExternalUrl;
    }

    public Object getShipmentGenericExternalUrl() {
        return shipmentGenericExternalUrl;
    }

    public void setShipmentGenericExternalUrl(Object shipmentGenericExternalUrl) {
        this.shipmentGenericExternalUrl = shipmentGenericExternalUrl;
    }

    public String getFedExOriginLocation() {
        return fedExOriginLocation;
    }

    public void setFedExOriginLocation(String fedExOriginLocation) {
        this.fedExOriginLocation = fedExOriginLocation;
    }

    public String getFedExDestinationLocation() {
        return fedExDestinationLocation;
    }

    public void setFedExDestinationLocation(String fedExDestinationLocation) {
        this.fedExDestinationLocation = fedExDestinationLocation;
    }

    public Object getCerIdentifier() {
        return cerIdentifier;
    }

    public void setCerIdentifier(Object cerIdentifier) {
        this.cerIdentifier = cerIdentifier;
    }

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public String getLastCommentOn() {
        return lastCommentOn;
    }

    public void setLastCommentOn(String lastCommentOn) {
        this.lastCommentOn = lastCommentOn;
    }

    public Boolean getIsWatched() {
        return isWatched;
    }

    public void setIsWatched(Boolean isWatched) {
        this.isWatched = isWatched;
    }

    public Boolean getIsPayer() {
        return isPayer;
    }

    public void setIsPayer(Boolean isPayer) {
        this.isPayer = isPayer;
    }

    public Boolean getIsIntervened() {
        return isIntervened;
    }

    public void setIsIntervened(Boolean isIntervened) {
        this.isIntervened = isIntervened;
    }

    public Boolean getIsShipper() {
        return isShipper;
    }

    public void setIsShipper(Boolean isShipper) {
        this.isShipper = isShipper;
    }

    public String getReturnShipment() {
        return returnShipment;
    }

    public void setReturnShipment(String returnShipment) {
        this.returnShipment = returnShipment;
    }

    public Boolean getIsSenseAwareId() {
        return isSenseAwareId;
    }

    public void setIsSenseAwareId(Boolean isSenseAwareId) {
        this.isSenseAwareId = isSenseAwareId;
    }

    public String getSenseAwareIdDeviceStatuses() {
        return senseAwareIdDeviceStatuses;
    }

    public void setSenseAwareIdDeviceStatuses(String senseAwareIdDeviceStatuses) {
        this.senseAwareIdDeviceStatuses = senseAwareIdDeviceStatuses;
    }

    public Boolean getisReturnShipmentIdAvailable() {
        return isReturnShipmentIdAvailable;
    }

    public void setisReturnShipmentIdAvailable(Boolean isReturnShipmentIdAvailable) {
        this.isReturnShipmentIdAvailable = isReturnShipmentIdAvailable;
    }

    public List<ScanHistory> getScanHistory() {
        return scanHistory;
    }

    public void setScanHistory(List<ScanHistory> scanHistory) {
        this.scanHistory = scanHistory;
    }

    public String getCerNumbers() {
        return cerNumbers;
    }

    public void setCerNumbers(String cerNumbers) {
        this.cerNumbers = cerNumbers;
    }

    public String getLatestContainerId() {
        return latestContainerId;
    }

    public void setLatestContainerId(String latestContainerId) {
        this.latestContainerId = latestContainerId;
    }

    public String getLatestEvent() {
        return latestEvent;
    }

    public void setLatestEvent(String latestEvent) {
        this.latestEvent = latestEvent;
    }

    public String getLatestPrimaryEvent() {
        return latestPrimaryEvent;
    }

    public void setLatestPrimaryEvent(String latestPrimaryEvent) {
        this.latestPrimaryEvent = latestPrimaryEvent;
    }

    public String getLatestScanDatetime() {
        return latestScanDatetime;
    }

    public void setLatestScanDatetime(String latestScanDatetime) {
        this.latestScanDatetime = latestScanDatetime;
    }

    public String getLastKnownRamp() {
        return lastKnownRamp;
    }

    public void setLastKnownRamp(String lastKnownRamp) {
        this.lastKnownRamp = lastKnownRamp;
    }

    public Object getLastKnownFedexFacility() {
        return lastKnownFedexFacility;
    }

    public void setLastKnownFedexFacility(Object lastKnownFedexFacility) {
        this.lastKnownFedexFacility = lastKnownFedexFacility;
    }

    public Object getDamagedPackage() {
        return damagedPackage;
    }

    public void setDamagedPackage(Object damagedPackage) {
        this.damagedPackage = damagedPackage;
    }

    public Object getPersonalNotesMessage() {
        return personalNotesMessage;
    }

    public void setPersonalNotesMessage(Object personalNotesMessage) {
        this.personalNotesMessage = personalNotesMessage;
    }

    public Object getPodException() {
        return podException;
    }

    public void setPodException(Object podException) {
        this.podException = podException;
    }

    public Object getExceptionReason() {
        return exceptionReason;
    }

    public void setExceptionReason(Object exceptionReason) {
        this.exceptionReason = exceptionReason;
    }

    public Object getSupportUpdate() {
        return supportUpdate;
    }

    public void setSupportUpdate(Object supportUpdate) {
        this.supportUpdate = supportUpdate;
    }

    public Object getLastComment() {
        return lastComment;
    }

    public void setLastComment(Object lastComment) {
        this.lastComment = lastComment;
    }

    public Object getSenseAwareJourneyId() {
        return senseAwareJourneyId;
    }

    public void setSenseAwareJourneyId(Object senseAwareJourneyId) {
        this.senseAwareJourneyId = senseAwareJourneyId;
    }

    public Object getSenseAwareIdStatus() {
        return senseAwareIdStatus;
    }

    public void setSenseAwareIdStatus(Object senseAwareIdStatus) {
        this.senseAwareIdStatus = senseAwareIdStatus;
    }

    public Object getServiceDescCode() {
        return serviceDescCode;
    }

    public void setServiceDescCode(String serviceDescCode) {
        this.serviceDescCode = serviceDescCode;
    }

    public Object getlabelCreatedDate() {
        return labelCreatedDate;
    }

    public void setlabelCreatedDate(String labelCreatedDate) {
        this.labelCreatedDate = labelCreatedDate;
    }

    public String getCerCount() {
        return cerCount;
    }

    public void setCerCount(String cerCount) {
        this.cerCount = cerCount;
    }

    public String getScheduledDeliveryDateTimeBy() {
        return scheduledDeliveryDateTimeBy;
    }

    public void setScheduledDeliveryDateTimeBy(String scheduledDeliveryDateTimeBy) {
        this.scheduledDeliveryDateTimeBy = scheduledDeliveryDateTimeBy;
    }

    public String getColdStorageTemperatureMinC() {
        return coldStorageTemperatureMinC;
    }

    public void setColdStorageTemperatureMinC(String coldStorageTemperatureMinC) {
        this.coldStorageTemperatureMinC = coldStorageTemperatureMinC;
    }

    public String getColdStorageTemperatureMaxC() {
        return coldStorageTemperatureMaxC;
    }

    public void setColdStorageTemperatureMaxC(String coldStorageTemperatureMaxC) {
        this.coldStorageTemperatureMaxC = coldStorageTemperatureMaxC;
    }

    public String getDryIceAddedKgs() {
        return dryIceAddedKgs;
    }

    public void setDryIceAddedKgs(String dryIceAddedKgs) {
        this.dryIceAddedKgs = dryIceAddedKgs;
    }

    public String getDryIceAddedLbs() {
        return dryIceAddedLbs;
    }

    public void setDryIceAddedLbs(String dryIceAddedLbs) {
        this.dryIceAddedLbs = dryIceAddedLbs;
    }

    public String getGelPackQuantity() {
        return gelPackQuantity;
    }

    public void setGelPackQuantity(String gelPackQuantity) {
        this.gelPackQuantity = gelPackQuantity;
    }

    public String getScheduledDeliveryDateDestTZ() {
        return scheduledDeliveryDateDestTZ;
    }

    public void setScheduledDeliveryDateDestTZ(String scheduledDeliveryDateDestTZ) {
        this.scheduledDeliveryDateDestTZ = scheduledDeliveryDateDestTZ;
    }

    public Object getWorkgroup() {
        return workgroups;
    }

    public void setWorkgroup(Object workgroups) {
        this.workgroups = workgroups;
    }

}