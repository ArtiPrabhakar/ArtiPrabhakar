package API.ResponseModels;

import java.util.List;

public class OverallAlert {

    private String id;
    private Integer totalShipments;
    private Integer weatherImpacted;
    private Integer inbound;
    private Integer outbound;
    private Integer onTime;
    private Integer delayed;
    private Integer atRisk;
    private Integer intercepted;
    private List<Country> countries = null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getTotalShipments() {
        return totalShipments;
    }

    public void setTotalShipments(Integer totalShipments) {
        this.totalShipments = totalShipments;
    }

    public Integer getWeatherImpacted() {
        return weatherImpacted;
    }

    public void setWeatherImpacted(Integer weatherImpacted) {
        this.weatherImpacted = weatherImpacted;
    }

    public Integer getInbound() {
        return inbound;
    }

    public void setInbound(Integer inbound) {
        this.inbound = inbound;
    }

    public Integer getOutbound() {
        return outbound;
    }

    public void setOutbound(Integer outbound) {
        this.outbound = outbound;
    }

    public Integer getOnTime() {
        return onTime;
    }

    public void setOnTime(Integer onTime) {
        this.onTime = onTime;
    }

    public Integer getDelayed() {
        return delayed;
    }

    public void setDelayed(Integer delayed) {
        this.delayed = delayed;
    }

    public Integer getAtRisk() {
        return atRisk;
    }

    public void setAtRisk(Integer atRisk) {
        this.atRisk = atRisk;
    }

    public Integer getIntercepted() {
        return intercepted;
    }

    public void setIntercepted(Integer intercepted) {
        this.intercepted = intercepted;
    }

    public List<Country> getCountries() {
        return countries;
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }
}