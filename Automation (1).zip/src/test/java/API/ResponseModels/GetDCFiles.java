package API.ResponseModels;
public class GetDCFiles {

    private String fileFormat;
    private String fileName;
    private Object globalEntityNumber;
    private Object lastDownloadDateTime;
    private Object statusMessage;
    private String fileSizeInBytes;
    private String requestDateTime;
    private String requestStatus;
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

     public String getfileFormat() {
        return fileFormat;
    }

    public void setfileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

      public String getfileName() {
        return fileName;
    }

    public void setfileName(String fileName) {
        this.fileName = fileName;
    }

    public String getfileSizeInBytes() {
        return fileSizeInBytes;
    }

    public void setfileSizeInBytes(String fileSizeInBytes) {
        this.fileSizeInBytes = fileSizeInBytes;
    }

     public String getrequestDateTime() {
        return requestDateTime;
    }

    public void setrequestDateTime(String requestDateTime) {
        this.requestDateTime = requestDateTime;
    }
public String getrequestStatus() {
        return requestStatus;
    }

    public void setrequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }
    public Object getGlobalEntityNumber() {
        return globalEntityNumber;
    }

    public void setGlobalEntityNumber(Object globalEntityNumber) {
        this.globalEntityNumber = globalEntityNumber;
    }

    public Object getlastDownloadDateTime() {
        return lastDownloadDateTime;
    }

    public void setlastDownloadDateTime(Object lastDownloadDateTime) {
        this.lastDownloadDateTime = lastDownloadDateTime;
    }


    public Object getstatusMessage() {
        return statusMessage;
    }

    public void setstatusMessage(Object statusMessage) {
        this.statusMessage = statusMessage;
    }

}
