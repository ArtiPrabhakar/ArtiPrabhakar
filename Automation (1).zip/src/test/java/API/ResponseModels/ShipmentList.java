package API.ResponseModels;

import java.util.List;

public class ShipmentList {
    private Integer totalRecords;
    private Integer totalFilteredRecords;
    private List<ShipmentDetailsResponse> data = null;
    private String continuationToken;

    public Integer getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(Integer totalRecords) {
        this.totalRecords = totalRecords;
    }

    public Integer getTotalFilteredRecords() {
        return totalFilteredRecords;
    }

    public void setTotalFilteredRecords(Integer totalFilteredRecords) {
        this.totalFilteredRecords = totalFilteredRecords;
    }

    public List<ShipmentDetailsResponse> getData() {
        return data;
    }

    public void setData(List<ShipmentDetailsResponse> data) {
        this.data = data;
    }

    public String getContinuationToken() {
        return continuationToken;
    }

    public void setContinuationToken(String continuationToken) {
        this.continuationToken = continuationToken;
    }
}