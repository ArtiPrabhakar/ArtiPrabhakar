package API.ResponseModels;

import java.util.List;

public class Output {
    private UserProfile userProfile;
    private String uniqueKey;
    private String userLoginName;
    private String userFirstName;
    private String userContactName;
    private String userEmail;
    private String userLastActivityDate;
    private String userPackageNameKey;
    private String needsToAcceptTerms;
    private String userKey;
    private String hasSingletonUpdatesInPast60Days;
    private String hasMatchedIn23Days;
    private String isFullInSightUser;
    private String isAdvanceNotice;
    private String isLargeUserType;
    private String isExtraordinaryUserType;
    private String isPackageRevoked;
    private String isUserLockedOut;
    private String estimatedShipmentTotal;
    private String isDvxCust;
    private String isPriorityAlert;
    private String tzcode;
    private String isSurroundCustomer;
    private List<CustomerAccountList> customerAccountList = null;
    private LoginCookieOutputVO loginCookieOutputVO;

    public LoginCookieOutputVO getLoginCookieOutputVO() {
        return loginCookieOutputVO;
    }

    public void setLoginCookieOutputVO(LoginCookieOutputVO loginCookieOutputVO) {
        this.loginCookieOutputVO = loginCookieOutputVO;
    }

    public List<CustomerAccountList> getCustomerAccountList() {
        return customerAccountList;
    }

    public void setCustomerAccountList(List<CustomerAccountList> customerAccountList) {
        this.customerAccountList = customerAccountList;
    }

    public String getUniqueKey() {
        return uniqueKey;
    }

    public void setUniqueKey(String uniqueKey) {
        this.uniqueKey = uniqueKey;
    }

    public String getUserLoginName() {
        return userLoginName;
    }

    public void setUserLoginName(String userLoginName) {
        this.userLoginName = userLoginName;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserContactName() {
        return userContactName;
    }

    public void setUserContactName(String userContactName) {
        this.userContactName = userContactName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserLastActivityDate() {
        return userLastActivityDate;
    }

    public void setUserLastActivityDate(String userLastActivityDate) {
        this.userLastActivityDate = userLastActivityDate;
    }

    public String getUserPackageNameKey() {
        return userPackageNameKey;
    }

    public void setUserPackageNameKey(String userPackageNameKey) {
        this.userPackageNameKey = userPackageNameKey;
    }

    public String getNeedsToAcceptTerms() {
        return needsToAcceptTerms;
    }

    public void setNeedsToAcceptTerms(String needsToAcceptTerms) {
        this.needsToAcceptTerms = needsToAcceptTerms;
    }

    public String getUserKey() {
        return userKey;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getHasSingletonUpdatesInPast60Days() {
        return hasSingletonUpdatesInPast60Days;
    }

    public void setHasSingletonUpdatesInPast60Days(String hasSingletonUpdatesInPast60Days) {
        this.hasSingletonUpdatesInPast60Days = hasSingletonUpdatesInPast60Days;
    }

    public String getHasMatchedIn23Days() {
        return hasMatchedIn23Days;
    }

    public void setHasMatchedIn23Days(String hasMatchedIn23Days) {
        this.hasMatchedIn23Days = hasMatchedIn23Days;
    }

    public String getIsFullInSightUser() {
        return isFullInSightUser;
    }

    public void setIsFullInSightUser(String isFullInSightUser) {
        this.isFullInSightUser = isFullInSightUser;
    }

    public String getIsAdvanceNotice() {
        return isAdvanceNotice;
    }

    public void setIsAdvanceNotice(String isAdvanceNotice) {
        this.isAdvanceNotice = isAdvanceNotice;
    }

    public String getIsLargeUserType() {
        return isLargeUserType;
    }

    public void setIsLargeUserType(String isLargeUserType) {
        this.isLargeUserType = isLargeUserType;
    }

    public String getIsExtraordinaryUserType() {
        return isExtraordinaryUserType;
    }

    public void setIsExtraordinaryUserType(String isExtraordinaryUserType) {
        this.isExtraordinaryUserType = isExtraordinaryUserType;
    }

    public String getIsPackageRevoked() {
        return isPackageRevoked;
    }

    public void setIsPackageRevoked(String isPackageRevoked) {
        this.isPackageRevoked = isPackageRevoked;
    }

    public String getIsUserLockedOut() {
        return isUserLockedOut;
    }

    public void setIsUserLockedOut(String isUserLockedOut) {
        this.isUserLockedOut = isUserLockedOut;
    }

    public String getEstimatedShipmentTotal() {
        return estimatedShipmentTotal;
    }

    public void setEstimatedShipmentTotal(String estimatedShipmentTotal) {
        this.estimatedShipmentTotal = estimatedShipmentTotal;
    }

    public String getIsDvxCust() {
        return isDvxCust;
    }

    public void setIsDvxCust(String isDvxCust) {
        this.isDvxCust = isDvxCust;
    }

    public String getIsPriorityAlert() {
        return isPriorityAlert;
    }

    public void setIsPriorityAlert(String isPriorityAlert) {
        this.isPriorityAlert = isPriorityAlert;
    }

    public String getTzcode() {
        return tzcode;
    }

    public void setTzcode(String tzcode) {
        this.tzcode = tzcode;
    }

    public String getIsSurroundCustomer() {
        return isSurroundCustomer;
    }

    public void setIsSurroundCustomer(String isSurroundCustomer) {
        this.isSurroundCustomer = isSurroundCustomer;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
}