package API.ResponseModels;

import java.util.List;

public class UserProfile {
    private Boolean profileLocked;
    private LoginInformation loginInformation;
    private UserProfileAddress userProfileAddress;
    private RegisteredContactAndAddress registeredContactAndAddress;
    private Boolean isManaged;
    private DefaultAccount defaultAccount;
    private Customer customer;
    private List<ExpandedAccount> expandedAccounts = null;
    private SiteWideProfile siteWideProfile;

    public RegisteredContactAndAddress getRegisteredContactAndAddress() {
        return registeredContactAndAddress;
    }

    public void setRegisteredContactAndAddress(RegisteredContactAndAddress registeredContactAndAddress) {
        this.registeredContactAndAddress = registeredContactAndAddress;
    }

    public Boolean getIsManaged() {
        return isManaged;
    }

    public void setIsManaged(Boolean isManaged) {
        this.isManaged = isManaged;
    }

    public DefaultAccount getDefaultAccount() {
        return defaultAccount;
    }

    public void setDefaultAccount(DefaultAccount defaultAccount) {
        this.defaultAccount = defaultAccount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<ExpandedAccount> getExpandedAccounts() {
        return expandedAccounts;
    }

    public void setExpandedAccounts(List<ExpandedAccount> expandedAccounts) {
        this.expandedAccounts = expandedAccounts;
    }

    public SiteWideProfile getSiteWideProfile() {
        return siteWideProfile;
    }

    public void setSiteWideProfile(SiteWideProfile siteWideProfile) {
        this.siteWideProfile = siteWideProfile;
    }

    public Boolean getProfileLocked() {
        return profileLocked;
    }

    public void setProfileLocked(Boolean profileLocked) {
        this.profileLocked = profileLocked;
    }

    public LoginInformation getLoginInformation() {
        return loginInformation;
    }

    public void setLoginInformation(LoginInformation loginInformation) {
        this.loginInformation = loginInformation;
    }

    public UserProfileAddress getUserProfileAddress() {
        return userProfileAddress;
    }

    public void setUserProfileAddress(UserProfileAddress userProfileAddress) {
        this.userProfileAddress = userProfileAddress;
    }
}