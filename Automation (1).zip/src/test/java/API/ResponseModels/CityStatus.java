package API.ResponseModels;

public class CityStatus {

    private String status;
    private Integer inbound;
    private Integer outbound;
    private Integer totalCount;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getInbound() {
        return inbound;
    }

    public void setInbound(Integer inbound) {
        this.inbound = inbound;
    }

    public Integer getOutbound() {
        return outbound;
    }

    public void setOutbound(Integer outbound) {
        this.outbound = outbound;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
