package API.ResponseModels;

public class Day {

    private Boolean hasPrecipitation;
    private Integer icon;
    private String iconPhrase;
    private Object precipitationIntensity;
    private Object precipitationType;

    public Boolean getHasPrecipitation() {
        return hasPrecipitation;
    }

    public void setHasPrecipitation(Boolean hasPrecipitation) {
        this.hasPrecipitation = hasPrecipitation;
    }

    public Integer getIcon() {
        return icon;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    public String getIconPhrase() {
        return iconPhrase;
    }

    public void setIconPhrase(String iconPhrase) {
        this.iconPhrase = iconPhrase;
    }

    public Object getPrecipitationIntensity() {
        return precipitationIntensity;
    }

    public void setPrecipitationIntensity(Object precipitationIntensity) {
        this.precipitationIntensity = precipitationIntensity;
    }

    public Object getPrecipitationType() {
        return precipitationType;
    }

    public void setPrecipitationType(Object precipitationType) {
        this.precipitationType = precipitationType;
    }

}