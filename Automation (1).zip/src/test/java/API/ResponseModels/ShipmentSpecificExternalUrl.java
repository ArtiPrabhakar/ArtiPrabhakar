package API.ResponseModels;

public class ShipmentSpecificExternalUrl {

    private String senseAwareIdDasboardURL;
    private String caseManagementFieldClientURL;
    private String eopsURL;

    public String getSenseAwareIdDasboardURL() {
        return senseAwareIdDasboardURL;
    }

    public void setSenseAwareIdDasboardURL(String senseAwareIdDasboardURL) {
        this.senseAwareIdDasboardURL = senseAwareIdDasboardURL;
    }

    public String getCaseManagementFieldClientURL() {
        return caseManagementFieldClientURL;
    }

    public void setCaseManagementFieldClientURL(String caseManagementFieldClientURL) {
        this.caseManagementFieldClientURL = caseManagementFieldClientURL;
    }

    public String getEopsURL() {
        return eopsURL;
    }

    public void setEopsURL(String eopsURL) {
        this.eopsURL = eopsURL;
    }

}
