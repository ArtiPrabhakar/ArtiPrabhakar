package API.ResponseModels;

public class Customer {
    private Boolean cashOnly;
    private Boolean creditCardUpdateBlocked;
    private Boolean ukdomesticAllowed;

    public Boolean getCashOnly() {
        return cashOnly;
    }

    public void setCashOnly(Boolean cashOnly) {
        this.cashOnly = cashOnly;
    }

    public Boolean getCreditCardUpdateBlocked() {
        return creditCardUpdateBlocked;
    }

    public void setCreditCardUpdateBlocked(Boolean creditCardUpdateBlocked) {
        this.creditCardUpdateBlocked = creditCardUpdateBlocked;
    }

    public Boolean getUkdomesticAllowed() {
        return ukdomesticAllowed;
    }

    public void setUkdomesticAllowed(Boolean ukdomesticAllowed) {
        this.ukdomesticAllowed = ukdomesticAllowed;
    }
}
