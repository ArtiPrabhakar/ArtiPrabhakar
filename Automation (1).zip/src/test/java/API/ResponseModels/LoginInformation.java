package API.ResponseModels;

public class LoginInformation {
    private String userId;
    private SecretQuestion secretQuestion;
    private Boolean emailAsUserId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public SecretQuestion getSecretQuestion() {
        return secretQuestion;
    }

    public void setSecretQuestion(SecretQuestion secretQuestion) {
        this.secretQuestion = secretQuestion;
    }

    public Boolean getEmailAsUserId() {
        return emailAsUserId;
    }

    public void setEmailAsUserId(Boolean emailAsUserId) {
        this.emailAsUserId = emailAsUserId;
    }

}