package API.ResponseModels;

import java.util.List;

public class CustomerAccountList {
    private Account account;
    private List<ActiveAppRoleInfo> activeAppRoleInfos = null;

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public List<ActiveAppRoleInfo> getActiveAppRoleInfos() {
        return activeAppRoleInfos;
    }

    public void setActiveAppRoleInfos(List<ActiveAppRoleInfo> activeAppRoleInfos) {
        this.activeAppRoleInfos = activeAppRoleInfos;
    }
}
