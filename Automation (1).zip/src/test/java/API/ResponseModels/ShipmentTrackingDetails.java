package API.ResponseModels;

public class ShipmentTrackingDetails {
    TrackingApiDto TrackingApiDtoObject;
    ShipmentDto ShipmentDtoObject;

    // Getter Methods

    public TrackingApiDto getTrackingApiDto() {
        return TrackingApiDtoObject;
    }

    public void setTrackingApiDto(final TrackingApiDto trackingApiDtoObject) {
        this.TrackingApiDtoObject = trackingApiDtoObject;
    }

    // Setter Methods

    public ShipmentDto getShipmentDto() {
        return ShipmentDtoObject;
    }

    public void setShipmentDto(final ShipmentDto shipmentDtoObject) {
        this.ShipmentDtoObject = shipmentDtoObject;
    }
}






