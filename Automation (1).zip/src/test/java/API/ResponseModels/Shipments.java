package API.ResponseModels;

public class Shipments {
    MonitoredShipment MonitoredShipmentObject;
    private int allShipment;
    private int recentShipmentAddedToInventory;

    // Getter Methods

    public int getAllShipment() {
        return allShipment;
    }

    public void setAllShipment(int allShipment) {
        this.allShipment = allShipment;
    }

    public int getRecentShipmentAddedToInventory() {
        return recentShipmentAddedToInventory;
    }

    // Setter Methods

    public void setRecentShipmentAddedToInventory(int recentShipmentAddedToInventory) {
        this.recentShipmentAddedToInventory = recentShipmentAddedToInventory;
    }

    public MonitoredShipment getMonitoredShipment() {
        return MonitoredShipmentObject;
    }

    public void setMonitoredShipment(MonitoredShipment monitoredShipmentObject) {
        this.MonitoredShipmentObject = monitoredShipmentObject;
    }

    public class MonitoredShipment {
        private int plannedDeliveries;
        private int plannedDeliveriesNextFewDays;
        private int sopIntervened;

        // Getter Methods

        public int getPlannedDeliveries() {
            return plannedDeliveries;
        }

        public void setPlannedDeliveries(int plannedDeliveries) {
            this.plannedDeliveries = plannedDeliveries;
        }

        public int getPlannedDeliveriesNextFewDays() {
            return plannedDeliveriesNextFewDays;
        }

        // Setter Methods

        public void setPlannedDeliveriesNextFewDays(int plannedDeliveriesNextFewDays) {
            this.plannedDeliveriesNextFewDays = plannedDeliveriesNextFewDays;
        }

        public int getSopIntervened() {
            return sopIntervened;
        }

        public void setSopIntervened(int sopIntervened) {
            this.sopIntervened = sopIntervened;
        }
    }
}
