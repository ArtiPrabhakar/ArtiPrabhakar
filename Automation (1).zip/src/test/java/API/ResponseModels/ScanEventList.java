package API.ResponseModels;

public class ScanEventList {
    private String date;
    private String time;
    private String gmtOffset;
    private String status;
    private String scanCode;
    private String scanLocation;
    private Boolean exception;
    private Boolean delException;
    private Boolean clearanceDelay;
    private Boolean delivered;
    private String scanDetails;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getGmtOffset() {
        return gmtOffset;
    }

    public void setGmtOffset(String gmtOffset) {
        this.gmtOffset = gmtOffset;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getScanCode() {
        return scanCode;
    }

    public void setScanCode(String scanCode) {
        this.scanCode = scanCode;
    }

    public String getScanLocation() {
        return scanLocation;
    }

    public void setScanLocation(String scanLocation) {
        this.scanLocation = scanLocation;
    }

    public Boolean getException() {
        return exception;
    }

    public void setException(Boolean exception) {
        this.exception = exception;
    }

    public Boolean getDelException() {
        return delException;
    }

    public void setDelException(Boolean delException) {
        this.delException = delException;
    }

    public Boolean getClearanceDelay() {
        return clearanceDelay;
    }

    public void setClearanceDelay(Boolean clearanceDelay) {
        this.clearanceDelay = clearanceDelay;
    }

    public Boolean getDelivered() {
        return delivered;
    }

    public void setDelivered(Boolean delivered) {
        this.delivered = delivered;
    }

    public String getScanDetails() {
        return scanDetails;
    }

    public void setScanDetails(String scanDetails) {
        this.scanDetails = scanDetails;
    }
}
