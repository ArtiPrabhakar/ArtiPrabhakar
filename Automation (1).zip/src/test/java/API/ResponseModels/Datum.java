package API.ResponseModels;

public class Datum {

    private String accountId;
    private String surroundEligibilityType;
    private Object globalEntityNumber;
    private Boolean digital;
    private Boolean expedite;
    private Boolean iot;
    private Boolean onDemandCare;
    private Boolean monitoring;
    private Boolean contactRecipient;
    private Boolean sepDataVisibleToCustomer;
    private Boolean onlyMonitored;
    private Boolean onlyDigital;
    private Boolean premium;
    private Boolean usinboundOnly;
    private Boolean internalMonitoring;
    private Boolean allInternational;
    private Boolean pamonitoring;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSurroundEligibilityType() {
        return surroundEligibilityType;
    }

    public void setSurroundEligibilityType(String surroundEligibilityType) {
        this.surroundEligibilityType = surroundEligibilityType;
    }

    public Object getGlobalEntityNumber() {
        return globalEntityNumber;
    }

    public void setGlobalEntityNumber(Object globalEntityNumber) {
        this.globalEntityNumber = globalEntityNumber;
    }

    public Boolean getDigital() {
        return digital;
    }

    public void setDigital(Boolean digital) {
        this.digital = digital;
    }

    public Boolean getExpedite() {
        return expedite;
    }

    public void setExpedite(Boolean expedite) {
        this.expedite = expedite;
    }

    public Boolean getIot() {
        return iot;
    }

    public void setIot(Boolean iot) {
        this.iot = iot;
    }

    public Boolean getOnDemandCare() {
        return onDemandCare;
    }

    public void setOnDemandCare(Boolean onDemandCare) {
        this.onDemandCare = onDemandCare;
    }

    public Boolean getMonitoring() {
        return monitoring;
    }

    public void setMonitoring(Boolean monitoring) {
        this.monitoring = monitoring;
    }

    public Boolean getContactRecipient() {
        return contactRecipient;
    }

    public void setContactRecipient(Boolean contactRecipient) {
        this.contactRecipient = contactRecipient;
    }

    public Boolean getSepDataVisibleToCustomer() {
        return sepDataVisibleToCustomer;
    }

    public void setSepDataVisibleToCustomer(Boolean sepDataVisibleToCustomer) {
        this.sepDataVisibleToCustomer = sepDataVisibleToCustomer;
    }

    public Boolean getOnlyMonitored() {
        return onlyMonitored;
    }

    public void setOnlyMonitored(Boolean onlyMonitored) {
        this.onlyMonitored = onlyMonitored;
    }

    public Boolean getOnlyDigital() {
        return onlyDigital;
    }

    public void setOnlyDigital(Boolean onlyDigital) {
        this.onlyDigital = onlyDigital;
    }

    public Boolean getPremium() {
        return premium;
    }

    public Boolean getUsinboundOnly() {
        return usinboundOnly;
    }

    public Boolean getAllInternational() {
        return allInternational;
    }

    public Boolean getInternalMonitoring() {
        return internalMonitoring;
    }

    public Boolean getPamonitoring() {
        return pamonitoring;
    }

}