package API.ResponseModels;

import java.util.List;

public class TrackingApiDto {
    private String trackingNbr;
    private String keyStatus;
    private String subStatus;
    private String mainStatus;
    private String displayEstDeliveryDt;
    private String displayEstDeliveryTm;
    private String estDeliveryDt;
    private String statusWithDetails;
    private String shipperName;
    private String shipperCmpnyName;
    private String shipperPhoneNbr;
    private String recipCompany;
    private Object recipientCmpnyName;
    private String recipientName;
    private String recipientPhoneNbr;
    private String displayShipDt;
    private String displayShipDateTime;
    private String displayTotalKgsWgt;
    private String displayTotalLbsWgt;
    private String displayPkgKgsWgt;
    private String displayPkgLbsWgt;
    private RecipientAddress recipientAddress;
    private ShipperAddress shipperAddress;
    private List<String> cerNbrList = null;
    private String deliveryAttempt;
    private List<String> doorTagNbrList = null;
    private List<String> invoiceNbrList = null;
    private String totalPieces;
    private String packageType;
    private List<String> purchaseOrderNbrList = null;
    private String serviceDesc;
    private List<String> shipperRefList = null;
    private List<String> specialHandlingServicesList = null;
    private List<String> referenceList = null;
    private StandardTransitDate standardTransitDate;
    private StandardTransitTimeWindow standardTransitTimeWindow;
    private String terms;
    private List<ScanEventList> scanEventList = null;
    private String displayTotalWgt;
    private String displayPkgWgt;
    private Boolean delivered;
    private Boolean mps;
    private Boolean gmps;
    private String masterTrackingNbr;
    private String masterQualifier;
    private List<MultiPieceShipment> multiPieceShipments = null;
    private String dateDelivered;
    private String dimension;
    private List<String> deptNbrList = null;
    private String destTZ;
    private String cerCount;

    public String getTrackingNbr() {
        return trackingNbr;
    }

    public void setTrackingNbr(String trackingNbr) {
        this.trackingNbr = trackingNbr;
    }

    public String getKeyStatus() {
        return keyStatus;
    }

    public void setKeyStatus(String keyStatus) {
        this.keyStatus = keyStatus;
    }

    public String getSubStatus() {
        return subStatus;
    }

    public void setSubStatus(String subStatus) {
        this.subStatus = subStatus;
    }

    public String getMainStatus() {
        return mainStatus;
    }

    public void setMainStatus(String mainStatus) {
        this.mainStatus = mainStatus;
    }

    public String getDisplayEstDeliveryDt() {
        return displayEstDeliveryDt;
    }

    public void setDisplayEstDeliveryDt(String displayEstDeliveryDt) {
        this.displayEstDeliveryDt = displayEstDeliveryDt;
    }

    public String getDisplayEstDeliveryTm() {
        return displayEstDeliveryTm;
    }

    public void setDisplayEstDeliveryTm(String displayEstDeliveryTm) {
        this.displayEstDeliveryTm = displayEstDeliveryTm;
    }

    public String getEstDeliveryDt() {
        return estDeliveryDt;
    }

    public void setEstDeliveryDt(String estDeliveryDt) {
        this.estDeliveryDt = estDeliveryDt;
    }

    public String getStatusWithDetails() {
        return statusWithDetails;
    }

    public void setStatusWithDetails(String statusWithDetails) {
        this.statusWithDetails = statusWithDetails;
    }

    public String getShipperName() {
        return shipperName;
    }

    public void setShipperName(String shipperName) {
        this.shipperName = shipperName;
    }

    public String getShipperCmpnyName() {
        return shipperCmpnyName;
    }

    public void setShipperCmpnyName(String shipperCmpnyName) {
        this.shipperCmpnyName = shipperCmpnyName;
    }

    public String getShipperPhoneNbr() {
        return shipperPhoneNbr;
    }

    public void setShipperPhoneNbr(String shipperPhoneNbr) {
        this.shipperPhoneNbr = shipperPhoneNbr;
    }

    public Object getRecipientCmpnyName() {
        return recipientCmpnyName;
    }

    public void setRecipientCmpnyName(Object recipientCmpnyName) {
        this.recipientCmpnyName = recipientCmpnyName;
    }

    public String getRecipCompany() {
        return recipCompany;
    }

    public void setRecipCompany(String recipCompany) {
        this.recipCompany = recipCompany;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public String getRecipientPhoneNbr() {
        return recipientPhoneNbr;
    }

    public void setRecipientPhoneNbr(String recipientPhoneNbr) {
        this.recipientPhoneNbr = recipientPhoneNbr;
    }

    public String getDisplayShipDt() {
        return displayShipDt;
    }

    public void setDisplayShipDt(String displayShipDt) {
        this.displayShipDt = displayShipDt;
    }

    public String getDisplayShipDateTime() {
        return displayShipDateTime;
    }

    public void setDisplayShipDateTime(String displayShipDateTime) {
        this.displayShipDateTime = displayShipDateTime;
    }

    public String getDisplayTotalKgsWgt() {
        return displayTotalKgsWgt;
    }

    public void setDisplayTotalKgsWgt(String displayTotalKgsWgt) {
        this.displayTotalKgsWgt = displayTotalKgsWgt;
    }

    public String getDisplayTotalLbsWgt() {
        return displayTotalLbsWgt;
    }

    public void setDisplayTotalLbsWgt(String displayTotalLbsWgt) {
        this.displayTotalLbsWgt = displayTotalLbsWgt;
    }

    public String getDisplayPkgKgsWgt() {
        return displayPkgKgsWgt;
    }

    public void setDisplayPkgKgsWgt(String displayPkgKgsWgt) {
        this.displayPkgKgsWgt = displayPkgKgsWgt;
    }

    public String getDisplayPkgLbsWgt() {
        return displayPkgLbsWgt;
    }

    public void setDisplayPkgLbsWgt(String displayPkgLbsWgt) {
        this.displayPkgLbsWgt = displayPkgLbsWgt;
    }

    public RecipientAddress getRecipientAddress() {
        return recipientAddress;
    }

    public void setRecipientAddress(RecipientAddress recipientAddress) {
        this.recipientAddress = recipientAddress;
    }

    public ShipperAddress getShipperAddress() {
        return shipperAddress;
    }

    public void setShipperAddress(ShipperAddress shipperAddress) {
        this.shipperAddress = shipperAddress;
    }

    public List<String> getCerNbrList() {
        return cerNbrList;
    }

    public void setCerNbrList(List<String> cerNbrList) {
        this.cerNbrList = cerNbrList;
    }

    public String getDeliveryAttempt() {
        return deliveryAttempt;
    }

    public void setDeliveryAttempt(String deliveryAttempt) {
        this.deliveryAttempt = deliveryAttempt;
    }

    public List<String> getDoorTagNbrList() {
        return doorTagNbrList;
    }

    public void setDoorTagNbrList(List<String> doorTagNbrList) {
        this.doorTagNbrList = doorTagNbrList;
    }

    public List<String> getInvoiceNbrList() {
        return invoiceNbrList;
    }

    public void setInvoiceNbrList(List<String> invoiceNbrList) {
        this.invoiceNbrList = invoiceNbrList;
    }

    public String getTotalPieces() {
        return totalPieces;
    }

    public void setTotalPieces(String totalPieces) {
        this.totalPieces = totalPieces;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public List<String> getPurchaseOrderNbrList() {
        return purchaseOrderNbrList;
    }

    public void setPurchaseOrderNbrList(List<String> purchaseOrderNbrList) {
        this.purchaseOrderNbrList = purchaseOrderNbrList;
    }

    public String getServiceDesc() {
        return serviceDesc;
    }

    public void setServiceDesc(String serviceDesc) {
        this.serviceDesc = serviceDesc;
    }

    public List<String> getShipperRefList() {
        return shipperRefList;
    }

    public void setShipperRefList(List<String> shipperRefList) {
        this.shipperRefList = shipperRefList;
    }

    public List<String> getSpecialHandlingServicesList() {
        return specialHandlingServicesList;
    }

    public void setSpecialHandlingServicesList(List<String> specialHandlingServicesList) {
        this.specialHandlingServicesList = specialHandlingServicesList;
    }

    public List<String> getReferenceList() {
        return referenceList;
    }

    public void setReferenceList(List<String> referenceList) {
        this.referenceList = referenceList;
    }

    public StandardTransitDate getStandardTransitDate() {
        return standardTransitDate;
    }

    public void setStandardTransitDate(StandardTransitDate standardTransitDate) {
        this.standardTransitDate = standardTransitDate;
    }

    public StandardTransitTimeWindow getStandardTransitTimeWindow() {
        return standardTransitTimeWindow;
    }

    public void setStandardTransitTimeWindow(StandardTransitTimeWindow standardTransitTimeWindow) {
        this.standardTransitTimeWindow = standardTransitTimeWindow;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public List<ScanEventList> getScanEventList() {
        return scanEventList;
    }

    public void setScanEventList(List<ScanEventList> scanEventList) {
        this.scanEventList = scanEventList;
    }

    public String getDisplayTotalWgt() {
        return displayTotalWgt;
    }

    public void setDisplayTotalWgt(String displayTotalWgt) {
        this.displayTotalWgt = displayTotalWgt;
    }

    public String getDisplayPkgWgt() {
        return displayPkgWgt;
    }

    public void setDisplayPkgWgt(String displayPkgWgt) {
        this.displayPkgWgt = displayPkgWgt;
    }

    public Boolean getDelivered() {
        return delivered;
    }

    public void setDelivered(Boolean delivered) {
        this.delivered = delivered;
    }

    public Boolean getMps() {
        return mps;
    }

    public void setMps(Boolean mps) {
        this.mps = mps;
    }

    public Boolean getGmps() {
        return gmps;
    }

    public void setGmps(Boolean gmps) {
        this.gmps = gmps;
    }

    public String getMasterTrackingNbr() {
        return masterTrackingNbr;
    }

    public void setMasterTrackingNbr(String masterTrackingNbr) {
        this.masterTrackingNbr = masterTrackingNbr;
    }

    public String getMasterQualifier() {
        return masterQualifier;
    }

    public void setMasterQualifier(String masterQualifier) {
        this.masterQualifier = masterQualifier;
    }

    public List<MultiPieceShipment> getMultiPieceShipments() {
        return multiPieceShipments;
    }

    public void setMultiPieceShipments(List<MultiPieceShipment> multiPieceShipments) {
        this.multiPieceShipments = multiPieceShipments;
    }

    public String getDateDelivered() {
        return dateDelivered;
    }

    public void setDateDelivered(String dateDelivered) {
        this.dateDelivered = dateDelivered;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public List<String> getDeptNbrList() {
        return deptNbrList;
    }

    public void setDeptNbrList(List<String> deptNbrList) {
        this.deptNbrList = deptNbrList;
    }

    public String getDestTZ() {
        return destTZ;
    }

    public void setDestTZ(String destTZ) {
        this.destTZ = destTZ;
    }

    public String getCerCount() {
        return cerCount;
    }

    public void setCerCount(String cerCount) {
        this.cerCount = cerCount;
    }
}