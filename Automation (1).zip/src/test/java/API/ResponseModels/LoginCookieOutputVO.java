package API.ResponseModels;

public class LoginCookieOutputVO {
    private String fclCookie;
    private String nameCookie;
    private String contactNameCookie;
    private String uuidCookie;

    public String getFclCookie() {
        return fclCookie;
    }

    public void setFclCookie(String fclCookie) {
        this.fclCookie = fclCookie;
    }

    public String getNameCookie() {
        return nameCookie;
    }

    public void setNameCookie(String nameCookie) {
        this.nameCookie = nameCookie;
    }

    public String getContactNameCookie() {
        return contactNameCookie;
    }

    public void setContactNameCookie(String contactNameCookie) {
        this.contactNameCookie = contactNameCookie;
    }

    public String getUuidCookie() {
        return uuidCookie;
    }

    public void setUuidCookie(String uuidCookie) {
        this.uuidCookie = uuidCookie;
    }
}
