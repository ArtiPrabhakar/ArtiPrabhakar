package API.ResponseModels;

import java.util.List;

public class UserPreferences {

    private String id;
    private Object preferredTimeZone;
    private String preferredTimeFormat;
    private String preferredDateFormat;
    private String preferredTemperatureFormat;
    private String preferredDistanceFormat;
    private Object preferredOriginCities;
    private Object preferredDestinationCities;
    private Object firstName;
    private Object lastName;
    private String releaseForWhatsNew;
    private String dateOfDeploymentUnixTimeStampInSeconds;
    private Integer daysToHighlightWhatsNew;
    private String releaseVersion;
    private Boolean showWhatsNew;
    private Boolean autoSelectCities;
    private Object fedexAccountsDto;
    private Object shipmentsListViewState;
    private Boolean enableDigitalService;
    private List<QuickViewCardsPreference> quickViewCardsPreference = null;
    private Boolean hideQuickView;
    private Boolean enablei18n;
    private Boolean enableDownloadCenter;
    private List<QuickViewCardsPreference> savedViewCardsPreference = null;
    private String downloadCenterStatusPollTimeInSecond;
    private String downloadCenterMaxFileLimit;
    private Boolean enableMultiTrackingSearch;
    private Integer multiTrackingSearchMaxLimit;
    private Boolean enableGDPP;
    private Integer downloadCenterSmallFileRowLimit;
    private Boolean fusionAllowUSCanadaDomesticShipmentsOnly;
    private Boolean customerPortalShowUSInboundShipments;
    private Boolean cePortalShowGlobalShipments;
    private Boolean isSepDataEnabledForAtleastOneAccount;
    private SelectedImageRole selectedImageRole;
    private DefaultImageRole defaultImageRole;
    private List<AvailableImageRole> availableImageRoles = null;
    private Boolean enableGDPPpowerBIReports;
    private Boolean surroundMonitored;
    private Object preferredHierarchy;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Object getPreferredTimeZone() {
        return preferredTimeZone;
    }

    public void setPreferredTimeZone(Object preferredTimeZone) {
        this.preferredTimeZone = preferredTimeZone;
    }

    public String getPreferredTimeFormat() {
        return preferredTimeFormat;
    }

    public void setPreferredTimeFormat(String preferredTimeFormat) {
        this.preferredTimeFormat = preferredTimeFormat;
    }

    public String getPreferredDateFormat() {
        return preferredDateFormat;
    }

    public void setPreferredDateFormat(String preferredDateFormat) {
        this.preferredDateFormat = preferredDateFormat;
    }

    public String getPreferredTemperatureFormat() {
        return preferredTemperatureFormat;
    }

    public void setPreferredTemperatureFormat(String preferredTemperatureFormat) {
        this.preferredTemperatureFormat = preferredTemperatureFormat;
    }

    public String getPreferredDistanceFormat() {
        return preferredDistanceFormat;
    }

    public void setPreferredDistanceFormat(String preferredDistanceFormat) {
        this.preferredDistanceFormat = preferredDistanceFormat;
    }

    public Object getPreferredOriginCities() {
        return preferredOriginCities;
    }

    public void setPreferredOriginCities(Object preferredOriginCities) {
        this.preferredOriginCities = preferredOriginCities;
    }

    public Object getPreferredDestinationCities() {
        return preferredDestinationCities;
    }

    public void setPreferredDestinationCities(Object preferredDestinationCities) {
        this.preferredDestinationCities = preferredDestinationCities;
    }

    public Object getFirstName() {
        return firstName;
    }

    public void setFirstName(Object firstName) {
        this.firstName = firstName;
    }

    public Object getLastName() {
        return lastName;
    }

    public void setLastName(Object lastName) {
        this.lastName = lastName;
    }

    public String getReleaseForWhatsNew() {
        return releaseForWhatsNew;
    }

    public void setReleaseForWhatsNew(String releaseForWhatsNew) {
        this.releaseForWhatsNew = releaseForWhatsNew;
    }

    public String getDateOfDeploymentUnixTimeStampInSeconds() {
        return dateOfDeploymentUnixTimeStampInSeconds;
    }

    public void setDateOfDeploymentUnixTimeStampInSeconds(String dateOfDeploymentUnixTimeStampInSeconds) {
        this.dateOfDeploymentUnixTimeStampInSeconds = dateOfDeploymentUnixTimeStampInSeconds;
    }

    public Integer getDaysToHighlightWhatsNew() {
        return daysToHighlightWhatsNew;
    }

    public void setDaysToHighlightWhatsNew(Integer daysToHighlightWhatsNew) {
        this.daysToHighlightWhatsNew = daysToHighlightWhatsNew;
    }

    public String getReleaseVersion() {
        return releaseVersion;
    }

    public void setReleaseVersion(String releaseVersion) {
        this.releaseVersion = releaseVersion;
    }

    public Boolean getShowWhatsNew() {
        return showWhatsNew;
    }

    public void setShowWhatsNew(Boolean showWhatsNew) {
        this.showWhatsNew = showWhatsNew;
    }

    public Boolean getAutoSelectCities() {
        return autoSelectCities;
    }

    public void setAutoSelectCities(Boolean autoSelectCities) {
        this.autoSelectCities = autoSelectCities;
    }

    public Object getFedexAccountsDto() {
        return fedexAccountsDto;
    }

    public void setFedexAccountsDto(Object fedexAccountsDto) {
        this.fedexAccountsDto = fedexAccountsDto;
    }

    public Object getShipmentsListViewState() {
        return shipmentsListViewState;
    }

    public void setShipmentsListViewState(Object shipmentsListViewState) {
        this.shipmentsListViewState = shipmentsListViewState;
    }

    public Boolean getEnableDigitalService() {
        return enableDigitalService;
    }

    public void setEnableDigitalService(Boolean enableDigitalService) {
        this.enableDigitalService = enableDigitalService;
    }

    public List<QuickViewCardsPreference> getQuickViewCardsPreference() {
        return quickViewCardsPreference;
    }

    public void setQuickViewCardsPreference(List<QuickViewCardsPreference> quickViewCardsPreference) {
        this.quickViewCardsPreference = quickViewCardsPreference;
    }

    public Boolean getHideQuickView() {
        return hideQuickView;
    }

    public void setHideQuickView(Boolean hideQuickView) {
        this.hideQuickView = hideQuickView;
    }

    public Boolean getEnablei18n() {
        return enablei18n;
    }

    public void setEnablei18n(Boolean enablei18n) {
        this.enablei18n = enablei18n;
    }

    public Boolean getEnableDownloadCenter() {
        return enableDownloadCenter;
    }

    public void setEnableDownloadCenter(Boolean enableDownloadCenter) {
        this.enableDownloadCenter = enableDownloadCenter;
    }

    public List<QuickViewCardsPreference> getSavedViewCardsPreference() {
        return savedViewCardsPreference;
    }

    public void setSavedViewCardsPreference(List<QuickViewCardsPreference> savedViewCardsPreference) {
        this.savedViewCardsPreference = savedViewCardsPreference;
    }

    public String getDownloadCenterStatusPollTimeInSecond() {
        return downloadCenterStatusPollTimeInSecond;
    }

    public void setDownloadCenterStatusPollTimeInSecond(String downloadCenterStatusPollTimeInSecond) {
        this.downloadCenterStatusPollTimeInSecond = downloadCenterStatusPollTimeInSecond;
    }

    public String getDownloadCenterMaxFileLimit() {
        return downloadCenterMaxFileLimit;
    }

    public void setDownloadCenterMaxFileLimit(String downloadCenterMaxFileLimit) {
        this.downloadCenterMaxFileLimit = downloadCenterMaxFileLimit;
    }

    public Boolean getEnableMultiTrackingSearch() {
        return enableMultiTrackingSearch;
    }

    public void setEnableMultiTrackingSearch(Boolean enableMultiTrackingSearch) {
        this.enableMultiTrackingSearch = enableMultiTrackingSearch;
    }

    public Integer getMultiTrackingSearchMaxLimit() {
        return multiTrackingSearchMaxLimit;
    }

    public void setMultiTrackingSearchMaxLimit(Integer multiTrackingSearchMaxLimit) {
        this.multiTrackingSearchMaxLimit = multiTrackingSearchMaxLimit;
    }

    public Boolean getEnableGDPP() {
        return enableGDPP;
    }

    public void setEnableGDPP(Boolean enableGDPP) {
        this.enableGDPP = enableGDPP;
    }

    public Integer getDownloadCenterSmallFileRowLimit() {
        return downloadCenterSmallFileRowLimit;
    }

    public void setDownloadCenterSmallFileRowLimit(Integer downloadCenterSmallFileRowLimit) {
        this.downloadCenterSmallFileRowLimit = downloadCenterSmallFileRowLimit;
    }

    public Boolean getFusionAllowUSCanadaDomesticShipmentsOnly() {
        return fusionAllowUSCanadaDomesticShipmentsOnly;
    }

    public void setFusionAllowUSCanadaDomesticShipmentsOnly(Boolean fusionAllowUSCanadaDomesticShipmentsOnly) {
        this.fusionAllowUSCanadaDomesticShipmentsOnly = fusionAllowUSCanadaDomesticShipmentsOnly;
    }

    public Boolean getCustomerPortalShowUSInboundShipments() {
        return customerPortalShowUSInboundShipments;
    }

    public void setCustomerPortalShowUSInboundShipments(Boolean customerPortalShowUSInboundShipments) {
        this.customerPortalShowUSInboundShipments = customerPortalShowUSInboundShipments;
    }

    public Boolean getCePortalShowGlobalShipments() {
        return cePortalShowGlobalShipments;
    }

    public void setCePortalShowGlobalShipments(Boolean cePortalShowGlobalShipments) {
        this.cePortalShowGlobalShipments = cePortalShowGlobalShipments;
    }

    public Boolean getIsSepDataEnabledForAtleastOneAccount() {
        return isSepDataEnabledForAtleastOneAccount;
    }

    public void setIsSepDataEnabledForAtleastOneAccount(Boolean isSepDataEnabledForAtleastOneAccount) {
        this.isSepDataEnabledForAtleastOneAccount = isSepDataEnabledForAtleastOneAccount;
    }

    public SelectedImageRole getSelectedImageRole() {
        return selectedImageRole;
    }

    public void setSelectedImageRole(SelectedImageRole selectedImageRole) {
        this.selectedImageRole = selectedImageRole;
    }

    public DefaultImageRole getDefaultImageRole() {
        return defaultImageRole;
    }

    public void setDefaultImageRole(DefaultImageRole defaultImageRole) {
        this.defaultImageRole = defaultImageRole;
    }

    public List<AvailableImageRole> getAvailableImageRoles() {
        return availableImageRoles;
    }

    public void setAvailableImageRoles(List<AvailableImageRole> availableImageRoles) {
        this.availableImageRoles = availableImageRoles;
    }

    public Boolean getEnableGDPPpowerBIReports() {
        return enableGDPPpowerBIReports;
    }

    public void setEnableGDPPpowerBIReports(Boolean enableGDPPpowerBIReports) {
        this.enableGDPPpowerBIReports = enableGDPPpowerBIReports;
    }

    public Boolean getSurroundMonitored() {
        return surroundMonitored;
    }

    public void setSurroundMonitored(Boolean surroundMonitored) {
        this.surroundMonitored = surroundMonitored;
    }

    public Object getpreferredHierarchy() {
        return this.preferredHierarchy;
    }

    public void setpreferredHierarchy(Object preferredHierarchy) {
        this.preferredHierarchy = preferredHierarchy;
    }
}