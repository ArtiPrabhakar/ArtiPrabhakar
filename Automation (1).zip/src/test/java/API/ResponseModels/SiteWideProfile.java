package API.ResponseModels;

public class SiteWideProfile {
    private Boolean companyAdmin;
    private Boolean departmentAdmin;

    public Boolean getCompanyAdmin() {
        return companyAdmin;
    }

    public void setCompanyAdmin(Boolean companyAdmin) {
        this.companyAdmin = companyAdmin;
    }

    public Boolean getDepartmentAdmin() {
        return departmentAdmin;
    }

    public void setDepartmentAdmin(Boolean departmentAdmin) {
        this.departmentAdmin = departmentAdmin;
    }
}
