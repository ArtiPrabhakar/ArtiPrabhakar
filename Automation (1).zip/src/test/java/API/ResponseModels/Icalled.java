package API.ResponseModels;

public class Icalled {
    private Object shipper;
    private Object recipient;
    private Other other;

    public Object getShipper() {
        return shipper;
    }

    public void setShipper(Object shipper) {
        this.shipper = shipper;
    }

    public Object getRecipient() {
        return recipient;
    }

    public void setRecipient(Object recipient) {
        this.recipient = recipient;
    }

    public Other getOther() {
        return other;
    }

    public void setOther(Other other) {
        this.other = other;
    }

}
