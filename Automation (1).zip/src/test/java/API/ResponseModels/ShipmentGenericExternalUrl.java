package API.ResponseModels;

public class ShipmentGenericExternalUrl {

    private String tripsURL;
    private String thorURL;
    private String workbenchURL;
    private String senseAwareURL;
    private String consURL;
    private String foisURL;
    private String weightAndBalanceURL;

    private String GlobalColdChainContingencyServices;

    public String getTripsURL() {
        return tripsURL;
    }

    public void setTripsURL(String tripsURL) {
        this.tripsURL = tripsURL;
    }

    public String getThorURL() {
        return thorURL;
    }

    public void setThorURL(String thorURL) {
        this.thorURL = thorURL;
    }

    public String getWorkbenchURL() {
        return workbenchURL;
    }

    public void setWorkbenchURL(String workbenchURL) {
        this.workbenchURL = workbenchURL;
    }

    public String getSenseAwareURL() {
        return senseAwareURL;
    }

    public void setSenseAwareURL(String senseAwareURL) {
        this.senseAwareURL = senseAwareURL;
    }

    public String getConsURL() {
        return consURL;
    }

    public void setConsURL(String consURL) {
        this.consURL = consURL;
    }

    public String getFoisURL() {
        return foisURL;
    }

    public void setFoisURL(String foisURL) {
        this.foisURL = foisURL;
    }

    public String getWeightAndBalanceURL() {
        return weightAndBalanceURL;
    }

    public void setWeightAndBalanceURL(String weightAndBalanceURL) {
        this.weightAndBalanceURL = weightAndBalanceURL;
    }

    public String getGlobalColdChainContingencyServices() {
        return GlobalColdChainContingencyServices;
    }

}
