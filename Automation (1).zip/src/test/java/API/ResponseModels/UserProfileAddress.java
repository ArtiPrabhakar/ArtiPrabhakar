package API.ResponseModels;

public class UserProfileAddress {
    private Contact contact;
    private ContactAncillaryDetail contactAncillaryDetail;
    private Address address;

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public ContactAncillaryDetail getContactAncillaryDetail() {
        return contactAncillaryDetail;
    }

    public void setContactAncillaryDetail(ContactAncillaryDetail contactAncillaryDetail) {
        this.contactAncillaryDetail = contactAncillaryDetail;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}