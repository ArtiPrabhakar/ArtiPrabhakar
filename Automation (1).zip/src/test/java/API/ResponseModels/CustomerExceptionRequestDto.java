package API.ResponseModels;

public class CustomerExceptionRequestDto {

    private String cerNumber;
    private String cerType;
    private String cerStatus;
    private String date;
    private String comment;

    public String getCerNumber() {
        return cerNumber;
    }

    public void setCerNumber(String cerNumber) {
        this.cerNumber = cerNumber;
    }

    public String getCerType() {
        return cerType;
    }

    public void setCerType(String cerType) {
        this.cerType = cerType;
    }

    public String getCerStatus() {
        return cerStatus;
    }

    public void setCerStatus(String cerStatus) {
        this.cerStatus = cerStatus;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}