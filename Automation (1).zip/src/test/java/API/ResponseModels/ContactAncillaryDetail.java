package API.ResponseModels;

import java.util.List;

public class ContactAncillaryDetail {
    private List<PhoneNumberDetail> phoneNumberDetails = null;

    public List<PhoneNumberDetail> getPhoneNumberDetails() {
        return phoneNumberDetails;
    }

    public void setPhoneNumberDetails(List<PhoneNumberDetail> phoneNumberDetails) {
        this.phoneNumberDetails = phoneNumberDetails;
    }
}