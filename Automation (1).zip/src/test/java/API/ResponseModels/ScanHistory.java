package API.ResponseModels;

import java.util.HashMap;
import java.util.Map;

public class ScanHistory {

    private final Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private String scanEventDateTime;
    private String eventPostedTimestamp;
    private String scanCode;
    private String codeDescription;
    private String comments;
    private String statusDetail;
    private String additionalDetails;
    private String scanEventLocationId;
    private String scanEventState;
    private String scanEventCity;
    private String scanEventCountryCode;
    private String employeeId;
    private String consContainerTypeCd;
    private String consCategory;
    private String flightNbr;
    private String consDestinationLocCity;
    private String consDestinationLocState;
    private String consDestinationLocCountry;
    private String destFedExLocation;
    private String statusCode;

    public String getScanEventLocationId() {
        return scanEventLocationId;
    }

    public void setScanEventLocationId(String scanEventLocationId) {
        this.scanEventLocationId = scanEventLocationId;
    }

    public String getScanEventState() {
        return scanEventState;
    }

    public void setScanEventState(String scanEventState) {
        this.scanEventState = scanEventState;
    }

    public String getScanEventCity() {
        return scanEventCity;
    }

    public void setScanEventCity(String scanEventCity) {
        this.scanEventCity = scanEventCity;
    }

    public String getScanEventCountryCode() {
        return scanEventCountryCode;
    }

    public void setScanEventCountryCode(String scanEventCountryCode) {
        this.scanEventCountryCode = scanEventCountryCode;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getConsContainerTypeCd() {
        return consContainerTypeCd;
    }

    public void setConsContainerTypeCd(String consContainerTypeCd) {
        this.consContainerTypeCd = consContainerTypeCd;
    }

    public String getConsCategory() {
        return consCategory;
    }

    public void setConsCategory(String consCategory) {
        this.consCategory = consCategory;
    }

    public String getFlightNbr() {
        return flightNbr;
    }

    public void setFlightNbr(String flightNbr) {
        this.flightNbr = flightNbr;
    }

    public String getConsDestinationLocCity() {
        return consDestinationLocCity;
    }

    public void setConsDestinationLocCity(String consDestinationLocCity) {
        this.consDestinationLocCity = consDestinationLocCity;
    }

    public String getConsDestinationLocState() {
        return consDestinationLocState;
    }

    public void setConsDestinationLocState(String consDestinationLocState) {
        this.consDestinationLocState = consDestinationLocState;
    }

    public String getConsDestinationLocCountry() {
        return consDestinationLocCountry;
    }

    public void setConsDestinationLocCountry(String consDestinationLocCountry) {
        this.consDestinationLocCountry = consDestinationLocCountry;
    }

    public String getDestFedExLocation() {
        return destFedExLocation;
    }

    public void setDestFedExLocation(String destFedExLocation) {
        this.destFedExLocation = destFedExLocation;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getScanEventDateTime() {
        return scanEventDateTime;
    }

    public void setScanEventDateTime(String scanEventDateTime) {
        this.scanEventDateTime = scanEventDateTime;
    }

    public String getEventPostedTimestamp() {
        return eventPostedTimestamp;
    }

    public void setEventPostedTimestamp(String eventPostedTimestamp) {
        this.eventPostedTimestamp = eventPostedTimestamp;
    }

    public String getScanCode() {
        return scanCode;
    }

    public void setScanCode(String scanCode) {
        this.scanCode = scanCode;
    }

    public String getCodeDescription() {
        return codeDescription;
    }

    public void setCodeDescription(String codeDescription) {
        this.codeDescription = codeDescription;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    public String getAdditionalDetails() {
        return additionalDetails;
    }

    public void setAdditionalDetails(String additionalDetails) {
        this.additionalDetails = additionalDetails;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}