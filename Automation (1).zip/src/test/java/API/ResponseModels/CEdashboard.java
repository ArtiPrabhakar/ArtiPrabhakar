package API.ResponseModels;

import java.util.List;

public class CEdashboard {

    private String companyCode;
    private String companyName;
    private Integer plannedDeliveries;
    private Integer late;
    private Integer recipientCallsNeedToBeMade;
    private Integer atRisk;
    private Object isWatched;
    private List<String> accountId = null;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getPlannedDeliveries() {
        return plannedDeliveries;
    }

    public void setPlannedDeliveries(Integer plannedDeliveries) {
        this.plannedDeliveries = plannedDeliveries;
    }

    public Integer getLate() {
        return late;
    }

    public void setLate(Integer late) {
        this.late = late;
    }

    public Integer getRecipientCallsNeedToBeMade() {
        return recipientCallsNeedToBeMade;
    }

    public void setRecipientCallsNeedToBeMade(Integer recipientCallsNeedToBeMade) {
        this.recipientCallsNeedToBeMade = recipientCallsNeedToBeMade;
    }

    public Integer getAtRisk() {
        return atRisk;
    }

    public void setAtRisk(Integer atRisk) {
        this.atRisk = atRisk;
    }

    public Object getIsWatched() {
        return isWatched;
    }

    public void setIsWatched(Object isWatched) {
        this.isWatched = isWatched;
    }

    public List<String> getAccountId() {
        return accountId;
    }

    public void setAccountId(List<String> accountId) {
        this.accountId = accountId;
    }

}
