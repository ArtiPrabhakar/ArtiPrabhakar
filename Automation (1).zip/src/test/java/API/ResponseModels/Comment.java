package API.ResponseModels;

public class Comment {
    private String id;
    private Comment_ comment;
    private Icalled icalled;
    private Object unixFusionMessageCreationTimestamp;
    private Object unixCommentLastUpdatedTimestamp;
    private Object unixCommentMessageCreationTimestamp;
    private String shipmentId;
    private CustomerExceptionRequestDto customerExceptionRequestDto;
    private String message;
    private String ownerID;
    private String ownerName;
    private String firstName;
    private String lastName;
    private String ownerRole;
    private String fedexId;
    private String createdDateTimeStamp;
    private String lastUpdatedTimeStamp;
    private String enablement;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(String ownerID) {
        this.ownerID = ownerID;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getOwnerRole() {
        return ownerRole;
    }

    public void setOwnerRole(String ownerRole) {
        this.ownerRole = ownerRole;
    }

    public String getFedexId() {
        return fedexId;
    }

    public void setFedexId(String fedexId) {
        this.fedexId = fedexId;
    }

    public String getCreatedDateTimeStamp() {
        return createdDateTimeStamp;
    }

    public void setCreatedDateTimeStamp(String createdDateTimeStamp) {
        this.createdDateTimeStamp = createdDateTimeStamp;
    }

    public String getLastUpdatedTimeStamp() {
        return lastUpdatedTimeStamp;
    }

    public void setLastUpdatedTimeStamp(String lastUpdatedTimeStamp) {
        this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
    }

    public String getEnablement() {
        return enablement;
    }

    public void setEnablement(String enablement) {
        this.enablement = enablement;
    }

    public CustomerExceptionRequestDto getCustomerExceptionRequestDto() {
        return customerExceptionRequestDto;
    }

    public void setCustomerExceptionRequestDto(CustomerExceptionRequestDto customerExceptionRequestDto) {
        this.customerExceptionRequestDto = customerExceptionRequestDto;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Comment_ getComment() {
        return comment;
    }

    public void setComment(Comment_ comment) {
        this.comment = comment;
    }

    public Icalled getIcalled() {
        return icalled;
    }

    public void setIcalled(Icalled icalled) {
        this.icalled = icalled;
    }

    public Object getUnixFusionMessageCreationTimestamp() {
        return unixFusionMessageCreationTimestamp;
    }

    public void setUnixFusionMessageCreationTimestamp(Object unixFusionMessageCreationTimestamp) {
        this.unixFusionMessageCreationTimestamp = unixFusionMessageCreationTimestamp;
    }

    public Object getUnixCommentLastUpdatedTimestamp() {
        return unixCommentLastUpdatedTimestamp;
    }

    public void setUnixCommentLastUpdatedTimestamp(Object unixCommentLastUpdatedTimestamp) {
        this.unixCommentLastUpdatedTimestamp = unixCommentLastUpdatedTimestamp;
    }

    public Object getUnixCommentMessageCreationTimestamp() {
        return unixCommentMessageCreationTimestamp;
    }

    public void setUnixCommentMessageCreationTimestamp(Object unixCommentMessageCreationTimestamp) {
        this.unixCommentMessageCreationTimestamp = unixCommentMessageCreationTimestamp;
    }
}
