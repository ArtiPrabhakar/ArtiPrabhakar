package API.ResponseModels;

public class InterventionLog {

    private Object id;
    private Object shipmentId;
    private Object documentType;
    private Object accountId;
    private Object company;
    private Object intervention;
    private Integer unixShipmentCreationDate;
    private Object shipmentKey;
    private Object shipmentCreationDate;
    private long unixInterventionLatestMessageCreationDateTime;

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public Object getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(Object shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Object getDocumentType() {
        return documentType;
    }

    public void setDocumentType(Object documentType) {
        this.documentType = documentType;
    }

    public Object getAccountId() {
        return accountId;
    }

    public void setAccountId(Object accountId) {
        this.accountId = accountId;
    }

    public Object getCompany() {
        return company;
    }

    public void setCompany(Object company) {
        this.company = company;
    }

    public Object getIntervention() {
        return intervention;
    }

    public void setIntervention(Object intervention) {
        this.intervention = intervention;
    }

    public Integer getUnixShipmentCreationDate() {
        return unixShipmentCreationDate;
    }

    public void setUnixShipmentCreationDate(Integer unixShipmentCreationDate) {
        this.unixShipmentCreationDate = unixShipmentCreationDate;
    }

    public Object getShipmentKey() {
        return shipmentKey;
    }

    public void setShipmentKey(Object shipmentKey) {
        this.shipmentKey = shipmentKey;
    }

    public Object getShipmentCreationDate() {
        return shipmentCreationDate;
    }

    public void setShipmentCreationDate(Object shipmentCreationDate) {
        this.shipmentCreationDate = shipmentCreationDate;
    }

    public long getUnixInterventionLatestMessageCreationDateTime() {
        return unixInterventionLatestMessageCreationDateTime;
    }

    public void setUnixInterventionLatestMessageCreationDateTime(long unixInterventionLatestMessageCreationDateTime) {
        this.unixInterventionLatestMessageCreationDateTime = unixInterventionLatestMessageCreationDateTime;
    }

}