package API.ResponseModels;

public class Area {
    private String endTime;
    private Integer epochEndTime;
    private Integer epochStartTime;
    private LastAction lastAction;
    private String name;
    private String startTime;
    private String summary;

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getEpochEndTime() {
        return epochEndTime;
    }

    public void setEpochEndTime(Integer epochEndTime) {
        this.epochEndTime = epochEndTime;
    }

    public Integer getEpochStartTime() {
        return epochStartTime;
    }

    public void setEpochStartTime(Integer epochStartTime) {
        this.epochStartTime = epochStartTime;
    }

    public LastAction getLastAction() {
        return lastAction;
    }

    public void setLastAction(LastAction lastAction) {
        this.lastAction = lastAction;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

}
