package API.CosmosModels;

public class Fusion {
    private Long unixShipmentCreationDate;
    private ShipmentExtensions shipmentExtensions;
    private Long monthKey;
    private String documentType;
    private ShipmentKey shipmentKey;
    private RiskProfile riskProfile;
    private Long hourKey;
    private Long dayKey;
    private String accountId;
    private String shipmentCreationDate;
    private Long documentGeneratedTS;
    private Payload payload;
    private Long yearKey;
    private String shipmentId;
    private Long unixFusionLatestMessageCreationDateTime;
    private String ingestionType;
    private String id;
    private String rid;
    private String self;
    private String etag;
    private String attachments;
    private Long ts;

    public Long getUnixShipmentCreationDate() {
        return unixShipmentCreationDate;
    }

    public void setUnixShipmentCreationDate(Long unixShipmentCreationDate) {
        this.unixShipmentCreationDate = unixShipmentCreationDate;
    }

    public ShipmentExtensions getShipmentExtensions() {
        return shipmentExtensions;
    }

    public void setShipmentExtensions(ShipmentExtensions shipmentExtensions) {
        this.shipmentExtensions = shipmentExtensions;
    }

    public Long getMonthKey() {
        return monthKey;
    }

    public void setMonthKey(Long monthKey) {
        this.monthKey = monthKey;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public ShipmentKey getShipmentKey() {
        return shipmentKey;
    }

    public void setShipmentKey(ShipmentKey shipmentKey) {
        this.shipmentKey = shipmentKey;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    public void setRiskProfile(RiskProfile riskProfile) {
        this.riskProfile = riskProfile;
    }

    public Long getHourKey() {
        return hourKey;
    }

    public void setHourKey(Long hourKey) {
        this.hourKey = hourKey;
    }

    public Long getDayKey() {
        return dayKey;
    }

    public void setDayKey(Long dayKey) {
        this.dayKey = dayKey;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getShipmentCreationDate() {
        return shipmentCreationDate;
    }

    public void setShipmentCreationDate(String shipmentCreationDate) {
        this.shipmentCreationDate = shipmentCreationDate;
    }

    public Payload getPayload() {
        return payload;
    }

    public Long getDocumentGeneratedTS() {
        return documentGeneratedTS;
    }

    public void setDocumentGeneratedTS(Long documentGeneratedTS) {
        this.documentGeneratedTS = documentGeneratedTS;
    }

    public Long getYearKey() {
        return yearKey;
    }

    public void setYearKey(Long yearKey) {
        this.yearKey = yearKey;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Long getUnixFusionLatestMessageCreationDateTime() {
        return unixFusionLatestMessageCreationDateTime;
    }

    public void setUnixFusionLatestMessageCreationDateTime(Long unixFusionLatestMessageCreationDateTime) {
        this.unixFusionLatestMessageCreationDateTime = unixFusionLatestMessageCreationDateTime;
    }

    public String getIngestionType() {
        return ingestionType;
    }

    public void setIngestionType(String ingestionType) {
        this.ingestionType = ingestionType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }

    public String getEtag() {
        return etag;
    }

    public void setEtag(String etag) {
        this.etag = etag;
    }

    public String getAttachments() {
        return attachments;
    }

    public void setAttachments(String attachments) {
        this.attachments = attachments;
    }

    public Long getTs() {
        return ts;
    }

    public void setTs(Long ts) {
        this.ts = ts;
    }
}
