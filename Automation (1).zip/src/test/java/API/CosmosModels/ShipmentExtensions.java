package API.CosmosModels;

public class ShipmentExtensions {

    private String internalStatus;
    private Boolean isShipmentActive;
    private String externalStatus;

    public String getInternalStatus() {
        return internalStatus;
    }

    public void setInternalStatus(String internalStatus) {
        this.internalStatus = internalStatus;
    }

    public Boolean getIsShipmentActive() {
        return isShipmentActive;
    }

    public void setIsShipmentActive(Boolean isShipmentActive) {
        this.isShipmentActive = isShipmentActive;
    }

    public String getExternalStatus() {
        return externalStatus;
    }

    public void setExternalStatus(String externalStatus) {
        this.externalStatus = externalStatus;
    }

}
