package API.CosmosModels;

public class DelayPredictions {
    private String reason;
    private String reasonDetail;
    private String riskType;
    private String categoryExternal;
    private long createdTime;
    private String categoryInternal;
    private String interventionRecommendation;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReasonDetail() {
        return reasonDetail;
    }

    public void setReasonDetail(String reasonDetail) {
        this.reasonDetail = reasonDetail;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getCategoryExternal() {
        return categoryExternal;
    }

    public void setCategoryExternal(String categoryExternal) {
        this.categoryExternal = categoryExternal;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }

    public String getCategoryInternal() {
        return categoryInternal;
    }

    public void setCategoryInternal(String categoryInternal) {
        this.categoryInternal = categoryInternal;
    }

    public String getInterventionRecommendation() {
        return interventionRecommendation;
    }

    public void setInterventionRecommendation(String interventionRecommendation) {
        this.interventionRecommendation = interventionRecommendation;
    }
}
