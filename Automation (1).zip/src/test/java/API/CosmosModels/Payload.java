package API.CosmosModels;

public class Payload {

}
