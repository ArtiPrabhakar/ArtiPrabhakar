package API.CosmosModels;

public class InsightDetails {
    private long unixShipmentCreationDate;
    private RiskProfile riskProfile;
    private Integer monthKey;
    private String documentType;
    private ShipmentKey shipmentKey;
    private Integer dayKey;
    private String accountId;
    private long shipmentCreationDate;
    private Integer yearKey;
    private String shipmentId;
    private long unixInsightsLatestMessageCreationDateTime;
    private long riskProfileCreatedTimestamp;
    private String id;
    private String rid;
    private String self;
    private String etag;
    private String attachments;
    private Integer ts;

    public long getUnixShipmentCreationDate() {
        return unixShipmentCreationDate;
    }

    public void setUnixShipmentCreationDate(long unixShipmentCreationDate) {
        this.unixShipmentCreationDate = unixShipmentCreationDate;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    public void setRiskProfile(RiskProfile riskProfile) {
        this.riskProfile = riskProfile;
    }

    public Integer getMonthKey() {
        return monthKey;
    }

    public void setMonthKey(Integer monthKey) {
        this.monthKey = monthKey;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public ShipmentKey getShipmentKey() {
        return shipmentKey;
    }

    public void setShipmentKey(ShipmentKey shipmentKey) {
        this.shipmentKey = shipmentKey;
    }

    public Integer getDayKey() {
        return dayKey;
    }

    public void setDayKey(Integer dayKey) {
        this.dayKey = dayKey;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public long getShipmentCreationDate() {
        return shipmentCreationDate;
    }

    public void setShipmentCreationDate(long shipmentCreationDate) {
        this.shipmentCreationDate = shipmentCreationDate;
    }

    public Integer getYearKey() {
        return yearKey;
    }

    public void setYearKey(Integer yearKey) {
        this.yearKey = yearKey;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public long getUnixInsightsLatestMessageCreationDateTime() {
        return unixInsightsLatestMessageCreationDateTime;
    }

    public void setUnixInsightsLatestMessageCreationDateTime(long unixInsightsLatestMessageCreationDateTime) {
        this.unixInsightsLatestMessageCreationDateTime = unixInsightsLatestMessageCreationDateTime;
    }

    public long getRiskProfileCreatedTimestamp() {
        return riskProfileCreatedTimestamp;
    }

    public void setRiskProfileCreatedTimestamp(long riskProfileCreatedTimestamp) {
        this.riskProfileCreatedTimestamp = riskProfileCreatedTimestamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }

    public String getEtag() {
        return etag;
    }

    public void setEtag(String etag) {
        this.etag = etag;
    }

    public String getAttachments() {
        return attachments;
    }

    public void setAttachments(String attachments) {
        this.attachments = attachments;
    }

    public Integer getTs() {
        return ts;
    }

    public void setTs(Integer ts) {
        this.ts = ts;
    }
}
