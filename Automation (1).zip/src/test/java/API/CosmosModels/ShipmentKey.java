package API.CosmosModels;

public class ShipmentKey {
    private String carrier;
    private String trackId;
    private String trackIdQualifier;

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getTrackId() {
        return trackId;
    }

    public void setTrackId(String trackId) {
        this.trackId = trackId;
    }

    public String getTrackIdQualifier() {
        return trackIdQualifier;
    }

    public void setTrackIdQualifier(String trackIdQualifier) {
        this.trackIdQualifier = trackIdQualifier;
    }
}
