package API.CosmosModels;

public class RiskProfile {
    private DelayPredictions delayPredictions;
    private Boolean callRecipient;

    public DelayPredictions getDelayPredictions() {
        return delayPredictions;
    }

    public void setDelayPredictions(DelayPredictions delayPredictions) {
        this.delayPredictions = delayPredictions;
    }

    public Boolean getCallRecipient() {
        return callRecipient;
    }

    public void setCallRecipient(Boolean callRecipient) {
        this.callRecipient = callRecipient;
    }
}
