package stepDefinitions;

import common.CommonHelpers;
import common.CosmosHelpers;
import common.DriverManager;
import common.QueryParameters;
import genericfunctions.API_GenericFun;
import genericfunctions.Constants;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.cucumber.datatable.DataTableTypeRegistry;
import io.cucumber.datatable.DataTableTypeRegistryTableConverter;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.text.WordUtils;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import pageObjects.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Slf4j
public class LocalizationTestUI extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    public DashboardPage dashboardPage;
    SoftAssertions softly;
    HomePage homePage;
    LoginPage loginPage;
    AdvisoryPage advisoryPage;
    CEDashboard ceDashboard;
    ShipmentOverviewPage shipmentOverviewPage;
    AccountAlias accountAlias;
    LocalizationHelper localizationHelper;
    ShipmentDetails shipmentDetails;
    ManagementCenterPage managementCenter;
    ProductCenter productCenter;
    DownloadCenterPage downloadCenterPage;
    TestAPI apiCall;
    CosmosHelpers cosmosHelpers;
    QueryParameters queryParameters;
    GenericFunction genericFunObj;
    PreferencesPage preferencePage;
    TrainingVideosPage trainingVideosPage;
    ManageQCPage manageQCPage;
    HeaderPage headerPage;
    API_GenericFun api_GenericFun;
    TestUI testUI;

    public LocalizationTestUI(CommonHelpers commonHelpers) throws IOException {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.softly = new SoftAssertions();
        this.homePage = new HomePage(this.commonHelpers);
        this.loginPage = new LoginPage(this.commonHelpers);
        this.advisoryPage = new AdvisoryPage(this.commonHelpers);
        this.shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
        this.localizationHelper = new LocalizationHelper(this.commonHelpers);
        this.shipmentDetails = new ShipmentDetails(this.commonHelpers);
        this.apiCall = new TestAPI(this.commonHelpers);
        this.queryParameters = new QueryParameters();
        this.genericFunObj = new GenericFunction();
        this.preferencePage = new PreferencesPage(this.commonHelpers);
        this.ceDashboard = new CEDashboard(this.commonHelpers);
        this.manageQCPage = new ManageQCPage(this.commonHelpers);
        this.headerPage = new HeaderPage(this.commonHelpers);
        this.api_GenericFun = new API_GenericFun(this.commonHelpers);
        this.managementCenter = new ManagementCenterPage(this.commonHelpers);
        this.productCenter = new ProductCenter(this.commonHelpers);
        this.trainingVideosPage = new TrainingVideosPage(this.commonHelpers);
        this.testUI = new TestUI(this.commonHelpers);
        this.dashboardPage = new DashboardPage(this.commonHelpers);
        this.downloadCenterPage = new DownloadCenterPage(this.commonHelpers);
        this.accountAlias = new AccountAlias(this.commonHelpers);
    }

    @Given("^I verify \"([^\"]*)\" is displayed in the portal - localization$")
    public void i_verify_is_displayed_in_the_portal(String text) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            text = this.genericFunObj.getLocalizedValue(text);

            testUI.i_verify_is_displayed_in_the_portal(text);

        }
    }

    @Then("^I validate the menu option \"([^\"]*)\" is available on left pane - localization$")
    public void i_validate_the_menu_option_is_available_on_left_pane(String menuOption) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            if (menuOption.equalsIgnoreCase("Sustainability")) {
                boolean sustainabilityFeatureEnabled = (boolean) this.commonHelpers
                        .getValuefromContextStore("sustainabilityFeatureEnabled");
                if (!sustainabilityFeatureEnabled) {
                    log.info(
                            " **INFORMATION** Sustainability flag is off. hence avoiding the validation for the same. It will not appear on left side");
                    return;
                }
            }
            menuOption = this.genericFunObj.getLocalizedValue(menuOption);
            Assert.assertTrue((this.homePage.IsSideMenuVisibility(menuOption)));
        }
    }

    @When("^user navigates to \"([^\"]*)\" menu - localization$")
    public void user_navigates_to_menu(String menuOption) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {

            this.waitUntilNotVisible(this.loadingIndicator, 20);
            this.ScrollToTop();
            menuOption = this.genericFunObj.getLocalizedValue(menuOption);

            if (Constants.SubMenuModules.contains(menuOption)) {
                this.homePage.verifySideMenuVisibility(menuOption);
                this.waitUntilNotVisible(this.loadingIndicator);
                this.ScrollToTop();
                this.homePage.navigateToDefaultSubMenu(menuOption);
            } else {
                this.JavaScriptClick(By.xpath(String.format(homePage.menu, menuOption)));
            }
        }

        this.waitUntilNotVisible(this.loadingIndicator, 30);
        this.waitForDOMToLoad(DriverManager.getDrv());
    }

    @Then("^verify \"([^\"]*)\" is shown on Persitent header - localization$")
    public void verify_is_shown_on_Persitent_header(String menuOption) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            String[] breadCrumbs = menuOption.split("/");
            for (String menu : breadCrumbs) {
                if (menu.contains("FedEx® Surround")) {
                    menu = "FedEx(MD) Surround";
                } else {
                    menu = this.genericFunObj.getLocalizedValue(menu);
                }
                Assertions.assertThat(homePage.verifyPersitentHeader(menu).getText().trim()).contains(menu);
            }
        }
    }

    @When("^I verify checkbox \"([^\"]*)\" is \"([^\"]*)\" - localization$")
    public void i_verify_checkbox_is(String checkBoxName, String state) {
        checkBoxName = this.genericFunObj.getLocalizedValue(checkBoxName);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Checkbox state is incorrect",

                    this.advisoryPage.verifyCheckBoxSelection(checkBoxName, state));
        }
    }

    @Given("^I click on \"([^\"]*)\" quick view card - localization$")
    public void i_click_on_quick_view_card(String cardName) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
                //cardName = this.genericFunObj.getLocalizedValue(cardName);
            }
            this.shipmentOverviewPage.ClickOncardViewLocalization(cardName);
        }
    }

    @When("^I click on \"([^\"]*)\" sub-menu - localization$")
    public void i_click_on_sub_menu(String subMenu) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            subMenu = this.genericFunObj.getLocalizedValue(subMenu);
            this.advisoryPage.NavigateToSubMenu(subMenu);
        }
    }

    @When("^I click on \"([^\"]*)\" in Preference SecondarySideBar - localization$")
    public void i_click_on_in_Preference_SecondarySideBar(String SecondarySideOption) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            SecondarySideOption = this.genericFunObj.getLocalizedValue(SecondarySideOption);
            Assert.assertTrue("Click on secondary Side Options",
                    this.preferencePage.ClickOnSecondaryOptions(SecondarySideOption));
        }
    }

    @And("^I validate \"([^\"]*)\" column is present in the FedEx Accounts - localization$")
    public void iValidateColumnIsPresentInTheFedExAccounts(String columnName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            columnName = this.genericFunObj.getLocalizedValue(columnName);
            this.preferencePage.validateFedexPreferenceColumnIsPresent(columnName);
        }

    }

    @Then("user validate the text got translated as per the language on overview page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnOverviewPage(DataTable table) {
        {
            this.homePage.validateHomePageDataTranslation(table);
        }
    }

    @Then("user validate the text got translated as per the language on my shipments page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnMyShipmentsPageForLocalization(DataTable dataTable) {
        {
            this.shipmentOverviewPage.validateColumnBasicsValidation(dataTable);
        }
    }

    @When("user navigates to {string} menu for localization")
    public void userNavigatesToMenuForlocalization(String menu) {
        menu = this.genericFunObj.getLocalizedValue(menu);
        this.testUI.user_navigates_to_menu(menu);
    }

    @And("I click on {string} in the portal for localization")
    public void iClickOnInThePortalForlocalization(String element) {
        String xpath = this.buildXpathForString(element);
        String localised = this.genericFunObj.getLocalizedValue(element);
        xpath = xpath.replace(element, localised);
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(getByusingString(xpath));
        this.waitUntilVisible(this.loadingIndicator, 5);
        this.waitUntilNotVisible(this.loadingIndicator, 30);
        this.waitForDOMToLoad(DriverManager.getDrv());
    }

    @And("I click on {string} text in the portal for localization")
    public void iClickOnInThePortalTextForlocalization(String element) {
        String localizedValue = this.genericFunObj.getLocalizedValue(element);
        String xpath = "";
        switch (element) {
            case "Preferences":
                xpath = String.format("//span[text()=\"%s\"]", localizedValue);
                break;
            default:
                Assertions.fail("You have passed an element which is not handled here --> " + element);

        }
        this.waitUntilNotVisible(this.loadingIndicator, 30);
        this.findElement(getByusingString(xpath)).click();
        this.waitForDOMToLoad(DriverManager.getDrv());
    }

    @Then("user validate the text got translated as per the language on preferences page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnPreferencesPageForLocalization(DataTable dataTable) {
        this.preferencePage.validateSettingsLocalization(dataTable);
    }

    @Then("user validate the text got translated as per the language on preferred location section of preferences page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnPreferredLocationSectionOfPreferencesPageForLocalization(
            DataTable dataTable) {
        this.preferencePage.validatePreferredLocLocalization(dataTable);
    }

    @Then("user validates the text got translated as per the language on FedEx Accounts section of Preferences page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnFedExAccountsSectionOfPreferencesPageForLocalization(
            DataTable dataTable) {
        this.preferencePage.validateFedExAccountsLocalization(dataTable);
    }

    @Then("user validate the text got translated as per the language on shipment Details page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        this.shipmentDetails.validateTabHeadings(dataTable);
    }

    @Then("user validate the text got translated as per the language under history on shipment Details page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageUnderOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        this.shipmentDetails.validateOptionsUnderHistory(dataTable);
    }

    @Then("user validate the text got translated as per the language for personal note on shipment Details page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageForPersonalNoteOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        this.shipmentDetails.validatePersonalNoteDetailsFieldsForlocalization(dataTable);
    }

    @And("I select {string} option from the date {string} dropdown for localization")
    public void iSelectOptionFromTheDateDropdownForLocalisation(String option, String value) {
        String localizedValue = this.genericFunObj.getLocalizedValue(option);
        this.testUI.i_select_option_from_the_date_dropdown_localised(option, localizedValue, value);
    }

    @Then("user validate the text got translated as per the language on Weather Forecast section of Advisories page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnWeatherForecastSectionOfAdvisoriesPageForLocalization(
            DataTable dataTable) throws InterruptedException {
        this.advisoryPage.validateWeatherForecastLocalisation(dataTable);
    }

    @Then("I validate the text got translated as per the language for section on purple bar on shipment Details page for localization")
    public void iValidateTheTextGotTranslatedAsPerTheLanguageForSectionOnPurpleBarOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        if (this.commonHelpers.getValuefromContextStore("NumberOfShipments") != "0") {
            this.shipmentOverviewPage.clickonFirstTrackingNumber();
            this.shipmentDetails.validatePurpleBarForLocalization(dataTable);
            this.iClickOnInThePortalForlocalization("BACK");

        }
    }

    @Then("I validate the text got translated as per the language for section below purple bar on shipment Details page for localization")
    public void iValidateTheTextGotTranslatedAsPerTheLanguageForSectionBelowPurpleBarOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        this.shipmentDetails.validateSectionUnderPurpleBarForLocalization(dataTable);
    }

    @And("I validate the text got translated as per the language for section related to multiple pieces on shipment Details page for localization")
    public void iValidateTheTextGotTranslatedAsPerTheLanguageForSectionRelatedToMultiplePiecesOnShipmentDetailsPageForLocalization(
            DataTable dataTable) {
        this.shipmentDetails.validateMultiplePiecesTable(dataTable);
    }

    @Then("user validate the text got translated as per the language for {string} under Shipment Data on shipment Details page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageForUnderShipmentDataOnShipmentDetailsPageForLocalization(
            String mainSection, DataTable dataTable) {
        this.shipmentDetails.validateSectionUnderShipmentData(mainSection, dataTable);
    }

    @Then("user validate the text got translated as per the language on Account Summary section of Dashboard page for localization")
    public void userValidateTheTextGotTranslatedAsPerTheLanguageOnAccountSummarySectionOfDashboardPageForLocalization(
            DataTable dataTable) {
        this.dashboardPage.validateBasicHeadersOnAccountSummary(dataTable);
    }

    @Then("user validates the text got translated as per the language on Download Center page for localization")
    public void userValidatesTheTextGotTranslatedAsPerTheLanguageOnDownloadCenterPageForLocalization(
            DataTable dataTable) {
        this.downloadCenterPage.validateDownloadCenterLocalization(dataTable);
    }

    @Then("user validates the text got translated as per the language on hovering over menu options on My Shipments page for localization")
    public void userValidatesTheTextGotTranslatedAsPerTheLanguageOnHoveringOverMenuOptionsOnMyShipmentsPageForLocalization(
            DataTable dataTable) {
        this.shipmentOverviewPage.validateHoverOverMenuMyShipmentsLocalization(dataTable);
    }

    @Then("I validate the text got translated as per the language for Preferred Locations section under Advisories")
    public void iValidateTheTextGotTranslatedAsPerTheLanguageForPreferredLocationsSectionUnderAdvisories(
            DataTable dataTable) {
        this.advisoryPage.validatePreferredLocationLocalization(dataTable);
    }

    @Then("I select below values from the {string} dropdown for localization")
    public void i_select_below_values_from_the_dropdown_for_localization(String DropDownType, DataTable table)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            DropDownType = DropDownType.equalsIgnoreCase("SHIPMENT TYPES") ? "Types" : DropDownType;
            DropDownType = this.genericFunObj.getLocalizedValue(DropDownType);
            List<String> optionsToSelect = table.asList(String.class);
            List<String> optionsToSelectLocalised = new ArrayList<>();
            List<List<String>> localisedTable = new ArrayList<>();
            DataTableTypeRegistry registry = new DataTableTypeRegistry(Locale.ENGLISH);
            DataTable.TableConverter tableConverter = new DataTableTypeRegistryTableConverter(registry);
            for (String options : optionsToSelect) {
                if (!options.contains("SenseAware ID")) {
                    optionsToSelectLocalised.add(this.genericFunObj.getLocalizedValue("Types " + options));
                } else {
                    optionsToSelectLocalised.add(this.genericFunObj.getLocalizedValue(options));
                }
            }
            localisedTable.add(optionsToSelectLocalised);

            Assertions.assertThat(this.shipmentOverviewPage.SelectValuesFromDDForLocalization(DropDownType,
                            DataTable.create(localisedTable, tableConverter)))
                    .withFailMessage("Selection and validation of shipment Types is failed")
                    .isTrue();
        }
    }

    @And("I remove the below filters using close icon in filter bubble for localization")
    public void i_remove_the_below_filters_using_close_icon_in_filter_bubble_for_localization(DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> filterBubbles = table.asList(String.class);
            List<String> filterBubblesLocalized = new ArrayList<>();
            List<List<String>> localizedTable = new ArrayList<>();
            DataTableTypeRegistry registry = new DataTableTypeRegistry(Locale.ENGLISH);
            DataTable.TableConverter tableConverter = new DataTableTypeRegistryTableConverter(registry);
            for (String filterBubble : filterBubbles) {
                filterBubblesLocalized
                        .add(this.genericFunObj.getLocalizedValue("FILTERBUBBLE." + filterBubble));
            }
            localizedTable.add(filterBubblesLocalized);
            this.shipmentOverviewPage.RemoveFiltersinBubble(DataTable.create(localizedTable, tableConverter));
        }
    }

    @And("I change the language to {string} from the footer")
    public void iChangeTheLangauageToFromTheFooter(String language) {
        String localeToChangeTo = Constants.EN_US;
        switch (language) {
            case "English":
                localeToChangeTo = Constants.EN_CA;
                break;
            case "French":
                localeToChangeTo = Constants.FR_CA;
                break;
        }
        this.selectDropdown(this.homePage.languageSelector, "value", localeToChangeTo);
        // updating the locale value as well
        GenericFunction.locale = localeToChangeTo;
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    @And("I verify left side menu {string} is {string} for localization")
    public void iVerifyLeftSideMenuIsForLocalization(String option, String state) {
        option = this.genericFunObj.getLocalizedValue(option);
        Assertions.assertThat(this.homePage.ValidateLeftSideMenuVisibility(option, state)).isTrue();
    }

    @Then("Validate the text that got translated as per the language for global search page for localization")
    public void userValidateTheTexThattGotTranslatedAsPerTheLanguageForGlobalSearchPageForLocalization(
            DataTable dataTable) throws Throwable {
        this.shipmentOverviewPage.validateGlobalSearchTab(dataTable);
    }

    @Then("Navigate to multipletrackingnumbers page and validate the text for localization")
    public void navigateToMultipleTrackingNumberPageAndValidateTheTextForLocalization(
            DataTable dataTable) throws Throwable {
        this.commonHelpers.AddToContextStore("InvalidTrackingID", "111111111111");
        this.commonHelpers.AddToContextStore("partialInvalidTrackingID", "sds");
        this.shipmentOverviewPage.validateMultipleTrackingPage(dataTable);
    }

    @Then("Use partial trackingId and validate the results for localization")
    public void useAnInvalidTrackingIdAndValidateTheResultsForLocalization(
            DataTable dataTable) throws Throwable {
        this.shipmentOverviewPage.validateInvalidSearchResults(dataTable);
    }

    @When("User navigates to {string} for localization")
    public void userNavigatesToElementForLocalization(String name) throws Throwable {
        this.shipmentOverviewPage.navigateToElement(name);
    }

    @Then("user validates the text got translated as per the language for Types option for localization")
    public void userValidatesTheTextGotTranslatedAsPerTheLanguageForTypesOptionForLocalization(DataTable dataTable) {
        this.shipmentOverviewPage.typesOptionsValidation(dataTable);
    }

    @Then("I validate that the filter bubble with the options for localization")
    public void iValidateThatTheFilterBubbleWithTheOptionsForLocalization(DataTable dataTable) {
        this.shipmentOverviewPage.filterBubbleValidation(dataTable);
    }

    @Then("I validate that the filter bubble with the {string} options for localization")
    public void iValidateThatTheFilterBubbleWithTheOptionsForLocalizationWithUserChoice(String condition, DataTable dataTable) {
        this.shipmentOverviewPage.filterBubbleValidationWithUserChoice(condition, dataTable);
    }


    @Then("user validates the column names got translated as per the language in columns menu on my shipments page for localization")
    public void userValidatesTheColumnNamesGotTranslatedAsPerTheLanguageInColumnsMenuOnMyShipmentsPageForLocalization(
            DataTable dataTable) {
        this.shipmentOverviewPage.validateColumnNamesTranslationinColumnsMenu(dataTable);
    }

    @Then("user validates the column names got translated as per the language in shipments list on my shipments page for localization")
    public void userValidatesTheColumnNamesGotTranslatedAsPerTheLanguageInShipmentsListOnMyShipmentsPageForLocalization(
            DataTable dataTable) {
        this.shipmentOverviewPage.validateColumnNamesTranslationinShipmentsList(dataTable);
    }

    @And("I click on {string} link in My Shipments for localization")
    public void iClickOnLinkInMyShipmentsForLocalization(String link) {
        link = this.genericFunObj.getLocalizedValue(link);
        this.testUI.i_click_on_link_in_My_Shipments(link);
    }

    @When("I Apply below Column options for tab {string}")
    public void iApplyBelowColumnOptionsForTab(String tab, DataTable table) {
        this.localizationHelper.selectColumnOptions(tab, table);
    }


    @And("I click on Element {string} in the portal with localization")
    public void iClickOnElementInThePortalWithLocalization(String value) {
        this.localizationHelper.clickOnElementByTranslatedText(value);
    }

    @Then("I verify the field lables")
    public void iVerifyTheFieldLables(DataTable table) {
        this.shipmentDetails.FieldLabels(table);
    }

    @And("I verify the First Level Categories of Filters")
    public void iVerifyTheFirstLevelCategoriesOfFilters(DataTable table) {
        this.shipmentDetails.firstLevelCategories(table);
    }

    @And("I verify the Second Level Categories of Filter {string}")
    public void iVerifySecondLebelCategoriesOfFilters(String parentFilter, DataTable table) {
        this.shipmentDetails.secondLevelCategories(parentFilter, table);
    }

    @And("To verify the all types of search")
    public void toVerifyTheAllTypesOfSearch(DataTable table) {
        this.shipmentDetails.allSearchTypesInColumns(table);

    }

    @Then("I Navigate or Apply filters by {string} filter options for localization")
    public void iNavigateOrApplyFiltersByFilterOptionsForLocalization(String filterOptions) {
        this.localizationHelper.selectFilterOptions(filterOptions);
    }

    @Then("I validate below text for localization")
    public void iValidateBelowTextForLocalization(DataTable table) {
        this.localizationHelper.selectFilterOptionValues(table);
    }

    @Then("I verify data in downloaded file for {string} column is matching with UI for Localization")
    public void iVerifyDataInDownloadedFileForColumnIsMatchingWithUIForLocalization(String columnName) throws IOException {
        String translatedColumnValue = this.genericFunObj.getLocalizedValue(columnName);
        this.testUI.verify_data_in_downoaded_file_with_ui(translatedColumnValue);

    }

    @Then("I verify {string} rows of data {string} for column grid {string} using {string} in UI for localization")
    public void iVerifyRowsOfDataForColumnGridUsingInUIForLocalization(String rowsToValidate, String data, String columnName, String validation) throws IOException {
        String translatedColumnValue = this.genericFunObj.getLocalizedValue(data);
        this.testUI.verify_data_in_ui_grid(rowsToValidate, translatedColumnValue, columnName, validation);
    }


    @And("I select the below filters in filter edit grid")
    public void iSelectTheBelowFiltersInFilterEditGrid(DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> filterTable = dataTable.asMap(String.class, String.class);
            this.localizationHelper.SelectFiltersinView(filterTable);
        }
    }

    @When("I Apply below Column options for tab {string} based on Search")
    public void iApplyBelowColumnOptionsForTabBasedOnSearch(String tab, DataTable table) {
        this.localizationHelper.selectColumnOptionsBasedOnSearch(tab, table);
    }


    @And("I apply filter by selecting value in {string} for filter {string}")
    public void iApplyFilterWithFilterOptionForLocalization(String search, String filterOptions, DataTable table) {
        this.shipmentOverviewPage.selectFilterOption(search, filterOptions, table);
    }

    @When("^I click on \"([^\"]*)\" in portal for localization$")
    public void navi_click_on_in_the_portal_for_localization(String link) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            if (!link.equalsIgnoreCase("RESET")) {
                if ((link.equalsIgnoreCase("Add file to download center"))
                        && this.commonHelpers.getValuefromContextStore("DownloadType") != null) {
                    if (this.commonHelpers.getValuefromContextStore("DownloadType").toString()
                            .contains("COMBINED FILES")) {
                        this.JavaScriptClick(this.getByusingString("(" + (this.buildXpathForString(link)) + ")[2]"));
                    }
                } else {
                    if (link.equalsIgnoreCase("EXPORT LIST")) {
                        //link = this.genericFunObj.getLocalizedValue(link);
                        if (!this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString(link)))) {
//                            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                            this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(link)));
                            this.commonHelpers.thinkTimer(3000);
                            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP")));
                        } else {
                            log.error("**WARNING** - Export list button was not enabled(diplayed). Hence skipping.");
                            log.error("Possible Reasons - No Data in grid to export");
                            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                        }
                    } else {
                        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                        //below wait is only when the download button is clicked and it doesn't impact other operations
                        this.waitUntilNotVisible(this.shipmentOverviewPage.dcfileloadingIndicator, 540);
                    }
                    // this.waitUntilNotVisible(By.xpath(this.buildXpathForString(link)));
                }
            }
            if (link.equalsIgnoreCase("RESET")) {
                String localizedValue = this.genericFunObj.getLocalizedValue(link);
                this.commonHelpers.thinkTimer(3);
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString(localizedValue)));
                // this.shipmentOverviewPage.AcceptResetPopup();
                By resetPopup = By.xpath("// button[contains(text(),'" + localizedValue + "')]");
                this.JavaScriptClick(resetPopup);
                this.commonHelpers.thinkTimer(3);
            }
        }

    }

    @Then("^I apply filter to display less than 1000 records for localization$")
    public void display_less_than_thousand_records_for_localization() {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.filterLessThanThousandRecordsForLocalization();
        }
    }

    @And("^I perform right click on selected shipments to select \"([^\"]*)\" option for localization$")
    public void i_perform_right_click_to_select_something(String optionToSelect) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (!GenericFunction.locale.equalsIgnoreCase(Constants.EN_US)) {
                optionToSelect = this.genericFunObj.getLocalizedValue(optionToSelect);
            }
            this.rightClickAndSelect(this.shipmentOverviewPage.shipmentOverviewFirstRow,
                    By.xpath(getXPathforAnyElementWithText(optionToSelect)));
        }
    }

    @And("I click on cancel button to close popup for localization")
    public void iClickOnCancelButtonToClosePopup() {
        By closeButton = By.xpath("//button/div[@class='close-icn bk']");
        JavaScriptClick(closeButton);
    }

    @And("I validate the {string} button on the screen")
    public void iValidateButtonOnScreen(String button) {
        if (!GenericFunction.locale.equalsIgnoreCase(Constants.EN_US)) {
            button = this.genericFunObj.getLocalizedValue(button);
        }
        softly.assertThat(this.elementIsDisplayed(this.getByusingString(String.format(this.downloadCenterPage.clearOrDownloadButtonText2, button)))).isTrue();
    }

    @Then("^I verify following footer element are displayed in surround portal for localization$")
    public void i_verify_following_footer_element_are_displayed_in_surround_portal(DataTable table) throws Throwable {
        Assert.assertTrue("Failed in validating Footer elements", homePage.ValidateFooterElementsForLocalization(table));
    }

    @Then("^I verify filter bubble in my shipments page for localization$")
    public void i_verify_filter_bubble_in_my_shipments_page_for_localization(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            Assert.assertTrue("Filter Bubble verification failed",
                    this.shipmentOverviewPage.ValidateFilterBubbleForLocalization(table));
        }
    }

    @Then("Validate the WaterMark for Search box for localization")
    public void validateTheWaterMarkForSearchBox() {
        String search = "SEARCH BY ACCOUNTS";
        String lang = GenericFunction.ReadConfigFile("LANG");
        if (!lang.equalsIgnoreCase("en-us")) {
            search = this.genericFunObj.getLocalizedValue(search);
        }
        this.accountAlias.validateWaterMarkforSearchBarLocalization(search);
    }

    @Then("^I validate account header is \"([^\"]*)\" displayed or not for localization$")
    public void i_validate_accounts_header(String header) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String lang = GenericFunction.ReadConfigFile("LANG");
        if (!lang.equalsIgnoreCase("en-us")) {
            header = this.genericFunObj.getLocalizedValue(header);
        }
        Assert.assertTrue("Header is not displayed for the accounts",
                this.preferencePage.isHeaderDisplayed(header));
    }

    @And("Validate the below text on the screen for account alias")
    public void validateTheTextOnTheScreenForLocalization(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            commonHelpers.thinkTimer(5000);
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                if (validation.contains("|")) {
                    String[] split = validation.split("\\|");
                    for (int i = 0; i < split.length; i++) {
                        if (!GenericFunction.locale.equalsIgnoreCase(Constants.EN_US)) {
                            split[i] = this.genericFunObj.getLocalizedValue(split[i]);
                        }
                        Assert.assertTrue("The value : " + split[i] + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForString(split[i], "")), false));
                    }
                } else {
                    if (!genericFunObj.locale.equalsIgnoreCase(Constants.EN_US)) {
                        validation = this.genericFunObj.getLocalizedValue(validation);
                    }
                    Assert.assertTrue("The value : " + validation + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForString(validation, "")), false));
                }
            }
        }
    }
}

