package stepDefinitions;

import API.RequestModels.TestCase;
import common.DriverManager;
import common.Singleton;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import pageObjects.SeleniumGenericFunction;
import genericfunctions.GenericFunction;

import java.net.MalformedURLException;
import java.util.Collection;

@Slf4j
public class Hooks {
    public static Boolean customerTestCase = true;

    @Before
    public void setup(Scenario scenario) throws MalformedURLException {

        // To not close the browser for CE
        customerTestCase = !scenario.getSourceTagNames().contains("@CE");
        GenericFunction.TESTCASE_STATUS="";
        if(scenario.getSourceTagNames().contains("@CE")){
            GenericFunction.PORTAL="CE";
        }else{
            GenericFunction.PORTAL="Customer";
        }

        log.info("\n ---------------------------------------Started Execution of Scenario---------------------------------------");
        log.info(scenario.getName() + " Execution is started");
         //SeleniumGenericFunction.getDriver(scenario);
         DriverManager.getDrv();

    }


    @After
    public void close(Scenario scenario) throws Exception {
        log.info("Scenario executed. Now closing the browser");

        try {
            SeleniumGenericFunction.tearDown(scenario);
            // if its CE we will not close the browser
            boolean serverExecution = SeleniumGenericFunction.getCEHostExecution();
            if (customerTestCase || serverExecution) {
                DriverManager.getDrv().quit();
                DriverManager.setDrv(null);
                DriverManager.unload();
            }
            //DriverManager.getDrv()Manager.unload();

        } catch (Exception e) {
            log.error("Issue in taking screenshot May be case is of API");
        }
    }

    @After
    public void createTestResultJson(Scenario scenario) {
        Collection<String> col = scenario.getSourceTagNames();
        for (String e : col) {
            if (e.contains("TEST")|| e.contains("DEPENDENT")) {
                TestCase testCaseData = new TestCase();
                String id = StringUtils.substringAfter(e, "=");
                testCaseData.setTestCaseId(Integer.valueOf(id));
                String outcome = String.valueOf(scenario.getStatus());
                String cap="";
                if(GenericFunction.TESTCASE_STATUS.equalsIgnoreCase("NotExecuted")){
                    cap = "NotExecuted";
                }else {
                    cap = outcome.substring(0, 1).toUpperCase() + outcome.substring(1);
                }
                testCaseData.setOutcome(cap);
                Singleton.getInstance().addTestCase(testCaseData);
            }
        }

    }


}