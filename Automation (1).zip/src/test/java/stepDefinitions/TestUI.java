package stepDefinitions;

import com.microsoft.azure.documentdb.Document;
import com.microsoft.azure.documentdb.FeedResponse;
import com.opencsv.exceptions.CsvException;
import common.*;
import genericfunctions.API_GenericFun;
import genericfunctions.Constants;
import genericfunctions.DateTimeUtils;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.lv.Ja;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageObjects.*;
import java.io.IOException;
import java.sql.Driver;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.Map.Entry;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
public class TestUI extends SeleniumGenericFunction {
    public CommonHelpers commonHelpers;
    SoftAssertions softly;
    HomePage homePage;
    LoginPage loginPage;
    ScheduledReports reportCenter;
    AdvisoryPage advisoryPage;
    CEDashboard ceDashboard;
    ShipmentOverviewPage shipmentOverviewPage;
    ShipmentDetails shipmentDetails;
    ManagementCenterPage managementCenter;
    ProductCenter productCenter;
    TestAPI apiCall;
    CosmosHelpers cosmosHelpers;
    QueryParameters queryParameters;
    GenericFunction genericFunObj;
    PreferencesPage preferencePage;
    AccountAlias accountAlias;
    TrainingVideosPage trainingVideosPage;
    ManageQCPage manageQCPage;
    HeaderPage headerPage;
    API_GenericFun api_GenericFun;
    DateTimeUtils dateTimeUtils;

    public TestUI(CommonHelpers commonHelpers) {
        super(commonHelpers);
        this.commonHelpers = commonHelpers;
        this.softly = new SoftAssertions();
        this.homePage = new HomePage(this.commonHelpers);
        this.loginPage = new LoginPage(this.commonHelpers);
        this.advisoryPage = new AdvisoryPage(this.commonHelpers);
        this.shipmentOverviewPage = new ShipmentOverviewPage(this.commonHelpers);
        this.shipmentDetails = new ShipmentDetails(this.commonHelpers);
        this.reportCenter = new ScheduledReports(this.commonHelpers);
        this.apiCall = new TestAPI(this.commonHelpers);
        // this.cosmosHelpers = new CosmosHelpers(this.commonHelpers);
        this.queryParameters = new QueryParameters();
        this.genericFunObj = new GenericFunction();
        this.preferencePage = new PreferencesPage(this.commonHelpers);
        this.ceDashboard = new CEDashboard(this.commonHelpers);
        this.manageQCPage = new ManageQCPage(this.commonHelpers);
        this.accountAlias = new AccountAlias(this.commonHelpers);
        this.headerPage = new HeaderPage(this.commonHelpers);
        this.api_GenericFun = new API_GenericFun(this.commonHelpers);
        this.managementCenter = new ManagementCenterPage(this.commonHelpers);
        this.productCenter = new ProductCenter(this.commonHelpers);
        this.trainingVideosPage = new TrainingVideosPage(this.commonHelpers);
        this.dateTimeUtils = new DateTimeUtils();
    }

    @Given("^I get the envt variable from cmd$")
    public void i_get_the_envt_variable_from_cmd() {
        log.info("Environment variable: " + GenericFunction.ENV);
    }

    // Sample method to Read documents from cosmos DB
    @Then("^I Get the data from cosmos$")
    public void i_Get_the_data_from_cosmos() {
        // this.queryParameters.AddQueryParams(FilterClause.Default, "c.id",
        // "Andersen.1");
        // this.queryParameters.AddQueryParams(FilterClause.Default, "c.lastName",
        // "Andersen");
        FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDb("surround-shipments-db-dev",
                "shipmentDetails", this.queryParameters, "top 1");
        for (Document doc : queryResults.getQueryIterable()) {
            log.info("Read " + doc);
        }
    }

    @Then("^I Get the \"([^\"]*)\" document with below query params$")
    public void i_Get_the_document_with_below_query_params(String selectType, DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.queryParameters = this.cosmosHelpers.TransformQueryParams(table);
        if (selectType.contains("accountId")) {
            FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDb(this.commonHelpers.DATABASENAME,
                    "accountDetails", this.queryParameters, selectType);

            String allResponse = "";
            for (Document doc : queryResults.getQueryIterable()) {
                allResponse = allResponse + "'" + JSONHelpers.StringtoJObject(doc.toJson()).get("accountId") + "',";
            }
            allResponse = allResponse.substring(0, allResponse.length() - 1);
            this.commonHelpers.AddToContextStore("MonitoredAccounts", allResponse);
        } else {
            FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDb(this.commonHelpers.DATABASENAME,
                    "shipmentDetails", this.queryParameters, selectType);
            if (selectType.equalsIgnoreCase("c.shipmentId")) {
                this.commonHelpers.AddToContextStore("ShipmentIds",
                        this.commonHelpers.SetCosmosResptoList(queryResults, selectType));
            } else {
                for (Document doc : queryResults.getQueryIterable()) {
                    System.out.printf("\tRead %s%n", doc.toJson());
                    this.commonHelpers.SetCosmosToContextStore(doc.toJson(), selectType);
                }
            }
        }
    }

    @Then("^I validate \"([^\"]*)\" as \"([^\"]*)\" is displayed in summary bar of details page$")
    public void i_validate_as_is_displayed_in_summary_bar_of_details_page(String field, String value) {
        Assert.assertTrue(String.format("Validation of panel items: %s : %s is failed", field, value),
                this.shipmentDetails.ValdatePanelitems(field, value));
    }

    @Then("^I Get the \"([^\"]*)\" documents in cosmos and store \"([^\"]*)\" in ContextStore$")
    public void i_Get_the_documents_in_cosmos_and_store_in_ContextStore(String surroundEligibilityType,
                                                                        String ContextStoreKey) {
        if (this.commonHelpers.verifyKeyinContextStore("UserContext")) {
            this.commonHelpers.AddToContextStore(ContextStoreKey,
                    this.commonHelpers.GetAccIdsofSurroundEligibility(surroundEligibilityType));
        } else {
            FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDbForStaticQuery(
                    this.commonHelpers.DATABASENAME, "accountDetails", this.queryParameters, "top 1 account",
                    surroundEligibilityType);
            for (Document doc : queryResults.getQueryIterable()) {
                System.out.printf(surroundEligibilityType + "  %s %n", doc.toJson());
                this.commonHelpers.AddToContextStore(ContextStoreKey,
                        JSONHelpers.StringtoJObject(doc.toJson()).get("accountId"));
            }
        }
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());

        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("user")
                || this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("Shipper")
                && virtualizationFlag) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Given("^I Read all accounts from company \"([^\"]*)\" documents in cosmos and store \"([^\"]*)\" in ContextStore$")
    public void i_Read_all_accounts_from_company_documents_in_cosmos_and_store_in_ContextStore(String CompanyCode,
                                                                                               String ContextStoreKey) throws Throwable {
        if (CompanyCode.contains("ContextStore")) {
            CompanyCode = this.commonHelpers.getValuefromContextStore(CompanyCode).toString();
        }
        FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDbCE(this.commonHelpers.DATABASENAME,
                "accountDetails", this.queryParameters, "c.accountId", CompanyCode);
        String allResponse = "";

        for (Document doc : queryResults.getQueryIterable()) {
            allResponse = allResponse + "'" + JSONHelpers.StringtoJObject(doc.toJson()).get("accountId") + "',";
        }
        allResponse = allResponse.substring(0, allResponse.length() - 1);
        this.commonHelpers.AddToContextStore(ContextStoreKey, allResponse);
    }

    @When("^I Read all the \"([^\"]*)\" document in cosmos for the \"([^\"]*)\" with below query params$")
    public void i_Read_all_the_document_in_cosmos_for_the_with_below_query_params(String QuickCardFilter,
                                                                                  String ContextStoreKey, DataTable table) throws Throwable {
        String allAccount = (String) this.commonHelpers.getValuefromContextStore(ContextStoreKey);

        this.waitUntilNotVisible(this.loadingIndicator);
        this.queryParameters = this.cosmosHelpers.TransformQueryParams(table);

        FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDbCE(this.commonHelpers.DATABASENAME,
                "shipmentDetails", this.queryParameters, QuickCardFilter, allAccount);

        int quickViewCardNumber = 0;
        String response = "";
        if (QuickCardFilter.contains("AT RISK1")) {
            for (Document doc : queryResults.getQueryIterable()) {
                response = response + "'" + JSONHelpers.StringtoJObject(doc.toJson()).get("shipmentId") + "',";
            }
            response = response.substring(0, response.length() - 1);
            this.commonHelpers.AddToContextStore(QuickCardFilter, response);
        } else {
            for (Document doc : queryResults.getQueryIterable()) {
                System.out.printf((doc.toJson()) + "%n");
                quickViewCardNumber = (Integer) JSONHelpers.StringtoJObject(doc.toJson()).get("_aggregate");
            }
            this.commonHelpers.AddToContextStore(QuickCardFilter, "" + quickViewCardNumber);
        }
    }

    @When("^I select \"([^\"]*)\" from dropdown$")
    @Then("^select \"([^\"]*)\" company from drop down$")
    public void select_company_from_drop_down(String CompanyName) throws Throwable {
        if (CompanyName.equalsIgnoreCase("Destination Time Zone")) {
            this.shipmentDetails.SelectValueFromDropDown("text", CompanyName);
        } else {
            CompanyName = CompanyName.contains("ContextStore")
                    ? this.commonHelpers.getValuefromContextStore(CompanyName).toString()
                    : CompanyName;
            this.shipmentOverviewPage.selectNextComapnyfromDropDown("text", CompanyName);
        }
    }

    @Then("^Verify QuickViewIndicatorCount \"([^\"]*)\" is same as ContextStore from cosmos$")
    public void verify_QuickViewIndicatorCount_is_same_as_ContextStore_from_cosmos(String QuickViewCard)
            throws Throwable {

        log.info(QuickViewCard + " card count in cosmos = "
                + this.commonHelpers.getValuefromContextStore("cosmos-" + QuickViewCard));
        log.info(QuickViewCard + " card count in portal = "
                + this.commonHelpers.getValuefromContextStore(QuickViewCard));
        String cosmosval = (String) this.commonHelpers.getValuefromContextStore("cosmos-" + QuickViewCard);
        String portalval = (String) this.commonHelpers.getValuefromContextStore(QuickViewCard);
        softly.assertThat(cosmosval.equalsIgnoreCase(portalval)).isTrue();
        if (QuickViewCard.equalsIgnoreCase("PRIORITY ALERT"))
            softly.assertAll();
    }

    @Given("^I fetch the \"([^\"]*)\" fusion document using \"([^\"]*)\" and store below values$")
    public void i_fetch_the_fusion_document_using_and_store_below_values(String queryType, String ContextSToreKey,
                                                                         DataTable table) throws Throwable {
        FeedResponse<Document> queryResults = this.cosmosHelpers.ReadDocumentFromDb(this.commonHelpers.DATABASENAME,
                "shipmentDetails", this.queryParameters, queryType);
        for (Document doc : queryResults.getQueryIterable()) {
            log.info(String.format("\tRead %s", doc.toJson()));
        }
    }

    @When("^User Navigate to \"([^\"]*)\"$")
    public void user_Navigate_to(String LUMINAPORTALLINK) throws Throwable {
        this.commonHelpers.AddToContextStore("luminalink", LUMINAPORTALLINK);
        this.loginPage.launchApplication(this.commonHelpers.getValuefromContextStore("luminalink").toString());
    }

    @Then("^I verify \"([^\"]*)\" \"([^\"]*)\" tile is selected$")
    public void i_verify_tile_is_selected(String menuType, String menuName) {
        Assert.assertTrue(this.advisoryPage.VerifyMenuSelection(menuType, menuName));
    }

    @Given("^I login to application using id \"([^\"]*)\"$")
    public void i_login_to_application_using_id(String loginId) throws Throwable {
        String userName = this.getUserId(loginId);
        String password = Constants.ShipperLogins.contains(userName) ? this.getCustomerPassword()
                : this.getCEPassword();
        // password = GenericFunction.ReadConfigFile("ENV").contentEquals("PROD")
        // ? this.keyVaultHelpers.getValuefromKeyVault("ProdShipperpwd")
        // : password;
        this.commonHelpers.AddToContextStore(loginId, userName);
        this.commonHelpers.AddToContextStore("password", password);
        if (loginId.contains("CE")) {
            this.loginPage.LogintoApp(userName, password, loginId);
            this.waitUntilNotVisible(this.loadingIndicator);
            this.commonHelpers.AddToContextStore("UserContext", "CE");
            String companyName = GenericFunction.ReadConfigFile("CE_COMPANY");
            String imageRoles = GenericFunction.ReadConfigFile("IMAGEROLE");
            if (!(this.elementIsDisplayed(By.xpath(String.format(labelContainsText, imageRoles))))) {
                user_navigates_to_menu("CE Preferences");
                i_click_on_in_Preference_SecondarySideBar("Settings");
                iSelectImageRoles(imageRoles);
            }
            Map<String, String> SelectCompany = new HashMap<String, String>() {{
                put(companyName, "all");

            }};
            i_select_accounts_from_dropdown_set_as_default_programatically("Company", "Set As Default", SelectCompany);
            user_navigates_to_menu("My Shipments");
            i_click_on_in_the_portal("Reset");
            this.genericFunObj.retrieveToken();
            this.apiCall.SetCEPrerequisites(loginId);
            this.api_GenericFun.WhenIMakeputCall("CE_PreferencesHierarchy_Update");
            this.apiCall.get_the_user_preferences_using_for_the_user("CE_Preferences_user", loginId);
            this.apiCall.CreatePayloadforPrefRole("CE_Preferences_user", "CE_PreferencesRole_Update",
                    "AssignDefaultRoles");
            this.api_GenericFun.WhenIMakeputCall("CE_PreferencesRole_Update");
//            this.loginPage.LogintoApp(userName, password, loginId);
            this.waitUntilNotVisible(this.loadingIndicator);
            // this.headerPage.SelectImageRoleFromConfig();
        } else {
            if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
                this.loginPage.LogintoApp(userName, password);
                this.waitUntilNotVisible(this.loadingIndicator, 30);
                this.waitUntilVisible(this.homePage.welcomeText, 30);
                this.apiCall.SetAccountIds(loginId);
                this.commonHelpers.AddToContextStore("UserContext", loginId);
            }
        }
        if (this.elementIsDisplayed(CloseUpdateTerms)) {
            this.JavaScriptClick(CloseUpdateTerms);
        }
    }

    @Given("^I set the \"([^\"]*)\" context for the execution$")
    public void i_set_the_context_for_the_execution(String loginId) throws Throwable {
        if (!loginId.contains("CE")) {
            String userName = this.getUserId(loginId);
            String password = Constants.ShipperLogins.contains(userName) ? this.getCustomerPassword()
                    : GenericFunction.ReadConfigFile("CEpwd");
            // String password = this.keyVaultHelpers.getValuefromKeyVault(userName +
            // "pwd");
            // password = GenericFunction.ReadConfigFile("ENV").contentEquals("PROD")
            // ? this.keyVaultHelpers.getValuefromKeyVault("ProdShipperpwd")
            // : password;
            this.commonHelpers.AddToContextStore("password", password);
            this.commonHelpers.AddToContextStore(loginId, userName);
            this.apiCall.SetAccountIds(loginId);
            this.commonHelpers.AddToContextStore("UserContext", loginId);
        } else {
            this.apiCall.SetCEPrerequisites(loginId);
            this.api_GenericFun.WhenIMakeputCall("CE_PreferencesHierarchy_Update");
            this.apiCall.get_the_user_preferences_using_for_the_user("CE_Preferences_user", loginId);
            this.apiCall.CreatePayloadforPrefRole("CE_Preferences_user", "CE_PreferencesRole_Update",
                    "AssignDefaultRoles");
            this.api_GenericFun.WhenIMakeputCall("CE_PreferencesRole_Update");
        }
    }

    @Given("^I click on \"([^\"]*)\" button$")
    public void i_click_on_button(String buttonText) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (buttonText.contains("Cancel")) {
                buttonText = "CANCEL";
            }
//            this.clickOnElement(this.getByusingString(this.getXPathforButton(buttonText)));
            JavaScriptClick(this.getByusingString(this.getXPathforButton(buttonText)));
            this.waitUntilNotVisible(loadingIndicator);

        }
    }

    @Then("^I Verify that the search \"([^\"]*)\" filter bubble is \"([^\"]*)\"$")
    public void i_Verify_that_the_search_filter_bubble_is(String view, String flag) throws Throwable {
        Assert.assertTrue("Something went wrong with view bubble",
                this.shipmentOverviewPage.VerifySearchBubble(view, flag));
    }

    @Then("^I Verify mts valid count with viewing count$")
    public void i_Verify_view_count_is_matching_with_Mts_search() throws Throwable {
        Assert.assertTrue("Mts Duplicate count is not matching",
                this.shipmentOverviewPage.mtsCountValidation());
    }

    @Then("^I Verify error message for \"([^\"]*)\" tracking Numbers$")
    public void i_Verify_error_msg_is(String flag) throws Throwable {
        int size = this.commonHelpers.getValuefromContextStore("InValid TrackingIds").toString().toCharArray().length;
        if (size > 4) {
            Assert.assertTrue("Something went wrong with view bubble",
                    this.shipmentOverviewPage.VerifyErrormsg(flag));
        } else {
            log.error("*WARNING* Since no invalid tracking Ids were entered, skipping the error message validation");
        }
    }

    @Then("^I verify the below header elements are displayed in surround portal$")
    public void i_verify_the_below_header_elements_are_displayed_in_surround_portal(DataTable table) {
        Assert.assertTrue("Failed in validating header elements", homePage.ValidateHeaderElements(table));
    }

    @Then("^\"([^\"]*)\" Opens$")
    public void opens(String arg1) {
        String LUMINAPORTALTITLE = GenericFunction.ReadConfigFile("LUMINAPORTALPAGETITLE");
        Assert.assertTrue(DriverManager.getDrv().getTitle().contains(LUMINAPORTALTITLE));
    }

    @When("^I click on the \"([^\"]*)\" view of MyShipments$")
    public void i_click_on_the_view_of_MyShipments(String viewState) throws Throwable {
        this.shipmentOverviewPage.expandView(viewState);
    }

    @Then("^I sort the dashboard columns and verify in UI with API$")
    public void i_sort_the_dashboard_columns_and_verify_in_UI_with_API(DataTable table) throws Throwable {
        Assert.assertTrue("Failed in validating sorting of the dashboard",
                this.ceDashboard.ValidateSortofColumns(table));
    }

    @Then("^I click on the expand icon of the sub navigation$")
    public void i_click_on_the_expand_icon_of_the_sub_navigation() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            if (!this.homePage.expandSubNavigation()) {
                this.clickOnElement(By.xpath(".//*[contains(@class,'kebab-icn')]"));
            }
    }

    @When("^I click on \"([^\"]*)\" in the portal$")
    public void i_click_on_in_the_portal(String link) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            if (!link.equalsIgnoreCase("RESET")) {
                if ((link.equalsIgnoreCase("Add file to download center"))
                        && this.commonHelpers.getValuefromContextStore("DownloadType") != null) {
                    if (this.commonHelpers.getValuefromContextStore("DownloadType").toString()
                            .contains("COMBINED FILES")) {
                        this.JavaScriptClick(this.getByusingString("(" + (this.buildXpathForString(link)) + ")[2]"));
                    }
                } else {
                    if (link.equalsIgnoreCase("EXPORT LIST")) {

                        if (!this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString(link)))) {
//                            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                            this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(link)));
                            this.commonHelpers.thinkTimer(3000);
                            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP")));
                        } else {
                            log.error("**WARNING** - Export list button was not enabled(diplayed). Hence skipping.");
                            log.error("Possible Reasons - No Data in grid to export");
                            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                        }
                    } else {
                        this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                        //below wait is only when the download button is clicked and it doesn't impact other operations
                        this.waitUntilNotVisible(this.shipmentOverviewPage.dcfileloadingIndicator, 2000);
                        commonHelpers.thinkTimer(5000);
                    }
                    this.commonHelpers.thinkTimer(3000);
                    // this.waitUntilNotVisible(By.xpath(this.buildXpathForString(link)));
                }
            }
            if (link.equalsIgnoreCase("RESET")
                    && !this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString("RESET")))) {
                this.commonHelpers.thinkTimer(3);
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                this.shipmentOverviewPage.AcceptResetPopup();
                this.commonHelpers.thinkTimer(3);
            }
        }

    }

    @Given("^I click on \"([^\"]*)\" link in My Shipment Details$")
    public void i_click_on_link_in_My_Shipment_Details(String link) throws Throwable {
        this.ScrollToTop();
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.thinkTimer(2000);
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
            this.commonHelpers.thinkTimer(5000);
            // if (link.equalsIgnoreCase("RESET")) {
            // this.shipmentOverviewPage.AcceptResetPopup();
            // }
        }
    }

    @When("^I click on \"([^\"]*)\" link in My Shipments$")
    public void i_click_on_link_in_My_Shipments(String link) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.clickOnApplyButton(link);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @Then("^I validate column \"([^\"]*)\" is populated with below values$")
    public void i_validate_column_is_populated_with_below_values(String columnName, DataTable expectedValues) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Column populated values are not as expected",
                    this.shipmentOverviewPage.ValidateColumnValues(columnName, expectedValues));
        }
    }

    @Then("^I validate column \"([^\"]*)\" is not populated with below values$")
    public void i_validate_column_is_not_populated_with_below_values(String columnName, DataTable expectedValues)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertFalse("Column populated values are not as expected",
                    this.shipmentOverviewPage.ValidateColumnValues(columnName, expectedValues));
        }
    }

    @Then("^I validate CER Count value matches CER Number data$")
    public void i_validate_CERCount_value_matches_CERNumber_data() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Columnn values do not match",
                    this.shipmentOverviewPage.CompareCERNumberAndCountValues());
        }
    }

    @When("^I verify right chevron is displayed in portal$")
    public void i_verify_right_chevron_is_displayed_in_portal() {
        Assert.assertTrue(this.homePage.VerifyChevronisDisplayed());
    }

    @Then("^I click on right chevron$")
    public void i_click_on_right_chevron() {
        this.homePage.ClickChevron();
    }

    @Then("^I verify the last updated at field in the portal with system date$")
    public void i_verify_the_last_updated_at_field_in_the_portal_with_system_date() {
        this.homePage.VerifyDateWithSysDate();
    }

    @Given("^I verify \"([^\"]*)\" is displayed in the portal$")
    public void i_verify_is_displayed_in_the_portal(String text) {
        text = text.split("'")[0];
        String xpath = homePage.buildXpathForString(text);
        Assert.assertTrue(this.elementIsDisplayed(getByusingString(xpath)));
    }

    @Then("^I verify \"([^\"]*)\" is displayed in the dashboard of portal$")
    public void i_verify_is_displayed_in_the_dashboard_of_portal(String text) {
        try {
            String xpath = Constants.appDashboard
                    + homePage.buildXpathForString(this.commonHelpers.getValuefromContextStore(text).toString());
            Assert.assertTrue(this.findElement(By.xpath(xpath)).isDisplayed());

        } catch (Exception e) {
            System.err
                    .println("**EXCEPTION** Something went wrong in validation of text in dashboard" + e.getMessage());
        }
    }

    @Then("^I verify \"([^\"]*)\" is displayed on the page$")
    public void i_verify_is_displayed_on_the_page(String text) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilVisible(this.getByusingString(this.buildXpathForString(text)));
            Assert.assertTrue(text + " is not displayed in the application, Hence failing the test",
                    this.elementIsDisplayed(this.getByusingString(this.buildXpathForString(text))));
        }
    }

    @Given("^I verify \"([^\"]*)\" is not displayed in the portal$")
    public void i_verify_is_not_displayed_in_the_portal(String text) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            WebDriverWait wait = new WebDriverWait(DriverManager.getDrv(), Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath(".//*[contains(text(),\"" + text + "\")]"),
                    text));
        }
    }

    @Given("^I validate the numbers displayed in dashboard with UI and API$")
    public void i_validate_the_numbers_displayed_in_dashboard_with_UI_and_API() throws Throwable {
        Assert.assertTrue("Validation of the CE dashboard counts against API is failed",
                this.ceDashboard.ValidateNumbersInDashboard());
    }

    @Given("^I verify the below column headers are displayed in CE dashboard$")
    public void i_verify_the_below_column_headers_are_displayed_in_CE_dashboard(DataTable table) {
        Assert.assertTrue("Headers validation of the CE dashboard is failed",
                this.ceDashboard.ValidateColumnHeaders(table));
    }

    @When("^I refresh the page$")
    public void i_refresh_the_page() throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag
                || this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")) {
            DriverManager.getDrv().navigate().refresh();
            this.waitForDOMToLoad(DriverManager.getDrv());
            this.waitUntilNotVisible(this.loadingIndicator);
        }
        this.waitUntilNotVisible(this.loadingIndicator);
        if (this.elementIsDisplayed(CloseUpdateTerms)) {
            this.JavaScriptClick(CloseUpdateTerms);
        }
    }

    @Then("^I validate the menu option \"([^\"]*)\" is available on left pane$")
    public void i_validate_the_menu_option_is_available_on_left_pane(String menuOption) {
        this.waitUntilNotVisible(this.loadingIndicator);
        // softly.assertThat(this.homePage.IsSideMenuVisibility(menuOption));
        // softly.assertAll();
        if (menuOption.equalsIgnoreCase("Sustainability")) {
            boolean sustainabilityFeatureEnabled = (boolean) this.commonHelpers
                    .getValuefromContextStore("sustainabilityFeatureEnabled");
            if (!sustainabilityFeatureEnabled) {
                log.info(
                        " **INFORMATION** Sustainability flag is off. hence avoiding the validation for the same. It will not appear on left side");
                return;
            }
        }
        Assert.assertTrue((this.homePage.IsSideMenuVisibility(menuOption)));
    }

    @When("^user navigates to \"([^\"]*)\" menu$")
    public void user_navigates_to_menu(String menuOption) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {

            this.waitUntilNotVisible(this.loadingIndicator, 40);
            this.ScrollToTop();
            if (Constants.SubMenuModules.contains(menuOption)) {
                if (menuOption.equalsIgnoreCase("Sustainability")) {
                    boolean sustainabilityFeatureEnabled = (boolean) this.commonHelpers
                            .getValuefromContextStore("sustainabilityFeatureEnabled");
                    if (!sustainabilityFeatureEnabled) {
                        log.info(
                                " **INFORMATION** Sustainability flag is off. hence avoiding the validation for the same. It will not appear on left side");
                        return;
                    }
                }
                this.homePage.verifySideMenuVisibility(menuOption);
                this.waitUntilNotVisible(this.loadingIndicator);
                this.ScrollToTop();
                this.homePage.navigateToDefaultSubMenu(menuOption);
            } else {

                this.JavaScriptClick(By.xpath(String.format(homePage.menu, menuOption)));
                this.waitUntilVisible(By.xpath(String.format(homePage.menu, menuOption)));
            }
        }
        // this.waitForDOMToLoad(DriverManager.getDrv()Manager.getDrv());
        // Assert.assertTrue(this.homePage.verifyMenuHighlight(menuOption));

        this.waitUntilNotVisible(this.loadingIndicator, 30);
        this.waitForDOMToLoad(DriverManager.getDrv());
        // this.commonHelpers.thinkTimer(5000);
    }

    @When("^I validate \"([^\"]*)\" dropdown is populated with below values$")
    public void i_validate_dropdown_is_populated_with_below_values(String DropDownType, DataTable table) {
        DropDownType = DropDownType.equalsIgnoreCase("SHIPMENT TYPES") ? "Types" : DropDownType;
        Assert.assertTrue("Validation of the Types options is failed",
                this.shipmentOverviewPage.ValidateDropdownValues(DropDownType, table));

    }

    @Then("^I select below values from the \"([^\"]*)\" dropdown$")
    public void i_select_below_values_from_the_dropdown(String DropDownType, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            DropDownType = DropDownType.equalsIgnoreCase("SHIPMENT TYPES") ? "Types" : DropDownType;
            Assert.assertTrue("Selection and validation of shipment Types is failed",
                    this.shipmentOverviewPage.SelectValuesFromDD(DropDownType, table));
        }
    }

    @Then("^I validate \"([^\"]*)\" dropdown is populated with below bulk menu values$")
    public void i_validate_dropdown_is_populated_with_below_bulk_menu_values(String DropDownType, DataTable table)
            throws Throwable {
        DropDownType = DropDownType.equalsIgnoreCase("Bulk") ? "BULK" : DropDownType;
        Assert.assertTrue("Validation of the Types options is failed",
                this.shipmentOverviewPage.ValidateBulkDropDownValues(DropDownType, table));
    }

    @Then("^verify \"([^\"]*)\" is shown on Persitent header$")
    public void verify_is_shown_on_Persitent_header(String menuOption) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            String[] breadCrumbs = menuOption.split("/");
            for (String menu : breadCrumbs) {
                Assertions.assertThat(homePage.verifyPersitentHeader(menu).getText().trim()).contains(menu);
            }
        }
    }

    @When("^I signout and signIn to \"([^\"]*)\" using the \"([^\"]*)\"$")
    public void i_signout_and_signIn_to_using_the(String portalLink, String user) throws Throwable {
        this.homePage.logOut();
        this.i_login_to_application_using_id(user);
    }

    @Then("^I navigate back in the browser$")
    public void i_navigate_back_in_the_browser() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.NavigateToPreviousPageOfBrowser();
    }

    @Then("^I verify \"([^\"]*)\" icon is shown$")
    public void i_verify_icon_is_shown(String menu) throws Throwable {
        Assert.assertTrue(this.findElement(homePage.alertIcon).isDisplayed());
    }

    @Then("^I verify Home Page shows Current Date$")
    public void i_verify_Home_Page_shows_Current_Date() {
        Assert.assertTrue(this.homePage.VerifyCurrentDate());
    }

    @Given("^I click on \"([^\"]*)\" icon in carousel to navigate to \"([^\"]*)\" blade$")
    public void i_click_on_icon_in_carousel_to_navigate_to_blade(String index, String title) {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(homePage.navigateAndValidateCarosel(index, title));
    }

    @Then("^I verify the static text present in \"([^\"]*)\" for \"([^\"]*)\"$")
    public void i_verify_the_static_text_present_in_for(String title, String subModule) {
        Assert.assertTrue(this.homePage.ValidateStatictextInModule(title, subModule));
    }

    @Then("^I verify \"([^\"]*)\" as the number of \"([^\"]*)\" in blade$")
    public void i_verify_as_the_number_of_in_blade(String count, String subModule) {
        Assert.assertTrue(this.homePage.validatecountOfShipments(count, subModule));
    }

    @Then("^I verify Home Page Carousel is visible$")
    public void i_verify_Home_Page_is_visible() throws Throwable {
        Assert.assertTrue(this.homePage.VerifyHomePageCarouselIsVisible());
    }

    @Then("^I verify company name \"([^\"]*)\" is displayed on dashboard$")
    public void i_verify_company_name_is_displayed_on_dashboard(String company) {
        company = this.commonHelpers.getValuefromContextStore(company).toString();
        Assert.assertTrue(this.homePage.VerifyCompanyNameIsVisible(company));
    }

    @Given("^I verify Carousel is visible in Overview Page$")
    public void i_verify_Carousel_is_visible_in_Overview_Page() throws Throwable {
        Assert.assertTrue(this.homePage.VerifyHomePageCarouselIsVisible());
    }

    @Then("^I verify Weather alert count is sum of Category$")
    public void i_verify_Weather_alert_count_is_sum_of_Category() throws Throwable {
        Assert.assertTrue(this.advisoryPage.ValidateWeatherAlertCount());
    }

    @Then("^I verify the All Shipmet blade show \"([^\"]*)\" count for shipments$")
    public void i_verify_the_All_Shipmet_blade_show_count_for_shipments(String count) throws Throwable {
        Assert.assertTrue(this.homePage.VerifyAllShipmentCount(count));
    }

    @Then("^I verify data from \"([^\"]*)\" api with surround portal UI for below values$")
    public void i_verify_data_from_api_with_surround_portal_UI_for_below_values(String endPointKey, DataTable table) {
        Assert.assertTrue("API and UI values for " + endPointKey + " are not equal",
                this.apiCall.ValidateAPIDatainUI(endPointKey, table));
    }

    @Then("^Verify \"([^\"]*)\" Image is present in Persistent Footer$")
    public void verify_Image_is_present_in_Persistent_Footer(String GlobeImage) {
        List<WebElement> caasIcon = this.findElements(this.homePage.globalImgIcon);
        Boolean flag = true;
        for (WebElement ele : caasIcon) {
            if (ele.getAttribute("class").equalsIgnoreCase("caas-icon caas-icon--grey")) {
                flag = true;
                break;
            } else {
                flag = false;
            }
        }
        Assert.assertTrue("Global Icon is Found - ", flag);
    }

    @Then("^Verify Language are present in Language DropDown in Persistent Footer$")
    public void verify_Language_are_present_in_Language_DropDown_in_Persistent_Footer(DataTable table)
            throws Throwable {
        Assert.assertTrue("Language Dropdown value is incorrect", this.homePage.ValidateLanguageDropdown(table));
    }

    @Then("^I verify the Social Icon ae displayed in surround portal$")
    public void i_verify_the_Social_Icon_ae_displayed_in_surround_portal(DataTable table) throws Throwable {
        Assert.assertTrue(this.homePage.ValidateSocialIcon(table));
    }

    @Then("^I verify following footer element are displayed in surround portal$")
    public void i_verify_following_footer_element_are_displayed_in_surround_portal(DataTable table) throws Throwable {
        Assert.assertTrue("Failed in validating Footer elements", homePage.ValidateFooterElements(table));
    }

    @Then("^Verify \"([^\"]*)\" Text is present in Persistent Footer$")
    public void verify_Text_is_present_in_Persistent_Footer(String UnitedStatesText) throws Throwable {
        softly.assertThat(this.elementIsDisplayed(this.homePage.contry)).isTrue();
    }

    @When("^I navigate to \"([^\"]*)\"$")
    public void i_navigate_to(String pageString) throws Throwable {
        this.loginPage.NavigateToPage(pageString);
    }

    @When("^I select the users preferred language as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_select_the_users_preferred_language_as(String language, String user) throws Throwable {
        this.loginPage.Selectlanguage(language);
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (virtualizationFlag) {
            i_login_to_application_using_id(user);
        }
    }

    @When("^I verify placeholder \"([^\"]*)\" text is displayed in application as below$")
    public void i_verify_placeholder_text_is_displayed_in_application_as_below(String placeholder, DataTable table) {
        List<String> list = table.asList(String.class);
        Assert.assertTrue(this.advisoryPage.VerifyPlaceHoldertext(placeholder, list));
    }

    @When("^I search the weather impact of \"([^\"]*)\" by providing input as \"([^\"]*)\"$")
    public void i_search_the_weather_impact_of_by_providing_input_as(String reference, String location) {
        this.advisoryPage.EnterLocation(reference, location);
    }

    @Given("^I verify searched results  of \"([^\"]*)\" has the state name along with city name$")
    public void i_verify_searched_results_of_has_the_state_name_along_with_city_name(String reference) {
        Assert.assertTrue(this.advisoryPage.VerifySearchResults(reference));
    }

    @Given("^I select the \"([^\"]*)\" result of \"([^\"]*)\" search outputs$")
    public void i_select_the_result_of_search_outputs(String index, String reference) {
        this.advisoryPage.SelectSearchResults(index, reference);
    }

    @When("^I verify \"([^\"]*)\" along with state is displayed in \"([^\"]*)\" search$")
    public void i_verify_along_with_state_is_displayed_in_search(String cityName, String reference) throws Throwable {
        Assert.assertTrue(this.advisoryPage.VerifySelectedValueinSearchBox(cityName, reference));
    }

    @Then("^I wait till weather forecast is displayed for the city in surround$")
    public void i_wait_till_weather_forecast_is_displayed_for_the_city_in_surround() {
        this.advisoryPage.WaitweatherForcastisDisplayed();
    }

    @Then("^I validate searched city \"([^\"]*)\" is displayed in the center of the map$")
    public void i_validate_searched_city_is_displayed_in_the_center_of_the_map(String cityName) {
        Assert.assertTrue(this.advisoryPage.ValidatecityInMap(cityName));
    }

    @Then("^I verify the next \"([^\"]*)\" days weather forecast of \"([^\"]*)\" is displayed$")
    public void i_verify_the_next_days_weather_forecast_of_is_displayed(String days, String reference) {
        Assert.assertTrue(this.advisoryPage.VerifyweatherForecastInfo(days, reference));
    }

    @Given("^I verify the next \"([^\"]*)\" days weather forecast of \"([^\"]*)\" is displayed along with temperature information$")
    public void i_verify_the_next_days_weather_forecast_of_is_displayed_along_with_temperature_information(String days,
                                                                                                           String reference) throws Throwable {
        Assert.assertTrue(this.advisoryPage.VerifyTemparatureInfo(days, reference));
    }

    @Given("^I verify the weather forecast alerts is displayed along with temperature information for \"([^\"]*)\"$")
    public void i_verify_the_next_days_weather_forecast_alerts_is_displayed_along_with_temperature_information(
            String reference) throws Throwable {
        Assert.assertTrue(this.advisoryPage.VerifyAlertsInfo(reference));
    }

    @When("^I verify header and footer is displayed in \"([^\"]*)\"$")
    public void i_verify_header_and_footer_is_displayed_in(String language) throws Throwable {
        Assert.assertTrue(this.loginPage.Validatelanginheader(language));
    }

    @Then("^I \"([^\"]*)\" the map for \"([^\"]*)\" map$")
    public void i_the_map_for_map(String operation, String map) throws Throwable {
        this.advisoryPage.MapOperations(operation, map);
    }

    @When("^I verify checkbox \"([^\"]*)\" is \"([^\"]*)\"$")
    public void i_verify_checkbox_is(String checkBoxName, String state) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Checkbox state is incorrect",

                    this.advisoryPage.verifyCheckBoxSelection(checkBoxName, state));
        }
    }

    @When("^I \"([^\"]*)\" \"([^\"]*)\" filter$")
    public void i_filter(String action, String checkBoxName) throws Throwable {
        this.advisoryPage.performActionOnFilter(action, checkBoxName);
    }

    @Then("^I click on city \"([^\"]*)\" with number \"([^\"]*)\"$")
    public void i_click_on_city_with_number(String notation, String count) throws Throwable {
        this.advisoryPage.clickOnCityOrCluster(notation, count);
    }

    @Then("^I validate count for city \"([^\"]*)\" for \"([^\"]*)\" in UI against \"([^\"]*)\"$")
    public void i_validate_count_for_city_for_in_UI_against(String city, String filter, String endPointKey)
            throws Throwable {
        Assert.assertTrue(this.apiCall.validateCountOnCityOrCluster(endPointKey, city, filter));
    }

    @Then("^I navigate to \"([^\"]*)\" view$")
    public void i_navigate_to_view(String view) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.advisoryPage.navigateToView(view);
        }
    }

    @Given("^I validate \"([^\"]*)\" are dispayed on \"([^\"]*)\" view$")
    public void i_validate_are_dispayed_on_view(String TypeOfElements, String View) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of Alert icons on page is failed",
                    this.advisoryPage.ValidateAlertsinAdvisories(View));
        }
    }

    @Given("^I validate weather forecast and alerts for the cities in Advisories Shipments with \"([^\"]*)\"$")
    public void i_validate_weather_forecast_and_alerts_for_the_cities_in_Advisories_Shipments_with(String endPointKey)
            throws Throwable {
        Assert.assertTrue("validation of weather forecast and alerts for the cities in Advisories Shipments is failed",
                this.advisoryPage.ValidateWeatherForecast(endPointKey));
    }

    @Then("^I verify the most impacted City card for \"([^\"]*)\" is shown on top against \"([^\"]*)\"$")
    public void i_verify_the_most_impacted_City_card_for_is_shown_on_top_against(String filter, String endpointKey)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int expectedCount = this.apiCall.getMostImpactedCount(filter, endpointKey);
            int actualCount = (expectedCount == 0) ? 0 : this.advisoryPage.getTopCardCityCountforFilter(filter);
            if (actualCount == 0) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
            Assert.assertEquals(expectedCount, actualCount);
        }
    }

    @When("^I click on \"([^\"]*)\" link for city \"([^\"]*)\"$")
    public void i_click_on_link_for_city(String link, String cityName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.ClickOnLinkForCity(link, cityName);
        }
    }

    /**
     * This method gives Total count from Prefrred location tab
     *
     * @param cardName
     * @param endPointKey
     * @throws Throwable
     */
    @When("^I validate the count for \"([^\"]*)\" in UI against \"([^\"]*)\"$")
    public void i_validate_the_count_for_in_UI_against(String cardName, String endPointKey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.apiCall.VerifyCountofQCcardsinUIandAPI(cardName.toUpperCase(), endPointKey);
            if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
                this.waitUntilNotVisible(this.loadingIndicator);
                this.shipmentOverviewPage.GetShipmentsData(cardName);
                if (!cardName.equalsIgnoreCase("Total Records")) {
                    Assert.assertTrue("Quick View Card Highlight failed",
                            this.shipmentOverviewPage.VerifyQuickViewCardHighlight(cardName));
                    Assert.assertTrue("Comparing UI and Api count for Quick view card failed",
                            this.shipmentOverviewPage.CompareCountonCardandViewing(cardName));
                }
            }
        }
    }

    @Then("^I validate the \"([^\"]*)\" color of the \"([^\"]*)\" quick view card$")
    public void i_validate_the_color_of_the_quick_view_card(String iconorBackGround, String QCName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Color Validation of icon on Quick view card is failed",
                    this.shipmentOverviewPage.ValidateColorinUI(iconorBackGround, QCName));
        }
    }

    @When("^I verify filter bubbles is displayed with \"([^\"]*)\" in UI$")
    public void i_verify_filter_bubbles_is_displayed_with_in_UI(String cardName) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(this.shipmentOverviewPage.VerifyFilterBubbleVisibility(cardName));
    }

    @Given("^I click on \"([^\"]*)\" quick view card$")
    public void i_click_on_quick_view_card(String cardName) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator, 60);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
            }
            this.shipmentOverviewPage.ClickOncardView(cardName);
        }
        this.waitUntilNotVisible(this.loadingIndicator, 60);
    }

    @Then("^I verify the viewing count with variable \"([^\"]*)\"$")
    public void i_verify_the_viewing_count_with_variable(String contextStoreKey) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue(String.format("viewing count for %s is not matching with UI", contextStoreKey),
                    this.shipmentOverviewPage.ValidateViewingCount(contextStoreKey));
        }
    }

    @Given("^I click on \"([^\"]*)\" saved quick view card and verify count$")
    public void i_click_on_saved_quick_view_card(String cardName) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.ClickOnSaveViewCard(cardName);
        }
    }

    @Then("^I verify default number of records shown to user is \"([^\"]*)\"$")
    public void i_verify_default_number_of_records_shown_to_user_is(String arg1) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int actualRecordsCount = this.shipmentOverviewPage.getShipmentRecordsCount();
            int actualSelectedCount = this.shipmentOverviewPage.getSelectedShipmentsPerPageValue();
            int expectedCount = Integer.parseInt(arg1);
            Assert.assertTrue("Default number of records per page in shipments page is not set to: " + expectedCount,
                    (actualSelectedCount == actualRecordsCount) && (actualRecordsCount == expectedCount));
        }
    }

    @When("^I select \"([^\"]*)\" shipments per page$")
    public void i_select_shipments_per_pageSize(String recordsCount) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentOverviewPage.setShipmentsCountPerPage(recordsCount);
    }

    @Then("^I verify \"([^\"]*)\" records are displayed in shipments page$")
    public void i_verify_records_are_displayed_in_shipments_page(String arg1) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int actualCount = this.shipmentOverviewPage.getShipmentRecordsCount();
            int expectedCount = Integer.parseInt(arg1);

            Assert.assertTrue("Number of records per page in shipments page is equal to: " + actualCount
                    + " instead of: " + expectedCount, actualCount == expectedCount);

            this.shipmentOverviewPage.paginationToRight();

            actualCount = this.shipmentOverviewPage.getShipmentRecordsCount();

            Assert.assertTrue("Number of records per page in shipments page is not equal to: " + expectedCount,
                    actualCount == expectedCount);

            this.shipmentOverviewPage.paginationToLeft();
        }
    }

    @Then("^I verify user is in \"([^\"]*)\" view$")
    public void i_verify_user_is_in_view(String view) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong with Map or List View",
                    this.advisoryPage.verifyListOrMapView(view));
        }
    }

    @Then("^I verify \"([^\"]*)\" is \"([^\"]*)\"$")
    public void i_verify_is(String cityPin, String visiblity) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            try {
                Assert.assertTrue(this.advisoryPage.visibilityOfCityPin(cityPin, visiblity));
            } catch (AssertionError e) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }


    @Then("^I skip remaining steps if \"([^\"]*)\" are zero in advisories page$")
    public void i_skip_remaining_steps_if_are_zero_in_advisories_page(String module) throws Throwable {
        this.advisoryPage.validatezeros(module);
    }

    @Then("^I verify City Card are \"([^\"]*)\"$")
    public void i_verify_City_Card_are(String visibility) throws Throwable {
        Assert.assertTrue(this.advisoryPage.visibilityOfCityCard(visibility));
    }

    @When("^I verify filter bubles is not displayed in UI$")
    public void i_verify_filter_bubles_is_not_displayed_with_in_UI(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            Assert.assertFalse("Filter Bubble is still visible",
                    this.shipmentOverviewPage.ValidateFilterBubble(table));
        }
    }

    @When("^I click on Quick View Card \"([^\"]*)\"$")
    public void i_click_on_Quick_View_Card(String cardName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            // this.commonHelpers.thinkTimer(5000);
            this.waitUntilNotVisible(this.loadingIndicator);
            this.shipmentOverviewPage.ClickOncardView(cardName);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("^I see blue tick icon appears to the right of Download Center$")
    public void iSeeBlueTickIconAppearsToTheRightOfDownloadCenter() {
        // Waiting for 3 minutes for the blue tick to appear
        this.commonHelpers.thinkTimer(120000);
        assertThat(this.waitUntilVisible(homePage.blueTickIconDownloadCenter, 20))
                .withFailMessage("Blue tick did not appear after waiting for 240 seconds for download center")
                .isTrue();
    }

    @When("^I delete all files from download directory$")
    public void i_delete_all_files_from_download_directory() throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            // if (GenericFunction.ENV == null) {
            String filename = Constants.fileNameForShipment;
            log.info("Filename to be deleted is = " + filename);
            try {
                this.genericFunObj.deleteFilefrom(filename);
            } catch (Exception e) {
                log.error("Exception during deletion of file " + e);
            }

        }
    }

    @Then("^I verify File is downloaded$")
    public void i_verify_File_is_downloaded() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {

            this.waitUntilNotVisible(this.loadingIndicator);
            this.commonHelpers.thinkTimer(15000);
            String fileName;
            if (!this.commonHelpers.verifyKeyInContextStore("dfileName")) {
                fileName = Constants.fileNameForShipment;
            } else {
                fileName = this.commonHelpers.getValuefromContextStore("dfileName").toString();

            }
            Assert.assertTrue("Failed to download document which has extension .csv",
                    this.genericFunObj.isFileDownloaded(fileName, false));
        }
    }

    @Then("^I verify headers in downloaded file$")
    public void i_verify_headers_in_downloaded_file() throws Throwable {
        List<String> headerInExcel = this.genericFunObj.readCSVHeader();
        Collections.sort(headerInExcel);
        List<String> headerFromUI = this.shipmentOverviewPage.getColumnsingrid();
        Collections.sort(headerFromUI);
        Assert.assertEquals(headerInExcel, headerFromUI);
    }

    @Then("^I verify header \"([^\"]*)\" in downloaded file for user \"([^\"]*)\"$")
    public void i_verify_particular_headers_in_downloaded_file(String header, String loginId) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {

            List<String> headerInExcel = this.genericFunObj.readCSVHeader();
            Collections.sort(headerInExcel);
            boolean checkCondition = headerInExcel.contains(header);
            for (String allheader : headerInExcel) {
                if (allheader.equals(header)) {
                    Assert.assertTrue("Header is not presented in excel sheet", checkCondition);
                }
            }
            if (!checkCondition && loginId.equals("user3")) {
                Assert.assertTrue("Header is not presented in excel sheet", !checkCondition);
            }
        }
    }

    @Then("^I verify header \"([^\"]*)\" in downloaded file$")
    public void i_verify_particular_headers_in_downloaded_file(String header) throws Throwable {
        List<String> headerInExcel = this.genericFunObj.readCSVHeader();
        Collections.sort(headerInExcel);
        if (headerInExcel.contains(header)) {
            log.info(header + "Header is presented in excel sheet");
        }

    }

    @Then("^I verify the record in file for column \"([^\"]*)\" against \"([^\"]*)\"$")
    public void i_verify_the_record_in_file_for_column_against(String columnName, String endpointKey) throws Throwable {
        String columnValue = this.commonHelpers.getValuefromContextStore(columnName).toString();
        List<String> headerInExcel = this.genericFunObj.readCSVHeader();
        Map<String, String> recordFromApi = this.apiCall.shipmentRecord(headerInExcel, columnName, columnValue,
                endpointKey);
        ArrayList<String> headerInApi = new ArrayList<String>(recordFromApi.keySet());
        Map<String, String> recordFromFile = this.genericFunObj.readCSVRecord(columnName, columnValue, headerInApi);

        Assert.assertEquals(recordFromFile, recordFromApi);

    }

    @When("^I select the below columns in column edit grid$")
    public void i_select_the_below_columns_in_column_edit_grid(DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> columnTable = dataTable.asMap(String.class, String.class);
            this.shipmentOverviewPage.SelectColumnsinView(columnTable);
        }
    }

    @Then("^I sort Shipment list with \"([^\"]*)\" column \"([^\"]*)\"$")
    public void i_sort_Shipment_list_with_column(String columnName, String orderOfSort) throws Throwable {
        this.shipmentOverviewPage.SortOnColumn(columnName, orderOfSort);
    }

    @Then("^I check the number of pages visible for the user in shipments page$")
    public void i_check_the_number_of_pages_visible_for_the_user_in_shipments_page() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int pageCount = this.shipmentOverviewPage.getShipmentsPageCount();
            commonHelpers.AddToContextStore("shipmentsPageCount", String.valueOf(pageCount));
        }
    }

    @Then("^I verify the columns in the shipment list grid$")
    public void i_verify_the_columns_in_the_shipment_list_grid() throws Throwable {
        i_click_on_the_view_of_MyShipments("expand");
        List<String> columnInGrid = this.shipmentOverviewPage.getColumnsingrid();
        Collections.sort(columnInGrid);
        List<String> expectedColumn = this.shipmentOverviewPage.columnsGrid;
        Collections.sort(expectedColumn);
        Assert.assertEquals(columnInGrid, expectedColumn);
    }

    @When("^I Select Monitored toggle$")
    public void i_Select_Monitored_toggle() throws Throwable {
        this.shipmentOverviewPage.SelectMonitoredToggle();
    }

    @When("^I select \"([^\"]*)\" tracking number from the shipment list$")
    public void i_select_tracking_number_from_the_shipment_list(String trackingNum) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.shipmentOverviewPage.SelectTrackingNumber(trackingNum, true);
        }
    }

    @When("^I select \"([^\"]*)\" return to shipper tracking number from the shipment list$")
    public void i_select_return_to_shipper_tracking_number_from_the_shipment_list(String trackingNum) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.shipmentOverviewPage.SelectReturnToShipperTrackingNumber(trackingNum, true);
        }
    }

    @When("^I click on selected \"([^\"]*)\" tracking number from the list$")
    public void i_select_tracking_number_from_the_shipment_list_selected(String trackingNum) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String trackingNumber = this.commonHelpers.getValuefromContextStore(trackingNum).toString();
            this.waitUntilNotVisible(this.loadingIndicator);
            this.shipmentOverviewPage.SelectTrackRandom(trackingNumber);
        }
    }

    @Then("^I verify data in Api and Shipment detail page for below values$")
    public void i_verify_data_in_Api_and_Shipment_detail_page_for_below_values(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                Assert.assertTrue("Validation of signature is failed", this.shipmentDetails.ValidateDetailsPageWithAPI(table));
            }
        }
    }

    @When("^I verify the summary bar is populated with below fields$")
    public void i_verify_the_summary_bar_is_populated_with_below_fields(DataTable tableViews) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of summary bar with expected data is failed",
                    this.shipmentDetails.ValidateSummaryBar(tableViews));
        }
    }

    @Then("^I verify contact Us link is having \"([^\"]*)\" in subject and mail to \"([^\"]*)\"$")
    public void i_verify_contact_Us_link_is_having_in_subject(String ContextStoreValue, String emailTo)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue("Validation of contact us link with tracking number is failed",
                    this.shipmentDetails.validateContactUsLink(ContextStoreValue, emailTo));
        }
    }

    @Given("^I verify the below column headers are displayed in CE shipment history$")
    public void i_verify_the_below_column_headers_are_displayed_in_CE_shipment_history(DataTable table)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Headers validation of the CE dashboard is failed",
                    this.shipmentDetails.ValidateColumnHeaders(table));
        }
    }

    @Then("^I verify the below column headers are displayed in \"([^\"]*)\" shipment history$")
    public void i_verify_the_below_column_headers_are_displayed_in_shipment_history(String tab, DataTable table)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Headers validation of the history SEP  is failed",
                    this.shipmentDetails.ValidateColumnHeaders(table, tab));
        }
    }

    @Given("^I Validate the \"([^\"]*)\" details with the \"([^\"]*)\" API$")
    public void i_Validate_the_details_with_the_API(String tab, String endPointKey, DataTable table) throws Throwable {
        Assert.assertTrue("History SEP data validation is failed",
                this.shipmentDetails.ValidateShipmentHistoryforCE(endPointKey, table, tab));
    }

    @Given("^I validate the shipment history table is populated with shipments from API \"([^\"]*)\" in UI$")
    public void i_validate_the_shipment_history_table_is_populated_with_shipments_from_API_in_UI(String endPointKey,
                                                                                                 DataTable table) throws Throwable {

        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());

        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps) && !virtualizationFlag) {
            String userContext = this.commonHelpers.getValuefromContextStore("UserContext").equals("CE") ? "CE" : "MS";
            if (userContext.equalsIgnoreCase("CE")) {
                Assert.assertTrue(
                        "Validation of contents in the shipment history table in shipment details is failed for CE",
                        this.shipmentDetails.ValidateShipmentHistoryforCE(endPointKey, table));
            } else {
                Assert.assertTrue(
                        "Validation of contents in the shipment history table in shipment details is failed for Shipper",
                        this.shipmentDetails.ValidateShipmentHistoryForShipper(endPointKey, table));
            }
        } else {
            Assert.assertTrue("Skipping titles validation due to virtualization", true);
        }
    }

    /**
     * This method Verify the icon against shipment in shipment list view
     *
     * @param icon
     * @param trackId
     * @throws Throwable
     */
    @When("^I Verify the \"([^\"]*)\" icon is added to the shipment in shipment list for \"([^\"]*)\"$")
    public void i_Verify_the_icon_is_added_to_the_shipment_in_shipment_list_for(String icon, String trackId)
            throws Throwable {
        if (trackId.contains("Tracking Number")) {
            trackId = this.commonHelpers.getValuefromContextStore(trackId).toString();
        }
        Assert.assertTrue(icon + " Icon validation failed",
                this.shipmentOverviewPage.verifyShipmentIcon(trackId, icon));
    }

    @Then("^I validate column \"([^\"]*)\" is populated with below values for \"([^\"]*)\"$")
    public void i_validate_column_is_populated_with_below_values_for(String columnName, String ContextStoreValue,
                                                                     DataTable table) throws Throwable {
        Assert.assertTrue("Validation of " + columnName + "with shipments grid is failed",
                this.shipmentOverviewPage.VerifyCommentForShipment(columnName, ContextStoreValue, table));
    }

    @Then("^I click on \"([^\"]*)\" arrow in summary bar to navigate to second view$")
    public void i_click_on_arrow_in_summary_bar_to_navigate_to_second_view(String arrow) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentOverviewPage.clickonFirstTrackingNumber();
        this.shipmentDetails.NavigateSummaryBar(arrow);
    }

    @Then("^I verify \"([^\"]*)\" link is linked to \"([^\"]*)\"$")
    public void i_verify_link_is_linked_to(String hrefLink, String SupportTeam) throws Throwable {
        Assert.assertTrue("Validation of support link is failed",
                this.shipmentDetails.ValidatehrefLink(hrefLink, SupportTeam));
    }

    @When("^I click on \"([^\"]*)\" link in \"([^\"]*)\" page$")
    public void i_click_on_link_in_page(String displayLink, String pageDetails) throws Throwable {
        if (displayLink.equalsIgnoreCase("Tooling")) {
            this.shipmentDetails.ClickonTab(displayLink);
            this.waitUntilNotVisible(this.loadingIndicator);
        } else if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                this.waitUntilNotVisible(this.loadingIndicator);
                this.shipmentDetails.ClickonTab(displayLink);
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                log.info("**WARNING** Some steps would be skipped due to virtualization true");
            }
        }
    }

    @When("^I validate ShipmentDetails info for \"([^\"]*)\" with format \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_validate_shipmentdetailsPageInfo(String field, String format, String timeFormat) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                this.waitUntilNotVisible(this.loadingIndicator);
                this.shipmentDetails.validateDetailsPage(field, format, timeFormat);
            } else {
                log.info("**WARNING** Some steps would be skipped due to virtualization true");
            }
        }
    }

    @Then("^I verify below titles are displayed in the shipments section of details page$")
    public void i_verify_below_titles_are_displayed_in_the_shipments_section_of_details_page(DataTable table)
            throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());

        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps) && !virtualizationFlag)
            Assert.assertTrue("Titles validation of shipment section is failed",
                    this.shipmentDetails.ValidateHeadersinDetails(table));
        else {
            Assert.assertTrue("Skipping titles validation due to virtualization", true);
        }
    }

    @Then("^I verify tooltip of \"([^\"]*)\" with expected result$")
    public void i_verify_tooltip_of_with_expected_result(String SectionName) throws Throwable {
        Assert.assertTrue("Tooltip content with expected result is not matched",
                this.shipmentDetails.ValidateToolTip(SectionName));
    }

    @Given("^I click on all links of \"([^\"]*)\" external links$")
    public void i_click_on_all_links_of_external_links(String SectionName) throws Throwable {
        Assert.assertTrue("Validation of the external Links opened for a session is falied",
                this.shipmentDetails.ValidateExternalLinks(SectionName));
    }

    @Then("^I validate all tooling sections for \"([^\"]*)\" external links with expected result$")
    public void i_validate_all_tooling_sections_for_external_links_with_expected_result(String SectionName,
                                                                                        DataTable table) throws Throwable {
        Assert.assertTrue("Validation of tooling section is failed ",
                this.shipmentDetails.ValidateToolingSections(SectionName, table));
    }

    @And("I validate all tooling sections for {string} external links with expected value")
    public void iValidateAllToolingSectionsForExternalLinksWithExpectedValue(String SectionName, DataTable table) throws Throwable {
        this.shipmentDetails.ValidateTooling(SectionName, table);
    }

    @Then("^I validate \"([^\"]*)\" section of shipment is having the fixed labels$")
    public void i_validate_section_of_shipment_is_having_the_fixed_labels(String subHeader) throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());

        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps) && !virtualizationFlag)
            Assert.assertTrue("Labels validation of shipment section is failed",
                    this.shipmentDetails.ValidateLabelsinTabs(subHeader));
        else {
            Assert.assertTrue("Skipping labels validation due to virtualization", true);
        }
    }

    @When("^I click on \"([^\"]*)\" sub-menu$")
    public void i_click_on_sub_menu(String subMenu) throws Throwable {
        if (!(GenericFunction.locale.equalsIgnoreCase(Constants.EN_US))) {
            subMenu = genericFunObj.getLocalizedValue(subMenu);
        }
        this.advisoryPage.NavigateToSubMenu(subMenu);
    }

    @And("^I validate AccountNumber and Alias mapping values")
    public void i_validate_account_alias_data() throws Throwable {
        this.accountAlias.validateAccountAliasScreen();
    }

    @When("^I validate the below labels on the page$")
    public void i_validate_tableValues(DataTable table) throws Throwable {
        this.accountAlias.validateLabels(table);
    }


    @When("^I click on \"([^\"]*)\" from the left pane in the portal$")
    public void i_click_on_from_the_left_pane_in_the_portal(String link) throws Throwable {
        softly.assertThat(this.preferencePage.ClickOnPreferences(link)).isTrue();
        softly.assertAll();
    }

    @Given("^I validate the value for \"([^\"]*)\" is displayed as per configuration of \"([^\"]*)\"$")
    public void i_validate_the_value_for_is_displayed_as_per_configuration_of(String LabelinUI,
                                                                              String SurroundEligibility) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of " + LabelinUI + " in shipment details is failed ",
                    this.shipmentDetails.ValidateLabelValues(LabelinUI, SurroundEligibility));
        }
    }

    @Then("^I verify following element are displayed in Preference Screen$")
    public void i_verify_following_element_are_displayed_in_Preference_Screen(DataTable table) throws Throwable {
        softly.assertThat(this.preferencePage.ValidateScreenElements(table)).isTrue();
        softly.assertAll();
    }

    @Then("^I verify following elements are not displayed in Preferences-Settings Screen$")
    public void i_verify_following_elements_are_not_displayed_in_Preferences_Settings_Screen(DataTable table)
            throws Throwable {
        SoftAssertions softAssert = new SoftAssertions();
        softAssert.assertThat(this.preferencePage.ValidateScreenElements(table)).isFalse();
        softAssert.assertAll();
    }

    @Then("^I verify Updated at will reflect as per prefered DATE FORMAT and TIME FORMAT$")
    public void i_verify_Updated_at_will_reflect_as_per_prefered_DATE_FORMAT_and_TIME_FORMAT() throws Throwable {
        softly.assertThat(this.preferencePage.CheckUpdateAt()).isTrue();
        softly.assertAll();
    }

    @Then("^I verify preferrence date Format is matching with filters date Frormat$")
    public void i_verify_date_format_with_filters_date() {
        this.preferencePage.getFilterDateFormat();
    }

    @When("^TIMEFORMAT and DATEFORMAT is set to last value$")
    public void timeformat_and_DATEFORMAT_is_set_to_last_value() throws Throwable {
        softly.assertThat(this.preferencePage.SetDropDown()).isTrue();
    }

    @Then("^I verify page number is reduced$")
    public void i_verify_page_number_is_reduced() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int currentPageCount = this.shipmentOverviewPage.getShipmentsPageCount();
            int previousPageCount = Integer
                    .valueOf((String) commonHelpers.getValuefromContextStore("shipmentsPageCount"));
            Assert.assertTrue(
                    "Shipments: " + "Current page count (" + currentPageCount
                            + ") should be less than previous page count (" + previousPageCount + ")",
                    currentPageCount < previousPageCount);
        }
    }

    @Then("^I verify page number is increased$")
    public void i_verify_page_number_is_increased() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int currentPageCount = this.shipmentOverviewPage.getShipmentsPageCount();
            int previousPageCount = Integer
                    .valueOf((String) commonHelpers.getValuefromContextStore("shipmentsPageCount"));
            Assert.assertTrue(
                    "Shipments: " + "Current page count (" + currentPageCount
                            + ") should be greater than previous page count (" + previousPageCount + ")",
                    currentPageCount > previousPageCount);
        }
    }

    @When("^I select any Filter from Quick View \"([^\"]*)\"$")
    public void i_select_any_Filter_from_Quick_View(String filter) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.ScrollToTop();
            this.shipmentOverviewPage.ClickOncardView(filter);
        }
    }

    @Then("^I verify the records count \"([^\"]*)\" filter remains same$")
    public void i_verify_the_records_count_filter_remains_same(String arg1) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int expectedValue = Integer.parseInt(arg1);
            int actualValue = this.shipmentOverviewPage.getSelectedShipmentsPerPageValue();
            Assert.assertTrue(
                    "Shipment records count dropdown is set to: " + actualValue + " instead of " + expectedValue,
                    expectedValue == actualValue);
        }
    }

    @Then("^I verify user can navigate to different pages by clicking on the Page number and arrow keys around page number$")
    public void i_verify_user_can_navigate_to_different_pages_by_clicking_on_the_Page_number_and_arrow_keys_around_page_number()
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            boolean isSuccess = this.shipmentOverviewPage.verifyShipmentsPageNavigation();
            Assert.assertTrue("pagination is failed in shipment details page", isSuccess);
        }
    }

    @Then("^I verify when page number is greater than ten ellipsis are shown to user after four for page number$")
    public void i_verify_when_page_number_is_greater_than_ellipsis_are_shown_to_user_after_for_page_number()
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            boolean isSuccess = this.shipmentOverviewPage.verifyShipmentsPageNavigationItems();
            Assert.assertTrue("pagination items are not proper", isSuccess);
        }
    }

    @Then("^I verify first and last page number value is always shown to user$")
    public void i_verify_first_and_last_page_number_value_is_always_shown_to_user() throws Throwable {
        Set<Boolean> result = new HashSet<Boolean>();
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            result.add(this.shipmentOverviewPage.isPaginationItemPoistionVerified("1", "2"));
            result.add(this.shipmentOverviewPage.isPaginationItemPoistionVerified(
                    String.valueOf(this.shipmentOverviewPage.getExpectedShipmentsPageCount()), "7"));

            Assert.assertTrue("first and last page number value is not shown", !result.contains(false));
        }
    }

    @Then("^I verify count of column selected for \"([^\"]*)\"$")
    public void i_verify_count_of_column_selected_for(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.shipmentOverviewPage.validateCountForColumn(viewName));
        }
    }

    @When("^I search the \"([^\"]*)\" using \"([^\"]*)\" in UI$")
    public void i_search_the_using_in_UI(String searchContext, String contextStorevariable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (searchContext.contains("Tracking Number")) {
                if (searchContext.split("-").length > 1) {
                    this.shipmentOverviewPage.SearchTrackingNumber(searchContext, contextStorevariable);
                } else {
                    this.shipmentOverviewPage.SearchTrackingNumber(contextStorevariable);
                }
            } else if (searchContext.contains("AccountNumber")) {
                this.preferencePage.searchAccountNumber(contextStorevariable);
            } else {
                this.shipmentOverviewPage.SearchText(searchContext, contextStorevariable);
            }
        }
    }

    @Given("^I verify \"([^\"]*)\" section in \"([^\"]*)\" is populated with below values$")
    public void i_verify_section_in_is_populated_with_below_values(String section, String page, DataTable table)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (page.equalsIgnoreCase("shipmentDetails")) {
                Assert.assertTrue("Validation of modules in Shipment Details page is failed",
                        this.shipmentDetails.ValidateDetailsPageWithAPI(table, section));
            }
        }
    }

    @When("^I search the \"([^\"]*)\" multi track numbers with \"([^\"]*)\" data$")
    public void i_search_MltiTracking(String randomTrackIds, String data) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentOverviewPage.SearchMultiTrackingNumber(randomTrackIds, data);
    }

    @Given("^User search validates invalid search with \"([^\"]*)\" and validate search result count in My Shipments Page$")
    public void user_search_validates_invalid_search_with_and_validate_search_result_count_in_My_Shipments_Page(
            String decimalValue) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(this.findElement(this.shipmentOverviewPage.Searchicon));
        this.enterText(this.shipmentOverviewPage.searchTextBx, decimalValue);
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue("Validate Invalid Tracking Number search functionality", this
                .getText(this.shipmentOverviewPage.trackingNumber).trim().equals("Invalid Tracking Number"));

    }

    @Given("^User search with \"([^\"]*)\" digits tracking number and validate search result count in My Shipments Page$")
    public void user_search_with_digits_tracking_number_and_validate_search_result_count_in_My_Shipments_Page(
            String noOfDigits) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (Integer.parseInt(noOfDigits) < 12 && this.commonHelpers.verifyKeyInContextStore("Tracking Number")) {
            this.commonHelpers.AddToContextStore("Partial Tracking Number",
                    this.commonHelpers.getValuefromContextStore("Tracking Number").toString().substring(0,
                            Integer.valueOf(noOfDigits)));
            Assert.assertTrue(this.shipmentOverviewPage.SearchAndValidateRecord("search", "Partial Tracking Number"));
        } else {
            this.commonHelpers.AddToContextStore("Tracking Number",
                    this.getText(this.shipmentOverviewPage.trackingNumCellValue).substring(0,
                            Integer.valueOf(noOfDigits)));
            Assert.assertTrue(this.shipmentOverviewPage.SearchAndValidateRecord("search", "Tracking Number"));
        }
    }

    @Given("^Validate the search bubble is displaying the in Shipments Page$")
    public void validate_the_search_bubble_is_displaying_the_in_Shipments_Page() throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.VerifySearchBubbles());
    }

    @When("^User searches for \"([^\"]*)\" tracking number and validates prediction status in Shipment Details Page$")
    public void user_searches_for_tracking_number_and_validates_prediction_status_in_Shipment_Details_Page(
            String predictionStatus) throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue(this.shipmentOverviewPage.SearchAndValidateRecord(predictionStatus,
                    this.commonHelpers.getValuefromContextStore("DBTrackingNumber").toString()));
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            Assert.assertTrue(true);
        }

    }

    @When("^User validates prediction status as \"([^\"]*)\" in Shipment Details Page$")
    public void user_verify_for_tracking_number_and_validates_prediction_status_in_Shipment_Details_Page(
            String predictionStatus) throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue(this.shipmentOverviewPage.SearchAndValidateRecord(predictionStatus,
                    "Tracking Number"));
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            Assert.assertTrue(true);
        }

    }

    @When("^User validates prediction fields and status as \"([^\"]*)\" in Shipment Details Page$")
    public void user_verify_for_tracking_number_and_validates_prediction_fields_and_status_in_Shipment_Details_Page(
            String predictionStatus) throws InterruptedException {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {

            Assert.assertTrue(this.shipmentOverviewPage.SearchAndValidateRecord(predictionStatus,
                    "Tracking Number"));

        }
    }

    @When("^User validates whether all the tracking number contains the partial tracking number in my shipments page$")
    public void user_validates_whether_all_the_tracking_number_contains_the_partial_tracking_number_in_my_shipments_page()
            throws Throwable {
        Assert.assertTrue(
                this.shipmentOverviewPage.ValidateTrackingNumbersInMyShipmentsPage("Partial Tracking Number"));
    }

    @When("^user clicks on tracking to validate whether tracking number contains the searched partial tracking number in shipment details page$")
    public void user_clicks_on_tracking_to_validate_whether_tracking_number_contains_the_searched_partial_tracking_number_in_shipment_details_page()
            throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue(this.shipmentOverviewPage.ValidateAndClickTrackingNumberFromTable());
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            Assert.assertTrue(true);
        }
    }

    @Given("^User validated whether system is displaying the complete tracking number searched in Shipment Details Page$")
    public void user_validated_whether_system_is_displaying_the_complete_tracking_number_searched_in_Shipment_Details_Page()
            throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.ValidateTrackingNumberInShipmentDetailsPage("Complete Search"));
    }

    @Given("^I select tracking number from My shipment list$")
    public void i_select_tracking_number_from_My_shipment_list() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.AddToContextStore("FullTrackingNumber",
                this.getText(this.shipmentOverviewPage.trackingNumCellValue));
    }

    @Then("^I Select a company  \"([^\"]*)\" on CE dashboard$")
    public void i_Select_a_company_on_CE_dashboard(String companyName) throws Throwable {
        this.homePage.SelectCompanyNameinCE(companyName);
    }

    @Then("^I navigate to \"([^\"]*)\" page number$")
    public void i_navigate_to_page_number(String pageNum) throws Throwable {
        this.shipmentOverviewPage.clickOnShipmentsPageNumber(pageNum);
    }

    @When("^I click on \"([^\"]*)\" chevron \"([^\"]*)\" in the portal$")
    public void i_click_on_chevron_in_the_portal(String tab, String operation) throws Throwable {
        this.clickOnElement(this.shipmentOverviewPage.EditcolumnsChevron);
    }

    @Then("^I verify page number \"([^\"]*)\" is selected$")
    public void i_verify_page_number_is_selected(String pageNum) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.isShipmentsPageClicked(pageNum));
    }

    @Then("^I verify \"([^\"]*)\" column for sort$")
    public void i_verify_column_for_sort(String columnName) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(this.shipmentOverviewPage.verifySortOnColumn(columnName));
    }

    @Then("^I verify \"([^\"]*)\" column is not sortable$")
    public void I_verify_column_is_not_sortable(String columnName) throws Throwable {
        Assert.assertFalse(this.shipmentOverviewPage.verifySortOnColumn(columnName));
    }

    @When("^I click on \"([^\"]*)\" link and add a preferred location$")
    public void i_click_on_link_and_add_a_preferred_locations(String link, DataTable table) throws Throwable {
        Boolean flag = this
                .elementIsDisplayed((By.xpath(String.format(this.preferencePage.addInOrOutPrefLocation, link))));
        if (!flag) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        } else {
            commonHelpers.thinkTimer(2000);
            this.ScrollToTop();
            List<String> cities = table.asList(String.class);
            for (String city : cities) {
                this.preferencePage.clickOnAddPreferenceLink(link);
                this.preferencePage.addPreferredLocation(city);
            }
        }
    }

    @Then("^I verify \"([^\"]*)\" preferred location is added \"([^\"]*)\"$")
    public void i_verify_outbound_preferred_location_is_added(String location, String city) throws Throwable {
        Assert.assertTrue(location + " preferred location: " + city + " is not added",
                preferencePage.isPreferredLocationAdded(location, city));
    }

    @When("^I remove \"([^\"]*)\" preferred location \"([^\"]*)\"$")
    public void i_remove_outbound_preferred_location(String location, String city) throws Throwable {
        this.commonHelpers.AddToContextStore("previousCount",
                String.valueOf(this.preferencePage.getPrefLocationsCount(location)));
        this.preferencePage.removePrefLocation(location, city);
    }

    @Then("^I verify that the \"([^\"]*)\" preferred location \"([^\"]*)\" is removed$")
    public void i_verify_that_the_outbound_preferred_location_is_removed(String location, String arg1)
            throws Throwable {
        int previousCount = Integer.valueOf((String) commonHelpers.getValuefromContextStore("previousCount"));
        int currentCount = this.preferencePage.getPrefLocationsCount(location);
        Assert.assertTrue("Preferred location(s) not removed ", previousCount > currentCount);
    }

    @When("^I remove \"([^\"]*)\" all preferred locations if available$")
    public void i_remove_outbound_inbound_preferred_location(String location) throws Throwable {
        if (this.preferencePage.getPrefLocationsCount(location) > 0) {
            List<WebElement> lists = this.findElements(this.preferencePage.removePrefLoc);
            for (int i = 0; i < lists.size(); i++) {
                this.preferencePage.removePrefLocation();
            }

        }
    }

    @When("^I click on full screen icon and validate page is in full screen$")
    public void i_click_on_full_screen_icon_and_validate_page_is_in_full_screen() throws Throwable {
        Assert.assertTrue("Full screen validation in shipment list view is failed",
                this.shipmentOverviewPage.ValidateFullScreen());
    }

    @When("^I click on full screen$")
    public void i_click_on_full_screen() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.clickOnElement(By.xpath(String.format(this.shipmentOverviewPage.expandIcon, "expand")));
    }

    @Then("^I validate all the shipment have \"([^\"]*)\" Icon and \"([^\"]*)\" tooltip$")
    public void i_validate_all_the_shipment_have_and_tooltip(String Icon, String ToolTip) throws Throwable {
        this.softly.assertThat(this.shipmentOverviewPage.searchInSelectAll(Icon)).isTrue();
        this.softly.assertThat(this.shipmentOverviewPage.searchInSelectAll(ToolTip)).isTrue();
        this.softly.assertAll();
    }

    @Then("^I validate status Column will be \"([^\"]*)\" for all shipment list$")
    public void i_validate_Column_will_be_for_all_shipments(String columnValue) throws Throwable {
        this.softly.assertThat(this.shipmentOverviewPage.checkStatusColumn(columnValue)).isTrue();
        this.softly.assertAll();
    }

    @Then("^I validate all the shipment have \"([^\"]*)\"$")
    public void i_validate_all_the_shipment_have(String exceptionIcon) throws Throwable {
        this.softly.assertThat(this.shipmentOverviewPage.searchInSelectAll(exceptionIcon)).isTrue();
        this.softly.assertAll();
    }

    @Then("^I validate all the shipments do not have \"([^\"]*)\"$")
    public void i_validate_all_the_shipments_do_not_have(String exceptionIcon) throws Throwable {
        SoftAssertions softAssert = new SoftAssertions();
        softAssert.assertThat(this.shipmentOverviewPage.searchInSelectAll(exceptionIcon)).isTrue();
        softAssert.assertAll();
    }

    @Then("^validate that persist summary bar will be always present in the shipment details$")
    public void validate_that_persist_summary_bar_will_be_always_present_in_the_shipment_details() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitForDOMToLoad(DriverManager.getDrv());
            Assert.assertTrue(this.findElement(this.shipmentDetails.purplePanelTrackingNbrXpath).getText()
                    .contains("TRACKING NUMBER:"));
        }
    }

    @Then("^I validate the count for \"([^\"]*)\" is same as Viewing Counter$")
    public void i_validate_the_count_for_is_same_as_Viewing_Counter(String cardName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
            }
            Assert.assertTrue("Shipment List - able to Compare the Quick View number with viewing Counter -  ",
                    this.shipmentOverviewPage.CompareCountonCardandViewing(cardName));
        }
    }

    @Then("^I verify \"([^\"]*)\" is visible on page$")
    public void i_verify_is_visible_on_page(String historyMode) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue(historyMode + " is not visible", this.shipmentDetails.VerifyHistoryMode(historyMode));
        }
    }

    @Then("^I verify count for Scant event in UI against \"([^\"]*)\" in Api$")
    public void i_verify_count_for_Scant_event_in_UI_against_in_Api(String contextText) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertEquals(this.commonHelpers.getValuefromContextStore(contextText).toString(),
                    this.shipmentDetails.GetScanEventCount());
        }
    }

    @When("^I click on \"([^\"]*)\" in shipment detail page$")
    public void i_click_on_in_shipment_detail_page(String scanMode) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentDetails.switchScanEventMode(scanMode);
        }
    }

    @Then("^I verify \"([^\"]*)\" are displayed in Preference SecondarySideBar$")
    public void i_verify_are_displayed_in_Preference_SecondarySideBar(String SecondaryBarText) throws Throwable {
        softly.assertThat(this.preferencePage.CheckElementExist(SecondaryBarText)).isTrue();
        softly.assertAll();
    }

    @Then("^I verify no dropdowndown is blank in Preference Screen$")
    public void i_verify_no_dropdowndown_is_blank_in_Preference_Screen() throws Throwable {
        softly.assertThat(this.preferencePage.AllDropDownBlankCheck()).isTrue();
        softly.assertAll();
    }

    @Then("^I verify the \"([^\"]*)\" scan event from UI against API \"([^\"]*)\"$")
    public void i_verify_the_scan_event_from_UI_against_API(String eventNumber, String endpointkey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            HashMap<String, String> actualEvent = this.apiCall.GetScanEvent(endpointkey, eventNumber);
            HashMap<String, String> expectedEvent = this.shipmentDetails.GetScanEvent(eventNumber);
            Assert.assertEquals(actualEvent, expectedEvent);
        }
    }

    @Then("^I verify the scan event from UI against API \"([^\"]*)\" with Exception$")
    public void i_verify_the_scan_event_from_UI_against_API_with_Exception(String endpointkey) throws Throwable {
        if (this.commonHelpers.verifyKeyinContextStore("ScanEventCountWithException")) {
            String eventNumber = this.commonHelpers.getValuefromContextStore("ScanEventCountWithException").toString();
            HashMap<String, String> actualEvent = this.apiCall.GetScanEvent(endpointkey, eventNumber, true);
            HashMap<String, String> expectedEvent = this.shipmentDetails.GetScanEvent(eventNumber, true);
            Assert.assertEquals(actualEvent, expectedEvent);
        }
    }

    @Then("^I navigate to \"([^\"]*)\" page in \"([^\"]*)\" using \"([^\"]*)\" in the url$")
    public void i_navigate_to_shipment_details_page_using_in_the_url(String page, String url, String input)
            throws Throwable {
        this.loginPage.HitTheUrlWithAppendedInput(page, url, input);
    }

    @Given("^I verify the shipment details page of \"([^\"]*)\" with UI and API response stored in \"([^\"]*)\" for below values$")
    public void i_verify_the_shipment_details_page_of_with_UI_and_API_response_stored_in_for_below_values(
            String shipmentType, String endPointKey, DataTable table) throws Throwable {
        if (shipmentType.equalsIgnoreCase("MPS") && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("validation of MPS shipment in details is failed",
                    this.shipmentDetails.ValidateMPSfieldsWithUI(endPointKey, table));
        } else if (shipmentType.equalsIgnoreCase("MPS")
                && this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")) {
            Assert.assertTrue("CE validation of MPS shipment in details is failed",
                    this.shipmentDetails.CEValidateMPSfieldsWithUI(endPointKey, table));
        } else {
            Assert.assertTrue("Skiped because of virtualization turned ON", true);
        }
    }

    @Given("^I validate the \"([^\"]*)\" of shipment in Details using ContextStore values in UI with below values$")
    public void i_validate_the_of_shipment_in_Details_using_ContextStore_values_in_UI_with_below_values(String context,
                                                                                                        DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Validation of shipment details with tracking API is failed",
                    this.shipmentDetails.ValidateDetailsinUI(context, table));
    }

    @Given("^I validate the multi piece shipment table is populated with shipments from API \"([^\"]*)\" in UI$")
    public void i_validate_the_multi_piece_shipment_table_is_populated_with_shipments_from_API_in_UI(String endPointKey,
                                                                                                     DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Column headers are not displayed for MPS shipment",
                    this.shipmentDetails.ValidateColumnHeaders("MPS", table));
            Assert.assertTrue("Validation of contents in the MPS table in shipment details is failed",
                    this.shipmentDetails.ValidateMPStableWithUI(endPointKey, table));
        }
    }

    @Given("^I validate MPS table is expanded by default with click on \"([^\"]*)\" table is hidden$")
    public void i_validate_MPS_table_is_expanded_by_default_with_click_on_table_is_hidden(String viewingStatus)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("MPS table expand and collapse functionality is not working",
                    this.shipmentDetails.ValidateMPScollapseAndExpand(viewingStatus));
        }
    }

    @Given("^I click on child shipments and verify user navigating to shipment details of selected shipment$")
    public void i_click_on_child_shipments_and_verify_user_navigating_to_shipment_details_of_selected_shipment()
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentDetails.ValidateMPStrackNuminDetails();
        }
    }

    @Given("^I click on \"([^\"]*)\" link in portal$")
    public void i_click_on_link_in_portal(String Link) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (Link.equalsIgnoreCase("SHIPMENTS IN PROGRESS")) {
            if (Integer.parseInt(this.getText(this.homePage.shipmentsInProgress).replace(",", "").trim()) == 0) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                return;
            }
            this.clickOnElement(this.homePage.shipmentsInProgress);
        } else
            this.clickOnElement(By.xpath(buildXpathForString(Link)));
    }

    @Given("^I verify data in \"([^\"]*)\" against Viewing Data in the Shipment List page$")
    public void i_verify_data_in_against_Viewing_Data_in_the_Shipment_List_page(String linkName) throws Throwable {
        String lang  = GenericFunction.ReadConfigFile("LANG");
        if(!lang.equalsIgnoreCase("en-us")){
            linkName=this.genericFunObj.getLocalizedValue(linkName);
        }
        String pageCount = this.homePage.ValidateMonitoredShipmentsLinksCount(linkName).replace(",", "");
        if (Integer.parseInt(pageCount) == 0) {
            // Assert.assertTrue("Right Chevron for " + linkName + " is not Displayed",
            // this.homePage.VerifyChevronisDisplayed());
            Assert.assertTrue("Right Chevron for " + linkName + " is Displayed",
                    this.homePage.VerifyChevronisDisplayedWhenDiabled(linkName));
        } else {
            Assert.assertTrue(
                    "Monitered Shipments Caresoul for " + linkName + "Count and viewing Counter are not equal  ",
                    this.homePage.CompareCountonPageandViewing(pageCount, this.shipmentOverviewPage.getViewingCount()));
            this.NavigateToPreviousPageOfBrowser();
        }
    }

    @Given("^I capture the \"([^\"]*)\" from URL and store in \"([^\"]*)\"$")
    public void i_capture_the_from_URL_and_store_in(String ID, String contextStoreVariable) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            switch (ID) {
                case "shipmentID":
                    this.commonHelpers.AddToContextStore(contextStoreVariable,
                            this.shipmentDetails.getTrackingNumberFromCurrentURL());
                case "CompanyNumber":
                    this.commonHelpers.AddToContextStore(contextStoreVariable,
                            this.shipmentDetails.getTrackingNumberFromCurrentURL());
                    break;
                case "TrackingNumber":
                    this.commonHelpers.AddToContextStore(contextStoreVariable,
                            this.shipmentDetails.getTrackingNumberFromCurrentURL(ID));
                    break;
            }
    }

    @Then("^I get the below values from \"([^\"]*)\" and store in ContextStore for the user \"([^\"]*)\"$")
    public void i_get_the_below_values_from_and_store_in_ContextStore_for_the_user(String endPointkey, String user,
                                                                                   DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.apiCall.getValuesfromResp(endPointkey, table);
    }

    @Then("^I Validate the Shipment address in UI with API data$")
    public void i_Validate_the_Shipment_address_in_UI_with_API_data(DataTable dataTable) throws Throwable {
        Map<String, String> columnTable = dataTable.asMap(String.class, String.class);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Address in Summary tab is not displayed correctly",
                    this.shipmentDetails.ValidateShipmentAddressInSummaryTab(columnTable));
    }

    @Then("I verify user is shown with dropdown values")
    public void i_verify_user_is_shown_with_dropdown_values(DataTable dataTable) throws Throwable {
        Assert.assertTrue(" Drop down does not contian the expected values",
                this.shipmentOverviewPage.ValidateFilterValuesInDropDown(dataTable));
    }

    @And("^I select a value \"([^\"]*)\" from Date Dropdown$")
    public void i_select_a_value_from_Date_Dropdown(String dateType) throws Throwable {
        this.shipmentOverviewPage.SelectDateFilter(dateType);
    }

    @Then("^I Click on Calendar icon and Verify current date is highlighted$")
    public void i_click_on_Calendar_icon_and_Verify_current_date_is_highlighted() throws Throwable {
        Assert.assertTrue("Current date is not highlighted in calendar",
                this.shipmentOverviewPage.ValidateCurrentDateIsHighlightedInCalendar());
    }

    @And("^I Verify user is not shown date \"([^\"]*)\" days before from current date$")
    public void i_verify_user_is_not_shown_date_days_before_from_current_date(String datePrior) throws Throwable {
        Assert.assertTrue("Calendar does not display correct dates",
                this.shipmentOverviewPage.ValidateCalendarDisplaysDatesFromPreviousDays(datePrior));
    }

    @Given("^I validate \"([^\"]*)\" button in Calendar is \"([^\"]*)\" by default$")
    public void i_validate_button_in_Calendar_is_by_default(String button, String state) throws Throwable {
        Assert.assertTrue("Button: " + button + "is not as expected state: " + state,
                this.shipmentOverviewPage.validateButtonStateinCalender(button, state));
    }

    @Given("^I verify filter bubble shows TO and FROM date in \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_verify_filter_bubble_shows_TO_and_FROM_date_in_and(String preferredDateFormat, String DateType)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Filter bubble does not show have the chosen dates",
                    this.shipmentOverviewPage.VerifyFilterBubbleIsShownWithValues(preferredDateFormat, DateType));
        }
    }

    @Given("^I validate the viewing count for \"([^\"]*)\" in UI with API \"([^\"]*)\"$")
    public void i_validate_the_viewing_count_for_in_UI_with_API(String cardName, String endPointKey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
            }
            if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
                this.apiCall.VerifyCountofQCcardsinUIandAPI(cardName, endPointKey);
                this.waitUntilNotVisible(this.loadingIndicator);
                Boolean flag = false;
                if (cardName.equalsIgnoreCase("Total Filtered Records")) {
                    flag = this.commonHelpers.AssertCountswithCorrection(
                            Integer.parseInt(this.commonHelpers.getValuefromContextStore(cardName).toString()),
                            Integer.parseInt(this.shipmentOverviewPage.getViewingCount()));
                } else {
                    flag = this.commonHelpers.AssertCountswithCorrection(
                            Integer.parseInt(this.commonHelpers.getValuefromContextStore(cardName).toString()),
                            Integer.parseInt(this.shipmentOverviewPage.getTotalRecords()));
                }
                Assert.assertTrue(String.format(
                        "Count of records for cardName: %s and API filter count with correction factor is not matched",
                        cardName), flag);
            }
        }
    }

    @Given("^I remove the below filters using close icon in filter bubble$")
    public void i_remove_the_below_filters_using_close_icon_in_filter_bubble(DataTable filters) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.RemoveFiltersinBubble(filters);
            this.commonHelpers.thinkTimer(300);
        }
    }

    @Then("^I remove the below filter bubble using close icon$")
    public void i_remove_the_below_the_filter_bubble(DataTable filters) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.RemoveFiltersinBubble(filters);
        }
    }

    @Then("^I Click on \"([^\"]*)\" to open the right flyout$")
    public void i_Click_on_to_open_the_right_flyout(String cityPin) throws Throwable {
        if (elementIsDisplayed(this.advisoryPage.genericCityPin)) {
            this.advisoryPage.ClickOnCityPin(cityPin);
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Then("^Click on the View impacted shipments on the right flyout and verify navigated to shipment list with filter as \"([^\"]*)\"$")
    public void click_on_the_View_impacted_shipments_on_right_flyout_and_verify_navigated_to_shipment_list_with_filter_as(
            String City) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.ClickOnrightChevronandStoreShimpentData(City);
        }
    }

    @Then("^Validate data present in the grid matches to count right flyout$")
    public void validate_data_present_in_the_grid_matches_to_count_right_flyout() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String viewingCount = this.shipmentOverviewPage.getViewingCount();
            String cityName = this.shipmentOverviewPage.getCityfromCityBubble();
            Assert.assertTrue("Total Shipments Count and viewing Counter are not equal ",
                    this.advisoryPage.CompareCountonPageandViewing(viewingCount));
            Assert.assertTrue("City Name displayed on Filter is not matching ",
                    this.advisoryPage.CompareCityonPageandCitybubble(cityName));
        }
    }

    @Then("^Click on the toggle button to navigate to \"([^\"]*)\" view$")
    public void click_on_the_toggle_button_to_navigate_to_view(String view) throws Throwable {
        this.advisoryPage.navigateToView(view);
    }

    @Given("^Click on the View impacted shipments for the same City and Verify user navigated to shipment list with filter as \"([^\"]*)\"$")
    public void click_on_the_View_impacted_shipments_for_the_same_City_and_Verify_user_navigated_to_shipment_list_with_filter_as(
            String City) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.ClickOnrightChevronandStoreShimpentData_forGivenCity(
                    this.commonHelpers.getValuefromContextStore(City).toString());
        }
    }

    @Then("^Validate the count with respect to list view$")
    public void validate_the_count_with_respect_to_list_view() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String viewingCount = this.shipmentOverviewPage.getViewingCount();
            String cityName = this.shipmentOverviewPage.getCityfromCityBubble();
            Assert.assertTrue("Total Shipments Count and viewing Counter are not equal ",
                    this.advisoryPage.CompareCountonPageandViewing(viewingCount));
            Assert.assertTrue("City Name displayed on Filter is not matching ",
                    this.advisoryPage.CompareCityonPageandCitybubble(cityName));
        }
    }

    @Then("^Validate the view all shipments link should not be clickable for a preferred city which has no impacted shipments$")
    public void validate_the_view_all_shipments_link_should_not_be_clickable_for_a_preferred_city_which_has_no_impacted_shipments()
            throws Throwable {
        Assert.assertTrue(
                "Preferred Locations - ViewImpacted Shipments Right Chevron is clickable even when Shipments Count is Zero  ",
                this.advisoryPage.isRightChevronClickable());
    }

    @When("^the Shipment count is \"([^\"]*)\"$")
    public void the_Shipment_count_is(String arg1) throws Throwable {
        Assert.assertTrue("The check for 0 Shipment for current user is - ",
                this.homePage.VerifyAllShipmentCount(arg1));
    }

    @Then("^I verify these value should be present in Overview Screen$")
    public void i_verify_these_value_should_be_present_in_Overview_Screen(DataTable table) throws Throwable {
        Assert.assertTrue("All the values are found in Overview screen - ",
                this.preferencePage.ValidateScreenElements(table));
    }

    @Then("^login user should navigate to \"([^\"]*)\"$")
    public void login_user_should_navigate_to(String REDIRECTURL) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue("User navigated to page with title and URL flag - ",
                    this.loginPage.RedirectURL(REDIRECTURL));
        }
    }

    @Then("^User should not see the details from portal$")
    public void user_should_not_see_the_details_from_portal() throws Throwable {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertFalse("Overview presence from the Non Surround User should be false ",
                    this.waitUntilNotVisible(By.xpath(String.format(this.homePage.menu, "Overview"))));
        }
    }

    @When("^I click on \"([^\"]*)\" in Preference SecondarySideBar$")
    public void i_click_on_in_Preference_SecondarySideBar(String SecondarySideOption) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Click on secondary Side Options",
                    this.preferencePage.ClickOnSecondaryOptions(SecondarySideOption));
    }

    @When("^I click on Label \"([^\"]*)\"$")
    public void i_click_on_Label(String labelText) throws Throwable {
        Assert.assertTrue("Click on secondary Side Options", this.preferencePage.ClickOnSecondaryOptions(labelText));
    }

    @Then("^I validate all CPP Enablements in UI with API \"([^\"]*)\"$")
    public void i_validate_all_CPP_Enablements_in_UI_with_API(String endPointKey) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue("validation of CPP enablements with API is failed",
                this.preferencePage.ValidateCPPEnablements(endPointKey));
    }

    @Then("^I validate account header is \"([^\"]*)\" displayed or not$")
    public void i_validate_accounts_header(String header) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue("Header is not displayed for the accounts",
                this.preferencePage.isHeaderDisplayed(header));
    }

    @Then("^I validate account header \"([^\"]*)\" is not displayed$")
    public void i_validate_account_header_is_not_displayed(String header) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertFalse("Header is displayed for the accounts",
                this.preferencePage.isHeaderDisplayed(header));
    }

    @Then("^I verify data from \"([^\"]*)\" with \"([^\"]*)\"$")
    public void i_verify_data_from_with(String preferredListKey, String AllImpactedListKey) throws Throwable {
        Assert.assertTrue("Click on secondary Side Options",
                this.preferencePage.CheckPreferredLocation(preferredListKey, AllImpactedListKey));
    }

    @Then("^I validate all \"([^\"]*)\" in UI with API \"([^\"]*)\"$")
    public void i_validate_all_in_UI_with_API(String module, String endPointKey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            switch (module) {
                case "CER Comments":
                    Assert.assertTrue("Validation of CER Comments with API is failed",
                            this.shipmentDetails.ValidateDetailswithUIandAPI(module, endPointKey));
                    break;
            }
        }
    }

    @Then("^I verify the file name$")
    public void i_verify_the_file_name() throws Throwable {
        String fileNameExpected = Constants.fileNameForShipment;
        Date date = new Date();
        String todayDate = this.dateTimeUtils.setDateFormat(date.toString(), Constants.fileNameDate);
        fileNameExpected = fileNameExpected.concat("_").concat(todayDate).concat(".").concat(Constants.fileExtension);
        Assert.assertEquals(this.genericFunObj.fileName, fileNameExpected);
    }

    @Then("^I verify \"([^\"]*)\" link is disabled$")
    public void i_verify_link_is_disabled(String link) throws Throwable {
        boolean flag = preferencePage.isAddPrefCityLinkDisabled(link);
        Assert.assertTrue(link + " link is not disabled", flag);
    }

    @Then("^I verify preferred locations in advisories list$")
    public void i_verify_preferred_locations_in_advisories_list(DataTable table) throws Throwable {
        Map<String, String> map = table.asMap(String.class, String.class);

        for (String city : map.keySet()) {

            boolean flag = preferencePage.isAddedPrefCityShownInAdvList(city);

            if (map.get(city).equalsIgnoreCase("visible")) {
                Assert.assertTrue("Added preferred city: " + city + " is not shown in advisories > preferred locations",
                        flag);
            } else if (map.get(city).equalsIgnoreCase("invisible")) {
                Assert.assertFalse("Added preferred city: " + city + " is shown in advisories > preferred locations",
                        flag);
            }
        }
    }

    @Then("^I \"([^\"]*)\" on the checkbox$")
    public void i_on_the_checkbox(String action) throws Throwable {
        if (!elementIsDisplayed(this.preferencePage.prefLocationCheckboxState)) {
            try {
                this.waitUntilNotVisible(this.loadingIndicator);
                this.ScrollToTop();
                this.JavaScriptClick(this.preferencePage.disableCheckbox);
                preferencePage.performActionOnCheckbox(action);
            } catch (Exception e) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }

    @Given("^I click on monitored shipment's \"([^\"]*)\" chevron on overview page$")
    public void i_click_on_monitored_shipment_s_chevron_on_overview_page(String chevron) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            homePage.ClickSpecifiedChevron(chevron);
    }

    /**
     * If there is intervention added already this will delete that and adds a new
     * intervention
     */
    @When("^I delete any existing intervention$")
    public void i_delete_any_existing_intervention() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            shipmentDetails.deleteInterventionAndVerifyRequiredField();
    }

    /**
     * This method validates dropdowns in the Intervention addition or deletion
     *
     * @param dropdown
     * @param table
     * @return
     */
    @When("^I verify dropdown options for \"([^\"]*)\" in shipment details$")
    public void i_verify_dropdown_options_for_Status_and_intervention_type_in_shipment_details(String dropdown,
                                                                                               DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> options = table.asList(String.class);
            Assert.assertTrue(dropdown + " - dropdown options are not correct",
                    this.shipmentDetails.VerifydropdownoptionsforIntervention(dropdown, options));
        }
    }

    /**
     * This method gives the feasability to select options from Intervention
     *
     * @param button
     * @throws Throwable
     */
    @When("^Click on \"([^\"]*)\" button$")
    public void click_on_button(String button) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentDetails.OperaionsforIntervention(button);
    }

    /**
     * This method can enter all the details for intervention
     *
     * @param table
     * @throws Throwable
     */
    @When("^User enters intervention with below details$")
    public void user_enters_intervention_with_below_details(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> columnTable = table.asMap(String.class, String.class);
            this.shipmentDetails.EnterallthedetailsforIntervention(columnTable);
        }
    }

    /**
     * This method can Validate CaseID Boundarylimit in Intervention
     *
     * @param count
     * @throws Throwable
     */
    @When("^I Verify Case Id is a free text which can take upto \"([^\"]*)\" characters$")
    public void i_Verify_Case_Id_is_a_free_text_which_can_take_upto_characters(String count) throws Throwable {
        Assert.assertEquals("Max no. of characters mismatched: ", Integer.parseInt(count),
                this.shipmentDetails.ValidateCaseIDBoundarylimit());
    }

    /**
     * This method can Validate Comment box Boundarylimit in Intervention
     *
     * @param count
     * @throws Throwable
     */
    @When("^I Verify the Comments is a text field which can take upto \"([^\"]*)\" characters$")
    public void i_Verify_the_Comments_is_a_text_field_which_can_take_upto_characters(String count) throws Throwable {
        Assert.assertTrue("Max no. of characters mismatched" + "Expected: " + count,
                this.shipmentDetails.ValidateCommentboxBoundarylimit(count));
    }

    // Assert.assertEquals(actualLimit, Integer.parseInt(count));
    @When("^I get \"([^\"]*)\" tracking number from the shipment list$")
    public void i_get_tracking_number_from_the_shipment_list(String trackingNum) throws Throwable {
        this.shipmentOverviewPage.SelectTrackingNumber(trackingNum);
    }

    @Then("^I verify the Exception icon shown for event$")
    public void i_verify_the_Exception_icon_shown_for_event() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String event = this.commonHelpers.getValuefromContextStore("ScanEventCountWithException").toString();
            Assert.assertTrue(this.shipmentDetails.ValidateExceptionIcon(event));
        }
    }

    @When("^I click on \"([^\"]*)\" section in Shipment detail page$")
    public void i_click_on_section_in_Shipment_detail_page(String section) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentDetails.NavigateToSection(section);
        }
    }

    @Then("^I verify AddComment button is displayed and click on Plus sign$")
    public void i_verify_AddComment_button_is_displayed_and_click_on_Plus_sign() throws Throwable {
        boolean flag = this.shipmentDetails.VerifyAddCommentButtonIsDisplayed();
        if (flag)
            this.shipmentDetails.ClickOnAddCommentButton();
        else
            Assert.assertFalse("Add Comment button is not displayed", flag);
    }

    @Then("^I verify default value selected is \"([^\"]*)\"$")
    public void i_verify_default_value_selected_is(String value) throws Throwable {
        Assert.assertTrue(value + " is not selected", this.shipmentDetails.VerifyRadioButtonIsSelected(value));
    }

    @Then("^I verify default check box value is selected \"([^\"]*)\"$")
    public void i_verify_default_checkbox_value_(String value) throws Throwable {
        boolean check = this.manageQCPage.verifyCheckBoxIsSelected(value);
        switch (value) {
            case "Digital":
                if (check == true) {
                    Assert.assertFalse(value + "box is selected by default", check);
                }
                break;
            case "Hide Quick View Cards":
                if (check == true) {
                    Assert.assertTrue(value + " is not selected", check);
                    this.clickOnElement(this.getByusingString(this.buildXpathForString(value)));
                }
                break;
        }
    }

    @Given("^I select \"([^\"]*)\" option and verify the below fields are displayed$")
    public void i_select_option_and_verify_the_below_fields_are_displayed(String option, DataTable dataTable)
            throws Throwable {
        this.shipmentDetails.SelectOptioninICalledField(option);
        Assert.assertTrue(option + " option does not have correct fields",
                this.shipmentDetails.VerifyShipperOptionFields(dataTable));
    }

    @Then("^I verify user cannot add more than \"([^\"]*)\" characters in Comment textbox$")
    public void i_verify_user_cannot_add_more_than_characters_in_Comment_textbox(String maxLimit) throws Throwable {
        Assert.assertEquals(this.shipmentDetails.GetMaxLimitOfTextBox(), maxLimit);
    }

    @Then("^I click on \"([^\"]*)\" and verify below fields are highlighted as mandatory$")
    public void i_click_on_and_verify_below_fields_are_highlighted_as_mandatory(String option, DataTable table)
            throws Throwable {
        this.shipmentDetails.ClickOnLinkInComment(option);
        this.shipmentDetails.VerifyRequiredFieldsInCommentSection(table);
    }

    @Given("^I enter the below details and Click on \"([^\"]*)\"$")
    public void i_enter_the_below_details_Click_on(String option, DataTable dataTable) throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        this.shipmentDetails.AddDetailsForAddComment(table);
        this.shipmentDetails.ClickOnLinkInComment(option);
    }

    @Then("^I verify comments are displayed in the list of comments with the below values$")
    public void i_verify_comments_are_displayed_in_the_list_of_comments_with_the_below_values(DataTable dataTable)
            throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        Assert.assertTrue(this.shipmentDetails.VerifyDataDisplayedInCommentList(table));
    }

    @Given("^I click on ellipses and verify the below options are displayed$")
    public void i_click_on_ellipses_and_verify_the_below_options_are_displayed(DataTable dataTable) throws Throwable {
        Assert.assertTrue("Options are not displayed correctly",
                this.shipmentDetails.ValidateEllipsesOptionsForComment(dataTable));
    }

    @Then("^I select the \"([^\"]*)\" option after clicking on ellipses$")
    public void i_select_the_option_after_clicking_on_ellipses(String option) throws Throwable {
        this.shipmentDetails.SelectOptionsForComment(option);
    }

    @And("^I verify previous data is auto-populated in the fields$")
    public void i_verify_previous_data_is_auto_populated_in_the_fields(DataTable dataTable) throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        this.shipmentDetails.VerifyDataIsAutoPopulatedWhenEditCommentIsClicked(table);
    }

    @Then("^I verify below options are displayed in DeleteConfirmationDialog$")
    public void i_verify_below_options_are_displayed_in_DeleteConfirmationDialog(DataTable dataTable) throws Throwable {
        Assert.assertTrue("Update link is not displayed",
                this.shipmentDetails.VerifyButtonIsDisplayedInConfirmationDialog(dataTable));
    }

    @Then("^I update all the values in the comment with the below values and Click on \"([^\"]*)\"$")
    public void i_update_all_the_values_in_the_comment_with_the_below_values_and_Click_on(String option,
                                                                                          DataTable dataTable) throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        this.shipmentDetails.AddDetailsForAddComment(table);
        this.shipmentDetails.ClickOnLinkInComment(option);
    }

    @Then("^I Validate \"([^\"]*)\" is not present in Dashboard page$")
    public void i_Validate_is_not_present_in_Dashboard_page(String Search) throws Throwable {
        Assert.assertFalse("Search is not present in Dashboard page", this.homePage.VerifySearchisDisplayed());
    }

    @Then("^I Validate \"([^\"]*)\" is not present in Preferences page$")
    public void i_Validate_is_not_present_in_Preferences_page(String Search) throws Throwable {
        Assert.assertFalse("Search is not present in Preferences page", this.homePage.VerifySearchisDisplayed());
    }

    @Then("^Verify we have more than one Company on Dashboard page$")
    public void verify_we_have_more_than_one_Company_on_Dashboard_page() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue("We have only One Company Available on Dashboard page",
                this.ceDashboard.CheckforMorethanOneCompany());
    }

    @Then("^Click on SearchBox and Enter \"([^\"]*)\" and hit Enter$")
    public void click_on_SearchBox_and_Enter_and_hit_Enter(String trackingNum) throws Throwable {
        this.shipmentOverviewPage.SearchTrackingNumber(trackingNum);
    }

    @Then("^Verify Shipment Details page will get opened with \"([^\"]*)\" on Top$")
    public void verify_Shipment_Details_page_will_get_opened_with_on_Top(String textString) throws Throwable {
        Assert.assertTrue(textString + " is not Displayed on Shipment Details page",
                this.shipmentDetails.VerifyGivenTextisDisplayed(textString));

    }

    @Then("^Store \"([^\"]*)\" in Context-Store$")
    public void store_in_Context_Store(String companyName) throws Throwable {
        this.commonHelpers.AddToContextStore(companyName, this.shipmentOverviewPage.getSelectedCompanyName());
    }

    @Then("^I Select the next Company from Dropdown$")
    public void i_Select_the_next_Company_from_Dropdown() throws Throwable {
        this.shipmentOverviewPage.selectNextComapnyfromDropDown("index", "1");
    }

    @Then("^I Verify Shipment list will be get opened for the same \"([^\"]*)\" which is in Context-Store$")
    public void i_Verify_Shipment_list_will_be_get_opened_for_the_same_which_is_in_Context_Store(String companyName)
            throws Throwable {
        Assert.assertTrue("Shipment List - able to Compare the ContextStore CompanyName with CompanyName on page ",
                this.shipmentOverviewPage.CompareBothCompanyNames(companyName));
    }

    @Then("^Click on SearchBox and Enter \"([^\"]*)\" digit Partial Tracking Number and hit Enter$")
    public void click_on_SearchBox_and_Enter_digit_Partial_Tracking_Number_and_hit_Enter(String digit)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.SearchPartialTrackingNumber(digit, "Tracking Number");
        }
    }

    @Then("^Verify all the Tracking number contains the given Partial Tracking Number in Shipment List$")
    public void verify_all_the_Tracking_number_contains_the_given_Partial_Tracking_Number_in_Shipment_List()
            throws Throwable {
        int searchresultCountInt = Integer
                .parseInt(this.commonHelpers.getValuefromContextStore("searchresultCount").toString());
        if (searchresultCountInt > 1) {
            Assert.assertTrue(
                    "All the tracking numbers in the Shipment List are having the given partical Tracking number",
                    this.shipmentOverviewPage
                            .VerifyAllTrackinNumsContainsGivenPartialTrackingNumOnly(searchresultCountInt));
        } else {
            Assert.assertTrue("TRACKING NUMBER is not Displayed on Shipment Details page",
                    this.shipmentDetails.VerifyGivenTextisDisplayed("TRACKING NUMBER"));
        }
    }

    @Then("^Verify that No Searching is Displayed when we Type \"([^\"]*)\" digit in Search Box$")
    public void verify_that_No_Searching_is_Displayed_when_we_Type_digit_in_Search_Box(int twoDigit) throws Throwable {
        Assert.assertFalse("Searching is displayed when we Type 2 digit in search Box",
                this.shipmentOverviewPage.isNoSearchDisplayedforTwoDigitTrackingNumber(twoDigit));
    }

    @Then("^Verify that \"([^\"]*)\" is displayed when we Enter value \"([^\"]*)\" in Search Box$")
    public void verify_that_is_displayed_when_we_Enter_value_in_Search_Box(String textString, String trackingNum)
            throws Throwable {
        Assert.assertTrue("Invalid Tracking Number is displayed when we Enter " + trackingNum + " in search Box",
                this.shipmentOverviewPage.isInvalidTrackingNumberDisplayed(trackingNum, textString));
    }

    @Then("^I skip remaining steps if monitored shipment's \"([^\"]*)\" are zero in overview page$")
    public void i_skip_remaing_steps_if_monitored_shipment_s_are_zero_in_overview_page(String chevron)
            throws Throwable {
        this.waitUntilNotVisible(loadingIndicator);
        if (homePage.ValidateIfMonitoredShipmentCountZero(chevron)) {
            this.commonHelpers.AddToContextStore("skipRemainingSteps",
                    homePage.ValidateIfMonitoredShipmentCountZero(chevron));
        } else if (this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.removeKeyinContextStore(Constants.skipSteps);
        }
    }

    @Then("^I skip remaining steps if the viewing count is less than \"([^\"]*)\"$")
    public void i_skip_remaining_steps_if_the_viewing_count_is_less_than(String count) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (shipmentOverviewPage.getViewCount() < Integer.parseInt(count))
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Then("^I verify \"([^\"]*)\" sub menu is shown$")
    public void i_verify_sub_menu_is_shown(String subMenu) throws Throwable {
        Assert.assertTrue(subMenu + " sub menu is not shown", homePage.verifySubMenu(subMenu));
    }

    @Then("^I Run below Mandatory Steps$")
    public void i_run_below_mandatorySteps() throws Throwable {
        if (this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.commonHelpers.removeKeyinContextStore(Constants.skipSteps);
        }
    }

    @Then("^I verify \"([^\"]*)\" sub menu is not shown$")
    public void i_verify_sub_menu_is_not_shown(String subMenu) throws Throwable {
        Assert.assertFalse(subMenu + " sub menu is shown", homePage.verifySubMenu(subMenu));
    }

    @Then("^I verify \"([^\"]*)\" and \"([^\"]*)\" options are displayed$")
    public void i_verify_and_options_are_displayed(String link1, String link2) throws Throwable {
        Assert.assertTrue("Update link is not displayed", this.shipmentDetails.VerifyLinkInCommentSection(link1));
        Assert.assertTrue("Cancel link is not displayed", this.shipmentDetails.VerifyLinkInCommentSection(link2));
    }

    @Given("^I click on \"([^\"]*)\" button in ConfirmationDialog$")
    public void i_click_on_button_in_ConfirmationDialog(String button) throws Throwable {
        this.shipmentDetails.ClickOnButtonIsDisplayedInConfirmationDialog(button);
    }

    @Given("^I verify user is prompted to with confirmation Message$")
    public void i_verify_user_is_prompted_to_with_confirmation_Message() throws Throwable {
        Assert.assertTrue(this.shipmentDetails.VerifyConfirmationDialogIsDisplayedWithErrorMessage());
    }

    @Given("^I verify the comment is deleted from Comment list$")
    public void i_verify_the_comment_is_deleted_from_Comment_list() throws Throwable {
        Assert.assertTrue("Comment is not deleted and is visible",
                this.shipmentDetails.VerifyCommentIsDeletedFromCommentList());
    }

    @Then("^I select \"([^\"]*)\" company from drop down$")
    public void i_select_company_from_drop_down(String company) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        company = company.contains("ContextStore-") ? this.commonHelpers.getValuefromContextStore(company).toString()
                : company;

        // this.shipmentOverviewPage.selectNextComapnyfromDropDown("text", company);
        this.shipmentOverviewPage.SelectCompanyAccountDD(company);
    }

    @Given("^Verify Total count of Companies in dashboard is same in Company Dropdown$")
    public void verify_Total_count_of_Companies_in_dashboard_is_same_in_Company_Dropdown() throws Throwable {
        int allcompanycount = this.shipmentOverviewPage.getAllCompanyFromDropdown();
        int dashBoardCompanyCount = Integer
                .parseInt((String) this.commonHelpers.getValuefromContextStore("TotalCompanies"));
        Assert.assertTrue("Companies Count Matching is ", allcompanycount == dashBoardCompanyCount);
    }

    @When("^I click on first row from the list$")
    public void i_select_first_row() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentOverviewPage.clickOnFirstList();
    }

    @When("^user navigates to Different Company$")
    public void user_navigates_to_Different_Company() throws Throwable {
        this.shipmentOverviewPage.selectNextComapnyfromDropDown("text", GenericFunction.ReadConfigFile("CE_COMPANY"));
    }

    @Then("^Store TrackingNumber as per \"([^\"]*)\" in Context-Store$")
    public void store_TrackingNumber_as_per_in_Context_Store(String CompanyName) throws Throwable {
        this.commonHelpers.thinkTimer(15000);
        this.shipmentOverviewPage.storecompanytrackingnumber(CompanyName);
    }

    @Then("^Verify that \"([^\"]*)\" TrackingNumber is not same as \"([^\"]*)\"$")
    public void verify_that_TrackingNumber_is_not_same_as(String CompanyName1, String CompanyName2) throws Throwable {
        Assert.assertTrue("Companies Tracking Matching is ",
                this.shipmentOverviewPage.comparetrackingnumber(CompanyName1, CompanyName2));
    }

    @Then("^Verify \"([^\"]*)\" can have only these values$")
    public void verify_can_have_only_these_values(String columnName, DataTable table) throws Throwable {
        Assert.assertTrue("Column data matching is ", this.shipmentOverviewPage.checkvalueinColumn(columnName, table));
    }

    @Given("^I verify values displayed for \"([^\"]*)\" in UI against \"([^\"]*)\" Impacted Shipments$")
    public void i_verify_values_displayed_for_in_UI_against_Impacted_Shipments(String filter, String endpointKey)
            throws Throwable {
        HashMap<String, Integer> expectedCountfromAPI = this.apiCall
                .getListofCitieswithCountFromAdvisoriesShipments(filter, endpointKey);
        List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(expectedCountfromAPI.entrySet());

        HashMap<String, Integer> actualCountfromUI = this.advisoryPage.GettingTotalCont();
        List<Entry<String, Integer>> UIList = new LinkedList<Entry<String, Integer>>(actualCountfromUI.entrySet());

        Assert.assertEquals(list, UIList);
    }

    @Then("^I get the information for \"([^\"]*)\"$")
    public void i_get_the_information_for(String location) throws Throwable {
        if (this.shipmentDetails.getShipperLocationDetailsFromSummaryTab(location)
                .contains("Weather data not available!"))
            log.info("Weather data not available!");
    }

    /**
     * This method is for
     * Descending_Order_for_is_shown_on_top_against_Impacted_Shipments
     *
     * @param filter
     * @param endpointKey URL to be used
     */
    @Then("^I verify Descending Order for \"([^\"]*)\" is shown on top against \"([^\"]*)\" Impacted Shipments$")
    public void i_verify_Descending_Order_for_is_shown_on_top_against_Impacted_Shipments(String filter,
                                                                                         String endpointKey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            HashMap<String, Integer> expectedCountfromAPI = this.apiCall
                    .getListofCitieswithCountFromAdvisoriesShipments(filter, endpointKey);
            List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(expectedCountfromAPI.entrySet());
            Collections.sort(list, new Comparator<Entry<String, Integer>>() {
                public int compare(Entry<String, Integer> output1, Entry<String, Integer> output2) {
                    return output2.getValue().compareTo(output1.getValue());
                }
            });
            HashMap<String, Integer> actualCountfromUI = this.advisoryPage.GettingTotalCont();
            List<Entry<String, Integer>> UIList = new LinkedList<Entry<String, Integer>>(actualCountfromUI.entrySet());
            Collections.sort(UIList, new Comparator<Entry<String, Integer>>() {
                public int compare(Entry<String, Integer> output1, Entry<String, Integer> output2) {
                    return output2.getValue().compareTo(output1.getValue());
                }
            });
            Assertions.assertThat(list).containsSequence(UIList);
        }
    }

    /**
     * This method gives getListofCitieswithCountFromPreferredLocations
     *
     * @param filter
     * @param endpointKey
     * @throws Throwable
     */
    @When("^I verify number of cities for \"([^\"]*)\" is shown in \"([^\"]*)\" Preferred Locations$")
    public void i_verify_number_of_cities_for_is_shown_in_Preferred_Locations(String filter, String endpointKey)
            throws Throwable {
        HashMap<String, Integer> expectedCountfromAPI = this.apiCall
                .getListofCitieswithCountFromPreferredLocations(filter, endpointKey);
        HashMap<String, Integer> actualCountfromUI = this.advisoryPage.GettingTotalCont();
        Assert.assertTrue(expectedCountfromAPI.equals(actualCountfromUI));
    }

    @Then("^I verify toggle for \"([^\"]*)\" is selected$")
    public void i_verify_toggle_for_is_selected(String toggleSelection) throws Throwable {
        if (this.elementIsDisplayed(this.loadingIndicator)) {
            this.waitUntilNotVisible(this.loadingIndicator);
        }
        Assert.assertTrue(this.shipmentOverviewPage.verifyToggleSelection(toggleSelection));
    }

    @When("^I switch toggle to \"([^\"]*)\"$")
    public void i_switch_toggle_to(String toggle) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (this.elementIsDisplayed(this.loadingIndicator)) {
                this.waitUntilNotVisible(this.loadingIndicator);
            }
            this.shipmentOverviewPage.selectToggle(toggle);
        }
    }

    @Then("^I verify the toggled records against \"([^\"]*)\"$")
    public void i_verify_the_toggle_against(String endpointKey) throws Throwable {
        int actualCount = this.shipmentOverviewPage.getViewCount();
        int expectedCount = this.apiCall.filteredRecordsFromShipment(endpointKey);
        Assert.assertTrue("Count in Api is " + expectedCount + " ,but in UI is " + actualCount,
                this.commonHelpers.AssertCountswithCorrection(expectedCount, actualCount));
    }

    @Then("^I verify \"([^\"]*)\" against \"([^\"]*)\"$")
    public void i_verify_against(String count, String param) throws Throwable {
        this.shipmentOverviewPage.selectToggle("All");
        this.shipmentOverviewPage.selectToggle("Monitored");
        int uiCount = this.shipmentOverviewPage.getViewCount();
        int cosmosCount = Integer.parseInt(this.commonHelpers.getValuefromContextStore(count).toString());
        Assert.assertTrue("Count in Cosmos is " + cosmosCount + " ,but in UI is " + uiCount,
                this.commonHelpers.AssertCountswithCorrection(cosmosCount, uiCount));
    }

    @Given("^I validate \"([^\"]*)\" icons for shipments in list view$")
    public void i_validate_icons_for_shipments_in_list_view(String status) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Shipment Icon validation is failed for status: " + status,
                    this.shipmentOverviewPage.ValidateShipmentsIcon(status));
        }
    }

    @When("^I click on dashboard option and verify order in \"([^\"]*)\"$")
    public void i_verify_order_arrow(String order, DataTable table) throws Throwable {
        this.ceDashboard.clickDashBoard(table, order);
    }

    @Then("^I clicked on below columns values and verify filter bubble$")
    public void i_store_list(DataTable table) throws Throwable {
        List<String> dataOptions = table.asList(String.class);
        for (String column : dataOptions) {
            this.ceDashboard.clickDashboardColumnValues(column);
            clickOnElement(this.ceDashboard.ceDashBoardOption);
        }
    }

    @Then("^I verify watched icon for all shipments$")
    public void i_verify_watched_list() throws Throwable {
        this.ceDashboard.verifyOrderSelection();
    }

    @Given("^I \"([^\"]*)\" the filters using below conditions and verify filter Bubble$")
    public void i_select_the_filters_using_below_conditions_and_verify_filter_Bubble(String cancelOrApply,
                                                                                     DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Map<String, String> dataFilters = table.asMap(String.class, String.class);
            String handling = null;
            for (String key : dataFilters.keySet()) {
                if (key.equalsIgnoreCase("Shipment Information-Special Handling")) {
                    String value = dataFilters.get(key);
                    if (value.contains("FedEx Surround Elite")) {
                        handling = value;
                    }
                }
            }
            if (handling != null) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            } else {
               /* Assert.assertTrue("Something went wrong in selection of filter in UI or during filter bubble validation",
                        this.shipmentOverviewPage.SelectFilterforUI(cancelOrApply, table));*/
                Assert.assertTrue("Something went wrong in selection of filter in UI or during filter bubble validation",
                        this.shipmentOverviewPage.SelectFilterforUI_githubCopilot(cancelOrApply, table));
                this.waitUntilNotVisible(this.loadingIndicator);
            }

        }
    }

    @Given("^I \"([^\"]*)\" the filters using below conditions without filter bubble validation$")
    public void i_select_the_filters_using_below_conditions_without_filter_bubble_validation(String cancelOrApply,
                                                                                             DataTable table) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.selectOrDeselectFilter(cancelOrApply, table);
        }
    }

    @Given("^I navigate to below filters in the application and validate default text$")
    public void i_navigate_to_below_filters_in_the_application_and_validate_default_text(DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("validation of default text is failed", this.shipmentOverviewPage.Selectfilter(table));
        }
    }

    @Given("^I navigate to below filters in the application and validate the default selection$")
    public void i_navigate_to_below_filters_in_the_application_and_validate_the_default_selection(DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of default filter selection is failed",
                    this.shipmentOverviewPage.validateDefaultFilterSelection(table));
        }
    }

    @Given("^I verify the filter title using below conditions$")
    public void i_verify_the_filter_title_using_below_conditions(DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of sub filter title failed",
                    this.shipmentOverviewPage.validateFilterTitle(table));
        }
    }

    @Given("^I validate search bar filter information text for below inputs$")
    public void i_validate_search_bar_filter_information_text_for_below_inputs(DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of search bar information text failed",
                    this.shipmentOverviewPage.ValidateSearchBarFiltersInfoText(table));
        }
    }

    @Given("^I enter below text in \"([^\"]*)\" filters and click on \"([^\"]*)\"$")
    public void i_enter_below_text_in_filters_and_click_on(String context, String cancelApply, DataTable table)
            throws Throwable {
        Assert.assertTrue("Entering f the text is failed",
                this.shipmentOverviewPage.EnterTextinSearch(context, cancelApply, table));
    }

    @Given("^I verify below filters are not available for the user$")
    public void i_verify_below_filters_are_not_available_for_the_user(DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of non availability of filter is failed",
                    this.shipmentOverviewPage.FiltersNonAvailability(table));

        }
    }

    @When("^I validate the filters are having below values to apply conditions$")
    public void i_validate_the_filters_are_having_below_values_to_apply_conditions(DataTable table) throws Throwable {
        Assert.assertTrue("Validation of values in Filter is failed",
                this.shipmentOverviewPage.ValidateFilterConditions(table));
    }

    @Given("^I \"([^\"]*)\" the filters with selected days \"([^\"]*)\" using below conditions$")
    public void i_select_the_filters_using_below_conditions(String cancelOrApply, String date, DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong in selection of filter in UI",
                    this.shipmentOverviewPage.SelectFilterforUIwithDate(cancelOrApply, table, date));
        }
    }

    @Given("^I \"([^\"]*)\" the filters using below conditions and verify filter bubble$")
    public void i_select_the_filters_using_below_conditions(String cancelOrApply, DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong in selection of filter or during filter bubble valdiation in UI",
                    this.shipmentOverviewPage.SelectUIFilter(cancelOrApply, table));
        }
    }

    @When("^I select the filters using below conditions without apply$")
    public void i_select_the_filters_using_below_conditions_without_apply(DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.navigatesToDateFilter(table);
        }
    }

    @Given("^I perform logout$")
    public void i_perform_logout() throws Throwable {
        this.homePage.logOut();
    }

    @Then("^I compare the data in grid against Api using \"([^\"]*)\" for$")
    public void i_compare_the_data_in_grid_against_Api_using_for(String trkNbr, DataTable table) throws Throwable {

        List<String> fields = table.asList(String.class);
        Map<String, String> gridData = this.shipmentOverviewPage.GetUiField(fields, trkNbr);
        for (String key : gridData.keySet()) {
            String value = gridData.get(key);
            // Replace multiple spaces with a single space
            try {
                value = value.replaceAll("\\s+", " ");
                // Update the value in the map
            } catch (Exception exception) {
                log.info("No double whitespace available");
            }
            gridData.put(key, value);

        }
        Map<String, String> apiData = this.apiCall.GetApiData(fields, trkNbr);
        for (String key : apiData.keySet()) {
            String value = apiData.get(key);
            try {
                value = value.replaceAll("\\s+", " ");
            } catch (Exception exception) {
                log.info("No double whitespace available");
            }
            apiData.put(key, value);
        }
        Assert.assertEquals("Data in grid and Api response do not match", gridData, apiData);
    }

    @Then("^I verify data in Api and Shipment detail page for$")
    public void i_verify_data_in_Api_and_Shipment_detail_page_for(DataTable table) throws Throwable {
        List<String> fields = table.asList(String.class);
        Map<String, String> apiData = this.apiCall.GetApiData(fields, "ContextStore-Tracking Number");
        Map<String, String> uiData = this.shipmentDetails.GetUIDetail(fields);
        Assert.assertEquals("Data in grid and Api response do not match", uiData, apiData);
    }

    @Then("^I validate \"([^\"]*)\" company's numbers displayed in ce dashboard with list view$")
    public void i_validate_company_s_numbers_displayed_in_ce_dashboard_with_list_view(String company, DataTable columns)
            throws Throwable {
        Assert.assertTrue("validation of clickable links in CE dashboard is failed: ",
                this.ceDashboard.ValidateDashboardNumbers(company, columns));
    }

    @Then("^I validate the side link for \"([^\"]*)\" with constants$")
    public void i_validate_the_side_link_for_with_constants(String link) throws Throwable {
        Assert.assertTrue(String.format("Validation of the hyperlinks for link: %s is failed", link),
                this.homePage.ValidateExternalLinks(link));
    }

    @Then("^I validate the user navigate to \"([^\"]*)\" URL$")
    public void i_validate_the_user_navigate_to_URL(String externalURL) throws Throwable {
        Assert.assertTrue(String.format("External link navigation is failed for link : %s", externalURL),
                this.homePage.VerifyLinkNavigation(externalURL));
    }

    @Then("^I check the number of shipments in my shipments page$")
    public void i_check_the_number_of_shipments_in_my_shipments_page() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.AddToContextStore("previousShipmentsCount", this.shipmentOverviewPage.getViewCount());
        }
    }

    @When("^I \"([^\"]*)\" a shipment in my shipments page$")
    public void i_a_shipment_in_my_shipments_page(String watchOrUnwatch) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.watchOrUnwatchShipment(watchOrUnwatch);
        }
    }

    @Then("^I verify shipments count is \"([^\"]*)\"$")
    public void i_verify_shipments_count_is(String flag) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            Assert.assertTrue("Count mismatch in shipment list",
                    this.shipmentOverviewPage.validateWatchedListCount(flag));
        }
    }

    @When("^I switch \"([^\"]*)\" toggle to \"([^\"]*)\"$")
    public void i_switch_toggle_to(String toggle, String flag) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.ScrollToTop();
            this.shipmentOverviewPage.selectToggle(toggle, flag);
        }
    }

    @Then("^I compare the column data in grid against Api using \"([^\"]*)\" for$")
    public void i_compare_the_column_data_in_grid_against_Api_using_for(String trkNbr, DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        List<String> fields = table.asList(String.class);
        Map<String, String> gridData = this.shipmentOverviewPage.GetUiFieldData(fields, trkNbr);
        Map<String, String> apiData = this.apiCall.GetApiDataWithoutStatus(fields, trkNbr);
        Assert.assertEquals("Data in column grid and Api response do not match", gridData, apiData);
    }

    @Then("^I verify filter bubble in my shipments page$")
    public void i_verify_filter_bubble_in_my_shipments_page(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            Assert.assertTrue("Filter Bubble verification failed",
                    this.shipmentOverviewPage.ValidateFilterBubble(table));
        }
    }

    @Then("^I verify \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" values and validate filter bubble if international shipments are present$")
    public void i_verify_filter_bubble_in_my_shipments_page_using_flag(String customerFlag, String ceFlag,
                                                                       String fusionFlag, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            if (this.commonHelpers.getValuefromContextStore(customerFlag).toString().equals("true")
                    && this.commonHelpers.getValuefromContextStore(ceFlag).toString().equals("true")
                    && this.commonHelpers.getValuefromContextStore(fusionFlag).toString().equals("true")) {
                Assert.assertTrue("Filter Bubble verification failed",
                        this.shipmentOverviewPage.ValidateFilterBubble(table));
            }
        }
    }

    @Then("^Verify Timezone value is updated with the logged in users browser time zone$")
    public void verify_Timezone_value_is_updated_with_the_logged_in_users_browser_time_zone() throws Throwable {
        Assert.assertTrue("Last Comment column not contains system/browser time zone",
                this.shipmentDetails.ValidateLastCommentColumContainsSystemTimEZone());
    }

    @And("^Verify Last Comment contains \"([^\"]*)\"$")
    public void verify_Last_Comment_contains(String preferredDateFormat) throws Throwable {
        Assert.assertTrue("Last Comment column not contains preferred date format",
                this.shipmentDetails.ValidateLastColumnContainsPreferredDateFormat(preferredDateFormat));
    }

    @When("^I click on \"([^\"]*)\" link in My Shipmentdetails$")
    public void i_click_on_link_in_My_Shipmentdetails(String link) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.clickOnBackButton(link);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @When("^I navigate to page \"([^\"]*)\" in shipments overview page$")
    public void i_navigate_to_page_in_shipments_overview_page(String pageNumber) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.clickOnShipmentsPageNumber(pageNumber);
        }
    }

    @Then("^I verify page is navigated to \"([^\"]*)\" page$")
    public void i_verify_page_is_navigated_to_page(String pageNumber) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went in page navigation",
                    this.shipmentOverviewPage.isShipmentsPageClicked(pageNumber));

        }
    }

    @And("^I compare the \"([^\"]*)\" value with shipmentdetails$")
    public void i_compare_the_value_with_shipmentdetails(String lastComment) throws Throwable {

        String lastCommentInShipmentDetailsPage = this.commonHelpers.getValuefromContextStore(lastComment).toString()
                .trim();
        String lastCommntDateTimeFromShipmentpage = this.shipmentDetails.GetLastCommentDateTimeValueFromShipmentsPage()
                .replace(",", "")
                .trim();
        String[] dateTime = lastCommentInShipmentDetailsPage.split(" ");
        boolean assertDateValue = lastCommntDateTimeFromShipmentpage.contains(dateTime[0]);
        Assert.assertTrue("Last Comment Date missmatched", assertDateValue);
        boolean assertTimeValue = lastCommntDateTimeFromShipmentpage.contains(dateTime[1].trim().substring(0, 4));
        Assert.assertTrue("Last Comment Date missmatched", assertTimeValue);
    }

    @Then("^I verify \"([^\"]*)\" in Shipment list$")
    public void i_verify_in_Shipment_list(String lastComment) throws Throwable {
        i_click_on_the_view_of_MyShipments("expand");
        List<String> columnInGrid = this.shipmentOverviewPage.getColumnsingrid();
        Assert.assertTrue(columnInGrid.contains(lastComment));
    }

    @Given("^I \"([^\"]*)\" a shipment in shipments details page$")
    public void i_a_shipment_in_shipments_details_page(String text) throws Throwable {
        this.shipmentDetails.WatchlistIconsClick(text);
    }

    @Then("^I verify shipment is \"([^\"]*)\" in shipments details page$")
    public void i_verify_shipment_is_in_shipment_details__page(String text) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(text + " is Displayed on Shipment Details page", this.shipmentDetails.VerifyWatchlist(text));
    }

    @And("^I get \"([^\"]*)\" Date and Time from Shipmentdetails$")
    public void i_get_Date_and_Time_from_Shipmentdetails(String lastComment) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentDetails.AddLastCommentToContextStore(lastComment);
    }

    @Then("^I select the \"([^\"]*)\" option of \"([^\"]*)\" comment after clicking on ellipses$")
    public void i_select_the_option_of_comment_after_clicking_on_ellipses(String option, String row) throws Throwable {
        this.shipmentDetails.SelectOptionsForCommentByRow(option, row);
    }

    @Then("^I click on delete icon and select \"([^\"]*)\" option for view$")
    public void i_click_on_delete_icon_and_select_option_for_view(String option, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> columns = table.asList(String.class);
            this.ScrollByOffset("0", "300");
            this.shipmentOverviewPage.clickMyView();
            this.shipmentOverviewPage.DeleteView(option, columns);
        }
    }

    @Then("^I click on delete icon for default view and select \"([^\"]*)\" option for view$")
    public void i_click_on_delete_icon_for_default_view_and_select_option_for_view(String option, DataTable table)
            throws Throwable {
        List<String> columns = table.asList(String.class);
        this.shipmentOverviewPage.clickMyView();
        this.shipmentOverviewPage.DeleteDefaultView(option, columns);
    }

    @Then("^I verify the view is in the views list$")
    public void i_verify_the_view_is_in_the_views_list(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> columnTable = table.asMap(String.class, String.class);
            this.shipmentOverviewPage.clickMyView();
            Assert.assertTrue("Something went wrong with view",
                    this.shipmentOverviewPage.verifyViewInList(columnTable));
        }
    }

    @When("^I select the view \"([^\"]*)\"$")
    public void i_select_the_view(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.SelectView(viewName);
        }
    }

    @Then("^I Verify that the view \"([^\"]*)\" filter bubble is \"([^\"]*)\"$")
    public void i_Verify_that_the_view_filter_bubble_is(String view, String flag) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong with view bubble",
                    this.shipmentOverviewPage.VerifyViewBubble(view, flag));
        }
    }

    @Then("^I verify the \"([^\"]*)\" default columns in the shipment list grid$")
    public void i_verify_the_default_columns_in_the_shipment_list_grid(String persona) throws Throwable {
        if (persona.equalsIgnoreCase("shipper")) {
            Assert.assertTrue("Shipper default columns are not matched",
                    this.shipmentOverviewPage.VerifyDefaultColumns());
        } else if (persona.equalsIgnoreCase("ce")) {
            Assert.assertTrue("CE default columns are not matched", this.shipmentOverviewPage.VerifyCEDefaultColumns());
        }
    }

    @Then("^I save the view with the view name \"([^\"]*)\"$")
    public void i_save_the_view_with_the_view_name(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("View name is not matched", this.shipmentOverviewPage.SaveAView(viewName));
        }
    }

    @Then("^I save the view as default with the view name \"([^\"]*)\"$")
    public void i_save_the_view_as_default_with_the_view_name(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("View name is not matched/ Unable to save as default",
                    this.shipmentOverviewPage.SaveAViewAsDefault(viewName));
        }
    }

    @And("^I click on rename icon of view$")
    public void i_click_on_rename_icon_of_view(DataTable dataTable) throws Throwable {
        Map<String, String> columnTable = dataTable.asMap(String.class, String.class);
        this.shipmentOverviewPage.ClickRenameViewIconToRename(columnTable);
    }

    @And("^I verify rename popup header$")
    public void i_verify_rename_popup_header(DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
            for (String expkey : messageTable.keySet()) {
                Assert.assertTrue("Popup Message not matched",
                        this.shipmentOverviewPage.ValidateMessageOnViewRenamePopup(expkey, messageTable.get(expkey)));
            }
        }

    }

    @And("^Verify unique name error message on model popup of view$")
    public void verify_rename_by_existing_viewname_to_validate_error_message(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        Assert.assertTrue("Unique Name Error Message Not Macthed",
                this.shipmentOverviewPage.ValidateMessageOnViewRenamePopup("UniqueNameErrorMessage",
                        messageTable.get("UniqueNameErrorMessage")));
    }

    @Then("^I click on \"([^\"]*)\" to create a view$")
    public void i_click_on_to_create_a_view(String button) throws Throwable {
        this.ScrollToTop();
        this.shipmentOverviewPage.ClickOnSaveThisView(button);
    }

    @And("^I verify save view popup$")
    public void i_verify_Save_confirmation_popup(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        for (String expkey : messageTable.keySet()) {
            Assert.assertTrue("Popup Message not matched",
                    this.shipmentOverviewPage.ValidateMessageOnViewRenamePopup(expkey, messageTable.get(expkey)));
        }
    }

    @And("^I click on \"([^\"]*)\" button of view model popup$")
    public void i_click_on_button_of_ConfirmationDialog(String button) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.ClickOnRenameOrSaveViewConfirmSaveCancel(button);
        }
    }

    @And("^I enter view name \"([^\"]*)\"$")
    public void i_enter_view_name(String viewName) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.EnterViewNameToCreateView(viewName);
        }
    }

    @And("^I click on close button success popup$")
    public void i_click_on_close_button_success_popup() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.thinkTimer(2000);
            this.shipmentOverviewPage.ClickOnCloseButtonOnViewSuccessPopup();
            this.commonHelpers.thinkTimer(300);
        }
    }

    @And("^I verify \"([^\"]*)\" renamed to \"([^\"]*)\"$")
    public void i_verify_renamed_to(String oldViewName, String newViewName) {
        Assert.assertTrue("SuccessMessage Mismatched",
                shipmentOverviewPage.RenameSuccessMessageValidation(oldViewName, newViewName));
    }

    @And("^I click on X button success popup$")
    public void i_click_on_x_button_success_popup() {
        this.shipmentOverviewPage.ClickOnXButtonOnViewSuccessPopup();
    }

    @And("^I verify \"([^\"]*)\" is \"([^\"]*)\" in my shipments page$")
    public void i_Verify_is_enabled(String saveThisView, String flag) {
        saveThisView = WordUtils.capitalizeFully(saveThisView);
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (flag.equalsIgnoreCase("enabled")) {
                Assert.assertTrue("Save this view Button Disabled",
                        this.shipmentOverviewPage.IsSaveThisViewEnabled(flag));
            } else if (flag.equalsIgnoreCase("disabled")) {
                Assert.assertTrue("Save this view Button Enabled",
                        this.shipmentOverviewPage.IsSaveThisViewEnabled(flag));
            }
        }
    }

    @When("^I verify \"([^\"]*)\" view is active$")
    public void i_verify_view_is_active(String view) throws Throwable {
        this.waitUntilNotVisible(loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(view + ": view is not active", this.shipmentOverviewPage.VerifyViewIsActive(view));
        }
    }

    @When("^I verify \"([^\"]*)\" view has the text default displayed after it$")
    public void i_verify_view_has_the_text_default_displayed_after_it(String view) throws Throwable {
        this.waitUntilNotVisible(loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(view + ": view does not have default text displayed after it",
                    this.shipmentOverviewPage.VerifyViewHasDefaultTextDisplayed(view));
        }
    }

    @When("^I verify views are in alphabetical order$")
    public void i_verify_views_are_in_alphabetical_order() throws Throwable {
        Assert.assertTrue("Views are not in alphabetical order", this.shipmentOverviewPage.VerifyViewsListIsSorted());
    }

    @Then("^I skip remaining steps if weather impacted shipment's \"([^\"]*)\" are zero in advisories page$")
    public void i_skip_remaing_steps_if_weather_impacted_shipment_s_are_zero_in_advisories_page(String chevron)
            throws Throwable {
        this.waitUntilNotVisible(loadingIndicator);
        if (advisoryPage.ValidateIfWeatherRiskShipmentCountIsZero(chevron)) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps,
                    advisoryPage.ValidateIfWeatherRiskShipmentCountIsZero(chevron));
        } else if (this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.removeKeyinContextStore(Constants.skipSteps);
        }
    }

    @Given("^I click on weather impacted shipment's \"([^\"]*)\" chevron in advisories page$")
    public void i_click_on_weather_impacted_shipment_s_chevron_in_advisories_page(String chevron) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            advisoryPage.clickWeatherImpactedShipmentChevron(chevron);
    }

    @Then("^I verify total count of shipments with weather risk$")
    public void i_verify_count_of_weather_shipments() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            advisoryPage.verifyAvgWeatherCount();
    }

    @Then("^I select the value \"([^\"]*)\" from \"([^\"]*)\" dropdown$")
    public void i_select_the_value_from_dropdown(String ValueToSelect, String ddName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.advisoryPage.SelectWeatherStatusdropdown(ValueToSelect, ddName);
        }
    }

    @Given("^I verify the grey \"([^\"]*)\" or \"([^\"]*)\" are displayed on map$")
    public void i_verify_the_grey_or_are_displayed_on_map(String clusters, String citypins) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(loadingIndicator);
            Assert.assertTrue("Validation of grey clusters or city pins is failed",
                    this.advisoryPage.ValidateGreyClusterorPins(clusters, citypins));
        }
    }

    @When("^I validate \"([^\"]*)\" dropdown is having active weather impacted statuses$")
    public void i_validate_dropdown_is_having_active_weather_impacted_statuses(String dropdownName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of dropdown labels is failed",
                    this.advisoryPage.ValidateDropDownvalues(dropdownName));
        }
    }

    @Then("^I verify the \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" columns in the shipment list grid$")
    public void i_verify_the_default_columns_in_the_shipment_list_grid(String shipment, String shipper,
                                                                       String recipient) throws Throwable {
        Assert.assertTrue("Columns are not matched",
                this.shipmentOverviewPage.VerifyColumnsInShipmentsGrid(shipment, shipper, recipient));
    }

    @Given("^I validate the columns of \"([^\"]*)\" with expected result$")
    public void i_validate_the_columns_of_with_expected_result(String section) throws Throwable {
        this.shipmentOverviewPage.ValidateColumnswithExpected(section);
    }

    @And("^I verify \"([^\"]*)\" view is in the top of the list$")
    public void i_verify_view_is_in_the_top_of_the_list(String view) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(view + ": view is not in the top of the list",
                    this.shipmentOverviewPage.verifyViewIsInTopOfTheList(view));
        }
    }

    @And("^I verify edit and delete icons are \"([^\"]*)\" for \"([^\"]*)\" view$")
    public void i_verify_edit_and_delete_icons_are_for_view(String flag, String view) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(
                    flag.equalsIgnoreCase("visible") ? "Edit and Delete icons are invisible for " + view
                            : "Edit and Delete icons are visible for " + view,
                    this.shipmentOverviewPage.verifyViewEditAndDeleteIcons(flag, view));
        }
    }

    @Then("^I verify the edit column checked state$")
    public void i_verify_the_edit_column_checked_state(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        for (String expkey : messageTable.keySet()) {
            Assert.assertTrue("Wrong checked state", this.shipmentOverviewPage.ValidateEditColumCheckedState(expkey,
                    Constants.EditColumnsCheckboxAttribute, messageTable.get(expkey)));
        }

    }

    @Then("^I verify given data for specified column in shipments list page$")
    public void I_verify_given_data_for_specified_column_in_shipments_list_page(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> columnTable = table.asMap(String.class, String.class);
            Assert.assertTrue("Column data verification is failed",
                    this.shipmentOverviewPage.verifyColumnData(columnTable));
        }
    }

    @Given("^I verify the column \"([^\"]*)\" contains \"([^\"]*)\" as hyperlink$")
    public void i_verify_the_column_contains_as_hyperlink(String colName, String ContextVariable) {
        Assert.assertTrue("Hyperlink validation for column is failed",
                this.shipmentOverviewPage.VerifyColumnDataasHyperlink(colName, ContextVariable));
    }

    @Then("^I verify prediction status \"([^\"]*)\" in details page$")
    public void i_verify_prediction_stauts_in_details_page(String status) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(status)) {
                status = WordUtils.capitalizeFully(status);
            }
            Assert.assertTrue("Prediction status mismatched",
                    this.shipmentDetails.verifyPredictionStatusInDetailsPage(status));
        }
    }

    @Then("^I Validate intervetion status with intervention reason \"([^\"]*)\"$")
    public void i_validate_intervention_status_with_intervention_reason(String interventionReason) throws Throwable {
        Assert.assertTrue("Intervention Reason not displayed",
                this.shipmentDetails.verifyInterventionReason(interventionReason));
    }

    @Then("^I verify \"([^\"]*)\" scan event column header in CE details page$")
    public void i_verify_scan_event_column_header_in_CE_details_page(String header) throws Throwable {
        Assert.assertTrue(header + " : Scan event header is not displayed",
                this.shipmentDetails.verifyscanEventColumnHeaderInDetailsPage(header));
    }

    @When("^I verify scan code event is displayed with \"([^\"]*)\" and is \"([^\"]*)\"$")
    public void i_Verify_Scan_Code_Event_Is_Displayed_With_And_Is(String keyToStore, String isClickable) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                Assert.assertTrue("Return scan code label is not correct",
                        shipmentDetails.validateReturnScanCodeLink(keyToStore, isClickable));
            }
        }
    }

    @Then("^I verify \"([^\"]*)\" in the shipment details page$")
    public void i_verify_in_the_shipment_details_page(String keyToStore) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Tracking number not shown in shipment details page",
                    this.shipmentDetails.validateTrackingNumberOnShipmentDetails(keyToStore));
        }
    }

    @When("^I click on the \"([^\"]*)\" button$")
    public void i_click_on_the_button(String buttonText) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentDetails.clickOnButton(buttonText);
        }
    }

    @Then("^I verify \"([^\"]*)\" is displayed with below options$")
    public void i_verify_is_displayed_with_below_options(String dropDown, DataTable dataTable) {
        Assert.assertTrue("Options are not displayed correctly",
                this.shipmentDetails.VerifyICalledOptions(dropDown, dataTable));
    }

    @Then("^I verify user cannot add more than \"([^\"]*)\" characters in \"([^\"]*)\" text area$")
    public void i_verify_user_cannot_add_more_than_characters_in_text_area(String maxLimit, String field) {
        Assert.assertEquals(this.shipmentDetails.getMaxLimitiOfTextArea(field), maxLimit);
    }

    @When("^I select \"([^\"]*)\" option from the \"([^\"]*)\" dropdown$")
    public void i_select_option_from_the_dropdown(String option, String dropDown) {
        this.shipmentDetails.selectValueFromDD(dropDown, option);
    }

    @When("^I select \"([^\"]*)\" option from the date \"([^\"]*)\" dropdown$")
    public void i_select_option_from_the_date_dropdown(String dateFormat, String inputType) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.preferencePage.selectDropDown(dateFormat, inputType);
            this.waitUntilNotVisible(this.loadingIndicator);
            if (dateFormat.contains(("DATE"))) {
                this.commonHelpers.AddToContextStore("preferredDateFormat", inputType.split(": ")[1]);
            }
            if (dateFormat.contains(("TIME"))) {
                this.commonHelpers.AddToContextStore("preferredTimeFormat", inputType.split(": ")[1]);
            }
        }
    }

    @When("^I select \"([^\"]*)\" option from the date \"([^\"]*)\" dropdown for localisation$")
    public void i_select_option_from_the_date_dropdown_localised(String originalStr, String localisedValue,
                                                                 String inputType) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.preferencePage.selectDropDown(localisedValue, inputType);
            this.waitUntilNotVisible(this.loadingIndicator);
            if (originalStr.contains(("DATE"))) {
                this.commonHelpers.AddToContextStore("preferredDateFormat", inputType.split(": ")[1]);
            }
            if (originalStr.contains(("TIME"))) {
                this.commonHelpers.AddToContextStore("preferredTimeFormat", inputType.split(": ")[1]);
            }
        }
    }

    @Then("^I verify below options are displayed in Comments sections$")
    public void i_verify_below_options_are_displayed_in_Comments_section(DataTable dataTable) {
        Assert.assertTrue("Option is not displayed", this.shipmentDetails.VerifyButtonsInCommentsSection(dataTable));
    }

    @Given("^I verify \"([^\"]*)\" is displayed with below fields$")
    public void i_verify_is_diplayed_with_below_fields(String section, DataTable dataTable) {
        Assert.assertTrue("Fields are not shown ", this.shipmentDetails.VerifyLogCallOptions(dataTable));
    }

    public void i_verify_below_columns_are_shown_the_shipment_list_grid(DataTable table) {
        Assert.assertTrue("Column is not visible on the shipment list grid",
                this.shipmentOverviewPage.VerifyColumnsVisibleOnShipmentListGrid(table));
    }

    @Given("^I validate the value for \"([^\"]*)\" is displayed as per API in \"([^\"]*)\"$")
    public void i_validate_the_value_for_is_displayed_as_per_API_in(String LabelinUI, String page) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Validation of " + LabelinUI + " in shipment details is failed ",
                    this.shipmentDetails.ValidateLabelValuesInShipmentDetails(LabelinUI, page));
        }
    }

    @Then("^I validate below fields in shipment details page$")
    public void i_validate_field_is_in_shipment_details_page(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something wrong with Label visibility in shipment details",
                    this.shipmentDetails.VerifyFieldVisibilityInShipmentDetails(table));
        }
    }

    @And("^I get \"([^\"]*)\" from shipmentdetails$")
    public void i_get_from_shipmentdetails(String columnName) throws Throwable {
        this.shipmentDetails.AddStatusDetailsToContextStore(columnName);
    }

    @And("^I compare \"([^\"]*)\" with shipmentlist$")
    public void i_compare_with_shipmentlist(String columnName) {
        String statusDetailsValue = this.shipmentOverviewPage.GetColumnValueFromShipmentsPage(columnName);
        String statusDetailsFromShipmentDetail = this.commonHelpers.getValuefromContextStore(columnName).toString();
        Assert.assertTrue("Status Detail value is not matched for shipment details and Shimentlist page",
                statusDetailsValue.equalsIgnoreCase(statusDetailsFromShipmentDetail));
    }

    // Columns visibility check in the grid
    @Then("^I verify below columns are shown on the shipment list grid$")
    public void i_verify_below_columns_are_shown_on_the_shipment_list_grid(DataTable table) {
        Assert.assertTrue("Column is not visible on the shipment list grid",
                this.shipmentOverviewPage.VerifyColumnsVisibleOnShipmentListGrid(table));
    }

    @Then("^I verify below columns are not shown on the shipment list grid$")
    public void i_verify_below_columns_are_not_shown_on_the_shipment_list_grid(DataTable table) {
        Assert.assertTrue("Column is visible on the shipment list grid when it should not be",
                this.shipmentOverviewPage.VerifyColumnsNotVisibleOnShipmentListGrid(table));
    }

    @Then("^I verify the map is displayed in the shipment details page with below options$")
    public void i_verify_the_map_is_displayed_in_the_shipment_details_page_with_below_options(DataTable table) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Options are not displayed on the map in shipment details",
                    this.shipmentDetails.ValidateShipmentJourneyMap(table));
        }
    }

    @Then("^I validate the updated time of shipment against the user preferences \"([^\"]*)\"$")
    public void i_validate_the_updated_time_of_shipment_against_the_user_preferences(String preferredDateFormat)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Updated time is not visible in shipment details",
                    this.shipmentDetails.ValidateUpdatedTime(preferredDateFormat));
    }

    @Then("^I validate the map refresh time in the shipment details$")
    public void i_validate_the_map_refresh_time_in_the_shipment_details() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Updated time is not visible in shipment details",
                    this.shipmentDetails.ValidateMapRefreshTime());
    }

    @Then("^I Validate column comment is having ellipsis$")
    public void i_verify_column_comment_is_having_ellipsis() {
        Assert.assertTrue("Column is not having elipsis", this.shipmentOverviewPage.VerifyElipsisForCommentColumn());
    }

    @Then("^I validate \"([^\"]*)\" link$")
    public void i_validate_link(String text) {

        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());

        String xpath = homePage.buildXpathForString(text);
        String actualText = this.findElement(By.xpath(xpath)).getAttribute("href").replace("%20", " ").replace(": ",
                ":");
        log.info(actualText);
        if (virtualizationFlag) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        } else {
            Assert.assertTrue(actualText.contains(Constants.ExternalLinks.get("Contact Us")));
        }
    }

    @And("^I validate highlighting of \"([^\"]*)\" link$")
    public void i_validate_highlighting_of_link(String link) {
        Assert.assertTrue("What's New highlight is not correct ", this.homePage.VerifyWhatsNewHighlight(link));
    }

    @And("^I verify delay prediction data is hidden on shipmentDetails$")
    public void i_verify_delay_prediction_is_hidden_on_shipmentdetails() {
        Assert.assertFalse(this.shipmentDetails.IsPredictionDataDisplayed());
    }

    @And("^I verify delay prediction data is not hidden on shipmentDetails$")
    public void i_verify_delay_prediction_is_not_hidden_on_shipmentdetails() {
        Assert.assertTrue(this.shipmentDetails.IsPredictionDataDisplayed());
    }

    @And("^I verify \"([^\"]*)\" checked state in shipment types and badge count as \"([^\"]*)\"$")
    public void i_verify_checked_state_in_shipment_types_and_badge_count_as(String shipmentType, String count) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Types")));
            Assert.assertTrue(shipmentType.equals(this.shipmentOverviewPage.getShipmentTypeCheckedState(shipmentType)));
            if (!count.equals("0")) {
                Assert.assertTrue(count.equals(this.shipmentOverviewPage.getShipmentTypeBadgeCount()));
            }
        }

    }

    @Then("^I verify \"([^\"]*)\" menu collapse link$")
    public void i_verify_menu_collapse_link(String menuOption) {
        Boolean flag = this
                .elementIsDisplayed(By.xpath(String.format(this.homePage.menuOptionCollapseLink, menuOption)));
        if (!flag) {
            this.homePage.verifySideMenuVisibility(menuOption);
        }
    }

    @Then("^I validate the Whats New pop up$")
    public void i_validate_the_Whats_New_pop_up() {
        Assert.assertTrue("What's New pop up visibility issue ", this.homePage.VerifyWhatsNewPopup());
    }

    @Then("^I verify \"([^\"]*)\" status dropdown should contains the options$")
    public void i_verify_shipment_status_dropdown_should_contains_the_options(String option, DataTable statuses) {
        if (option.equalsIgnoreCase("shipment")) {
            this.advisoryPage.JavaScriptClick(this.advisoryPage.shipmentStatusDropdown);
        } else if (option.equalsIgnoreCase("region")) {
            this.advisoryPage.JavaScriptClick(this.advisoryPage.regionStatusDropdown);
        }
        Assert.assertTrue(this.advisoryPage.ValidateDropdown(statuses));
        Assert.assertTrue(this.elementIsDisplayed(this.advisoryPage.clearButton));
    }

    @Then("^I verify \"([^\"]*)\" cards are shown along with shipment details$")
    public void i_verify_cards_and_shipment_details(String option) {
        int count = Integer.parseInt(option);
        // Validate atleast these many number of elements appear on this page
        Assertions.assertThat(this.findElements(By.xpath(this.advisoryPage.genericCityCard)).size())
                .isLessThanOrEqualTo(count)
                .isNotEqualTo(0);
        Assertions.assertThat(
                        this.findElements(By.xpath(String.format(this.advisoryPage.shipmentsNumber, "Shipments"))).size())
                .isLessThanOrEqualTo(count)
                .isNotEqualTo(0);
    }

    @Then("^I verify \"([^\"]*)\" list in \"([^\"]*)\" based on \"([^\"]*)\" flag$")
    public void i_verify_list_in_based_in_flag(String status, String module, String flag) {
        this.advisoryPage.ValidateStatusBasedOnFlag(status, flag);
    }

    @And("^I verify by selecting Region$")
    @Then("^I verify by selecting shipment statuses$")
    public void i_verify_by_selecting_shipment_statuses(DataTable dropDownOptions) {
        List<String> checkboxes = dropDownOptions.asList(String.class);
        for (String checkbox : checkboxes) {
            By statusCheckboxEle = By.xpath(String.format(this.advisoryPage.statusCheckbox, checkbox));
            this.JavaScriptClick(statusCheckboxEle);
        }
    }

    @Then("^I click on clear button on shipment status$")
    public void i_click_on_clear_button_on_shipment_status() {
        this.clickOnElement(this.advisoryPage.clearButton);
    }

    @And("^I verify checked state of region status$")
    @Then("^I verify checked state of shipment status$")
    public void i_verify_checked_state_of_shipment_status(DataTable shipmentStatuses) {
        Map<String, String> statusesCheckbox = shipmentStatuses.asMap(String.class, String.class);
        String actualState;
        for (String status : statusesCheckbox.keySet()) {
            log.info("Status: " + status);
            if (this.advisoryPage.getCheckedStateOfShipmentStatus(status).equals("true"))
                actualState = "checked";
            else
                actualState = "unchecked";
            Assert.assertEquals(actualState, statusesCheckbox.get(status));
        }
    }

    @And("^I verify \"([^\"]*)\" data from Advisory page to Shipment Details page$")
    public void iVerifyDataFromAdvisoryPageToShipmentDetailsPage(String option) {
        this.advisoryPage.ValidateDataFromAdvisoryToShipment(option);

    }

    @And("^I verify \"([^\"]*)\" data from Advisory page to Shipment Details page for left side statuses$")
    public void iVerifyDataFromAdvisoryPageToShipmentDetailsPageLeftPortion(String option) {
        this.advisoryPage.ValidateDataFromAdvisoryToShipmentLeftSide(option);
    }

    @Then("^I validate \"([^\"]*)\" is having the below values$")
    public void i_validate_is_having_the_below_values(String module, DataTable table) {
        Assert.assertTrue("Validation of Action bar is failed",
                this.shipmentOverviewPage.ValidateModulesinBar(module, table));
    }

    @Given("^I verify \"([^\"]*)\" are displayed for below modules$")
    public void i_verify_are_displayed_for_below_modules(String elementType, DataTable table) {
        Assert.assertTrue("Validation of Chevron is failed",
                this.shipmentOverviewPage.ValidateWebElement(elementType, table));
    }

    @Then("^I validate \"([^\"]*)\" chevron is \"([^\"]*)\" on my shipments$")
    public void i_validate_chevron_is_on_my_shipments(String module, String state) {
        Assert.assertTrue("Validation of Active Chevron is failed with module",
                this.shipmentOverviewPage.ChevronState(module, state));
    }

    @Given("^I store QC cards with titles in contextStore as \"([^\"]*)\" from \"([^\"]*)\"$")
    public void i_store_QC_cards_with_titles_in_contextStore_as_from(String contextStoreKey, String page) {
        if (page.equalsIgnoreCase("my shipments")) {
            this.shipmentOverviewPage.StoreQuickViewsinContextStore(contextStoreKey);
        } else if (page.equalsIgnoreCase("manage cards")) {
            this.manageQCPage.StoreQuickViewsinContextStore(contextStoreKey);
        }
    }

    @When("^I select sorted minimum quick view from my shipments$")
    public void i_select_quick_views_myShipments() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentOverviewPage.SelectShipmentQuickView();
    }

    @Then("^I verify \"([^\"]*)\" download filename having prefix as \"([^\"]*)\" and file format as \"([^\"]*)\"$")
    public void i_verify_download_filename(String preOrPostDownloadInfo, String prefixText, String fileFormat) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.thinkTimer(30000);
        if (prefixText.contains("ContextStore")) {
            prefixText = this.commonHelpers.getValuefromContextStore(prefixText) + "_"
                    + Constants.fileNameForShipment;
        }
        this.shipmentOverviewPage.VerifyFileNameInFileDownloadDialogue(preOrPostDownloadInfo, prefixText, fileFormat);
    }

    @When("^I enter file name and verify file format as \"([^\"]*)\"$")
    public void i_enter_text_into_textbox(String fileFormat) {
        this.waitUntilNotVisible(this.loadingIndicator);
        String filename = RandomStringUtils.randomAlphabetic(4);
        this.shipmentOverviewPage.enterDownloadFileName(filename, fileFormat);
    }

    @When("^I save file name to be downloaded$")
    public void i_save_fileName_to_be_Downloaded() {
        By fileName = By.xpath("//div[@class='file-detailsSP__nameTxt']");
        this.commonHelpers.AddToContextStore("dfileName", this.findElement(fileName).getText());
        System.out.println("File name is " + this.commonHelpers.getValuefromContextStore("dfileName"));

    }

    @When("I save file name to be downloaded with index {string}")
    public void i_save_fileName_to_be_Downloaded_withIndex(String index) {
        By fileName = By.xpath("//div[@class='file-detailsSP__nameTxt']");
        this.commonHelpers.AddToContextStore("dfileName", this.findElements(fileName).get(Integer.parseInt(index)).getText());
        System.out.println("File name is " + this.commonHelpers.getValuefromContextStore("dfileName"));

    }

    @And("^I enter text as \"([^\"]*)\" in textbox \"([^\"]*)\" in page \"([^\"]*)\"$")
    public void i_enter_text_in_textbox_in_this_page(String textToEnter, String textBoxByElement, String pageName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (pageName.equalsIgnoreCase("shipmentOverviewPage"))
            this.shipmentOverviewPage.setTextInFileDownloadTextBox(textBoxByElement, textToEnter);
        else if (pageName.equalsIgnoreCase("shipmentDetails")) {
            textToEnter = textToEnter + this.commonHelpers.generateRandomString(5);
            this.shipmentDetails.setTextInPersonalNoteTextbox(textToEnter);
            this.commonHelpers.AddToContextStore("personalNotesMessage", textToEnter);
        }
    }

    @Then("^I validate message \"([^\"]*)\" is displayed for \"([^\"]*)\" in page \"([^\"]*)\"$")
    public void i_validate_message_displayed_in_this_page(String messageText, String messageElement, String pageName) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (pageName.equalsIgnoreCase("shipmentOverviewPage"))
            this.shipmentOverviewPage.verifyMessageOnFileDownloadScreen(messageElement, messageText);
    }

    @When("^I do not enter file name and verify file format as \"([^\"]*)\"$")
    public void i_do_not_enter_text_into_textbox(String fileFormat) {
        this.waitUntilNotVisible(this.loadingIndicator);
        String filename = "";
        this.shipmentOverviewPage.enterDownloadFileName(filename, fileFormat);
    }

    @Then("^I verify given file name in download page$")
    public void verify_flename_in_download_page() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.commonHelpers.thinkTimer(30000);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        Assert.assertTrue("The file is not added to download page",
                this.shipmentOverviewPage.verifyDownloadFileName(dfilename));
    }

    @Then("^I verify available reports count with popup available count$")
    public void verify_avail_count_in_download_page() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        String popupAvlCount = this.commonHelpers.getValuefromContextStore("popupAvailableCount").toString();
        Assert.assertTrue("The displayed count is not matched",
                this.shipmentOverviewPage.verifyAvailCount(popupAvlCount, dfilename));
    }

    @Then("^I verify the timestamp and its format in the report date column in download page$")
    public void I_verify_the_timestamp_and_its_format_in_the_report_date_column_in_download_page() {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        Assert.assertTrue("Report date column value is not as expected",
                this.shipmentOverviewPage.verifyReportDateColumnValue(dfilename));
    }

    @Then("^I store the current local time$")
    public void I_store_the_current_local_time() {
        this.shipmentOverviewPage.getCurrentLocalTime();
    }

    @Then("^I delete downloaded file from download page$")
    public void delete_file_download_page() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        this.shipmentOverviewPage.deleteFileFromPage(dfilename);
    }

    @Then("^I click on \"([^\"]*)\" icon on download page$")
    public void I_click_on_icon_on_download_page(String icon) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        this.shipmentOverviewPage.clickOnIconOnDownloadPage(icon, dfilename);
    }

    @Then("^I click on \"([^\"]*)\" button of delete confirmation pop up on download page$")
    public void I_click_on_button_of_delete_confirmation_pop_up_on_download_page(String button) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentOverviewPage.clickOnCancelOrDeleteElementofDeletePopUpInDownloadCenter(button);
    }

    @And("^I verify the delete confirmation pop up message for file on download page$")
    public void I_verify_the_delete_confirmation_pop_up_message_for_file_on_download_page() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        Assert.assertTrue("Delete confirmation pop up message is incorrect",
                this.shipmentOverviewPage.verifyDeleteConfirmationPopUpMessageDC(dfilename));
    }

    @Then("^I validate the check boxes present in \"([^\"]*)\" for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_validate_the_check_boxes_present_in_for_and(String page, String checkBox1, String checkBox2) {
        Assert.assertTrue("Validation of checkboxes in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateCheckBoxes(checkBox1, checkBox2));
    }

    @Then("^I validate the check boxes present in \"([^\"]*)\" for \"([^\"]*)\" and \"([^\"]*)\" for localization$")
    public void i_validate_the_check_boxes_present_in_for_localization(String page, String checkBox1,
                                                                       String checkBox2) {
        Assert.assertTrue("Validation of checkboxes in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateCheckBoxesForLocalization(checkBox1, checkBox2));
    }

    @Then("^I validate the static content present in the \"([^\"]*)\"$")
    public void i_validate_the_static_content_present_in_the(String page) throws Throwable {
        Assert.assertTrue("Validation of static content in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateStaticContent());
    }

    @Then("^I validate the static content present in the \"([^\"]*)\" for localization$")
    public void i_validate_the_static_content_present_in_the_localization(String page) throws Throwable {
        Assert.assertTrue("Validation of static content in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateStaticContentForLocalization());
    }

    @Then("^I validate below links are present in the \"([^\"]*)\"$")
    public void i_validate_below_links_are_present_in_the(String page, DataTable links) {
        List<String> availablelinks = links.asList(String.class);
        Assert.assertTrue("validation of links in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateLinksinManageQC(availablelinks));
    }

    @Then("^I validate below links are present in the \"([^\"]*)\" for localization$")
    public void i_validate_below_links_are_present_in_the_localization(String page, DataTable links) {
        List<String> availablelinks = links.asList(String.class);
        availablelinks = this.genericFunObj.getLocalizedValue(availablelinks);
        Assert.assertTrue("validation of links in Manage Quick view cards page is failed",
                this.manageQCPage.ValidateLinksinManageQC(availablelinks));
    }

    @Then("^I select \"([^\"]*)\" check box in \"([^\"]*)\"$")
    public void i_select_check_box_in(String cbName, String page) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.manageQCPage.ClickCheckBox(cbName);
        }
    }

    @Then("^I select \"([^\"]*)\" check box in \"([^\"]*)\" for localization$")
    public void i_select_check_box_in_localization(String cbName, String page) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            cbName = this.genericFunObj.getLocalizedValue(cbName);
            this.manageQCPage.ClickCheckBox(cbName);
        }
    }

    @Then("^I verify \"([^\"]*)\" check box is displayed in \"([^\"]*)\"$")
    public void i_verify_check_box_displayed(String cbName, String page) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        boolean check = this.manageQCPage.verifyCheckBoxDisplayed(cbName);
        Assert.assertTrue("The " + cbName + " Check box is not displayed", check);
    }

    @Then("^I verify \"([^\"]*)\" check box is not displayed in \"([^\"]*)\"$")
    public void i_check_box_is_not_isplayed(String cbName, String page) throws Throwable {
        boolean check = this.manageQCPage.verifyCheckBoxDisplayed(cbName);
        Assertions.assertThat(check)
                .withFailMessage("The " + cbName + " Check box is displayed")
                .isFalse();
    }

    @Given("^I verify cards displayed in page are \"([^\"]*)\" with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_verify_cards_displayed_in_page_are_with_and(String operation, String ContextStoreVariable1,
                                                              String ContextStoreVariable2) throws Throwable {
        Assert.assertTrue("Validation of placement of cards in My shipments and Manage cards is failed: ",
                this.manageQCPage.ValidateCardCountandPlacement(operation, ContextStoreVariable1,
                        ContextStoreVariable2));
    }

    @Then("^I click on shipment status dropdown$")
    public void i_click_on_shipment_status_dropdown() throws Throwable {
        this.advisoryPage.JavaScriptClick(this.advisoryPage.shipmentStatusDropdown);
    }

    @Then("^I click on region status dropdown$")
    public void i_click_on_region_status_dropdown() throws Throwable {
        this.advisoryPage.JavaScriptClick(this.advisoryPage.regionStatusDropdown);
    }

    @Then("^I select city pin$")
    public void i_select_city_pin() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (this.commonHelpers.verifyKeyInContextStore("Shipment Count")) {
                if (Integer.parseInt(this.commonHelpers.getValuefromContextStore("Shipment Count").toString()) > 1) {
                    while (this.elementIsNotDisplayed(this.advisoryPage.cityPin)) {
                        this.JavaScriptClick(this.advisoryPage.clusterPin);
                        // this.clickOnElement(this.advisoryPage.clusterPin);
                    }
                    this.JavaScriptClick(this.advisoryPage.cityPin);
                }
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }

    }

    @Then("^I click on \"([^\"]*)\" link on flyout$")
    public void i_click_on_link_on_flyout(String shipmentLink) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage
                    .clickOnElement(By.xpath(String.format(this.advisoryPage.flyOutShipmentLinks, shipmentLink)));
        }
    }

    @Then("^I get cityname from flyout \"([^\"]*)\"$")
    public void i_get_cityname_from_flyout(String companyName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.AddToContextStore(companyName, this.getText(this.advisoryPage.cityNameOnFlyout));
        }
    }

    @Then("^I get \"([^\"]*)\" count from flyout$")
    public void i_get_count_from_flyout(String shipmentLink) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.AddToContextStore("Shipment Count",
                    this.getText(By.xpath(String.format(this.advisoryPage.flyOutShipmentLinks, shipmentLink))));
        }
    }

    @And("^I validate the viewing count for \"([^\"]*)\" in Shipment list with Advisory Page$")
    public void i_validate_the_viewing_count_for_in_Shipment_list_with_advisory_page(String cardName) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (!Constants.QuickViewCardNames.contains(cardName)) {
                cardName = WordUtils.capitalizeFully(cardName);
            }
            if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
                this.waitUntilNotVisible(this.loadingIndicator);
                Boolean flag = false;
                if (cardName.equalsIgnoreCase("Shipment Count")) {
                    flag = this.commonHelpers.AssertCountswithCorrection(
                            Integer.parseInt(this.commonHelpers.getValuefromContextStore(cardName).toString()),
                            Integer.parseInt(this.shipmentOverviewPage.getViewingCount()));
                }
                Assert.assertTrue(String.format(
                        "Count of records for caredName: %s and Advisory page count with correction factor is not matched",
                        cardName), flag);
            }
        }
    }

    @Then("^I get \"([^\"]*)\" count for country in list view$")
    public void i_get_count_for_country_in_list_view(String shipmentLink) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (this.elementIsDisplayed(
                    By.xpath(String.format(this.advisoryPage.cityShimentlinkTxtInListView, shipmentLink))))
                this.commonHelpers.AddToContextStore("Shipment Count", this.getText(
                        By.xpath(String.format(this.advisoryPage.cityShimentlinkTxtInListView, shipmentLink))));
        }
    }

    @Then("^I click on \"([^\"]*)\" link of a country in list view$")
    public void i_click_on_link_of_a_country_in_list_view(String shipmentLink) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (this.commonHelpers.verifyKeyInContextStore("Shipment Count"))
                if (Integer.parseInt(this.commonHelpers.getValuefromContextStore("Shipment Count").toString()) > 1)
                    this.clickOnElement(
                            By.xpath(String.format(this.advisoryPage.cityShipmentlinksInListView, shipmentLink)));
                else {
                    this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                }
            else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }

    @Then("^I get cityname from list view \"([^\"]*)\"$")
    public void i_get_cityname_from_list_view(String companyName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (this.elementIsDisplayed(this.advisoryPage.cityNameInListView))
                this.commonHelpers.AddToContextStore(companyName, this.getText(this.advisoryPage.cityNameInListView));
        }
    }

    @Then("^I verify header of \"([^\"]*)\" not equal to \"([^\"]*)\"$")
    public void i_verify_header_of_not_equal_to(String subMenu, String headerText) throws Throwable {
        String actualHeaderText = null;
        switch (subMenu) {
            case "Subscribed Accounts":
                actualHeaderText = this.preferencePage.getPreferencePagesHeader("sr-accounts");
                break;
            case "Settings":
                actualHeaderText = this.preferencePage.getPreferencePagesHeader("sr-settings");
                break;
            case "Preferred Locations":
                actualHeaderText = this.preferencePage.getPreferencePagesHeader("preferred-locations");
                break;
        }
        Assert.assertEquals(!headerText.equals(actualHeaderText), subMenu.equals(actualHeaderText));
    }

    @Then("^I verify \"([^\"]*)\" quick view card is \"([^\"]*)\"$")
    public void i_verify_is_quick_view_card_is(String cardName, String flag) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(loadingIndicator);
            if (flag.equalsIgnoreCase("active"))
                Assert.assertTrue(cardName + ": Quick View card is not hilighted",
                        this.shipmentOverviewPage.ValidateWhetherQuickViewCardISHighlighted(cardName));
            else if (flag.equalsIgnoreCase("inactive"))
                Assert.assertFalse(cardName + ": Quick View card is hilighted",
                        this.shipmentOverviewPage.ValidateWhetherQuickViewCardISHighlighted(cardName));
        }
    }

    @When("^I remove \"([^\"]*)\" quick view cards from manage cards$")
    public void i_remove_quick_view_cards_from_manage_cards(String type, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.manageQCPage.RemoveQCInManageCards(type, table);
        }
    }

    @When("^I select below quick view cards from manage cards$")
    public void i_select_below_quick_view_card_s_from_manage_cards(DataTable table) {
        List<String> cards = table.asList(String.class);
        this.manageQCPage.SelectQCInManageCards(cards);

    }

    @When("^I select below quick view cards from manage cards in ui$")
    public void i_select_below_quick_view_card_s_from_manage_cards_ui(DataTable table) {
        List<String> cards = table.asList(String.class);
        this.manageQCPage.SelectQCInManageCardsUI(cards);
    }

    @When("^I select below quick view cards from manage cards for localization$")
    public void i_select_below_quick_view_card_s_from_manage_cards_localization(DataTable table) {
        List<String> cards = table.asList(String.class);
        cards = this.genericFunObj.getLocalizedValue(cards);
        this.manageQCPage.SelectQCInManageCards(cards);
    }

    @Then("^I verify the \"([^\"]*)\" column is \"([^\"]*)\" side to the \"([^\"]*)\" column$")
    public void i_verify_the_column_is_side_to_the_column(String column1, String position, String column2)
            throws Throwable {
        Assert.assertTrue(
                String.format("Column position validation for %s is not %s of the %s", column2, position, column1),
                this.shipmentOverviewPage.ValidateColumnPositionwithAnother(column1, position, column2));
    }

    @Given("^I validate \"([^\"]*)\" column is \"([^\"]*)\" on hover of the column header$")
    public void i_validate_column_is_on_hover_of_the_column_header(String columnName, String state) throws Throwable {
        Assert.assertTrue(String.format("Column: %s is not highlighted when user moved to the header", columnName),
                this.shipmentOverviewPage.ValidateColumnHoverState(columnName, state));
    }

    @Given("^I select the row with \"([^\"]*)\" and validate row is highlighted$")
    public void i_select_the_row_with_and_validate_row_is_highlighted(String contextStoreVariable) throws Throwable {
        String variable = this.commonHelpers.getValuefromContextStore(contextStoreVariable).toString();
        Assert.assertTrue("Validation of row highlight on selection is failed",
                this.shipmentOverviewPage.ValidateRowHighlightOnSelect(variable));
    }

    @Given("^I double click on row to navigate to details of Shipment for \"([^\"]*)\"$")
    public void i_double_click_on_row_to_navigate_to_details_of_Shipment_for(String ContextStoreVariable)
            throws Throwable {
        String variable = this.commonHelpers.getValuefromContextStore(ContextStoreVariable).toString();
        this.shipmentOverviewPage.DoubleClickRowForDetails(variable);
    }

    @Given("^I move the column \"([^\"]*)\" to \"([^\"]*)\"$")
    public void i_move_the_column_to(String FromElement, String ToElement) throws Throwable {
        this.shipmentOverviewPage.UIDragAndDrop(FromElement, ToElement);
    }

    @Given("^I validate position of the column \"([^\"]*)\" is persisted with \"([^\"]*)\"$")
    public void i_validate_position_of_the_column_is_persisted_with(String ColumnName, String ContextStoreVariable)
            throws Throwable {
        Assert.assertTrue("Validation of column position with pages navigationis failed",
                this.shipmentOverviewPage.ValidateColumnPosition(ColumnName, ContextStoreVariable));
    }

    @Then("^I verify below columns are shown on the shipment list$")
    public void iVerifyBelowColumnsAreShownOnTheShipmentList(DataTable table) throws Throwable {
        List<String> expectedColumns = table.asList(String.class);
        Boolean A = this.shipmentOverviewPage.elementIsDisplayed(
                By.xpath(String.format(this.shipmentOverviewPage.getShipmentListColumn(), expectedColumns.get(0))));
        Boolean B = this.shipmentOverviewPage.elementIsDisplayed(
                By.xpath(String.format(this.shipmentOverviewPage.getShipmentListColumn(), expectedColumns.get(1))));
        Assert.assertTrue("All expected columns are there in Shipment List", A && B);
    }

    @Then("^I validate \"([^\"]*)\" and \"([^\"]*)\" are removed from Edit Columns$")
    public void iValidateAndAreRemovedFromEditColumns(String columnName1, String columnName2) throws Throwable {
        Boolean colIsNotDisplayed1 = false, colIsNotDisplayed2 = false;
        String column1 = String.format(this.shipmentOverviewPage.getShipmentEditColumn(), columnName1);
        String column2 = String.format(this.shipmentOverviewPage.getShipmentEditColumn(), columnName2);
        if (!columnName1.equals("") && (this.findElement(By.xpath(String.format(this.shipmentOverviewPage.columnCheckBoxState, columnName1)))) != null)
            this.ScrollIntoView(this
                    .findElement(By.xpath(String.format(this.shipmentOverviewPage.columnCheckBoxState, columnName1))));
        colIsNotDisplayed1 = this.elementIsNotDisplayed(By.xpath(column1));
        if (!columnName2.equals("") && (this.findElement(By.xpath(String.format(this.shipmentOverviewPage.columnCheckBoxState, columnName2)))) != null)
            this.ScrollIntoView(this
                    .findElement(By.xpath(String.format(this.shipmentOverviewPage.columnCheckBoxState, columnName2))));
        colIsNotDisplayed2 = this.elementIsNotDisplayed(By.xpath(column2));
        Assertions.assertThat(colIsNotDisplayed1 && colIsNotDisplayed2)
                .withFailMessage("Columns are displayed in columns tab")
                .isTrue();
    }

    @Then("^I verify below columns are not shown on the shipment list$")
    public void iVerifyBelowColumnsAreNotShownOnTheShipmentList(DataTable table) throws Throwable {
        List<String> headerInExcel = this.genericFunObj.readCSVHeader();
        List<String> expectedColumns = table.asList(String.class);
        Assert.assertTrue("All expected columns are there in Shipment List",
                !this.checkForExpectedColumnsInShipmentList(headerInExcel, expectedColumns));
    }

    private boolean checkForExpectedColumnsInShipmentList(List<String> columnInGrid, List<String> expectedColumns) {
        Boolean allExcptedColumnsArePresentInShipmentList = true;
        for (String column : expectedColumns) {
            if (!columnInGrid.contains(expectedColumns)) {
                allExcptedColumnsArePresentInShipmentList = false;
                break;
            }
        }
        return allExcptedColumnsArePresentInShipmentList;
    }

    @Then("^I verify below filters are present in FILTERS$")
    public void iVerifyBelowFiltersArePresentInFILTERS(DataTable table) {
        Boolean allShipmentStatusFiltersPresent = true;
        List<String> expectedShipmentStatusFilters = table.asList(String.class);
        for (String filter : expectedShipmentStatusFilters) {
            if (!this.shipmentOverviewPage.verifyIfShipmentStatusFilterIsPresentOrNot(filter)) {
                allShipmentStatusFiltersPresent = false;
                break;
            }
        }
        Assert.assertTrue("All shipment status filters are present ", allShipmentStatusFiltersPresent);
    }

    @Then("^I verify below filter are not present in FILTERS$")
    public void iVerifyBelowFilterAreNotPresentInFILTERS(DataTable table) {
        Boolean allShipmentStatusFiltersPresent = true;
        List<String> expectedShipmentStatusFilters = table.asList(String.class);
        for (String filter : expectedShipmentStatusFilters) {
            if (!this.shipmentOverviewPage.verifyIfShipmentStatusFilterIsPresentOrNot(filter)) {
                allShipmentStatusFiltersPresent = false;
                break;
            }
        }
        Assert.assertTrue("All shipment status filters are not present ", !allShipmentStatusFiltersPresent);
        if (this.elementIsDisplayed(this.shipmentOverviewPage.filterChevron)) {
            this.JavaScriptClick(this.findElement(this.shipmentOverviewPage.filterChevron));
        }
    }

    @Then("^I verify below types are not present in shipment types$")
    public void iVerifyBelowTypeAreNotPresentInFILTERS(DataTable table) {
        this.waitUntilNotVisible(this.loadingIndicator);
        Boolean typesPresent;
        List<String> expectedShipmentTypes = table.asList(String.class);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            for (String types : expectedShipmentTypes) {
                typesPresent = this.shipmentOverviewPage.verifyIfShipmentTypesIsPresentOrNot(types);
                Assert.assertTrue("Validation of non availability of filter is failed", !typesPresent);
            }
        }
    }

    @Then("^I verify below types are present in shipment types$")
    public void iVerifyBelowTypeArePresentInFILTERS(DataTable table) {
        this.waitUntilNotVisible(this.loadingIndicator);
        Boolean typesPresent;
        List<String> expectedShipmentTypes = table.asList(String.class);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            for (String types : expectedShipmentTypes) {
                typesPresent = this.shipmentOverviewPage.verifyIfShipmentTypesIsPresentOrNot(types);
                Assert.assertTrue("Validation of non availability of filter is failed", typesPresent);
            }
        }
    }

    @When("^I move the quick view card \"([^\"]*)\" to \"([^\"]*)\"$")
    public void i_move_the_quick_view_card_to(String source, String destination) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        this.manageQCPage.DragAndDropQCCard(source, destination);
    }


    @And("^I verify Reset popup header$")
    public void i_verify_reset_popup_header(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        for (String expkey : messageTable.keySet()) {
            Assert.assertTrue("Popup Message not matched",
                    this.shipmentOverviewPage.ValidateMessageOnResetPopup(expkey, messageTable.get(expkey)));
        }
    }

    @And("^I verify the order of the columns$")
    public void i_verify_the_order_of_the_columns(DataTable dataTable) throws Throwable {
        Assert.assertTrue("Shipment list header order not matched",
                this.shipmentOverviewPage.ValidateOrderOfShipmentListHeader(dataTable));
    }

    @Then("^I verify \"([^\"]*)\" should be comma seperated$")
    public void i_verify_should_be_comma_seperated(String shipmentCount) throws Throwable {
        Assert.assertTrue("Shipment count is not comma seperated",
                this.shipmentOverviewPage.ValidateShipmentCountIsCommaSeperated(shipmentCount));
    }

    @Then("^I verify for opened new tab \"([^\"]*)\"$")
    public void iVerifyForOpenedNewTab(String Contact_Page) throws Throwable {
        List<String> list = this.shipmentDetails.GetWindowHandles();
        Assert.assertTrue("The New tab is not opened or not matching", loginPage.RedirectURL(Contact_Page));
    }

    @And("^I store the \"([^\"]*)\" column position index$")
    public void i_store_column_position_index(String column) throws Throwable {
        this.shipmentOverviewPage.StoreColumnPositionIndex(column);
    }

    @Then("I verify \"([^\"]*)\" menu is \"([^\"]*)\"")
    public void I_Verify_SubMenu_Collapse(String menuOption, String menuState) throws Throwable {
        Boolean flag = this
                .elementIsDisplayed(By.xpath(String.format(this.homePage.menuOptionCollapseLink, menuOption)));
        if (menuState.equalsIgnoreCase("Collapsed")) {
            Assert.assertTrue("Menu is collapsed ", flag);
        } else {
            Assert.assertFalse("Menu is collapsed ", flag);
        }
    }

    @Then("^I verify below columns in the Case section of shipment details page$")
    public void i_verify_in_the_views_list(DataTable table) throws Throwable {
        Map<String, String> columnTable = table.asMap(String.class, String.class);
        Assert.assertTrue("Something went wrong", this.shipmentDetails.verifyCERHeaders(columnTable));
    }

    @Then("^I verify \"([^\"]*)\" icon is \"([^\"]*)\" in my shipments page$")
    public void i_verify_icon_is_in_my_shipments_page(String icon, String check) throws Throwable {
        Assert.assertTrue(icon + ": Icon is not matched with shipments records",
                this.shipmentOverviewPage.verifyShipmentsIcon(icon, check));
    }

    @Then("^I verify the \"([^\"]*)\" half of the column order in \"([^\"]*)\" tab in shipments details page$")
    public void i_verify_the_half_of_the_column_order_in_tab_in_shipments_details_page(String order, String tab,
                                                                                       DataTable table) {
        Assert.assertTrue("Column position is not correct ",
                this.shipmentDetails.VerifyColumnPosition(order, tab, table));
    }

    @Then("^I remove the specfic filter status one by one inside bubble using close icon$")
    public void i_remove_the_below_the_filter_status_oneByOne_inside_bubble(DataTable filters) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentOverviewPage.RemoveSpecificOneFilterinBubble(filters);
    }

    @Then("^I select the filter \"([^\"]*)\" and verify filter conditions$")
    public void iSelectTheFilterAndVerifyFilterConditions(String filterCondition, DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong in selection filter from UI",
                    this.shipmentOverviewPage.SelectFilterAndVerifyConditionOnUI(filterCondition, table));
        }
    }

    @And("^I click on \"([^\"]*)\" button on filter$")
    public void iClickOnButtonOnFilter(String cancelOrApply) throws Throwable {
        this.shipmentOverviewPage.ClickOnButtonApplyOrCancel(cancelOrApply);
    }

    @And("^I click on filter button$")
    public void iClickOnFilterButton() {
        this.shipmentOverviewPage.ClickOnFilterButton();
    }

    @Then("^I verify \"([^\"]*)\" column is visible in FedEx Accounts$")
    public void i_verify_column_is_shown(String ColumnValue) throws Throwable {
        Assert.assertTrue(ColumnValue + " Column Value is not shown", homePage.verifyColumnValue(ColumnValue));
    }

    @Then("^I verify \"([^\"]*)\" column is not visible in FedEx Accounts$")
    public void i_verify_column_is_not_shown(String ColumnValue) throws Throwable {
        Assert.assertFalse(ColumnValue + " Column Value is shown", homePage.verifyColumnValue(ColumnValue));
    }

    @Then("^I verify below columns are displayed in FedEx Accounts page$")
    public void i_verify_below_columns_are_displayed_in_FedEx_Accounts_page(DataTable columnTable) throws Throwable {
        Assert.assertTrue(" Column is not displayed", homePage.verifyColumnsAreDisplayed(columnTable));
    }

    @Then("^I verify \"([^\"]*)\" icon is \"([^\"]*)\" in my shipments details page$")
    public void i_verify_icon_is_in_my_shipments_details_page(String icon, String check) throws Throwable {
        Assert.assertTrue(icon + ": Icon is not matched ",
                this.shipmentDetails.VerifyPayerIconInDetailsPage(icon, check));
    }

    @Then("^I validate the selected \"([^\"]*)\" shipment is highlighted$")
    public void i_validate_selected_row_is_highlighted(String contextStoreVariable) throws Throwable {
        String variable = this.commonHelpers.getValuefromContextStore(contextStoreVariable).toString();
        Assert.assertTrue("Validation of row highlight on selection is failed",
                this.shipmentOverviewPage.ValidateSelectedRowHighlighted(variable));
    }

    @And("^I compare the \"([^\"]*)\" value as \"([^\"]*)\" with shipmentdetails$")
    public void i_Compare_The_Value_As_With_Shipmentdetails(String column, String lastComment) throws Throwable {
        String lastCommentInShipmentDetailsPage = this.shipmentDetails.GetShipmentComment(lastComment);
        String lastCommntFromShipmentpage = this.shipmentDetails.GetLastCommentValueFromShipmentsPage().replace(",", "")
                .trim();
        boolean assertDateValue = lastCommntFromShipmentpage.equals(lastCommentInShipmentDetailsPage);
        Assert.assertTrue("Last Comment missmatched", assertDateValue);
    }

    @And("^I click on Accounts dropdown$")
    public void i_click_on_accounts_dropdown() {
        this.shipmentOverviewPage.clickAccountDropdown();
    }

    @Then("^I select following company with accounts from drop down and validate Accounts dropdown text$")
    public void i_select_multiple_accounts(DataTable table) throws Exception {
        this.shipmentOverviewPage.SelectMultipleCompanyAccountDD(table);
    }

    @Then("^I unselect following company with accounts from drop down and validate Accounts dropdown text$")
    public void i_unselect_multiple_accounts(DataTable table) throws Exception {
        this.shipmentOverviewPage.unSelectMultipleCompanyAccountDD(table);
    }

    @And("^Validate company and account in preferences$")
    public void validate_company_and_account_in_preferences(DataTable table) {
        Map<String, String> dataFilters = table.asMap(String.class, String.class);
        for (String key : dataFilters.keySet()) {
            if (!dataFilters.get(key).isEmpty()) {
                if (this.preferencePage.isPlusIconPresentPreferences(key)) {
                    this.preferencePage.clickPreferencePlusIcon(key);
                }

                String[] accountIds = dataFilters.get(key).trim().split(",");
                for (String accountId : accountIds) {
                    Assert.assertTrue(this.preferencePage.validateAccountPreference(accountId));
                }
            } else
                Assert.assertTrue(this.preferencePage.validateCompanyPreference(key));
        }
    }

    @And("^clear all company from company dropdown and validate message,sorting and other options on the dropdown$")
    public void clear_all_company_validate_message() {
        this.shipmentOverviewPage.ClearCompanyDDAndValidate();
    }

    @Then("^I verify left side menu icons and its active State$")
    public void i_verify_left_side_menu_icons_and_its_active_State(DataTable table) throws Throwable {
        Assert.assertTrue("Left menu icon validation failed: ", this.homePage.verifySideMenuIconsAndActiveState(table));
    }

    @And("^I search \"([^\"]*)\" company in accounts drop down$")
    public void iSearchCompanyInAccountsDropDown(String companyName) throws Throwable {
        this.shipmentOverviewPage.searchCompanyAccount(companyName);
    }

    @And("^I validate company search results$")
    public void iValidateCompanySearchResults(DataTable table) {
        this.shipmentOverviewPage.validateCompanySearchResult(table);

    }

    @And("^I validate there is no company filtered in company dropdown$")
    public void iValidateThereIsNoCompanyFilteredInCompanyDropdown() {
        Assert.assertFalse("Company Search filter result is not empty",
                this.shipmentOverviewPage.validateCompanyEmptySearchResult());
    }

    @Then("^I verify filter bubble of accounts dropdown as \"([^\"]*)\"$")
    public void iVerifyFilterBubbleOfAccountsDropdownAs(String accountFilterText) throws Throwable {
        Assertions.assertThat(this.shipmentOverviewPage.getCompanyDropdownText())
                .isEqualTo(accountFilterText);
    }

    @Then("^I verify the account is selected in account dropdown$")
    public void iVerifyTheAccountIsSelectedInAccountDropdown(DataTable dataTable) {
        this.shipmentOverviewPage.ValidateAccountDetails(dataTable);
    }

    @And("^I validate the below columns in column edit grid is \"([^\"]*)\"$")
    public void iValidateTheBelowColumnsInColumnEditGridIs(String checked, DataTable dataTable) throws Throwable {
        if (checked.equalsIgnoreCase("checked")) {
            Assert.assertTrue("Checkbox is not checked",
                    this.shipmentOverviewPage.ValidateColumnsinView(dataTable));
        } else if (checked.equalsIgnoreCase("unchecked")) {
            Assert.assertFalse("Checkbox is checked",
                    this.shipmentOverviewPage.ValidateColumnsinView(dataTable));
        }
    }

    @Then("^I validate column column is \"([^\"]*)\" in my shipment page$")
    public void iValidateColumnColumnIsInTheMyShipmentPage(String visiblity, DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (visiblity.equalsIgnoreCase("visible")) {
                Assert.assertTrue(this.shipmentOverviewPage.isShipmentColumnPresent(dataTable));
            } else if (visiblity.equalsIgnoreCase("invisible")) {
                Assert.assertFalse(this.shipmentOverviewPage.isShipmentColumnPresent(dataTable));
            }
        }
    }

    @And("^I validate hyperlink for column \"([^\"]*)\"$")
    public void iValidateHyperlinkForColumn(String column) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Link for " + column + " is not correct ",
                    this.shipmentOverviewPage.validateHyperLink(column));
        }
    }

    @And("^I validate senseaware id column link for \"([^\"]*)\"$")
    public void iValidateSenseawareIdColumnLinkFor(String trackingNum) {
        String trackingNumber = this.commonHelpers.getValuefromContextStore(trackingNum).toString();
        Assert.assertTrue("SenseAware LinkUrl validation failed",
                this.shipmentOverviewPage.validateSenseawareIdHyperLink(trackingNumber));
    }

    @And("^I validate senseaware id link for \"([^\"]*)\" which is below Tooling on shipment details page for \"([^\"]*)\"$")
    public void iValidateSenseawareIdColumnLinkForShipmentDetails(String toolingSubHeading, String trackingNum) {
        String trackingNumber = this.commonHelpers.getValuefromContextStore(trackingNum).toString();
        Assert.assertTrue("SenseAware LinkUrl validation failed on shipment details page",
                this.shipmentOverviewPage.validateSenseawareIdHyperLinkUnderTooling(toolingSubHeading, trackingNumber));
    }

    @And("^I validate link for \"([^\"]*)\" which is below Tooling on shipment details page for \"([^\"]*)\"$")
    public void iValidateLinkForShipmentDetailsTooling(String toolingSubHeading, String linkType) {
        Assert.assertTrue(
                "Link Url validation failed on shipment details page under Tooling for section = " + toolingSubHeading,
                this.shipmentOverviewPage.validateStaticHyperLinkUnderTooling(toolingSubHeading, linkType));
    }

    @Then("^I validate damaged package column value for \"([^\"]*)\" as \"([^\"]*)\"$")
    public void iValidateDamagedPackageColumnValueForAs(String trackingNumber, String damagedPackageValue) {
        Assert.assertTrue(this.shipmentOverviewPage.validateDamagePackageValue(
                this.commonHelpers.getValuefromContextStore(trackingNumber).toString(),
                this.commonHelpers.getValuefromContextStore(damagedPackageValue).toString()));
    }

    @And("^I navigate to below filters in the application and validate submenu$")
    public void iNavigateToBelowFiltersInTheApplicationAndValidateSubmenu(DataTable dataTable) {
        Assert.assertTrue("Filter is not present", this.shipmentOverviewPage.validateFilterSubmenu(dataTable));
    }

    @And("^I validate the checkbox status of the company present in dropdown$")
    public void iValidateTheCheckboxStatusOfTheCompanyPresentInDropdown(DataTable dataTable) {
        this.shipmentOverviewPage.validateAccountDropdownCheckbox(dataTable);
    }

    @Then("^I validate \"([^\"]*)\" column value for \"([^\"]*)\" as \"([^\"]*)\"$")
    public void iValidateColumnValueForAs(String columnName, String trackingNumber, String columnValue)
            throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateShipmentColumnValue(columnName,
                trackingNumber, columnValue));
    }

    @Then("^I validate \"([^\"]*)\" column is present$")
    public void iValidateColumnIsPresent(String columnName) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateColumnPresent(columnName));
    }

    @And("^I validate \"([^\"]*)\" dropdown has following options$")
    public void iValidateHasFollowingOptions(String dropDown, DataTable dataTable) throws Throwable {
        Assert.assertTrue(this.shipmentDetails.VerifyShipmentDetailsCommentDropdown(dropDown, dataTable));
    }

    @And("^I \"([^\"]*)\" the \"([^\"]*)\" log entry$")
    public void iTheLogEntry(String action, String dropdown, DataTable dataTable) throws Throwable {
        this.shipmentDetails.updateComment(action, dropdown, dataTable);
    }

    @And("^I select \"([^\"]*)\" image roles$")
    public void iSelectImageRoles(String imageRole) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.preferencePage.clickImageRole(imageRole);
    }

    @And("^I validate shipment not have shipment type icon$")
    public void iValidateShipmentNotHaveShipmentTypeIcon(DataTable dataTable) {
        List<String> table = dataTable.asList(String.class);
        for (String data : table) {
            Assert.assertFalse(data + " icon is visible",
                    this.shipmentOverviewPage.validateShipmentTypeIconNotPresent(data));
        }
    }

    @And("^I click on \"([^\"]*)\" dropdown$")
    public void iClickOnDropdown(String DropDownType) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            DropDownType = DropDownType.equalsIgnoreCase("SHIPMENT TYPES") ? "Types" : DropDownType;
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(DropDownType)));
        }
    }

    @And("^Click on the View impacted shipments for the City with shipments and Verify user navigated to shipment list with filter$")
    public void clickOnTheViewImpactedShipmentsForTheCityWithShipments() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.ClickOnrightChevronandStoreShipmentData();
        }
    }

    @And("^I validate \"([^\"]*)\" column is present in the FedEx Accounts$")
    public void iValidateColumnIsPresentInTheFedExAccounts(String columnName) throws Throwable {
        this.preferencePage.validateFedexPreferenceColumnIsPresent(columnName);
    }

    @And("^I validate \"([^\"]*)\" column is not present in the FedEx Accounts$")
    public void iValidateColumnIsNotPresentInTheFedExAccounts(String columnName) throws Throwable {
        this.preferencePage.validateFedexPreferenceColumnIsNotPresent(columnName);
    }

    @And("^I click on \"([^\"]*)\" on view popup$")
    public void iClickOnOnViewPopup(String label) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (label.equalsIgnoreCase("Update view"))
                this.shipmentOverviewPage.clickUpdateViewOnViewPopup();
            else if (label.equalsIgnoreCase("Set as default"))
                this.shipmentOverviewPage.clickSetAsDefaultOnViewPopup();
        }
    }

    @And("^I verify \"([^\"]*)\" is \"([^\"]*)\" in on view popup$")
    public void iVerifyIsInOnViewPopup(String button, String state) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (button.equalsIgnoreCase("save"))
                Assert.assertTrue(this.shipmentOverviewPage.validateViewSaveButtonStatus(state));
            else if (button.equalsIgnoreCase("cancel")) {
                if (state.equalsIgnoreCase("enabled"))
                    Assert.assertTrue(this.shipmentOverviewPage.validateViewCancelButtonEnabled());
            }
        }
    }

    @And("^I validate edit icon on view filter bubble$")
    public void iValidateEditIconOnViewFilterBubble(DataTable dataTable) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.validateEditIconRemovedFromViewBubbleFilter(dataTable);
        }
    }

    @And("^I click on edit icon of \"([^\"]*)\" view filter bubble$")
    public void iClickOnEditIconOfViewFilterBubble(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.clickViewFilterBubbleEditIcon(viewName);
        }
    }

    @And("^I verify following sections are present in views$")
    public void iVerifyFollowingSectionsArePresentInViews(DataTable dataTable) {
        this.shipmentOverviewPage.validateViewAvailable(dataTable);
    }

    @And("^I click on edit icon of \"([^\"]*)\" view \"([^\"]*)\"$")
    public void iClickOnEditIconOfView(String viewType, String viewName) throws Throwable {
        this.shipmentOverviewPage.clickOnEditView(viewType, viewName);
    }

    @And("^I verify the pop message of \"([^\"]*)\" of Standard Views$")
    public void iVerifyThePopMessageOfOfStandardViews(String viewName) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.verifyStandardViewPopUpMessage(viewName));
    }

    @And("^I click on share icon on my view \"([^\"]*)\"$")
    public void iClickOnShareIconOnMyView(String viewName) throws Throwable {
        this.shipmentOverviewPage.clickOnShareIconView(viewName);
    }

    @Then("^I verify the view is in the share views list$")
    public void iVerifyTheViewIsInTheShareViewsList(Map<String, String> columnTable) {
        this.shipmentOverviewPage.clickSharedView();
        Assert.assertTrue("Something went wrong with view", this.shipmentOverviewPage.verifyViewInList(columnTable));
    }

    @Then("^I click on delete icon and select \"([^\"]*)\" option for share view$")
    public void iClickOnDeleteIconAndSelectOptionForShareView(String option, DataTable table) throws Throwable {
        List<String> columns = table.asList(String.class);
        this.shipmentOverviewPage.clickSharedView();
        this.shipmentOverviewPage.DeleteView(option, columns);
    }

    @And("^I collect the Shipment Status List from Advisories$")
    public void iCollectTheShipmentStatusListFromAdvisories() throws Throwable {
        List<String> filterFromAdvisoryPage = this.advisoryPage.getShipmentStatusList();
        this.commonHelpers.AddToContextStore(Constants.FilterFromAdvisoryPage, filterFromAdvisoryPage);
    }

    @And("^I collect the Active Shipment Status List from Shipment$")
    public void iCollectTheActiveShipmentStatusListFromMyShipments() throws Throwable {
        List<String> filterFromShipmentPage = this.shipmentDetails.getActiveShipmentStatusList();
        this.commonHelpers.AddToContextStore(Constants.FilterFromShipmentPage, filterFromShipmentPage);
    }

    @Then("^I verify Advisories Shipment List order matches with My Shipment Status List$")
    public void iVerifyOrderMatch() throws Throwable {
        List<Object> filterFromAdvisoryPage = Arrays
                .asList(this.commonHelpers.getValuefromContextStore(Constants.FilterFromAdvisoryPage));
        for (Object filtervalue : filterFromAdvisoryPage) {
            log.info(filtervalue.toString());
        }
        List<Object> filterFromShipmentPage = Arrays
                .asList(this.commonHelpers.getValuefromContextStore(Constants.FilterFromAdvisoryPage));
        for (Object filtervalue : filterFromShipmentPage) {
            log.info(filtervalue.toString());
        }
        boolean result = this.commonHelpers.CompareTwoLists(filterFromAdvisoryPage, filterFromShipmentPage);
        Assert.assertTrue("List are not matching",
                result);
    }

    @And("^I select first tracking number from My Shipment list$")
    public void i_select_first_tracking_number_from_my_shipment_list() throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (this.shipmentOverviewPage.getViewCount() != 0) {
                this.shipmentOverviewPage.clickonFirstTrackingNumber();
                this.commonHelpers.AddToContextStore("NumberOfShipments", "MoreThan0");
                return;
            }
            log.info("**WARNING** - There are no tracking number with current filter applied");
            this.commonHelpers.AddToContextStore("NumberOfShipments", "0");
        }
    }

    @Then("^I validate \"([^\"]*)\" as tab index for \"([^\"]*)\" tab in Shipment detail page$")
    public void i_validate_something_tab_is_besides_something_tab_with_valid_text(String tabIndex, String tabName)
            throws Throwable {
        Assert.assertTrue(this.shipmentDetails.validateTabSequence(tabName));
    }

    @Then("^I validate \"([^\"]*)\" has been added to Personal Note tab with local date and time matching user machine time format$")
    public void i_validate_has_been_added_to_Personal_Note_tab_with_local_date_and_time_matching_user_machine_time_format(
            String personalNote) throws Throwable {
        Assert.assertTrue(this.shipmentDetails.validateDateFormatAndNote(personalNote,
                this.shipmentOverviewPage.getDateFromLeftPanel()));
    }

    @When("^I click on \"([^\"]*)\" button in Personal Note section of shipment details$")
    public void i_click_on_something_button_in_personal_note_section_of_shipment_details(String buttonText)
            throws Throwable {
        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(buttonText)));
    }

    @Then("^I Select \"([^\"]*)\" Calendar icon and Verify current date is highlighted$")
    public void i_select_calendar_icon_and_verify_current_date_is_highlighted(String filterButton) throws Throwable {
        Assert.assertTrue("Current date is not highlighted in calendar",
                this.shipmentOverviewPage.ValidateCalnderDetailsforFilter(filterButton));
    }

    @Then("^I verify \"([^\"]*)\" label on Personal note field with \"([^\"]*)\" as limit and the field is \"([^\"]*)\"$")
    public void i_verify_something_label_on_personal_note_field_with_something_as_limit_and_the_field_is_something(
            String note, String charLimit, String fieldStatus) {
        Assert.assertTrue(this.shipmentDetails.validatePersonalNoteDetailsFields(note, charLimit, true));
    }

    @And("^I verify different combinations of characters on personl note textbox$")
    public void i_verify_different_combinations_of_characters_on_personl_note_textbox() {
        Assert.assertTrue(this.shipmentDetails.validateNoteFieldLimit());
    }

    @Then("^I validate Personal Note is not added$")
    public void i_validate_personal_note_is_not_added() throws Throwable {
        Assert.assertTrue(this.shipmentDetails.validateDateFormatAndNote("", ""));
    }

    @Given("^I verify searched results for PIN \"([^\"]*)\" has the state name along with city name$")
    public void i_verify_searched_results_for_pin_has_the_state_name_along_with_city_name(String reference) {
        Assert.assertTrue(this.advisoryPage.VerifySearchResultsForPIN(reference));
    }

    @Then("^I Search for \"([^\"]*)\" in Filter and validate information text is displayed on top of search based filter$")
    public void i_search_for_something_in_filter_and_validate_information_text_is_displayed_on_top_of_search_based_filter(
            String filterText, DataTable table) throws Throwable {
        boolean specialChar = filterText.equalsIgnoreCase("special characters");
        Assert.assertTrue(this.shipmentOverviewPage.validateSearchForFilter(table, specialChar));
    }

    @Then("^I search for \"([^\"]*)\" in column search and validate information text$")
    public void i_search_for_something_in_column_search_and_validate_information_text(
            String columnText, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            boolean specialChar = columnText.equalsIgnoreCase("special characters");
            Assert.assertTrue(this.shipmentOverviewPage.validateSearchForColumn(table, specialChar));
        }
    }

    @Then("^I verify a search box appears with placeholder \"([^\"]*)\" and search icon$")
    public void i_verify_a_search_box_appears_with_placeholder_and_search_icon(
            String placeholderText) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateLegacyFilterSearchTextAndIcon(placeholderText));
    }

    @Then("^I search for \"([^\"]*)\" in filter search and validate result$")
    public void i_search_for_in_filter_search_and_validate_result(
            String filterType, DataTable table) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateLegacyFilterSearchAndResult(filterType, table));
    }

    @Then("^I search for \"([^\"]*)\" in column search and validate result$")
    public void i_search_for_in_column_search_and_validate_result(
            String filterType, DataTable table) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateColumnSearchAndResult(filterType, table));
    }

    @And("^I \"([^\"]*)\" a workgroup with workgroup name \"([^\"]*)\" in Management Center$")
    public void i_a_workgroup_with_workgroup_name_in_management_center(String operation, String label, DataTable table)
            throws Throwable {
        if (operation.contains("Create")) {
            Assert.assertTrue("Validation of workgroup creation is failed",
                    this.managementCenter.CreateWorkgroup(label, table));
        }
        if (operation.equalsIgnoreCase("Delete")) {
            this.managementCenter.deleteWorkGroup(label);
            Assert.assertTrue(this.managementCenter.verifyWorkGroupCompanyAccount("Group", label).indexOf(label) == -1);
        }

    }

    @Then("^I verify \"([^\"]*)\" workgroup is \"([^\"]*)\" in Management Center$")
    public void i_verify_workgroup_name_in_management_center(String label, String flag) throws Throwable {
        if (flag.equalsIgnoreCase("visible")) {
            Assert.assertTrue("Workgroup: " + label + " is not " + flag,
                    this.managementCenter.ValidateWorkgroupVisibility(label));
        } else if (flag.equalsIgnoreCase("invisible")) {
            Assert.assertFalse("Workgroup: " + label + " is not " + flag,
                    this.managementCenter.ValidateWorkgroupVisibility(label));

        }
    }

    @Then("^I \"([^\"]*)\" the \"([^\"]*)\" workgroup in Managment Center$")
    public void i_the_workgroup_in_managemetn_center(String action, String workgroup) throws Throwable {
        if (action.equalsIgnoreCase("Expand")) {
            this.managementCenter.ExpandWorkGroup(workgroup);
        } else if (action.equalsIgnoreCase("Collapse")) {
            this.managementCenter.CollapseWorkGroup(workgroup);
        }
    }

    @When("^I \"([^\"]*)\" below companies to workgroup$")
    public void i_assign_below_companies_to_workgroup(String action, DataTable table)
            throws Throwable {
        if (action.equalsIgnoreCase("Assign")) {
            this.managementCenter.AssignCompaniesToWorkGroup(table);
        }
    }

    @Then("^I verify below accounts are added in the left pane$")
    public void i_verify_below_accounts_are_added_in_the_left_pane(DataTable table)
            throws Throwable {
        Assert.assertTrue(this.managementCenter.VerifyAccountsUnderCompanyInLeftPane(table));
    }

    @Then("^I validate flight number is updated in more details tab with city,state,country$")
    public void i_validate_flight_number_is_updated_in_more_details_tab_with_citystatecountry(DataTable table)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String moredetailInfo = (String) table.asList(String.class).get(0);
            if (moredetailInfo.equals("no flight number")) {
                moredetailInfo = "Package on flight";
                Assert.assertTrue(this.shipmentDetails.validateMorDetailsInfo(moredetailInfo));
            } else {
                Assert.assertTrue(this.shipmentDetails
                        .validateMorDetailsInfo((String) this.commonHelpers.getValuefromContextStore("statusDetail")));
            }
        }
    }

    @Then("^I verify icons are translated to csv file$")
    public void i_verify_icons_are_translated_to_csv_file() throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateIconsFromUiAndFile());
    }

    @And("^I verify \"([^\"]*)\" download available count in the portal$")
    public void i_verify_download_available_count_in_the_portal(String action) throws Throwable {

        if (action.contains("post first"))
            Assertions.assertThat(this.shipmentOverviewPage.validateDownloadCountDecOnEachDownload(action))
                    .isEqualTo(1);
        else if (action.contains("post delete"))
            Assertions.assertThat(this.shipmentOverviewPage.validateDownloadCountDecOnEachDownload(action)).isZero();
    }

    @And("^I verify file to get deleted$")
    public void i_verify_file_to_get_deleted() throws Throwable {
        this.shipmentOverviewPage.clickOnDeleteElementofDownloadCenter();
    }

    @And("^I verify downloaded file is not deleted from download page$")
    public void I_verify_downloaded_file_is_not_deleted_from_download_page() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator, 60);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        Assert.assertTrue("The file is not present in download page",
                this.shipmentOverviewPage.verifyDownloadFileNameIsDisplayed(dfilename));
    }

    @And("^I verify downloaded file is deleted from download page$")
    public void I_verify_downloaded_file_is_deleted_from_download_page() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        Assert.assertFalse("The file is present in download page",
                this.shipmentOverviewPage.verifyDownloadFileNameIsDisplayed(dfilename));
    }

    @Then("^I verify the checkbox for given file name$")
    public void i_verify_the_checkbox_for_given_filename() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
        log.info(this.shipmentOverviewPage.verifyDownloadFilecheckbox(dfilename));
    }

    @And("^I verify the textBox Count for \"([^\"]*)\"$")
    public void i_verify_the_textbox_count_for(String PopUpName) throws Throwable {
        switch (PopUpName) {
            case "Download PopUp":
                Assert.assertTrue("count matches", this.shipmentOverviewPage.extractcountforpopup(PopUpName) == 1);
                break;
            case "Download PopUp-Combined Files":
                Assert.assertTrue("count matches", this.shipmentOverviewPage.extractcountforpopup(PopUpName) == 2);
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" and \"([^\"]*)\" should be displayed on right flyout for \"([^\"]*)\" view$")
    public void i_verify_something_and_something_should_be_displayed_on_right_flyout_for_something_view(String strArg1,
                                                                                                        String strArg2, String view) {
        Assert.assertTrue(this.advisoryPage.verifyRightFlyOutOptions(view));
    }

    @Then("^I Verify \"([^\"]*)\" and \"([^\"]*)\" checkboxes are displayed and selectable$")
    public void i_verify_something_and_something_checkboxes_are_displayed_and_selectable(String strArg1,
                                                                                         String strArg2) {
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertTrue(this.advisoryPage.verifyAdvisoriesDisplaySection());
    }

    @Then("^I verify \"([^\"]*)\" and \"([^\"]*)\" columns should be displayed in Preferences page$")
    public void i_verify_something_and_something_columns_should_be_displayed(String column1, String columnName2)
            throws Throwable {
        Assert.assertTrue(this.preferencePage.validateHeadersForPreferences(column1, columnName2));
    }

    @Then("^I verify files from \"([^\"]*)\" and \"([^\"]*)\" are present in download centre$")
    public void i_verify_files_from_and_are_present_in_download_centre(String comp1, String comp2) throws Throwable {
        String fileName1 = (String) this.commonHelpers.getValuefromContextStore("dfileName1");
        String fileName2 = (String) this.commonHelpers.getValuefromContextStore("dfileName");
        if (this.commonHelpers.getValuefromContextStore("UserContext").toString().contains("CE")) {
            this.clickOnElement(
                    this.getByusingString(String.format(this.shipmentOverviewPage.expandReportInDownloadCentre,
                            this.commonHelpers.getValuefromContextStore("CompanyName1"))));
            this.clickOnElement(
                    this.getByusingString(String.format(this.shipmentOverviewPage.expandReportInDownloadCentre,
                            this.commonHelpers.getValuefromContextStore("CompanyName"))));
        }
        Assert.assertEquals(fileName1.toLowerCase(),
                this.getText(this.getByusingString(this.getXPathforAnyElementWithText(fileName1))).toLowerCase());
        Assert.assertEquals(fileName2.toLowerCase(),
                this.getText(this.getByusingString(this.getXPathforAnyElementWithText(fileName2))).toLowerCase());
    }

    @And("^I click on \"([^\"]*)\" checkbox$")
    public void i_click_on_something_in_something_popup(String text) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (text.contains("ContextStore")) {
                if (text.contains("selectedCompanies")) {
                    text = this.shipmentOverviewPage.selectCompanyFromDownloadFilePopUp();
                } else {
                    text = this.commonHelpers.getValuefromContextStore(text).toString();
                }
            }
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(text)));
        }
    }

    @And("^I update \"([^\"]*)\" with \"([^\"]*)\" prefix$")
    public void i_update_something_with_something_prefix(String key, String postfixText, DataTable table)
            throws Throwable {
        List<String> keysToUpdate = table.asList(String.class);
        for (String keyToUpdate : keysToUpdate) {
            String value = (String) this.commonHelpers.getValuefromContextStore(keyToUpdate);
            String updatedkey = keyToUpdate.replace("ContextStore-", "") + postfixText;
            this.commonHelpers.AddToContextStore(updatedkey, value);
        }
    }

    @And("^I store key \"([^\"]*)\" in ContextStore with value \"([^\"]*)\"$")
    public void I_store_key_in_ContextStore_with_value(String key, String value)
            throws Throwable {
        this.commonHelpers.AddToContextStore(key, value);
    }

    @Then("^I validate \"([^\"]*)\" and  \"([^\"]*)\" options are displayed for download$")
    public void i_validate_something_and_something_options_are_displayed_for_download(String downloadOption1,
                                                                                      String downloadOption2) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertEquals(downloadOption1,
                    this.getText(this.getByusingString(this.getXPathforAnyElementWithText(downloadOption1))));
            Assert.assertEquals(downloadOption2,
                    this.getText(this.getByusingString(this.getXPathforAnyElementWithText(downloadOption2))));
        }
    }

    @And("^I Selects \"([^\"]*)\" shipments from shipment overview page$")
    public void user_selects_something_shipments_from_shipment_overview_page(String shipmentCount) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.selectMultipleShipmentsFromUI(Integer.valueOf(shipmentCount));
        }
    }

    @Then("^I verify shipments count as \"([^\"]*)\" in downloaded file and its contents$")
    public void i_verify_shipments_count_as_something_in_downloaded_file_and_its_contents(String shipmentCount)
            throws IOException {
        Assert.assertTrue(this.shipmentOverviewPage.verifySelectedShipmentsDownloaded(Integer.valueOf(shipmentCount)));
    }

    @Then("^I select \"([^\"]*)\" from \"([^\"]*)\" dropdown$")
    public void i_select_value_from_dropdown(String dropdownValue, String dropDownType) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(dropDownType)));
            this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.filterCategory, dropdownValue)));
        }
    }

    @Then("^I watch first \"([^\"]*)\" shipments on shipment overview page$")
    public void i_watch_first_something_shipments_on_shipment_overview_page(String shipmentCount) throws Throwable {
        this.shipmentOverviewPage.watchMultipleShipments(Integer.valueOf(shipmentCount));
    }

    @Then("^I verify selected shipments are changed to \"([^\"]*)\"$")
    public void i_verify_selected_shipments_are_changed(String shipmentType) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.verifyMultipleShipmentsWatchedUnwatched(shipmentType));
    }

    @And("^I perform right click on selected shipments to select \"([^\"]*)\" option$")
    public void i_perform_right_click_to_select_something(String optionToSelect) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.rightClickAndSelect(this.shipmentOverviewPage.shipmentOverviewFirstRow,
                    By.xpath(getXPathforAnyElementWithText(optionToSelect)));
        }
    }

    @Then("^I verify \"([^\"]*)\" value in Types dropdown with \"([^\"]*)\" icon$")
    public void i_verify_type_drodown_value(String shipmentType, String icon) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.verifyIfShipmentTypesIsPresentOrNot(shipmentType));
        Assert.assertTrue(icon.equals(this.shipmentOverviewPage.getTypeIcon(shipmentType)));
        this.JavaScriptClick(this.findElement(this.shipmentOverviewPage.filterType));
    }

    @And("^I verify only \"([^\"]*)\" shipments are displayed on shipment overview page$")
    public void i_verify_unwatched_shipments(String shipmentType) {
        Assert.assertTrue(this.shipmentOverviewPage.verifyOnlyUnwatchedShipmentsDisplayed(shipmentType));
    }

    @Then("^I verify \"([^\"]*)\" tab is displayed after \"([^\"]*)\" and is \"([^\"]*)\" with help text as \"([^\"]*)\"$")
    public void i_verify_tab_order_with_tab_state_help_txt(String tab1, String tab2, String butnState,
                                                           String helpText) {
        Assert.assertTrue(this.shipmentOverviewPage.verifyBulkTab(tab1, tab2));
        Assert.assertFalse(this.IsElementEnabled(getByusingString(tab1)));
        this.Mouse_MoveToElement(this.findElement(By.xpath(this.getXPathforAnyElementWithText(tab1))));
        Assert.assertTrue(helpText.equalsIgnoreCase(this.getText(this.shipmentOverviewPage.helpTextbulkTab)));
    }

    @Then("^I verify \"([^\"]*)\" filter options$")
    public void i_verify_filter_options(String dateFilter, DataTable table) {
        List<String> dateOptions = table.asList(String.class);
        // Check filter options
        if (dateFilter.contains("-")) {
            this.shipmentOverviewPage.selectParentChildFilters(dateFilter);
            dateFilter = dateFilter.split("-")[1];
        } else {
            this.shipmentOverviewPage.SelectDateFilter(dateFilter);
        }
        if (dateFilter.contains("Cold Storage Temp")) {
            dateFilter = "Cold Storage Temp";
        }
        switch (dateFilter) {
            case "Last Scan Time":
                for (String option : dateOptions) {
                    if (option.equalsIgnoreCase("Last Scanned")) {
                        Assert.assertEquals(option, this.getText(By.xpath(this.getXPathforAnyElementWithText(option))));
                    } else if (!option.equalsIgnoreCase("In the last")) {
                        Assert.assertEquals(option, this.getText(By.xpath(this.getXPathforCheckboxWithText(option))));
                    } else {
                        Assert.assertTrue(
                                (this.getText(By.xpath(this.getXPathforCheckboxWithText(option))).contains(option)));
                    }
                }
                // Check if options are mutually exclusive and perform other validations
                Assert.assertTrue(this.shipmentOverviewPage.verifyDeliveredDateOptions(dateFilter));
                break;
            case "Delivered Date":
                for (String option : dateOptions) {
                    if (!option.equalsIgnoreCase("In the last")) {
                        Assert.assertEquals(option, this.getText(By.xpath(this.getXPathforCheckboxWithText(option))));
                    } else {
                        Assert.assertTrue(
                                (this.getText(By.xpath(this.getXPathforCheckboxWithText(option))).contains(option)));
                    }
                }
                // Check if options are mutually exclusive na dperform other validations
                Assert.assertTrue(this.shipmentOverviewPage.verifyDeliveredDateOptions(dateFilter));
                break;
            case "Master Tracking Number":
                Assert.assertTrue(this.shipmentOverviewPage.verifyMasterTrackingNumberFilter(table));
                break;
            case "Package Dimensions":
                for (String option : dateOptions) {
                    Assert.assertEquals("e.g. 5.00",
                            this.getAttributeValue(
                                    By.xpath(String.format(this.shipmentOverviewPage.packageDimesionsInfilter, option)),
                                    "placeholder"));
                }
                List<WebElement> elmList = this.findElements(
                        By.xpath(String.format(this.shipmentOverviewPage.getElementWithAttribute, "radio")));
                Assert.assertEquals(2, elmList.size());
                Assert.assertEquals("in.", this.getAttributeValue(elmList.get(0), "aria-labelledby"));
                Assert.assertEquals("cm.", this.getAttributeValue(elmList.get(1), "aria-labelledby"));
                break;
            case "Scheduled Delivery Date/Time":
                for (String option : dateOptions) {
                    if (option.equalsIgnoreCase("Scheduled Delivery")) {
                        Assert.assertEquals(option,
                                this.getText(By.xpath(this.getNthInstanceOfXPathForAnyElementWithText(option, 2))));
                    } else if (option.contains("Next")) {
                        Assert.assertEquals(option,
                                this.getText(By.xpath(this.getXPathforCheckboxWithText(option.substring(4))))
                                        .replace("\n", " "));
                    } else if (!option.contains("Specific")) {
                        Assert.assertEquals(option, this.getText(By.xpath(this.getXPathforCheckboxWithText(option))));
                    }
                }
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(this.getXPathforCheckboxWithText(dateOptions.get(0)))));
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(this.getXPathforCheckboxWithText(dateOptions.get(1)))));

                // Check checkbox selection state
                Assert.assertTrue(this.verifyCheckBoxSelection(dateOptions.get(0), "unchecked"));
                Assert.assertTrue(this.verifyCheckBoxSelection(dateOptions.get(1), "unchecked"));
                Assert.assertTrue(this.IsElementEnabled(this.shipmentOverviewPage.specificDateRangeTo));
                // Verify Todays Date is selected in from Date
                this.clickOnElement(this.shipmentOverviewPage.specificDateRangeFrom);
                Assert.assertTrue(this.verifyDefaultSelectedDateInCalendar());
                // Verify From Date can be set from past 90 days or +15 days in future
                String[] filterCriteria = dateOptions.get(2).split(":");
                log.info("Validating the criteria " + Arrays.toString(filterCriteria));
                this.shipmentOverviewPage.selectDatetime(filterCriteria, true, false, false, false);

                String[] filterCriteria1 = dateOptions.get(3).split(":");
                log.info("Validating the criteria " + Arrays.toString(filterCriteria1));
                this.shipmentOverviewPage.selectDatetime(filterCriteria1, true, false, false, false);

                String[] filterCriteria2 = dateOptions.get(4).split(":");
                log.info("Validating the criteria " + Arrays.toString(filterCriteria2));
                this.shipmentOverviewPage.selectDatetime(filterCriteria2, true, false, false, false);
                // Enable from and to Date options and verify dates
                // this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Specific
                // Date")));
                // Verify To Date options
                String[] filterCriteria3 = dateOptions.get(5).split(":");
                this.clickOnElement(this.shipmentOverviewPage.specificDateRangeTo);
                Assert.assertTrue(this.verifyDefaultSelectedDateInCalendar());
                this.shipmentOverviewPage.selectDatetime(filterCriteria3, false, true, false, false);
                // Verify default selected time values
                Assert.assertTrue(this.verifyDefaultTime());
                break;
            case "Exception Reason":
            case "Workgroup":
            case "Dry Ice Added":
            case "Cold Storage Temp":
            case "Gel Pack Quantity":
                for (String option : dateOptions) {
                    if (option.equals("Specific Exception Reason") || option.equals("Specific Workgroup")) {
                        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(option)));
                    }
                    Assert.assertTrue(
                            (this.getText(By.xpath(this.getXPathforCheckboxWithText(option))).contains(option)));
                }
                if (dateFilter.equals("Exception Reason") || dateFilter.equals("Workgroup")) {
                    this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(dateOptions.get(2))));
                }
                // Check if options are mutually exclusive
                Assert.assertTrue(this.shipmentOverviewPage.verifyFilterOptions(dateFilter, table));
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Yes")));
                this.JavaScriptClick(this.findElement(this.getByusingString(String
                        .format(this.shipmentOverviewPage.applyButton, this.shipmentOverviewPage.applyUpperCase))));
                break;
            case "Healthcare Identifier":
                for (String option : dateOptions) {
                    this.Mouse_MoveToElement(By.xpath(this.getXPathforCheckboxWithText(option)));
                    Assert.assertTrue(
                            (this.getText(By.xpath(this.getXPathforCheckboxWithText(option))).contains(option)));
                }
                break;
            default:
                break;
        }

    }

    @Then("^I verify shipment overview page is updated with \"([^\"]*)\" shipments for \"([^\"]*)\" column$")
    public void i_verify_date_range(String dateCriteria, String colummnName, DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (dateCriteria.equalsIgnoreCase("random date")) {
                Assert.assertTrue(this.shipmentOverviewPage.verifyDateTime(colummnName, ""));
            } else {
                Assert.assertTrue(this.shipmentOverviewPage.verifyDateTime(colummnName, dateCriteria));
            }
        }
    }

    @Then("^I verify \"([^\"]*)\" filter bubble for \"([^\"]*)\" shipments")
    public void i_verify_date_filter_bubble(String filterName, String dateCriteria) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.shipmentOverviewPage.validateDateFlter(filterName, dateCriteria));
        }
    }

    @Then("^I verify data in downloaded file for \"([^\"]*)\" column is matching with UI$")
    public void verify_data_in_downoaded_file_with_ui(String columnName) throws IOException {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.shipmentOverviewPage.verifyDataOnUIAndDownloadedFile(columnName));
        }
    }


    @Then("^I verify \"([^\"]*)\" rows of data \"([^\"]*)\" for column grid \"([^\"]*)\" using \"([^\"]*)\" in UI$")
    public void verify_data_in_ui_grid(String rowsToValidate, String data, String columnName, String validation) throws IOException {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.validateDataInColumn(data, rowsToValidate, columnName, validation);
        }
    }

    @Then("^I verify selected shipments are displayed inside \"([^\"]*)\" pop up$")
    public void verify_shipments_inside_popup(String popupHeader) {
        Assert.assertTrue(this.shipmentOverviewPage.verifyShipmentsInsidePopUp(popupHeader));
    }

    @Then("^I verify shipments are repeated with same last comments and current timestamp$")
    public void last_repeat_comment_on_ui() {
        Assert.assertTrue(this.shipmentOverviewPage.verifyLastCommenstForShipments());
    }

    @Then("^I verify quick view cards are \"([^\"]*)\" in quick view panel$")
    public void quick_view_panel_visibility(String visibility) {
        int cardCount = 8;
        if (visibility.equals("hidden")) {
            cardCount = 0;
        }
        Assert.assertEquals(cardCount, this.findElements(this.shipmentOverviewPage.quickViewPanelItems).size());
    }

    @Then("^I verify more than 8 quick view cards can not be added$")
    public void verify_quick_view_cards_limit() {
        Assert.assertTrue(this.manageQCPage.verifyQuickViewCardsLimit());
    }

    @Then("^I verify timestamp and its format in generated file$")
    public void verify_timestamp_in_generated_excel_report() {
        Assertions.assertThat(this.shipmentOverviewPage.verifySummarySheet())
                .withFailMessage("Summary sheet verification failed for excel sheet ")
                .isTrue();
    }

    @When("^I set timezone \"([^\"]*)\"$")
    public void setTimezone(String zone) {
        this.dateTimeUtils.setTimeZone(zone);
    }

    @Then("^I verify \"([^\"]*)\" data for below columns on \"([^\"]*)\" page$")
    public void verify_data_in_columns(String filterName, String page, DataTable table) {
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            Assert.assertTrue(this.shipmentDetails.validateColumnValues(filterName, table));
        }
    }

    @And("^I verify right click options for \"([^\"]*)\" menu$")
    public void i_verify_right_click_options(String menuName, DataTable table) {
        List<String> options = table.asList(String.class);
        Assert.assertTrue(this.shipmentOverviewPage.verifyRightClickOptions(menuName, options));
    }

    @And("^I add \"([^\"]*)\" comment for selected shipments from \"([^\"]*)\" dropdown$")
    public void i_add_internal_comment_bulk(String comment, String menu) throws Throwable {
        if (comment.equals("random")) {
            this.shipmentOverviewPage.addComment("");
        } else {
            this.shipmentOverviewPage.addComment(comment);
        }
    }

    @Then("^I verify record count in \"([^\"]*)\" file and on UI$")
    public void i_verify_record_count_ui_downloaded_file(String fileType) throws Throwable {
        Assert.assertEquals(this.shipmentOverviewPage.getViewCount(),
                this.genericFunObj.getRecordsCountInDownLoadedFile(fileType));
    }

    @And("^I select the checkbox$")
    public void i_select_the_checkbox_for_AutomationWorkGroup() {
        this.shipmentOverviewPage.clickSearchedAccountORWorkgroup();
    }

    @When("^I click on \"([^\"]*)\" Button in accounts dropdown$")
    public void i_click_on_Button_in_accounts_dropdown(String button) {
        this.shipmentOverviewPage.clickAccountClearorApplyButton(button);
    }

    @Then("^I verify data in \"([^\"]*)\" field is \"([^\"]*)\"$")
    public void i_verify_field_has_null_value(String fieldname, String dataState) {
        if (dataState.equals("updated")) {
            this.shipmentOverviewPage.clickSerachMultiTackingNumbers();
        }
        Assert.assertTrue(this.shipmentOverviewPage.verifyFieldValue(fieldname, dataState));
    }

    @Then("^I verify sequence of tracking number and view count as per input$")
    public void i_verify_mts_sequence_on_ui() {
        Assert.assertTrue(this.shipmentOverviewPage.verifyTrackingNumberOrderForMts());
    }

    @Then("^I verify column data for \"([^\"]*)\" and \"([^\"]*)\" tracking ids$")
    public void i_verify_mts_data_for_valid_invalid_ids(String state1, String state2) {
        this.commonHelpers.thinkTimer(3000);
        Assert.assertTrue(this.shipmentOverviewPage.verifyDataInColumnsMts());
    }

    @Then("^I click on \"([^\"]*)\" icon of first \"([^\"]*)\" shipment and verify its \"([^\"]*)\"$")
    public void i_watch_unwatch_shipments(String operation, String count, String status) {
        this.shipmentOverviewPage.clickOnWatchIconAndVerifyStatus(Integer.parseInt(count), operation);
    }

    @Then("^I verify \"([^\"]*)\" tracking ids are \"([^\"]*)\"$")
    public void i_verify_tracking_ids_clickable(String state, String clickState, DataTable table) {
        List<String> trackingId = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
        if (clickState.equals("notclickable")) {
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(trackingId.get(trackingId.size() - 2))));
            Assert.assertFalse(this.elementIsDisplayed(this.shipmentDetails.pageheader, false));
        } else {
            Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText(trackingId.get(0)))));
        }
    }

    @Then("^I verify shipment view count includes count of only \"([^\"]*)\" tracking ids$")
    public void i_verify_tracking_count_mts(String state) {
        int viewCount = this.shipmentOverviewPage.getViewCount();
        List<String> validTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
        List<String> inValidTrackingIds = (List<String>) this.commonHelpers
                .getValuefromContextStore("InValid TrackingIds");
        if (state.equals("valid")) {
            Assert.assertEquals(viewCount, validTrackingIds.size() - 5);
        } else {
            Assert.assertEquals(viewCount, inValidTrackingIds.size());
        }
    }

    @And("^I verify only valid tracking ids are displayed and view count not changed$")
    public void i_verify_valid_tracking_ids() {
        Assert.assertTrue(this.shipmentOverviewPage.verifyMtsTrackingIds());
        int viewCount = this.shipmentOverviewPage.getViewCount();
        List<String> validTrackingIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
        if (this.commonHelpers.verifyKeyInContextStore("InValid TrackingIds")) {
            Assert.assertEquals(viewCount, validTrackingIds.size() - 5);
        } else {
            Assert.assertEquals(viewCount, validTrackingIds.size());
        }

    }

    @And("^I click on \"([^\"]*)\" link$")
    public void i_click_on_link(String link) {
        this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(link)));
    }

    @And("^I verify duplicate tracking ids are not displayed$")
    public void i_verify_unique_tracking_ids() {
        Assert.assertTrue(this.shipmentOverviewPage.validateDuplicateTrackingIds());
    }

    @Then("^I verify \"([^\"]*)\" saved view is under custom views section$")
    public void saved_view_in_custom_views_section(String view) {
        Assert.assertTrue(this.manageQCPage.verifyQVCinCustomViews(view));
    }

    @And("^I verify \"([^\"]*)\" of \"([^\"]*)\" view changes QVC layout$")
    public void verify_change_qvc_layout(String selction, String view) {
        Assert.assertTrue(this.manageQCPage.verifySelectionOfQVCChangesLayout(view));
    }

    @And("^I verify sequence of cards in quick view panel is as per in manage cards section$")
    public void verify_sequence_of_cards_in_qvc_panel(DataTable table) {
        List<String> qvcListExp = table.asList(String.class);
        Assert.assertTrue(this.shipmentOverviewPage.verifyQvcSequenceInPanel(qvcListExp));
    }

    @And("^I verify sequence of cards in quick view panel is as per in manage cards section for localization$")
    public void verify_sequence_of_cards_in_qvc_panel_localization(DataTable table) {
        List<String> qvcListExp = table.asList(String.class);
        qvcListExp = this.genericFunObj.getLocalizedValue(qvcListExp);
        Assert.assertTrue(this.shipmentOverviewPage.verifyQvcSequenceInPanel(qvcListExp));
    }

    @And("^I verify Payer Account details display duties or transportation$")
    public void verify_payer_account_details() {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.shipmentDetails.verifypayerAccountDetails());
        }
    }

    @Then("^I verify view count is matching with tracking id search count$")
    public void verify_trcking_ids_count_with_seachcount() throws NumberFormatException {
        Assert.assertEquals(this.shipmentOverviewPage.getViewCount(),
                Integer.parseInt((String) this.commonHelpers.getValuefromContextStore("searchCount")));
    }

    @Then("^I verify tracking ids matching companies are selected$")
    public void verify_companies_selected_for_matching_tracking_ids() {
        Assert.assertTrue(this.shipmentOverviewPage.verifyTrackingIdsAreDisplayedForSelectedCompanies());
    }

    @And("^I export the list$")
    public void export_list_in_file() {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.exportList();
        }
    }

    @When("^I click on the \"([^\"]*)\" button at index \"([^\"]*)\"$")
    public void i_click_on_the_button_at_index(String buttonText, String index) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.findElements(By.xpath(this.getXPathforAnyElementWithText(buttonText))).get(Integer.parseInt(index))
                .click();
    }

    @And("^I get the account ids$")
    public void get_account_ids() {
        this.shipmentOverviewPage.getAccountIds();
    }

    @And("^I get account ids for \"([^\"]*)\" company and store it$")
    public void get_acount_ids_for_company(String companyCode) {
        if (companyCode.contains("ContextStore-")) {
            companyCode = (String) this.commonHelpers.getValuefromContextStore(companyCode.split("-")[1]);
        }
        List<String> accountIdsList = Arrays
                .asList(this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString().split("\\[")[1]
                        .replaceAll("[]}\"]", "").split(","));
        for (int i = 0; i < accountIdsList.size(); i++) {
            this.commonHelpers.AddToContextStore("accountId" + i, accountIdsList.get(i));
        }
    }

    @Then("^I Verify date format for \"([^\"]*)\" field$")
    public void verify_date_format_for_field(String fieldName, DataTable table) {
        String orgField = "";
        if (fieldName.contains("filter")) {
            orgField = fieldName.split("-")[0];
            fieldName = fieldName.split("-")[1];
        }
        switch (fieldName) {
            case "Updated at":
                Assert.assertNotNull(this.dateTimeUtils.isDate(this.shipmentOverviewPage.getLastUpdatedDate(),
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "MM/dd/yyyy"));
                break;
            case "Shipment Details Page":
                this.shipmentDetails.verifyDateFormatForAllFields(
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat"), "MM/dd/yyyy");
                break;
            case "filter":
                Assert.assertTrue(this.shipmentOverviewPage.dateFormatOnFilterBubble(orgField));
                break;
            case "columns":
                Assert.assertTrue(this.shipmentOverviewPage.verifyDateFormat(table.asList(String.class),
                        (String) this.commonHelpers.getValuefromContextStore("preferredDateFormat")));
                break;
            default:
                break;
        }
    }

    @Then("^I verify placeholders on \"([^\"]*)\" filter fields$")
    public void placeholders_on_filter_fields(String filterName, DataTable table) {
        Map<String, String> expData = table.asMap(String.class, String.class);
        for (String key : expData.keySet()) {
            String actPlaceholder = this.getAttributeValue(By.xpath(".//*[@name='" + key + "']"), "placeholder");
            String expPlaceholder = expData.get(key);
            if (expData.get(key).contains("ContextStore-")) {
                expPlaceholder = (String) this.commonHelpers.getValuefromContextStore(expData.get(key).split("-")[1]);
            }
            Assert.assertEquals(actPlaceholder, expPlaceholder);
        }
    }

    @Then("^I apply filter to display less than 1000 records$")
    public void display_less_than_thousand_records() {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.filterLessThanThousandRecords();
        }
    }

    @Then("^I verify \"([^\"]*)\" popup$")
    public void verify_pop_up(String popupName) {
        switch (popupName) {
            case "Modify Entire List":
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(popupName)), true));
                Assert.assertTrue(
                        this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText("Confirm")), "class")
                                .contains("Disabled"));
                Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Watch Shipments"))));
                Assert.assertTrue(
                        this.IsElementEnabled(By.xpath(this.getXPathforCheckboxWithText("Unwatch Shipments"))));
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(String.format(this.shipmentOverviewPage.verifyViewBubbleValue,
                                this.shipmentOverviewPage.getViewCount() + " Shipments Selected"))));
                Assert.assertTrue("Checkbox state is incorrect",
                        this.verifyCheckBoxSelection("Watch Shipments", "unchecked"));
                Assert.assertTrue("Checkbox state is incorrect",
                        this.verifyCheckBoxSelection("Unwatch Shipments", "unchecked"));
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Watch Shipments")));
                Assert.assertFalse(
                        this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText("Confirm")), "class")
                                .contains("Disabled"));
                Assert.assertTrue("Checkbox state is incorrect",
                        this.verifyCheckBoxSelection("Unwatch Shipments", "unchecked"));
                this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("Unwatch Shipments")));
                Assert.assertFalse(
                        this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText("Confirm")), "class")
                                .contains("Disabled"));
                Assert.assertTrue("Checkbox state is incorrect",
                        this.verifyCheckBoxSelection("Watch Shipments", "unchecked"));

                break;
            case "Modify Entire List more than 1000 records":
                Assert.assertTrue(
                        this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText("Confirm")), "class")
                                .contains("Disabled"));
                Assert.assertTrue((boolean) this.getElementPropertyValueUsingJS(
                        By.xpath(this.getXPathforCheckboxWithText("Watch Shipments") + "/../input"), "disabled"));
                Assert.assertTrue((boolean) this.getElementPropertyValueUsingJS(
                        By.xpath(this.getXPathforCheckboxWithText("Unwatch Shipments") + "/../input"), "disabled"));
                String actText = this.getText(By
                        .xpath(String.format(this.shipmentOverviewPage.verifyViewBubbleValue, " Shipments Selected")));
                String expText = this.shipmentOverviewPage.getViewCount() + " Shipments Selected";
                Assert.assertEquals(actText.replace(",", ""), expText);
                Assert.assertEquals("Cannot bulk update for lists over 1000 shipments",
                        this.getText(By.xpath(
                                String.format(this.shipmentOverviewPage.verifyViewBubbleValue, "1000 shipments"))));
                break;
            case "Edit Work Group":
                this.clickOnElement(this.getByusingString(
                        String.format(this.managementCenter.editDeleteWorkGroup, Constants.randomWorkGroup, "edit")));
                Assert.assertTrue(this.elementIsDisplayed(
                        this.getByusingString(this.getXPathforAnyElementWithText("Edit Work Group"))));
                Assert.assertTrue(this.elementIsDisplayed(
                        this.getByusingString(this.getXPathforAnyElementWithText(Constants.editWorkGroupSubTitle))));
                Assert.assertTrue(this.getAttributeValue(this.managementCenter.workgroupName, "value")
                        .equals(Constants.randomWorkGroup));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Save"))));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Cancel"))));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                break;
            case "Edit Work Group-Clear All":
                this.clickOnElement(this.getByusingString(
                        String.format(this.managementCenter.expandGroupByName, Constants.randomWorkGroup)));
                this.JavaScriptClick(this.getByusingString(this.getXPathforAnyElementWithText("Clear All")));
                Assert.assertEquals(this.getText(this.managementCenter.removeWorkGroupPopUpMsg),
                        String.format(Constants.removeWorkGroupMsg, Constants.randomWorkGroup));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Remove"))));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Cancel"))));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                break;
            case "Delete Work Group":
                this.clickOnElement(this.getByusingString(
                        String.format(this.managementCenter.editDeleteWorkGroup, Constants.randomWorkGroup, "delete")));
                Assert.assertEquals(this.getText(this.managementCenter.removeWorkGroupPopUpMsg),
                        String.format(Constants.deleteWorkGroup, Constants.randomWorkGroup));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Delete"))));
                Assert.assertTrue(
                        this.elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText("Cancel"))));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                Assert.assertTrue(
                        this.managementCenter.verifyWorkGroupCompanyAccount("Group", Constants.randomWorkGroup)
                                .indexOf(Constants.randomWorkGroup) >= 0);
                break;
            case "Edit Company":
                String company = (String) this.commonHelpers.getValuefromContextStore("Company");
                this.managementCenter.searchCompany(company);
                this.clickOnElement(this
                        .getByusingString(String.format(this.managementCenter.editDeleteWorkGroup, company, "edit")));
                Assert.assertFalse(IsElementEnabled(this.managementCenter.globalEntityNumber));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                Assert.assertEquals("Search Accounts / Companies / Global Entity Numbers",
                        this.getAttributeValue(
                                this.getByusingString(this.getXPathforAnyElementWithText("COMPANIES")
                                        + "/../following-sibling::div/div/input[@class='sr-searchbox__input']"),
                                "placeholder"));
                break;
            case "Add New Last Comment":
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Please provide the comment in the box below.")),
                        true));
                Assert.assertTrue(this
                        .elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("Max 160 characters.")), true));
                Assert.assertEquals(this.getText(this.managementCenter.lastCommentMaxLength), "0/160");
                Assert.assertFalse(this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText("Save"))));
                String text = "testing";
                this.enterText(this.managementCenter.lastCommentTextbox, text);
                Assert.assertEquals(this.getText(this.managementCenter.lastCommentMaxLength),
                        text.length() + "/160");
                Assert.assertEquals(this.getText(this.managementCenter.acknowledgeCheckbox),
                        "I acknowledge that the comment being added has been reviewed and approved by legal.");
                String commnt = this.commonHelpers.generateRandomString(166);
                this.enterText(this.managementCenter.lastCommentTextbox, commnt);
                this.clickOnElement(this.managementCenter.acknowledgeCheckbox);
                Assert.assertTrue(this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText("Save"))));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
                this.enterText(this.managementCenter.searchlastComment, commnt);
                Assert.assertTrue(this.elementIsNotDisplayed(By.xpath(this.getXPathforAnyElementWithText(commnt))));
                break;
            case "File Download":
                assertThat(this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText("BY COMPANY") + "/.."),
                        "class")).withFailMessage("By Company is not Selected By default").contains("active");
                List<WebElement> companies = this.findElements(this.shipmentOverviewPage.companiesInDownloadpopUp);
                for (WebElement compnay : companies) {
                    String comp = this.getText(compnay);
                    if (!comp.equals("")) {
                        assertThat(comp).withFailMessage("More than 1 company is displayed other than default company ")
                                .isEqualToIgnoringCase(
                                        this.commonHelpers.getValuefromContextStore("CompanyName").toString());
                    }
                }
                break;
        }
    }

    @Then("^I verify search icon is \"([^\"]*)\" from below pages$")
    public void verify_search_icon_visibility(String state, DataTable table) throws Throwable {
        List<String> menuOptions = table.asList(String.class);
        for (int i = 0; i < menuOptions.size(); i++) {
            String menu = menuOptions.get(i);
            String submenu;
            if (menu.contains("-")) {
                submenu = menu.split("-")[1];
                menu = menu.split("-")[0];
                this.user_navigates_to_menu(menu);
                this.advisoryPage.NavigateToSubMenu(submenu);
            } else {
                this.user_navigates_to_menu(menu);
            }
            if (state.equals("visible")) {
                Assert.assertTrue(this.elementIsDisplayed(this.shipmentOverviewPage.Searchicon, true));
            } else {
                Assert.assertFalse(this.elementIsDisplayed(this.shipmentOverviewPage.Searchicon, true));
            }
        }
    }

    @Then("^I verify \"([^\"]*)\" UI$")
    public void i_verify_ui(String ui_name) throws InterruptedException {
        switch (ui_name) {
            case "Search":
                this.JavaScriptClick(this.findElement(this.shipmentOverviewPage.Searchicon));
                Assert.assertEquals(this.getAttributeValue(this.shipmentOverviewPage.searchinput, "placeholder"),
                        "Search or Tracking Number");
                Assert.assertTrue(this.elementIsDisplayed(this.shipmentOverviewPage.searchMultiTrack, true));
                break;
            case "Multiple Tracking Number":
                this.shipmentOverviewPage.clickSerachMultiTackingNumbers();
                Assert.assertEquals(
                        this.getText(this.getByusingString(this.shipmentOverviewPage.headerMultiTrackNumbersPopUp)),
                        "Enter or copy up to 50 FedEx Tracking Numbers");
                Assert.assertEquals(
                        this.getText(
                                getByusingString(this.shipmentOverviewPage.headerMultiTrackNumbersPopUp + "/../span")),
                        "You can enter up to 50 tracking numbers. Simply type into each single field or paste all of your tracking numbers into the first field and it will load all fields.");
                Assert.assertEquals(this.findElements(this.shipmentOverviewPage.searchMultiInput).size(), 9);
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Single Tracking Number")), true));
                Assert.assertFalse(
                        this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), false));
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Track ")));
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Please enter at least one tracking number.")),
                        true));
                this.findElements(this.shipmentOverviewPage.searchMultiInput).get(0).sendKeys("54236897512");
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), true));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
                Assert.assertTrue(this.shipmentOverviewPage.verifyFieldValue(ui_name, "empty"));
                this.findElements(this.shipmentOverviewPage.searchMultiInput).get(0).sendKeys("542abc97512");
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Please enter valid tracking number.")), true));
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), true));
                this.clickOnElement(this.getByusingString(this.getXPathforButton(" Track ")));
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), true));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
                Assert.assertTrue(this.shipmentOverviewPage.verifyFieldValue(ui_name, "empty"));
                this.findElements(this.shipmentOverviewPage.searchMultiInput).get(0).sendKeys("*/-//{}-.???");
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Please enter valid tracking number.")), true));
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), true));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
                Assert.assertTrue(this.shipmentOverviewPage.verifyFieldValue(ui_name, "empty"));
                this.findElements(this.shipmentOverviewPage.searchMultiInput).get(0).sendKeys("54789632142");
                Assert.assertEquals(this.getAttributeValue(this.shipmentOverviewPage.searchMultiInput, "value"),
                        "54789632142");
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("RESET")), true));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("RESET")));
                Assert.assertTrue(this.shipmentOverviewPage.verifyFieldValue(ui_name, "empty"));
                break;
            case "Groups":
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.managementCenter.groupsTitleString), true));
                Assert.assertEquals(
                        this.getText(By.xpath(this.managementCenter.groupsTitleString + "/following-sibling::div")),
                        Constants.groupsHederMsg);
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath("(" + this.managementCenter.groupsTitleString + ")[last()]"), true));
                Assert.assertTrue(
                        this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("Add New")), true));
                Assert.assertEquals("Search Groups / Accounts / Companies",
                        this.getAttributeValue(
                                this.getByusingString(this.getXPathforAnyElementWithText("Groups")
                                        + "/../following-sibling::div/div/input[@class='sr-searchbox__input']"),
                                "placeholder"));
                Assert.assertTrue(this
                        .elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText("Accounts/Companies")), true));
                Assert.assertEquals("Search Accounts / Companies",
                        this.getAttributeValue(
                                this.getByusingString(
                                        this.getXPathforAnyElementWithText("Accounts/Companies") + "/../div//input"),
                                "placeholder"));
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Show unassigned accounts only")), true));
                Assert.assertTrue(this.getAttributeValue(
                        By.xpath(this.getXPathforAnyElementWithText("Show unassigned accounts only") + "/..//label"),
                        "class").contains("toggle"));
                Assert.assertEquals(
                        this.getElementPropertyValueUsingJS(this.managementCenter.searchInfoTooltip, "innerText")
                                .toString().replace("-", " "),
                        Constants.searchAccountInfo);
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(
                                this.getXPathforAnyElementWithText("Assign selected  companies/accounts to targeted group.")),
                        true));
                List<WebElement> companyList = this.findElements(
                        this.getByusingString("//*[contains(text(),'Accounts/Companies')]/../div//input/../label"));
                Assert.assertTrue(this.verifyAlphabeticalSorting(companyList));
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforButton(" Assign ")), true));
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforButton(" Clear ")), true));
                List<WebElement> groupList = this.findElements(this.managementCenter.groupAccpuntsCompniesList);
                Assert.assertTrue(this.verifyAlphabeticalSorting(groupList));
//                this.managementCenter.verifyMappedCompaniesAccounts(Constants.randomWorkGroup,
//                        Constants.randomWgCompany);
                // Verify Clear all and Delete buttons for company group
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, Constants.randomWorkGroup)
                                + "/../following-sibling::div//span"),
                        true));
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, Constants.randomWorkGroup)
                                + "/../following-sibling::div//button"),
                        true));
                Assert.assertTrue(this.getAttributeValue(By.xpath(this.getXPathforButton(" Assign ")), "class")
                        .contains("disabled"));
                Assert.assertTrue(this.getAttributeValue(By.xpath(this.getXPathforButton(" Clear ")), "class")
                        .contains("disabled"));
                this.managementCenter.verifyPurpleDotOnSelectedUnAssignedAccounts(Constants.purpleColor);
                this.clickOnElement(this.getByusingString(
                        this.getXPathforAnyElementWithText("Show unassigned accounts only") + "/..//label"));
                this.managementCenter.verifyPurpleDotOnSelectedUnAssignedAccounts("");
                break;
            case "Comments":
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, "Last Comment")), true));
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, "Manage your last comments")), true));
                break;
            case "Groups Tab":
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, "View/Edit Groups")), true));
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, "Bulk Group Uploads")), true));
                Assert.assertEquals("View/Edit Groups",
                        this.getAttributeValue(this.managementCenter.selectedTab, "aria-controls"));
                break;
            case "Upload History":
                Assert.assertTrue(this.elementIsDisplayed(
                        By.xpath(String.format(this.managementCenter.elementOnUi, "Upload History")), true));
                List<WebElement> elms = this.findElements(this.managementCenter.uploadHistoryColumns);
                Assert.assertEquals("UPLOAD DATE/TIME", elms.get(0).getText());
                Assert.assertEquals("USER", elms.get(1).getText());
                Assert.assertEquals("UPLOAD RESULT", elms.get(2).getText());
                Assert.assertEquals("UPLOADED FILE", elms.get(3).getText());
                Assert.assertEquals(Constants.helpTextUploadHistory,
                        this.getText(this.managementCenter.helpTextUploadHistory));
                break;
        }

    }

    @And("^I verify Multi Tracking Form by pasting \"([^\"]*)\" tracking ids from \"([^\"]*)\" list at \"([^\"]*)\" index and \"([^\"]*)\" the form$")
    public void verify_mts_copy_paste_scenarios(String dataCount, String trackingIds, String indexToPaste,
                                                String dataType) {
        Assert.assertTrue(this.shipmentOverviewPage.verifyMtsbulkSearch(trackingIds, Integer.parseInt(dataCount),
                dataType, indexToPaste));
    }

    @Then("^I verify new blank rows are \"([^\"]*)\" after pasting \"([^\"]*)\" records and \"([^\"]*)\" the form$")
    public void verify_new_rows_in_mts(String rowsStatus, String rowCount, String action) {
        Assert.assertTrue(this.shipmentOverviewPage.verifyNewRowsInMtsForm(rowCount, action));
    }

    @Then("^I verify \"([^\"]*)\" and \"([^\"]*)\" the data$")
    public void verify_search_reset_data(String searchType, String action) {
        this.shipmentOverviewPage.verifySingleTrackingSearch(action);
    }

    @Then("^I search \"([^\"]*)\" through Single tracking Search and verify Multiple Tracking Numbers form$")
    public void verify_search_single_tracking_number(String trackingId) {
        this.shipmentOverviewPage.verifyMTsThroughSingleTrackingIdSearch(trackingId);
    }

    @Then("^I verify error message for \"([^\"]*)\" with limit of \"([^\"]*)\" views$")
    public void error_message_views(String action, String limit, DataTable viewList) {
        List<String> views = viewList.asList(String.class);
        switch (action) {
            case "save":
                Assert.assertEquals(this.shipmentOverviewPage.SaveViewGetMsg(views.get(0)),
                        "You have reached the maximum number of views (50).");
                break;
            case "share":
                String msgToVerify = "You have reached the maximum number of shared views (30).";
                if (Integer.parseInt(limit) < 10) {
                    msgToVerify = " VIEW successfully shared.";
                }
                Assert.assertTrue(this.shipmentOverviewPage.shareView(views.get(0), Integer.parseInt(limit))
                        .contains(msgToVerify));
                break;
            default:
                break;
        }
    }

    @Then("^I verify data in \"([^\"]*)\" sheet with column index as \"([^\"]*)\" for \"([^\"]*)\" file$")
    public void verify_data_in_generated_excel_report_for_sheet(String sheetName, String columnIndex, String fileType)
            throws IOException {
        Assert.assertTrue(this.shipmentOverviewPage.getSheetData(sheetName, Integer.valueOf(columnIndex), fileType));
    }

    @Then("^I validate only searched account is displayed on the page$")
    public void i_validate_only_searched_account_is_displayed_on_the_page(DataTable dataTable) {
        this.preferencePage.validateOnlySearchedAccountIsDisplayed(dataTable);
    }

    @Then("^I verify all image roles$")
    public void i_vverify_image_roles() {
        this.preferencePage.verifyImageRoles();
    }

    @Then("^I make \"([^\"]*)\" as \"([^\"]*)\" image role$")
    public void i_make_as_image_role(String roleName, String makedefault) throws Throwable {
        this.preferencePage.assignDefaultRole(roleName);
    }

    @Then("^I verify portal is updated as per \"([^\"]*)\" image role with company$")
    public void i_verify_portal_is_updated_as_per_image_role_with_company(String roleName) throws Throwable {
        this.preferencePage.validationspostRoleSelection(roleName);
    }

    @Then("^I verfiy company account dropdown$")
    public void i_verify_company_accounts_dropdown() {
        this.shipmentOverviewPage.verifyCompanyAccountsDropdown();
    }

    @Then("^I verify company name and account ids are sorted in ascending order$")
    public void i_verify_company_accounts_sorting() {
        Assert.assertTrue(this.shipmentOverviewPage.verifyCompanyAccountsSorting());
    }

    @Then("^I select accounts from \"([^\"]*)\" section$")
    public void i_select_accounts_from_dropdown(String companyType, DataTable table) {
        this.shipmentOverviewPage.selectmultipleCompaniesWorkGroups(companyType, table);
    }

    @Then("^I verify \"([^\"]*)\" comments$")
    public void i_verify_comments(String commentType) {
        this.shipmentDetails.verifyAutoComments(commentType);
    }

    @Then("^I verify applied filters as per below conditions on shipments page$")
    public void i_verify_filter_conditions(DataTable table) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.verifyAppliedFilterCondition(table);
        }
    }

    @And("^I search \"([^\"]*)\" and select from accounts dropdown$")
    public void i_search_select_account(String companyName) throws Exception {
        this.shipmentOverviewPage.SearchAndSelectCompanyAccountDD(companyName);
    }

    @And("^I search \"([^\"]*)\" and select workgroup from accounts dropdown$")
    public void i_search_select_workgroup(String workGroupName) throws Exception {
        this.shipmentOverviewPage.SearchAndSelectCompanyWorkGroupDD(workGroupName);
    }

    @Then("^I verify accounts dropdown options$")
    public void verify_button_status_accounts_dropdown(DataTable table) throws Exception {
        this.shipmentOverviewPage.verifyAccountsDropdownBtnStatus(table);
    }

    @And("^I \"([^\"]*)\" companies from accounts dropdown and verify \"([^\"]*)\" selected company$")
    public void i_click_button_in_accounts_dropdown(String buttonName, String company) {
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        if (buttonName.equals("RESET")) {
            String defaultCmp = (String) this.commonHelpers.getValuefromContextStore("CompanyName");
            this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(defaultCmp)));
            this.clickOnElement(this.shipmentOverviewPage.resetCompaniesBy);
            Assert.assertTrue("Selected Company",
                    this.findElement(By.xpath(this.getXPathforCheckboxWithText(defaultCmp) + "/../input"), true)
                            .isSelected());
        }
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
    }

    @Then("^I select accounts from \"([^\"]*)\" section and click \"([^\"]*)\"$")
    public void i_select_accounts_from_dropdown_set_as_default(String companyType, String setDefault, DataTable table) {
        Map<String, String> comp = table.asMap(String.class, String.class);
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        if (companyType.equals("Work Group")) {
            this.clickOnElement(By.xpath(this.shipmentOverviewPage.buildXpathForString("Clear")));
        }
        for (String company : comp.keySet()) {
            this.enterText(this.shipmentOverviewPage.companySearchInput, company);
            this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.companyNameinDD, company)));
        }
        Assert.assertTrue("RESET button is not enabled ",
                this.IsElementEnabled(this.shipmentOverviewPage.resetCompaniesBy));
        Assert.assertTrue("Set As default button is not enabled ",
                this.IsElementEnabled(By.xpath(this.getXPathforAnyElementWithText("Set As Default"))));
        if (setDefault.equals("Set As Default") && companyType.equals("Work Group")) {
            try {
                this.apiCall.SetWorkGroupContext(comp.entrySet().iterator().next().getKey());
            } catch (Exception e) {
                log.error("**EXCEPTION** Workgroup key is invalid");
            }
        }
        if (setDefault.equals("Set As Default")) {
            this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Set As Default")));
            Assert.assertFalse("RESET button", this.IsElementEnabled(this.shipmentOverviewPage.resetCompaniesBy));
            this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        } else if (setDefault.equals("Apply")) {
            this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        } else {
            this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        }

    }

    @Then("^I select accounts from \"([^\"]*)\" section and click and select \"([^\"]*)\"$")
    public void i_select_accounts_from_dropdown_set_as_default_programatically(String companyType, String setDefault, Map<String, String> comp) {
        this.commonHelpers.thinkTimer(500);
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.shipmentOverviewPage.buildXpathForString("Clear")));
        for (String company : comp.keySet()) {
            this.enterText(this.shipmentOverviewPage.companySearchInput, company);
            this.commonHelpers.thinkTimer(500);
            this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.companyNameinDD, company)));
        }
        if (setDefault.equals("Set As Default") && companyType.equals("Work Group")) {
            try {
                this.apiCall.SetWorkGroupContext(comp.entrySet().iterator().next().getKey());
            } catch (Exception e) {
                log.error("**EXCEPTION** Workgroup key is invalid");
            }
        }
        if (setDefault.equals("Set As Default")) {
            this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        } else if (setDefault.equals("Apply")) {
            this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        } else {
            this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        }
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    @Then("^I verify \"([^\"]*)\" section is \"([^\"]*)\"$")
    public void accounts_section(String section, String state) {
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        if (section.equals("Work Group")) {
            Assert.assertTrue(this
                    .findElements(this.getByusingString(
                            this.shipmentOverviewPage.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                    .get(1).getAttribute("class").contains("selection-not-allowed"));
        }
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
    }

    @Then("^I verify the color of text for \"([^\"]*)\" option$")
    public void verify_color_text(String option, DataTable table) {
        Map<String, String> colorMap = table.asMap(String.class, String.class);
        if (option.equals("ACCOUNTS")) {
            this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
            this.clickOnElement(By.xpath(this.shipmentOverviewPage.buildXpathForString("Clear")));
        }
        for (String colorElem : colorMap.keySet()) {
            String colorVal = colorMap.get(colorElem);
            if (colorElem.contains("ContextStore-")) {
                colorElem = (String) this.commonHelpers.getValuefromContextStore(colorElem.split("-")[1]);
            }
            Assert.assertEquals(
                    this.getElementCssProperty(By.xpath(this.getXPathforAnyElementWithText(colorElem)), "color"),
                    colorVal);
        }
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
    }

    @Then("^I verify future date selection is \"([^\"]*)\" in From Date field for \"([^\"]*)\" section of \"([^\"]*)\" filter$")
    public void i_verify_future_date_selection_is_in_From_Date_field_for_section_of_filter(String status,
                                                                                           String datecriteria, String filter) throws Throwable {
        Assert.assertEquals(status, this.shipmentOverviewPage.validateFutureDateInDateField(datecriteria, filter));
    }

    @Then("^I verify user can either select company or workgroup$")
    public void i_verify_company_workgroup(DataTable table) throws Exception {
        Map<String, String> comp = table.asMap(String.class, String.class);
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpath);
        this.clickOnElement(By.xpath(this.shipmentOverviewPage.buildXpathForString("Clear")));
        Assert.assertEquals(this.getText(this.shipmentOverviewPage.CompanyAccDefaultMessage),
                Constants.noAccountSelectedMsg);
        this.enterText(this.shipmentOverviewPage.companySearchInput,
                (String) this.commonHelpers.getValuefromContextStore("CompanyName"));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.companyNameinDD,
                this.commonHelpers.getValuefromContextStore("CompanyName"))));
        Assert.assertTrue(this
                .findElements(this.getByusingString(
                        this.shipmentOverviewPage.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                .get(1).getAttribute("class").contains("selection-not-allowed"));
        this.clickOnElement(By.xpath(this.shipmentOverviewPage.buildXpathForString("Clear")));
        this.enterText(this.shipmentOverviewPage.companySearchInput, comp.get("Workgroup"));
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.companyNameinDD, comp.get("Workgroup"))));
        Assert.assertTrue(this
                .findElements(this.getByusingString(
                        this.shipmentOverviewPage.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                .get(0).getAttribute("class").contains("selection-not-allowed"));
        this.clickOnElement(By.xpath(this.buildXpathForString("Apply")));
        this.apiCall.SetWorkGroupContext(comp.get("Workgroup"));
        String workname = this.shipmentOverviewPage.verifyCompanyWorkGroupInAccountsDropdown(comp.get("Workgroup"));
        Assert.assertTrue(this.elementIsDisplayed(
                By.xpath(this.getXPathforAnyElementWithText(
                        comp.get("Workgroup") + " (+ " + this.commonHelpers.getValuefromContextStore("companyCount"))),
                true) || workname.contains(comp.get("Workgroup")));
    }

    @Then("^I verify \"([^\"]*)\" is in \"([^\"]*)\" state$")
    public void i_verify_button_status(String btnName, String expStatus) {
        String status = this.getAttributeValue(By.xpath(this.getXPathforAnyElementWithText(btnName) + "/.."), "class");
        Assert.assertTrue(status.contains(expStatus));
    }

    @Then("^I verify export and download file flow with \"([^\"]*)\" option$")
    public void i_verify_export_download_flow(String downLoadType, DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            List<String> compOptions = table.asList(String.class);
            this.waitUntilNotVisible(this.loadingIndicator);
            boolean downLoadCenter = false;
            boolean largeFileDownload = false;
            if (downLoadType.contains("Download Center")) {
                downLoadCenter = true;
            }
            for (String option : compOptions) {
                String columnName = "";
                if (option.contains(":")) {
                    String[] options = option.split(":");
                    columnName = options[1];
                    option = options[0];
                }
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EXPORT LIST")));
                String header = this.getText(this.shipmentOverviewPage.fileDownloadPopUpHeader);
                if (header.equals("Large File Download")) {
                    largeFileDownload = true;
                }
                if (option.equals("BY COMPANY")) {
                    this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText("ContextStore-CompanyName")));
                } else {
                    this.JavaScriptClick(this.getByusingString(this.buildXpathForString(option)));
                }
                this.commonHelpers.AddToContextStore("DownloadType", option);
                // Click on Add to Download Centre
                if (downLoadCenter) {
                    this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Add file to download center")));
                }
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString(downLoadType.split("-")[0])));
                this.i_delete_all_files_from_download_directory();

                if (option.equals("COMBINED FILES")) {
                    this.shipmentOverviewPage.VerifyFileNameInFileDownloadDialogue("pre", "", downLoadType.split("-")[0]);
                    if (!largeFileDownload) {
                        this.findElements(By.xpath(this.getXPathforAnyElementWithText("Download"))).get(3)
                                .click();
                    }
                } else {
                    String text = "";
                    if (this.commonHelpers.verifyKeyInContextStore("CompanyName")) {
                        text = this.commonHelpers.getValuefromContextStore("CompanyName") + "_";
                    }
                    this.shipmentOverviewPage.VerifyFileNameInFileDownloadDialogue("pre", text + "FedEx_Surround",
                            downLoadType.split("-")[0]);
                    if (!largeFileDownload) {
                        this.clickOnElement(By.xpath(String.format(this.shipmentDetails.buttonXpath, "Download")));
                    }
                }
                if (largeFileDownload) {
                    this.clickOnElement(
                            By.xpath(String.format(this.shipmentDetails.buttonXpath, "Add to download center")));
                }

                this.waitUntillEleInvisible(this.loadingIndicator, 60);
                if (!largeFileDownload) {
                    this.i_verify_File_is_downloaded();
                    if (this.elementIsDisplayed(
                            this.getByusingString(this.buildXpathForString("CLOSE BUTTON POST DOWNLOAD")))) {
                        this.JavaScriptClick(this.getByusingString(this.buildXpathForString("CLOSE BUTTON POST DOWNLOAD")));
                    }
                }

                // Verify Column data if any
                if (!columnName.equals("")) {
                    // String columnName = option.split(":")[1];
                    if (downLoadType.contains("CSV")) {
                        Assert.assertTrue(this.shipmentOverviewPage.verifyDataOnUIAndDownloadedFile(columnName));
                    } else {
                        Assert.assertTrue(this.shipmentOverviewPage.verifyDataOnUIAndDownloadedFile("Excel-" + columnName));
                    }
                }
                if (downLoadCenter || largeFileDownload) {
                    this.i_delete_all_files_from_download_directory();
                    this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Download Center")));
                    if (option.equals("COMBINED FILES")) {
                        this.JavaScriptClick(this.getByusingString(this.buildXpathForString("COMBINED FILES")));
                    }
                    String dfilename = this.commonHelpers.getValuefromContextStore("dfileName").toString();
                    this.I_verify_downloaded_file_is_not_deleted_from_download_page();
                    this.waitUntillEleInvisible(this.loadingIndicator, 150);
                    // this.shipmentOverviewPage.verifyDownloadFileNameIsDisplayed(dfilename));
                    this.clickOnElement(this.getByusingString(
                            String.format(this.shipmentOverviewPage.downloadFileChecboxButtonDownloaded, dfilename)));
                    this.clickOnElement(this.getByusingString(this.getXPathforButton("Download")));
                    // Verify Column data if any
                    if (!columnName.equals("")) {
                        this.JavaScriptClick(this.getByusingString(this.buildXpathForString("My Shipments")));
                        if (!columnName.contains(":")) {
                            if (downLoadType.contains("CSV")) {
                                Assert.assertTrue(this.shipmentOverviewPage.verifyDataOnUIAndDownloadedFile(columnName));
                            } else {
                                Assert.assertTrue(
                                        this.shipmentOverviewPage.verifyDataOnUIAndDownloadedFile("Excel-" + columnName));
                            }
                        }
                    }
                    if (!largeFileDownload) {
                        this.i_verify_File_is_downloaded();
                    }
                }

            }
        }
    }

    @And("^I create \"([^\"]*)\" in Management Center$")
    public void i_create_comment_in_management_center(String comment) {
        this.managementCenter.createComment(comment);
    }

    @Then("^I verify \"([^\"]*)\" section$")
    public void i_verify_shipment_details_section(String section) {
        this.shipmentDetails.verifySupportUpdateSection(section);
    }

    @And("^I click on \"([^\"]*)\" radio button$")
    public void iClickOnRadioButton(String Id) throws Throwable {
        // this.clickOnElement(By.xpath(String.format(this.shipmentDetails.defaultRadioButton,Id)));
        this.shipmentOverviewPage.SelectDateFilter("Last Scan Time");
        this.clickOnElement(By.xpath("//label[@for='isNotWithin']"));
    }

    @And("^I verify default selected columns$")
    public void i_verify_default_columns() throws Throwable {
        this.shipmentOverviewPage.verifyDefaultColumns();
    }

    @And("^I verify bulk Group Uploads with \"([^\"]*)\" option for \"([^\"]*)\" operation$")
    public void bulk_group_upload_option(String option, String operation, DataTable table) throws IOException {
        Map<String, String> data = table.asMap(String.class, String.class);
        this.commonHelpers.generateRandomString(5);
        String filename = option.replace("/", "_") + " " + this.commonHelpers.generateRandomString(4).toLowerCase()
                + ".csv";
        this.commonHelpers.AddToContextStore("uploadedFileName", filename);
        for (String key : data.keySet()) {
            String[] headers = key.split(",");
            String[] dataToCsv = data.get(key).split(",");
            if (dataToCsv.length > 0) {
                if (data.get(key).contains(";")) {
                    dataToCsv = data.get(key).split(";");
                }
                this.genericFunObj.createCsvFileWithData(headers, dataToCsv, filename);
            } else {
                this.genericFunObj.createCsvFile(headers, filename);
            }

            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(option)));
            this.managementCenter.uploadFileForBulkGroup(filename);
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Submit")));
            this.managementCenter.verifyFileUploadPopUp(operation, filename);
            this.JavaScriptClick(this.getByusingString(this.buildXpathForString("Close")));
            this.genericFunObj.deleteFilefrom(filename);
        }
    }

    @Then("^I verify purple carousel has \"([^\"]*)\" option$")
    public void i_verify_shipment_details_purpe_carousel(String option) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(option, this.shipmentDetails.verifyShipmentDetailsSummaryHeaders(option) >= 0);
        }
    }

    @Then("^I verify the viewing count for \"([^\"]*)\" tracking numbers$")
    public void i_verify_viewing_count_for_valid_invalid_tracking_numbers(String status) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {

            this.waitUntilNotVisible(this.loadingIndicator);
            int viewCount = this.shipmentOverviewPage.getViewCount();
            List<String> validIds = (List<String>) this.commonHelpers.getValuefromContextStore("Valid TrackingIds");
            switch (status) {
                case "valid":
                    Assertions.assertThat(viewCount)
                            .withFailMessage("Viewing Count for Valid Tracking Ids failed")
                            .isEqualTo(validIds.size());
                    break;
                case "invalid":
                    List<String> inValidIds = (List<String>) this.commonHelpers
                            .getValuefromContextStore("InValid TrackingIds");
                    int expCount = validIds.size() - inValidIds.size();
                    if (validIds.size() <= inValidIds.size()) {
                        expCount = 0;
                    }
                    Assert.assertEquals("Viewing Count for Valid Tracking Ids", viewCount, expCount);
                    break;

            }
        }

    }

    @And("^I scroll to bring \"([^\"]*)\" visible in view$")
    public void iScrollToBringVisibleInView(String label) throws Throwable {
        this.shipmentOverviewPage.iScrollToBringVisibleInView(label);
    }

    @Then("^I verify left side submenu has options \"([^\"]*)\" under it$")
    public void i_verify_left_side_menu_has_options_under_it(String status, DataTable table) {
        Assert.assertTrue("Sub Menu option is not present as it was expected",
                this.productCenter.verifyMenuOptions(status, table));
    }

    @And("^I \"([^\"]*)\" the workgroup updates and verify workgroup list is \"([^\"]*)\" for \"([^\"]*)\"$")
    public void i_update_workgroup(String operation, String status, String newWorkGroupName) {
        String updatedWorkGroup = Constants.randomWorkGroup;
        if (operation.equals("Save")) {
            if (this.commonHelpers.verifyKeyInContextStore("updatedWorkGroup")) {
                updatedWorkGroup = (String) this.commonHelpers.getValuefromContextStore("updatedWorkGroup");
            }
            if (newWorkGroupName.equals("randomWorkGroup")) {
                newWorkGroupName = Constants.randomWorkGroup;
            }
        }
        this.clickOnElement(this
                .getByusingString(String.format(this.managementCenter.editDeleteWorkGroup, updatedWorkGroup, "edit")));
        this.enterText(this.managementCenter.workgroupName, newWorkGroupName);
        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText(operation)));
        if (operation.equals("Save")) {
            Assert.assertTrue(this.elementIsDisplayed(this.managementCenter.removeWorkGroupPopUpMsg, true));
            this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Close")));
            this.commonHelpers.AddToContextStore("updatedWorkGroup", newWorkGroupName);
            updatedWorkGroup = newWorkGroupName;
        }
        this.clickOnElement(this
                .getByusingString(String.format(this.managementCenter.editDeleteWorkGroup, updatedWorkGroup, "edit")));
        Assert.assertTrue(
                this.getAttributeValue(this.managementCenter.workgroupName, "value").equals(updatedWorkGroup));
        this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
        Assert.assertTrue(this.managementCenter.verifyWorkGroupCompanyAccount("Group", updatedWorkGroup)
                .indexOf(updatedWorkGroup) >= 0);
    }

    @Then("^I perform \"([^\"]*)\" operation and verify \"([^\"]*)\" company is updated$")
    @And("^I perform \"([^\"]*)\" operation and verify \"([^\"]*)\" workgroup is updated$")
    public void i_assign_delete_clear_companies_from_workgroup(String operation, String workgroup, DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        this.managementCenter.workGroupOperation(workgroup, operation, table);
        String company = "";
        if (this.commonHelpers.verifyKeyInContextStore("NewlyAssignedCompny")) {
            company = (String) this.commonHelpers.getValuefromContextStore("NewlyAssignedCompny");
        }
        switch (operation) {
            case "Assign":
                Assert.assertTrue(this.managementCenter.verifyWorkGroupCompanyAccount("Company", workgroup)
                        .indexOf(company) >= 0);
                break;
            case "Delete":
                Assert.assertTrue(this.managementCenter.verifyWorkGroupCompanyAccount("Company", workgroup)
                        .indexOf(company) == -1);
                this.clickOnElement(this.getByusingString(
                        this.getXPathforAnyElementWithText("Show unassigned accounts only") + "/..//label"));
                Assert.assertFalse(
                        this.findElement(this.getByusingString(this.getXPathforCheckboxWithText(company)), true)
                                .isSelected());
                break;
            case "Clear All-Cancel":
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Cancel")));
                List<String> selectedCompaniesAfter = this.managementCenter.verifyWorkGroupCompanyAccount("Company",
                        workgroup);
                List<String> selectedCompaniesBefore = (List<String>) this.commonHelpers
                        .getValuefromContextStore("SelectedCompanies");
                Assert.assertTrue(selectedCompaniesAfter.containsAll(selectedCompaniesBefore));
                break;
            case "Clear All-Remove":
                List<String> removedCompanies = this.managementCenter.verifyWorkGroupCompanyAccount("Company",
                        workgroup);
                Assert.assertEquals(0, removedCompanies.size());
                Assert.assertEquals(0, this.findElements(this.managementCenter.selectedCompaniesChevron).size());
                break;
            case "Remove All":
                Assert.assertTrue(this.elementIsDisplayed(this.managementCenter.removeWorkGroupPopUpMsg, true));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Close")));
                List<String> removedAccounts = this.managementCenter.verifyWorkGroupCompanyAccount("Companies Accounts",
                        workgroup);
                Assert.assertEquals(0, removedAccounts.size());
                break;
            case "Delete Company":
                Assert.assertTrue(this.elementIsDisplayed(this.managementCenter.removeWorkGroupPopUpMsg, true));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Close")));
                Assert.assertEquals(-1,
                        this.managementCenter.verifyWorkGroupCompanyAccount("Companies", workgroup).indexOf(company));
                break;
            case "Edit:Existing":
                Assert.assertTrue(this.elementIsDisplayed(By.xpath(
                        this.getXPathforAnyElementWithText("Work Group name already exists for the chosen region."))));
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
                break;
            case "Edit":
                Assert.assertTrue(this.elementIsDisplayed(this.managementCenter.removeWorkGroupPopUpMsg, true));
                this.clickOnElement(this.getByusingString(this.getXPathforAnyElementWithText("Close")));
                if (data.containsKey("name")) {
                    String newgroup = data.get("name");
                    Assert.assertTrue(this.managementCenter.verifyWorkGroupCompanyAccount("Group", newgroup)
                            .indexOf(newgroup) >= 0);
                }
                if (data.containsKey("region")) {
                    Assert.assertEquals(
                            this.managementCenter.verifyWorkGroupCompanyAccount("Group", workgroup).indexOf(workgroup),
                            -1);
                }
                break;
        }
    }

    @Then("^I verify workgroup \"([^\"]*)\" in accounts dropdown with \"([^\"]*)\" companies$")
    public void i_verify_workgroup_in_accounts_dropdown(String workGroup, String compCount) {
        String companyCount = "";
        try {
            companyCount = this.shipmentOverviewPage.verifyCompanyWorkGroupInAccountsDropdown(workGroup);
        } catch (Exception e) {
            log.error("Workgroup is not available");
        }

        if (compCount.equals("0")) {
            Assert.assertTrue(companyCount, companyCount.equals(""));
        } else {
            Assert.assertTrue(companyCount.equals(workGroup + " (" + compCount + ")"));
        }
    }

    @Then("^I switch to role \"([^\"]*)\" and verify workgroup \"([^\"]*)\" in dropdown with \"([^\"]*)\" companies and switch to original \"([^\"]*)\" role$")
    public void i_switch_to_roll_verify_workgroup_accounts_dropdown(String role1, String workgroup, String compCount,
                                                                    String role2) throws Throwable {
        this.user_navigates_to_menu("CE Preferences");
        this.i_click_on_in_Preference_SecondarySideBar("Settings");
        this.iSelectImageRoles(role1);
        this.i_verify_workgroup_in_accounts_dropdown(workgroup, compCount);
        this.iSelectImageRoles(role2);
        this.user_navigates_to_menu("Management Center");
        this.i_click_on_sub_menu("Groups");
    }

    @And("^I \"([^\"]*)\" a \"([^\"]*)\" with name \"([^\"]*)\" in Management Center and assign accounts$")
    public void create_delete_company_workgroup_in_management_center(String action, String type, String name,
                                                                     DataTable table) {
        switch (type) {
            case "Company":
                this.managementCenter.CreateCompany(name);
                this.managementCenter.expandWorkgroup(name);
                this.managementCenter.AssignAccountsToCompanies(table);
                break;
            case "Work Group":
                this.managementCenter.CreateWorkgroup(name, table);
                this.managementCenter.AssignCompaniesToWorkGroup(table);
                break;
        }
    }

    @Then("^I search \"([^\"]*)\" with name \"([^\"]*)\" and verify results$")
    public void i_search_compnay_workgroup(String type, String name) {
        if (name.contains("ContextStore-")) {
            name = (String) this.commonHelpers.getValuefromContextStore(name.split("-")[1]);
        }
        switch (type) {
            case "Company":
                this.enterText(this.getByusingString(this.getXPathforAnyElementWithText("COMPANIES")
                        + "/../following-sibling::div/div/input[@class='sr-searchbox__input']"), name);
                String company = (String) this.commonHelpers.getValuefromContextStore("Company");
                Assert.assertTrue("Company", this
                        .elementIsDisplayed(this.getByusingString(this.getXPathforAnyElementWithText(company)), true));
                Assert.assertTrue("Remove All Link", this.elementIsDisplayed(
                        this.getByusingString(this.getXPathforAnyElementWithText("Remove All")), true));
                break;
            default:
                log.error(" **EXCEPTION** : Provided search option not applicable");
                Assert.fail("Search option not applicable");
        }
    }

    @And("^I select \"([^\"]*)\" region for groups$")
    public void i_select_region_groups(String region) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.selectDropdown(By.xpath(String.format(this.managementCenter.wgRegion, "1")), "text", region);
    }

    @Then("^I verify selected \"([^\"]*)\" and \"([^\"]*)\"")
    public void i_verify_selected_wg_company(String wg, String region, DataTable table) {
        Map<String, String> data = table.asMap(String.class, String.class);
        this.shipmentOverviewPage.verifyWorkGroupRegion(data.get("workgroup"), data.get("region"));
    }

    @Then("^I verify region dropdown with below values on \"([^\"]*)\" page$")
    public void i_verify_region_dropdown(String location, DataTable regionTable) {
        List<String> regionList = regionTable.asList(String.class);
        switch (location) {
            case "Groups":
                List<String> regionGroupspage = this
                        .getDropdownOptions(By.xpath(String.format(this.managementCenter.wgRegion, "1")));
                Assert.assertEquals(regionGroupspage.size(), regionList.size());
                for (int i = 0; i < regionGroupspage.size(); i++) {
                    Assert.assertEquals(regionGroupspage.get(i), regionList.get(i));
                }
                break;
            case "Add New Group":
                this.clickOnElement(this.managementCenter.addNewButton);
                List<String> regionsAddNewWg = this
                        .getDropdownOptions(By.xpath(String.format(this.managementCenter.wgRegion, "2")));
                Assert.assertEquals(regionsAddNewWg.size(), regionList.size());
                for (int i = 0; i < regionsAddNewWg.size(); i++) {
                    Assert.assertEquals(regionsAddNewWg.get(i), regionList.get(i));
                }
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
                break;
            case "Edit Group":
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText(Constants.randomWorkGroup)));
                this.clickOnElement(this.getByusingString(
                        String.format(this.managementCenter.editDeleteWorkGroup, Constants.randomWorkGroup, "edit")));
                List<String> regionsEditPopUp = this
                        .getDropdownOptions(By.xpath(String.format(this.managementCenter.wgRegion, "2")));
                Assert.assertEquals(regionsEditPopUp.size(), regionList.size());
                for (int i = 0; i < regionsEditPopUp.size(); i++) {
                    Assert.assertEquals(regionsEditPopUp.get(i), regionList.get(i));
                }
                this.clickOnElement(By.xpath(this.getXPathforAnyElementWithText("Cancel")));
                break;
            case "Accounts":
                break;
            default:
                log.error(" **EXCEPTION** : Provided option not applicable");
                Assert.fail("option not applicable");
        }
    }

    @Then("^I verify file upload status as \"([^\"]*)\" for the file \"([^\"]*)\"$")
    public void i_verify_file_upload_status(String status, String fileName) {
        if (fileName.contains("ContextStore-")) {
            fileName = (String) this.commonHelpers.getValuefromContextStore(fileName);
        }
        Assert.assertEquals(status,
                this.getText(By.xpath(String.format(this.managementCenter.fileUpdateStatus, fileName))));

    }

    @Then("^I verify groups from \"([^\"]*)\" regions are displayed$")
    public void i_verify_regions_for_groups(String region, DataTable groupTable) {
        this.managementCenter.verifyGroupsInRegion(region, groupTable);
    }

    @Then("^I verify workgroups are separated as subcategories of region$")
    public void i_verify_workgroups_asubcategories_region(DataTable groupTable) {
        this.shipmentOverviewPage.verifyWorkGroupCategories(groupTable.asList(String.class));
    }

    @Then("^I search workgroup in accounts dropdown and verify respective region$")
    public void i_verify_workgroups_respective_to_regions_defined(DataTable groupTable) {
        Map<String, String> dataMap = groupTable.asMap(String.class, String.class);
        this.shipmentOverviewPage.searchAndGetWorkGroupRegion(dataMap.get("workgroup"), dataMap.get("region"));
    }

    @And("^I validate on hovering over \"([^\"]*)\" i see the value as \"([^\"]*)\"$")
    public void iValidateOnHoveringOverColumnISeeTheValueAs(String hoverOver, String textToCatch) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.mouseHoverAndValueValidation(hoverOver, textToCatch);
        }
    }

    @And("I validate on hovering over {string} i see the value as {string} for localization")
    public void iValidateOnHoveringOverISeeTheValueAsForlocalization(String hoverOver, String textToCatch) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            // hover over is not needed to be localised since we are using a class name to
            // catch it
            textToCatch = this.genericFunObj.getLocalizedValue(textToCatch);
            this.shipmentOverviewPage.mouseHoverAndValueValidation(hoverOver, textToCatch);
        }
    }

    @And("^I validate the value for \"([^\"]*)\" under \"([^\"]*)\" under Shipment Data on Shipment Details$")
    public void iValidateTheValueForIs(String mainElementText, String value) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.shipmentDetails.validateTextUnderShipmentData(mainElementText, value));
        }

    }

    @Then("^I verify Global search Options$")
    public void i_verify_global_search_options(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentOverviewPage.verifySearchOptions(table);
    }

    @Then("^I do global search with below options$")
    public void i_do_global_search_options(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            this.shipmentOverviewPage.SearchWithOptions(table);
    }

    @Then("^I search the comment \"([^\"]*)\" in management center and verify its \"([^\"]*)\"$")
    public void i_search_comment_management_center(String comment, String status) {
        this.managementCenter.searchComment(comment);
        if (status.equals("displayed")) {
            Assert.assertTrue(this.elementIsDisplayed(By.xpath(this.getXPathforAnyElementWithText(comment))));
        } else {
            Assert.assertTrue(this.elementIsNotDisplayed(By.xpath(this.getXPathforAnyElementWithText(comment))));
        }
    }

    @Then("^I verify package details on shipment details page$")
    public void i_verify_package_details(DataTable table) {
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            this.shipmentDetails.verifyPackageDetails(table);
        }
    }

    @Then("^I verify comment in comments dropdown$")
    public void i_verify_comments_dropdown(DataTable table) {
        this.shipmentDetails.verifyCommentInCommentsDropdown(table);
    }

    @Then("^I validate the \"([^\"]*)\" section in shipment details page under shipment Data$")
    public void iValidateTheSectionInShipmentDetailsPage(String section) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))
            Assert.assertTrue("Sensor section is not as per the requirement ",
                    this.shipmentDetails.validateSectionUnderShipmentData(section));
    }

    @Then("^I validate preferred locations not set message is \"([^\"]*)\"$")
    public void i_validate_preferred_location_not_set_message(String status) {
        if (status.equals("visible")) {
            Assert.assertEquals(Constants.preferredLocationNotSet,
                    this.advisoryPage.verifyLocationNotSetMessage().replace("\n", " "));
        } else {
            Assert.assertTrue("Preferred Locations Not Set link is displayed",
                    this.elementIsNotDisplayed(By.xpath(this.advisoryPage.preferredLocnNotAvailableLink)));
        }
    }

    @Then("^I verify data in downloaded file in \"([^\"]*)\" column$")
    public void i_verify_column_data_in_downloaded_file(String columnName, DataTable table) throws IOException {
        Assert.assertTrue(this.shipmentOverviewPage.verifyColumnDataInFile(columnName, table));
    }

    @Then("^I click on \"([^\"]*)\" icon of first \"([^\"]*)\" shipment$")
    public void i_watch_unwatch_shipments(String operation, String count) {
        this.shipmentOverviewPage.clickOnWatchUnwatchShipments(Integer.parseInt(count), operation);
    }

    @Then("^I verify upload history table for \"([^\"]*)\" operation$")
    public void i_watch_unwatch_shipments(String operation, DataTable table) throws IOException {
        this.managementCenter.verifyuploadHistory(operation, table);
    }

    @Then("^I verify below columns are updated with data on my shipments page$")
    public void i_verify_columns_data(DataTable table) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.verifyIfColumDataIsUpdated(table);
        }
    }

    @And("^I save the following values from the first record$")
    public void iSaveTheFollowingValuesFromTheFirstRecord(DataTable table) {
        this.shipmentOverviewPage.saveValueFromFirstShipmentRecord(table);
    }

    @And("^I search \"([^\"]*)\" from \"([^\"]*)\" section$")
    public void i_search_group_accounts_companies(String name, String searchType) {
        this.managementCenter.searchWorkgroupCompany(name, searchType);
    }

    @And("^I verify workgroup \"([^\"]*)\" is highlighted and active$")
    public void i_verify_style_properties(String wgname) {
        this.managementCenter.verifyPropertiesForSelectedGroup(wgname, Constants.purpleColor);
    }

    @Then("^I verify accounts/companies can be assigned only on workgroup \"([^\"]*)\" selection$")
    public void i_verify_accounts_company_assignments(String wgName) {
        this.managementCenter.removeWorkGroupSelection(wgName);
        this.clickOnElement(By.xpath(this.getXPathforCheckboxWithText(Constants.randomWgCompany)));
        Assert.assertTrue(
                this.getAttributeValue(By.xpath(this.getXPathforButton(" Assign ")), "class").contains("disabled"));
        Assert.assertTrue(
                this.getAttributeValue(By.xpath(this.getXPathforButton(" Clear ")), "class").contains("disabled"));
    }

    @Then("^I verify scrolling on \"([^\"]*)\" page$")
    public void i_verify_scrolling(String page) {
        switch (page) {
            case "View/Edit Groups":
                String offsetHeight = "500";
                String companyScroller = "cdk-virtual-scroll-orientation-vertical";
                this.scrollVerticallyInternalScrollBarOnPage("class", companyScroller, offsetHeight);
                Object scrollHt = this.getScrollOffSet("class", companyScroller, "top");
                Assert.assertEquals("Scrolling offset not matching", offsetHeight, String.valueOf(scrollHt));
                String workGroupScroller = "collapsible-panel-list";
                this.scrollVerticallyInternalScrollBarOnPage("id", workGroupScroller, offsetHeight);
                scrollHt = this.getScrollOffSet("id", workGroupScroller, "top");
                Assert.assertEquals("Scrolling offset not matching", offsetHeight, String.valueOf(scrollHt));
                break;
            default:
                log.error(" **EXCEPTION** : Provided option not applicable");
                Assert.fail("Option not applicable");
        }

    }

    /*
     * This section is for the steps related to Training Videos
     ***** START *****
     */
    @Then("^I verify the heading on the page is \"([^\"]*)\"$")
    public void iVerifyTheHeadingOnThePageIs(String heading) {
        this.trainingVideosPage.validateHeading(heading);
    }

    @And("^I verify the heading helptext is \"([^\"]*)\"$")
    public void iVerifyTheHeadingHelptextIs(String helpText) {
        this.trainingVideosPage.validateHeadingHelpText(helpText);
    }

    @And("^I verify that the videos with below headings are displayed$")
    public void iVerifyThatTheVideosWithBelowHeadingsAreDisplayed(DataTable videoHeadings) {
        this.trainingVideosPage.validateVideoHeadings(videoHeadings);
    }

    @And("^I validate the video controls for below sections$")
    public void iPlayTheVideoForBelowSections(DataTable videoSections) throws InterruptedException {
        this.trainingVideosPage.validateVideoControls(videoSections);
    }
    /*
     * This section is for the steps related to Training Videos
     ***** END *****
     */

    @Then("^I verify error message for \"([^\"]*)\"$")
    public void i_verify_error_message(String field) {
        switch (field) {
            case "Multiple Tracking Number":
                assertThat(this.elementIsDisplayed(
                        By.xpath(this.getXPathforAnyElementWithText("Please enter valid tracking number.")), true))
                        .withFailMessage("Error message for Invalid Multiple Tracking Number is not displayed")
                        .isTrue();
                this.clickOnPage();
                break;
            default:
                log.error(" **EXCEPTION** : Provided option not applicable");
                Assert.fail("Option not applicable");
        }
    }

    @Then("^I verify header \"([^\"]*)\" in downloaded \"([^\"]*)\" file is \"([^\"]*)\"$")
    public void i_verify_presence_of_headers_in_downloaded_file(String header, String fileType, String status)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            List<String> headerInFile = new ArrayList<String>();
            if (fileType.equals("CSV")) {
                headerInFile = this.genericFunObj.readCSVHeader();
            } else {
                headerInFile = this.genericFunObj.getColumnsList("Shipments");
            }
            Collections.sort(headerInFile);

            if (status.equals("Available")) {
                assertThat(headerInFile.indexOf(header.toUpperCase()) >= 0)
                        .withFailMessage("The header " + header + "in downloaded file is not present")
                        .isTrue();
            } else {
                assertThat(headerInFile.indexOf(header.toUpperCase()))
                        .withFailMessage("The header " + header + "in downloaded file is present")
                        .isEqualTo(-1);
            }
        }
    }

    @Then("^I click on SenseAware id \"([^\"]*)\" and verify it navigates to new page$")
    public void i_verify_senseaware_id_navigation(String id) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.verifySenseAwareMobileIdNavigation(id);
        }
    }

    @Then("I validate that TNT related options are {string} under Settings")
    public void iValidateThatTNTRelatedOptionsAreUnderSettings(String visibleOrNotVisible, DataTable dataTable) {
        boolean tntFeatureEnabled = (boolean) this.commonHelpers.getValuefromContextStore("tntFeatureEnabled");
        if (tntFeatureEnabled) {
            this.preferencePage.validateTNTOptions(visibleOrNotVisible, dataTable);
        } else {
            log.info("**WARNING** Skipping the next steps as the TNT flag is off");
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @And("I click on below options in the portal and validate default is coming")
    public void iClickOnBelowOptionsInThePortalAndValidateDefaultIsComing(DataTable dataTable) {
        this.preferencePage.validateTNTOptionsSelection(dataTable);
    }

    @Then("I validate the option selected is {string}")
    public void iValidateTheOptionSelectedIs(String option) {
        this.preferencePage.validationRadioButtionSelection(option);
    }

    @And("I verify right click options for {string} menu for localization")
    public void iVerifyRightClickOptionsForMenuForlocalization(String option, DataTable dataTable) {
        Assertions.assertThat(this.shipmentOverviewPage.validateBulkOption(option, dataTable))
                .withFailMessage("Validation of bulk options failed")
                .isTrue();

    }

    @And("I save the value for {string} in {string}")
    public void iSaveTheValueForIn(String valueToBeSaved, String variable) {
        this.shipmentOverviewPage.saveValueInContextstore(valueToBeSaved, variable);
    }

    @Then("I validate that the sum of TNT and Fedex is equal to individual sum")
    public void iValidateThatTheSumOfTNTAndFedexIsEqualToIndividualSum(DataTable dataTable) {
        this.shipmentOverviewPage.validateFedexAndTNTCount(dataTable);

    }

    @And("I validate {string} is present for scheduled delivery on shipment details page")
    public void iValidateIsPresntForScheduledDeliveryOnShipmentDetailsPage(String text) {
        this.shipmentDetails.validatePresenceOfText(text);
    }

    @Then("Use context value stored and search in multipleScreen page and validate result {string} for {string}")
    public void useContextValueStoredAndSearchInMultipleScreenPageAndValidateResult(String value, String caseType) {
        this.shipmentOverviewPage.searchAndValidateTheErrorMessage(value, caseType);
    }

    @And("I click on the kebab icon")
    public void iClickOnTheKebabIcon() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.ScrollToTop();
        this.ScrollIntoView(this.findElement(By.xpath("(.//span[contains(@class,'kebab-icn-list m-l-2')])[1]")));
        this.waitUntilNotVisible(this.loadingIndicator);
        this.JavaScriptClick(By.xpath("(.//span[contains(@class,'kebab-icn-list m-l-2')])[1]"));
        this.commonHelpers.thinkTimer(2000);
    }

    @And("I click on delete icon for favorite")
    public void iClickOnDeleteIconForFavorite() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.DeleteFavorite();
        }
    }

    @When("I click on the {string} button dropdown")
    public void iClickOnTheButtonDropdown(String favorites) {
        this.ScrollToTop();
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.clickOnElement(this.getByusingString(this.buildXpathForString(favorites)));
        }
    }

    @And("^I verify the \"([^\"]*)\" column value displayed$")
    public void i_verify_the_column_value_displayed(String value) {
        this.shipmentOverviewPage.validateRecipientAddressText(value);
    }

    @Given("^I \"([^\"]*)\" the filters with selected hours \"([^\"]*)\" using below conditions$")
    public void i_select_the_filters_selected_hours_using_below_conditions(String cancelOrApply, String date, DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong in selection of filter in UI",
                    this.shipmentOverviewPage.SelectFilterforUIwithHour(cancelOrApply, table, date));
        }
    }

    @And("^I verify the \"([^\"]*)\" column values displayed$")
    public void i_verify_the_column_values_displayed(String value) {
        this.shipmentOverviewPage.validateTimeInNetworkText(value);
    }

    @And("I verify account alias {string} text is displayed in application as below")
    public void iVerifyAccountAliasTextIsDisplayedInApplicationAsBelow(String accountText, DataTable table) {
        List<String> list = table.asList(String.class);
        Assert.assertTrue(this.advisoryPage.verifyAccountAliastext(accountText, list));
    }

    @Then("I click on {string} button on pre shipment page")
    public void iClickOnButtonOfDeleteConfirmationPopUpOnPreShipmentPage(String button) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.clickOnElementButtonofPS(button);
        ScrollByOffset("0", "150");
    }

    @Then("I verify the favorite is in the favorites list")
    public void iVerifyTheFavoriteIsInTheFavoritesList(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> columnTable = table.asMap(String.class, String.class);
            Assert.assertTrue("Something went wrong with the favorites",
                    this.advisoryPage.verifyFavoriteInList(columnTable));
        }
    }

    @And("I verify favorite kebob menu options")
    public void iVerifyFavoriteKebobMenuOptions(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        for (String expkey : messageTable.keySet()) {
            Assert.assertTrue("Sub Menu not matched",
                    this.advisoryPage.ValidateSubMenu(expkey, messageTable.get(expkey)));
        }
    }

    @Then("I verify below options are displayed in kebab menu")
    public void iVerifyBelowOptionsAreDisplayedInKebabMenu(DataTable dataTable) {
        Assert.assertTrue("Option is not displayed", this.advisoryPage.VerifyButtonsInKebobMenu(dataTable));
    }

    @Then("I Verify the watermark of the text box is {string}")
    public void iVerifyTheWatermarkOfTheTextBoxIs(String value) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Assert.assertTrue(this.advisoryPage.VerifyWaterMark(value));
        }
    }

    @Then("I verify Choose a Location text box and type {string} and are displayed in {string} view")
    public void iVerifyChooseALocationTextBoxAndTypeAndAreDisplayedInView(String City, String View) {
        JavaScriptClick(advisoryPage.advisories_LocationSearch);
        this.enterText(advisoryPage.advisories_LocationSearch, City);
        advisoryPage.clickOnSearchDrpDwn(City);
        advisoryPage.verifySlider();

    }

    @Then("I Verify the state names by searching value {string}")
    public void iVerifyTheStateNamesBySearchingValue(String State) {
        this.clickOnElement(advisoryPage.advisories_LocationSearch);
        this.enterText(advisoryPage.advisories_LocationSearch, State);
        advisoryPage.verifyDropDowns(State);
    }


    @Then("I Verify the zip by searching value {string}")
    public void iVerifyTheZipBySearchingValue(String Code) {
        this.enterText(advisoryPage.advisories_LocationSearch, Code);
        advisoryPage.verifyDropDowns(Code);
    }


    @When("I click on {string} link and add a location")
    public void iClickOnLinkAndAddALocation(String link, DataTable table) throws Throwable {
        commonHelpers.thinkTimer(2000);
        this.ScrollToTop();
        List<String> cities = table.asList(String.class);
        for (String city : cities) {
            this.advisoryPage.clickOnLocationLink(link);
            this.advisoryPage.addLocation(city);
        }
    }

    @When("I click on element {string} with index {string}")
    public void iClickOnElement(String text, String index) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (text.contains("Context-")) {
                text = String.valueOf(this.commonHelpers.getValuefromContextStore(text));
            }
            commonHelpers.thinkTimer(2000);

            if (!(GenericFunction.locale.equalsIgnoreCase(Constants.EN_US))) {
                text = genericFunObj.getLocalizedValue(text);
            }
            commonHelpers.thinkTimer(3000);
            this.clickOnElementByJavaScriptIndex(text, index);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("I click on Clear default option for favorite")
    public void iClickOnClearDefaultOptionForFavorite() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.ClearDefaultFavorite();
        }
    }

    @And("I verify the pop message of {string} of clearing default Favorite")
    public void iVerifyThePopMessageOfOfClearingDefaultFavorite(String favName) throws Throwable {
        Assert.assertTrue(this.advisoryPage.verifyStandardFavPopUpMessage(favName));
    }

    @And("I verify {string} is {string} in on favorite popup")
    public void iVerifyIsInOnFavoritePopup(String button, String state) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (button.equalsIgnoreCase("Clear Default"))
                Assert.assertTrue(this.advisoryPage.validateFavClearOptionStatus(state));
        }
    }

    @And("I click on Set as default option for favorite")
    public void iClickOnSetAsDefaultOptionForFavorite() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.SetAsDefultFavorite();
        }
    }

    @And("I save the favorite as default with the fav name {string}")
    public void iSaveTheFavoriteAsDefaultWithTheFavName(String favName) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Fav name is not matched/ Unable to save as default",
                    this.advisoryPage.SaveFavAsDefault(favName));
        }
    }


    @And("^I click on CountryOrTerritory dropdown$")
    public void i_click_on_countryorterritory_dropdown() {
        this.shipmentOverviewPage.clickCountryOrTerritoryDropdown();
    }

    @And("^I validate the checkbox status of the country or territory present in dropdown$")
    public void iValidateTheCheckboxStatusOfTheCountryOrTerritoryPresentInDropdown(DataTable dataTable) {
        this.shipmentOverviewPage.validateCountryOrTerritoryDropdownCheckbox(dataTable);
    }


    @Then("^I verify below values are shown on the country or territory dropdown$")
    public void i_verify_below_values_are_shown_on_the_country_or_territory_dropdown(DataTable table) {
        Assert.assertTrue("Dropdown values is not visible on the Country Territory dropdown",
                this.shipmentOverviewPage.VerifyDropdownValuesVisible(table));
    }

    @Then("^I verify a search box appears with placeholder \"([^\"]*)\" and search icon in country or territory dropdown$")
    public void i_verify_a_search_box_appears_with_placeholder_and_search_icon_in_country_or_territory_dropdown(
            String placeholderText) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.validateDropdownSearchBoxTextAndIcon(placeholderText));
    }

    @Then("^I select following values from country territory dropdown after clear$")
    public void i_select_following_values_from_country_territory_dropdown_after_clear(DataTable table) throws Exception {
        this.shipmentOverviewPage.selectMultipleValuesFromDD(table);
    }

    @Then("^I validate below country or territory value displayed in shipment page$")
    public void i_validate_below_country_on_terrirtory_value_displayed_in_shipment_page(DataTable dataTable) throws Throwable {
        Assert.assertTrue(this.shipmentOverviewPage.isCountryTerritoryValuePresent(dataTable));
    }

    @Then("I hover over kebob menu of favorite export")
    public void iHoverOverKebobMenuOfFavoriteExport() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.clickOnKebobMenuOfExport();
    }

    @And("I click on {string} in the kebob menu")
    public void iClickOnInTheKebobMenu(String link) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            if (link.equalsIgnoreCase("EXPORT")) {
                if (!this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString(link)))) {
//                            this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
                    this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(link)));
                    this.commonHelpers.thinkTimer(2000);
                    this.JavaScriptClick(this.getByusingString(this.buildXpathForString("EXPORT")));
                } else {
                    log.error("**WARNING** - Export list button was not enabled(diplayed). Hence skipping.");
                    log.error("Possible Reasons - No Data in grid to export");
                    this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                }
            } else {
                this.JavaScriptClick(this.getByusingString(this.buildXpathForString(link)));
            }
        }
    }

    @And("I click on Choose Accounts button")
    public void iClickOnChooseAccountsButton() {
        this.commonHelpers.thinkTimer(6000);
        this.accountAlias.clickChooseAccounts();
    }

    @And("I click on Choose Accounts dropdown and validate account number displayed")
    public void iClickOnChooseAccountsDropdownAndValidateAccountNumberDisplayed() {
        this.accountAlias.clickChooseAccountsDDAndValidate();
    }

    @And("I validate grid list of expandable dropdowns with Alias names")
    public void iValidateGridListOfExpandableDropdownsWithAliasNames() {
        this.accountAlias.validateGridListDDWithAliasNames();
    }

    @And("Validate the below text on the screen")
    public void validateTheTextOnTheScreen(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            commonHelpers.thinkTimer(5000);
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                if (!genericFunObj.locale.equalsIgnoreCase(Constants.EN_US)) {
                    validation = this.genericFunObj.getLocalizedValue(validation);
                }
                Assert.assertTrue("The value : " + validation + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForString(validation, "")), false));
            }
        }
    }

    @And("Verify the Default selections of favorite {string} from dropdown")
    public void verifyTheDefaultSelectionsOfFavoriteFromDropdown(String favoriteName) {
        this.advisoryPage.verifyTheDefaultValue(favoriteName);

    }

    @And("I Validate data in saveasfavorite by action {string}")
    public void iValidateDataInSaveasfavoriteByAction(String action) throws IOException {
        this.advisoryPage.iValidateDataInSaveasfavoriteByAction(action);
    }

    @Then("I verify By default, List view will be selected")
    public void iVerifyByDefaultListViewWillBeSelected() {
        advisoryPage.verifySlider();
        JavaScriptClick(advisoryPage.advisory_ListMapToggle);
    }

    @Then("I click on pin of state level city level and Export right flyout will be opened")
    public void iClickOnPinOfStateLevelCityLevelAndExportRightFlyoutWillBeOpened() throws InterruptedException {
        advisoryPage.clickLocationUntilPopup("");

    }

    @And("I navigate back to map view and filters will remain same as that of list view")
    public void iNavigateBackToMapViewAndFiltersWillRemainSameAsThatOfListView() {
        JavaScriptClick(advisoryPage.advisory_ListMapToggle);
        JavaScriptClick(advisoryPage.cityPinText);
        Assert.assertEquals(true, this.elementIsDisplayed(advisoryPage.advisory_MapPopup_affectedCount));
    }

    @Then("I verify white area with affected areas and All Zip Codes label")
    public void iVerifyWhiteAreaWithAffectedAreasAndAllZipCodesLabel() {
        Assert.assertEquals(true, this.elementIsDisplayed(advisoryPage.advisory_MapFlyout_AffectedAreas));
    }

    @When("I click on Affected area count number then navigated to list view and I verify the filter")
    public void iClickOnAffectedAreaCountNumberThenNavigatedToListViewAndIVerifyTheFilter() {
        JavaScriptClick(advisoryPage.advisory_MapPopup_affectedCount);
        Assert.assertEquals(true, this.elementIsDisplayed(advisoryPage.advisory_MapPopup_affectedCount));
    }

    @When("I click on Export Button popup button should come and select format as {string}")
    public void iClickOnExportButtonPopupButtonShouldComeAndSelectFormatAs(String Format) {
        JavaScriptClick(advisoryPage.advisory_MapPopup_ExportList);
        advisoryPage.selectFormat(Format);
        JavaScriptClick(advisoryPage.advisory_Btn_MapPopup_ExportList_DownloadOptn);
        JavaScriptClick(advisoryPage.advisory_Btn_MapPopup_ExportList_DownloadOptn);
        JavaScriptClick(advisoryPage.advisory_ListMapToggle);
    }


    @And("I click on Breadcrumb menu")
    public void iClickOnBreadcrumbMenu() {
        this.accountAlias.clickBreadcrumbMenu();
    }

    @When("I Verify Data in UI and {string} File for Tab {string} for {string}")
    public void iVerifyDataInUIAndFileForTab(String fileType, String sheetName, String advisories) throws IOException {
        // DriverManager.getDrv().navigate().refresh();
        if (fileType.trim().equalsIgnoreCase("Excel")) {
            advisoryPage.verifyDataOnUIAndDownloadedFile(fileType, sheetName, advisories);
        } else if (fileType.trim().equalsIgnoreCase("CSV")) {
            advisoryPage.verifyDataOnUIAndDownloadedFileCsv(fileType, sheetName, advisories);
        } else {
            Assert.assertTrue("Issue with CSV or Excel, please check", false);
        }
    }

    @Then("I click on filter button dropdown")
    public void iClickOnFilterButtonDropdown() throws Throwable {
        ScrollByOffset("0", "100");
        this.advisoryPage.JavaScriptClick(this.advisoryPage.filterButtonDropdown);
    }

    @Then("I verify {string} is having below values")
    public void iVerifyIsHavingBelowValues(String module, DataTable table) {
        Assert.assertTrue("Validation of Action bar is failed",
                this.advisoryPage.performActionOnFilterOption(module, table));
    }

    /*@Then("I {string} filter options for advisory")
    public void iFilterOptionsForAdvisory(String filterOption) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.advisoryPage.clickOnOption(filterOption);
        }
    }*/

    @Then("I {string} filter options for advisory")
    public void iFilterOptionsForAdvisory(String cancelOrApply, DataTable dataTable) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.advisoryPage.selectOrDeselectAdvisoryFilter(cancelOrApply, dataTable);
        }
    }

    @Then("^I remove the specfic advisory filter status one by one inside bubble using close icon$")
    public void i_remove_the_below_the_advisory_filter_status_oneByOne_inside_bubble(DataTable filters) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.RemoveSpecificOneFilterinBubble(filters);
    }


    @Then("I fill all the information in Report tab {string},{string},{string},{string},{string},{string},{string} and save ReportName as {string}")
    public void iFillAllTheInformationInReportTab(String reportName, String reportPrefix, String chooseView, String accountType, String chooseAccount, String format, String reportType, String reportNameKey) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            commonHelpers.thinkTimer(200);
            reportCenter.fillInformationInReportTab(reportName, reportPrefix, chooseView, accountType, chooseAccount, format, reportNameKey, reportType);

        }
    }


    @Then("I fill all the information in SendOption Tab {string},{string},{string},{string},{string}")
    public void iFillAllTheInformationInSendOptionTab(String chooseOption, String email, String language, String subject, String message) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.fillAllTheInformationInSendOptionTab(chooseOption, email, language, subject, message);
        }

    }


    @Then("I navigate to FrequencyTab and fill the information {string},{string},{string},{string},{string},{string}")
    public void iNavigateToFrequencyTabAndFillTheInformation(String frequency, String day, String hour, String timezone, String startDate, String endDate) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.navigateToFrequencyTabAndFillTheInformation(frequency, day, hour, timezone, startDate, endDate);
        }
    }

    @Then("I click on Create a Scheduled Report in ScheduledReports")
    public void iClickOnCreateAScheduledReportInScheduledReports() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            JavaScriptClick(reportCenter.scr_Btn_CreateAScheduledReport);
        }

    }

    @And("I click on the kebab icon for favorites")
    public void iClickOnTheKebabIconForFavorites() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.clickOnKabobIconOfFavorites();


    }


    @Then("I click on Get Status Updates and Verify Email, Your name, Your Email and Language")
    public void iClickOnGetStatusUpdatesAndVerifyEmailYourNameYourEmailAndLanguage() {
        JavaScriptClick(shipmentDetails.trackingnum_Btn_GetStatusUpdates);
        this.waitUntilNotVisible(this.loadingIndicator);
        Assert.assertEquals(true, this.elementIsDisplayed(shipmentDetails.trackingnum_DrpDwn_Languages));
        Assert.assertEquals(true, this.elementIsDisplayed(shipmentDetails.trackingnum_Txtbox_Email));
        Assert.assertEquals(true, this.elementIsDisplayed(shipmentDetails.trackingnum_Txtbox_YourEmail));
        Assert.assertEquals(true, this.elementIsDisplayed(shipmentDetails.trackingnum_Txtbox_YourName));

    }


    @Then("I verify below options with checkboxes are present")
    public void iVerifyBelowOptionsWithCheckboxesArePresent(DataTable table) {
        shipmentDetails.verifyCheckboxandText(table);
    }

    @Then("I verify {string} below the checkboxes")
    public void iVerifyBelowTheCheckboxes(String arg0) {
        Assert.assertEquals(true, this.elementIsDisplayed(By.xpath("//div[contains(text(),' You have to select atleast one option ')]")));

    }

    @Then("I verify {string}")
    public void iVerify(String arg0) {
        String txt = this.findElement(shipmentDetails.trackingnum_Text_IAgreeToThe).getText();
        System.out.println(txt);
        Assert.assertEquals("I agree to the Terms of use", txt);
        Assert.assertEquals(true, this.elementIsDisplayed(shipmentDetails.trackingnum_Checkbox_Iagreeto));
        JavaScriptClick(shipmentDetails.trackingnum_Checkbox_Iagreeto);
    }


    @Given("I select Tracking Number from My shipment list")
    public void iSelectTrackingNumberFromMyShipmentList() {
        JavaScriptClick(shipmentOverviewPage.trackingNumCellValue);
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    @Then("I fill all the information and click on submit")
    public void iFillAllTheInformationAndClickOnSubmit(DataTable table) {
        List<String> list = table.asList();
        shipmentDetails.fillEmailFields(list);
    }

    @And("I verify {string} is {string} in on Recurring Report page")
    public void iVerifyIsInOnRecurringReportPage(String button, String state) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (button.equalsIgnoreCase("Clear All"))
                Assert.assertTrue(this.reportCenter.validateClearAllButtonStatus(state));
        }
    }

    @When("I click on the {string} option for Recurring reports")
    public void iClickOnTheRROption(String filterOption) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.reportCenter.clickOnOption(filterOption);
        }
    }

    @Then("I {string} filter options for Recurring reports")
    public void iFilterOptionsForRecurringReports(String cancelOrApply, DataTable dataTable) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.reportCenter.selectOrDeselectRRFilter(cancelOrApply, dataTable);
        }
    }


    @And("I delete all Single Accounts Alias")
    public void iDeleteAllSingleAccountsAlias() {
        accountAlias.deleteAllSingleAcooumts();
    }

    @And("I add single account allias with name {string}")
    public void iAddSingleAccountAlliasWithName(String arg0) {
        accountAlias.addSingleAccountAllias(arg0);

    }

    @Then("I Validate below Data on the screen")
    public void iValidateBelowDataOnTheScreen(DataTable table) throws InterruptedException {
        this.validationOfLabels(table);
    }

    @And("I click on Export Download link")
    public void iClickOnExportDownloadLink() {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.clickOnExportDownloadLink();
    }


    @Then("I verify below state or territory are displayed in full state names")
    public void iVerifyBelowStateOrTerritoryAreDisplayedInFullStateNames(DataTable columnTable) throws Throwable {
        Assert.assertTrue("Full state names is not displayed", advisoryPage.verifyStateOrTerritoryAreDisplayed(columnTable));

    }

    @Then("I verify below risk type values displayed in risk type column")
    public void iVerifyBelowRiskTypeValuesDisplayedInRiskTypeColumn(DataTable columnTable) throws Throwable {
        Assert.assertTrue("Risk type values are not displayed", advisoryPage.verifyRiskTypeAreDisplayed(columnTable));
    }

    @And("I verify Add An Alias Button is present beside account number")
    public void iVerifyAddAnAliasButtonIsPresentBesideAccountNumber() {
        accountAlias.verifyAddAliasBtnBesideAccountNumber();
    }


    @Then("Hover on the Export Option and the validate the fields")
    public void hoverOnTheExportOptionAndTheValidateTheFields() {
        this.shipmentDetails.validateLabelsinShipment();
    }

    @Then("validate the breadcrumb {string}")
    public void validateTheBreadcrumb(String value) {
        this.reportCenter.validate_breadcrumb(value);
    }

    @Then("validate the Title {string}")
    public void validateTheTitle(String title) {
        this.reportCenter.validateTitle(title);
    }

    @Then("Verify the Filter is available in Action bar and Clear All is below the hamburger menu")
    public void verifyTheFilterIsAvailableInActionBarAndClearAllIsBelowTheHamburgerMenu() {
        //Filter
        this.reportCenter.VerifytheFilterDrpdwn();
        //Clearall below hamburger menu
        this.reportCenter.VerifytheClearAllOption();
    }

    @And("Apply the Clear All button")
    public void applyTheClearAllButton() {
        this.reportCenter.ClickonClearAllbutton();
    }

    @When("I click on the Reset Button")
    public void iClickOnTheResetButton() {
        this.reportCenter.ResetButton();
    }

    @And("validate the presence of the tooltip after clicking on cancel")
    public void validateThePresenceOfTheTooltipAfterClickingOnCancel() {
        this.Mouse_MoveToElement_Click(this.shipmentDetails.myshipments_cancelButton);
        Assert.assertEquals(0, this.getCount(this.shipmentDetails.Tooltip_presence));
    }

    @Then("I verify the filter badge {string}")
    public void iVerifyTheFilterBadge(String BadgeCount) {
        this.reportCenter.BadgeStatus(BadgeCount);
    }


    @Then("I verify report configuration created by everyone in workload Management should be visible")
    public void iVerifyReportConfigurationCreatedByEveryoneInWorkloadManagementShouldBeVisible() {
        this.reportCenter.verifyallreports();
    }

    @Then("I verify default report page of his own report should be on top")
    public void iVerifyDefaultReportPageOfHisOwnReportShouldBeOnTop() {
        reportCenter.verifyDefaultreport();
    }

    @Then("I verify CE Contributor should only see their reports")
    public void iVerifyCEContributorShouldOnlySeeTheirReports() {
        reportCenter.verifyOnlyContributorReports();
    }

    @Then("I verify Search box with label {string}")
    public void iVerifySearchBoxWithLabel(String arg0) {
        reportCenter.verifySearchBoxLabel();


    }

    @When("user search for {string} it should display name and FedEx ID")
    public void userSearchForItShouldDisplayNameAndFedExID(String Name) {
        reportCenter.verifyNameandID(Name);
    }

    @Then("I select one option and the results should show as same creator")
    public void iSelectOneOptionAndTheResultsShouldShowAsSameCreator() {
        reportCenter.verifyCreatorreportfromSearch();

    }


    @Then("I should be able to select multiple options from the list")
    public void iShouldBeAbleToSelectMultipleOptionsFromTheList() {
        reportCenter.selectMultipleOptions();
    }

    @Then("I select two Filter options then it should be treated as AND clause")
    public void iSelectTwoFilterOptionsThenItShouldBeTreatedAsANDClause() {
        reportCenter.selectMultipleFilters();

    }

    @Then("I verify if any filter is selected it should appear in filter bubble")
    public void iVerifyIfAnyFilterIsSelectedItShouldAppearInFilterBubble() {
        reportCenter.verifyFilterinFilterBubble();
    }

    @Then("I verify if Multiple Creator options are selected it should appear in filter bubble")
    public void iVerifyIfMultipleCreatorOptionsAreSelectedItShouldAppearInFilterBubble() {
        reportCenter.verifyMultipleFilters();
    }


    @And("I validate Choose Account Button is displayed below header")
    public void iValidateChooseAccountButtonIsDisplayedBelowHeader() {
        accountAlias.verifyChooseAccountsBtn();
    }


    @Then("I validate that the filter {string} is applied on the Recurring report page is {string}")
    public void iValidateThatTheFilterIsAppliedOnTheRecurringReportPageIs(String filter, String flag) {
        this.reportCenter.validateFilters(filter, flag);
    }


    @And("Verifying the Scroll into view with infinite scroll")
    public void verifyingTheScrollIntoViewWithInfiniteScroll() {
        for (int count = 0; count < 10; count++) {
            this.ScrollToBottom();
        }
//        this.ScrollIntoViewInfinite();
    }

    @Then("Select the Report and view the details page")
    public void selectTheReportAndViewTheDetailsPage() {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.reportCenter.FrstReportSelection();
    }

    @Then("I click on report and verify edit Icon for {string}")
    public void iClickOnReportAndVerifyEditIconFor(String label) {
        reportCenter.VerifyReportandEditIcon(label);
    }

    @Then("I click on Edit Icon in Report Information in purple bar and Verify Company")
    public void iClickOnEditIconInReportInformationInPurpleBarAndVerifyCompany() {
        reportCenter.verifycompanyname();
    }

    @Then("I delete the Company name from the list")
    public void iDeleteTheCompanyNameFromTheList() {
        reportCenter.DeleteCompany();
    }

    @Then("I select the Account which the Company has been deleted")
    public void iSelectTheAccountWhichTheCompanyHasBeenDeleted() {
        JavaScriptClick(reportCenter.scr_file_ReportName);
    }

    @Then("I Verify Edit Icon is only enable for Report Information in Purple bar")
    public void iVerifyEditIconIsOnlyEnableForReportInformationInPurpleBar() {
        reportCenter.VerifyEditforReportInf();
    }

    @And("I click on accounts dropdown and select other company and apply and save the report")
    public void iClickOnAccountsDropdownAndSelectOtherCompanyAndApplyAndSaveTheReport() {
        reportCenter.VerifyAccountandSelect();
    }

    @Then("I Verify Company and Accounts displayed in list view are updated as per new selection")
    public void iVerifyCompanyAndAccountsDisplayedInListViewAreUpdatedAsPerNewSelection() {
        reportCenter.VerifyCompanyinList();
    }

    @Then("I verify the Error message as {string}")
    public void iVerifyTheErrorMessageAs(String arg0) {
        reportCenter.VerifyErrorMsg();
    }

    @Then("I verify edit Icon for {string}")
    public void iVerifyEditIconFor(String label) {
        reportCenter.VerifyEditIcon(label);
    }


    @Then("Verify the List of Existing Reports are available")
    public void verifyTheListOfExistingReportsAreAvailable() {
        this.commonHelpers.thinkTimer(5000);
        this.waitUntilNotVisible(this.loadingIndicator, 200);
        Assert.assertTrue(this.getCount(this.reportCenter.ListOfReports) > 10);
    }

    @And("Validate the Navigated  page is Detailed page of the report")
    public void validateTheNavigatedPageIsDetailedPageOfTheReport() {
        this.reportCenter.validateDetailedReportPageHeaders();
    }

    @Then("Verify the {string} is not sortable")
    public void verifyTheIsnotSortable(String ColumnName) {
        this.scrollHorizontalBarOnPage("300");
        this.reportCenter.verifyTheIsnotSortable(ColumnName);
    }

    @Then("Verify the {string} is not sortable with offset {string}")
    public void verifyTheIsnotSortableWithOffset(String ColumnName, String offset) {
        this.scrollHorizontalBarOnPage(offset);
        this.reportCenter.verifyTheIsnotSortable(ColumnName);
    }

    @Then("Verify the {string} is sortable")
    public void verifyTheIsSortable(String ColumnName) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.ScrollToTop();
            if (ColumnName.equalsIgnoreCase("FILE SIZE") || ColumnName.equalsIgnoreCase("STATUS")) {
                this.scrollHorizontalBarOnPage("100");
                this.reportCenter.verifyTheIsSortable(ColumnName);
            } else {
                this.reportCenter.verifyTheIsSortable(ColumnName);
            }
        }
    }

    @Then("Verify the {string} is displayed for each report")
    public void verifyTheIsDisplayedForEachReport(String ColumnName) throws ParseException {
            commonHelpers.thinkTimer(2000);
            this.ScrollToTop();
            if (ColumnName.equalsIgnoreCase("EMAIL ADDRESSES")) {
                this.scrollHorizontalBarOnPage("100");
                this.reportCenter.verifyTheIsDisplayedForEachReport(ColumnName);
            } else if (ColumnName.equalsIgnoreCase("VIEW")) {
                this.scrollHorizontalBarOnPage("200");
                this.reportCenter.verifyTheIsDisplayedForEachReport(ColumnName);
            } else {
                this.ScrollByOffset("0", "300");
                this.reportCenter.verifyTheIsDisplayedForEachReport(ColumnName);
            }
    }

    @Then("Validate the checkbox functionality wrt to Hamburger menu options")
    public void validateTheCheckboxFunctionalityWrtToHamburgerMenuOptions() {
        this.reportCenter.validateOptionsInHamburgerMenu();
    }

    @Then("Click on the Delete icon, individual report should get deleted")
    public void clickOnTheDeleteIconIndividualReportShouldGetDeleted() {
        this.clickOnElement(By.xpath(String.format(this.reportCenter.DetailReport_ColumnName, "remove")));
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    @Then("I validate the Error Messages from Report Tab {string}")
    public void iValidateTheErrorMessagesFromReportTab(String reportname) {
        reportCenter.validateErrorMessagesFromReportTab(reportname);
    }


    @Then("I validate the Error Messages from Frequency Tab {string}")
    public void iValidateTheErrorMessagesFromFrequencyTab(String frequency) {
        reportCenter.validateErrorMessagesFromFrequencyTab(frequency);
    }

    @Then("I validate the Error Messages from SendOption Tab {string}")
    public void iValidateTheErrorMessagesFromSendOptionTab(String chooseOption) {
        reportCenter.validateErrorMessagesFromSendOptionTab(chooseOption);
    }

    @And("I Apply Filter for ReportName with Search criteria {string}")
    public void iApplyFilterForReportNameWithSearchCriteria(String ReportName) {
            if (ReportName.contains("Context-")) {
                ReportName = String.valueOf(this.commonHelpers.getValuefromContextStore(ReportName));
            } else {
                this.reportCenter.ApplyFilter_ReportName(ReportName);
            }
    }

    @Then("I click on {string} option of the Record {string}")
    public void iClickOnOptionOfTheRecord(String action, String record) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (record.contains("Context-")) {
                record = String.valueOf(this.commonHelpers.getValuefromContextStore(record));
            }
            this.ScrollToTop();
            reportCenter.drillDownRRRecord(action, record);
        }
    }

    @And("I click on {string} button in confirmation dialog box")
    public void iClickOnButtonInConfirmationDialogBox(String button) throws Throwable {
        this.reportCenter.ClickOnButtonIsDisplayedInConfirmationDialog(button);
    }

    @Then("user saves the first displayed Record with Name {string}")
    public void userSavesTheFirstDisplayedRecordWithName(String name) {
        this.reportCenter.storeFirstRecord(name);
    }

    @Then("I validate the Report Information with data {string},{string},{string},{string}")
    public void iValidateTheReportInformationWithData(String reportType, String view, String company, String accountType) {
        this.reportCenter.validateTheReportInformationWithData(reportType, view, company, accountType);
    }

    @And("I add multiple Account Alias {string}")
    public void iAddMultipleAccountAlias(String arg0) {
        accountAlias.addMultipleAccountAlias(arg0, 2);
    }


    @And("I validate edit scenarioes with {string} and {string} as aliasName")
    public void iValidateEditScenarioesWithAndAsAliasName(String arg0, String arg1) {
        accountAlias.editScenarioVerification(arg0, arg1);
    }

    @And("I validate special charecter {string} is not allowed as aliasName")
    public void iValidateSpecialCharecterIsNotAllowedAsAliasName(String arg0) {
        accountAlias.specialCharecterMultipleAccountAliasName(arg0);
    }

    @And("I validate Save button is disabled")
    public void iValidateSaveButtonIsDisabled() {
        Assert.assertEquals(true, this.elementIsPresent(accountAlias.disabledButtonSaveAlais));
    }


    @And("I click on edit the multiple Account Alias {string}")
    public void iClickOnEditTheMultipleAccountAlias(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.editPencilIcnBesideMultipleAccAliasName, arg0)));

    }

    @And("I delete multiple Account alias with AliasName {string}")
    public void iDeleteMultipleAccountAliasWithAliasName(String arg0) {
        accountAlias.deleteMultipleAccountAlias(arg0);
    }

    @And("I verify Sorting of AccountNumbers of {string}")
    public void iVerifySortingOfAccountNumbersOf(String arg0) {
        accountAlias.verifySortingOfAccountNumbers(arg0);
    }

    @And("I validate excel and data from ui")
    public void iValidateExcelAndDataFromUi() throws IOException {
        accountAlias.validateExcelAndUI();
        accountAlias.verifySortingOfExcelAccountsColumns();
    }

    @And("I click on question Mark icon")
    public void iClickOnQuestionMarkIcon() {
        JavaScriptClick(accountAlias.questionMarIcn);
    }

    @And("I click on Export Button")
    public void iClickOnExportButton(DataTable table) {
        if (!getAttributeValue(accountAlias.exportBtnIcn, "class").contains("disable"))
            JavaScriptClick(accountAlias.exportBtnIcn);
        else {
            accountAlias.addSingleAccountAlias(table);
            JavaScriptClick(accountAlias.exportBtnIcn);
        }
    }

    @And("I enter text {string} and Validate Same Name Appears in saved file")
    public void iEnterTextAndValidateSameNameAppearsInSavedFile(String arg0) {
        accountAlias.validateFileNameSameAsSaved(arg0);
    }

    @And("I click on download")
    public void iClickOnDownload() {
        JavaScriptClick(accountAlias.downloadBtn);
    }

    @And("I click on close Button.")
    public void iClickOnCloseButton() {
        JavaScriptClick(accountAlias.closeBtn);
    }

    @And("I add multiple acount alias {string} and delete and validate its deleted")
    public void iAddMultipleAcountAliasAndDeleteAndValidateItsDeleted(String arg0) {
        accountAlias.verifyDeleteScenario(arg0);
    }

    @And("I add multiple account Alias {string} and click on cancel and verify its not deleted")
    public void iAddMultipleAccountAliasAndClickOnCancelAndVerifyItsNotDeleted(String arg0) {
        accountAlias.addMultipleAccountAlias(arg0, 2);
        JavaScriptClick(By.xpath(String.format(accountAlias.deleteTrashIcnBesideMultipleAccAliasName, arg0)));
        JavaScriptClick(accountAlias.cancelBtnInMultipleAccAlias);
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.headerAccountAliasName, arg0))));
    }

    @And("I click on delete button beside {string}")
    public void iClickOnDeleteButtonBeside(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.deleteTrashIcnBesideMultipleAccAliasName, arg0)));
    }

    @And("I validate delete & edit icn beside aliasname {string}")
    public void iValidateDeleteEditIcnBesideAliasname(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.deleteTrashIcnBesideMultipleAccAliasName, arg0))));
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.editPencilIcnBesideMultipleAccAliasName, arg0))));

    }

    @And("I add single account allias with name valid values")
    public void iAddSingleAccountAlliasWithNameValidValues(DataTable table) {
        accountAlias.addSingleAccountAlias(table);
    }

    @And("I click on random Add an Alias Button")
    public void iClickOnRandomAddAnAliasButton() {
        JavaScriptClick(accountAlias.addAnAliasFirstBtn);
    }

    @And("I validate cross button is present Inside Text Box")
    public void iValidateCrossButtonIsPresentInsideTextBox() {
        Assert.assertEquals(1, getCount(accountAlias.closeCrossIcnInsideTxtBox));
        JavaScriptClick(accountAlias.closeCrossIcnInsideTxtBox);
    }

    @And("I validate watermark present inside text box")
    public void iValidateWatermarkPresentInsideTextBox() {
        Assert.assertEquals(1, getCount(accountAlias.addANameWaterMark));
    }

    @And("I click on delete button beside Single Account Alias {string}")
    public void iClickOnDeleteButtonBesideSingleAccountAlias(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.deleteBtnInSingleAccountAlias, arg0)));
    }

    @And("I validate Pop up window opened")
    public void iValidatePopUpWindowOpened() {
        Assert.assertEquals(true, elementIsPresent(accountAlias.deletePopUpWindow));
    }

    @And("I click on cross button to close popup And validate pop up is closed")
    public void iClickOnCrossButtonToClosePopupAndValidatePopUpIsClosed() {
        JavaScriptClick(accountAlias.deleteAliasModelPopupCloseIcn);
        Assert.assertEquals(false, elementIsPresent(accountAlias.deletePopUpWindow));

    }

    @And("I click on cancel to validate {string} is not deleted.")
    public void iClickOnCancelToValidateIsNotDeleted(String arg0) {
        JavaScriptClick(accountAlias.cancelBtnInMultipleAccAlias);
        accountAlias.searchAccountNumberOrAliasSaved(arg0);
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.searchAliasByNameOutput, arg0))));
        accountAlias.searchAccountNumberOrAliasSaved(arg0);
    }

    @And("I delete single account alias {string} and verify")
    public void iDeleteSingleAccountAliasAndVerify(String arg0) {
        accountAlias.deleteSingleAccountAliasVerification(arg0);
    }

    @And("I add multiple Account Alias {string} Delete and cancel then delete and verify")
    public void iAddMultipleAccountAliasDeleteAndCancelThenDeleteAndVerify(String arg0) {
        accountAlias.addAndCancelAndDelete(arg0);

    }

    @And("I add multiple Account Alias {string} and Validate AccountNumbers associated,count.")
    public void iAddMultipleAccountAliasAndValidateAccountNumbersAssociatedCount(String arg0) {
        HashMap<String, String> listOfAccNum = accountAlias.addMultipleAccountAlias(arg0, 2);
        accountAlias.blueDotAndAccountNumberValidationAfterEdit(arg0, listOfAccNum);
        accountAlias.deleteMultipleAccountAlias(arg0);
    }

    @And("I Validate Valid Strings Allowed In textBoxAliasname with aliasname as {string}")
    public void iValidateValidStringsAllowedInTextBoxAliasnameWithAliasnameAs(String arg0, DataTable table) {
        accountAlias.addMultipleAccountAlias(arg0, 2);
        accountAlias.verifyValidAliasName(arg0, table);

    }


    @Then("I validate the Sender Information with data {string},{string}")
    public void iValidateTheSenderInformationWithData(String download, String email) {
        this.reportCenter.validateTheSenderInformationWithData(download, email);
    }

    @Then("I validate the Frequency Information with data {string},{string},{string},{string},{string},{string},{string}")
    public void iValidateTheFrequencyInformationWithData(String frequency, String day, String hour, String timeZone, String startDate, String endDate, String format) {
        this.reportCenter.validateTheFrequencyInformationWithData(frequency, day, hour, timeZone, startDate, endDate, format);
    }


    @And("Validate the BackButton is displayed in Detailed report page")
    public void validateTheBackButtonIsDisplayedInDetailedReportPage() {
        this.reportCenter.btnBack();
    }

    @Then("Validate the ReportName {string} in detail report page")
    public void validateTheReportNameInDetailReportPage(String ActualReportName) {
        if (!ActualReportName.equalsIgnoreCase("")) {
            this.reportCenter.ValidateReportName(ActualReportName);
        } else {
            this.reportCenter.ValidateReportName(this.commonHelpers.getValuefromContextStore("Context-ReportName").toString());
        }
    }

    @Then("Validate the fields {string},{string},{string},{string},{string},{string},{string},{string} in {string} tab with index {string}")
    public void validateTheFieldsInReportInformationTabWithIndex(String field1, String field2, String field3, String field4, String field5, String field6, String field7, String field8, String tabName, String index) {
        this.reportCenter.VaidatefieldsinDetailsReportpage(field1, field2, field3, field4, field5, field6, field7, field8, tabName, index);
    }

    @And("verify the edit icon for tabs")
    public void verifyTheEditIconForTabs() {
        this.reportCenter.ValidateEditOption();
    }

    @And("validating the updated fields {string}")
    public void validatingTheUpdatedFields(String ExpectedVal) {
        this.reportCenter.verifytheUpdatedvaluesInfreqTab(ExpectedVal);
    }

    @And("Apply the {string} option in status option")
    public void applyTheOptionInStatusOption(String StatusOption) {
        this.reportCenter.ApplyFilter_Status(StatusOption);
    }

    @Then("I Click on the Edit icon for Frequency Tab")
    public void iClickOnTheEditIconForFrequencyTab() {
        this.JavaScriptClick(this.reportCenter.Edit_FreqInfo);
        this.waitUntilNotVisible(this.loadingIndicatorContains);
    }

    @And("verify the window title is {string}")
    public void verifyTheWindowTitleIs(String Expectedvalue) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.reportCenter.verifyEditReportLabelName(Expectedvalue);
    }

    @And("verify the guidance text window is {string}")
    public void verifyTheGuidanceTextWindowIs(String ExpectedValue) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.reportCenter.verifyGuidanceLabelName(ExpectedValue);
    }

    @And("Validate the Active Tab {string}")
    public void validateTheActiveTab(String TabName) {
        this.waitUntilNotVisible(this.loadingIndicatorContains);
        this.reportCenter.ActiveTabStatus(TabName);
    }

    @Then("Verify the fields are NonEditable in Report,Send Option, Frequency Tab")
    public void verifyTheFieldsAreNonEditableInReportSendOptionFrequencyTab() {
        this.reportCenter.VerifyDisabledFields();
    }

    @And("I click on .csv option")
    public void iClickOnCsvOption() {
        JavaScriptClick(accountAlias.csvOptionDownload);
    }

    @And("I click on .xlsx")
    public void iClickOnXlsx() {
        JavaScriptClick(accountAlias.xlsxOptionDownload);
    }

    @And("I verify Its selected")
    public void iVerifyItsSelected() {
        Assert.assertEquals(true, findElement(accountAlias.csvOptionDownload).isSelected());
    }

    @And("^I click on Accounts dropdown in Recurring Report$")
    public void i_click_on_accounts_dropdown_in_recurring_report() {
        this.shipmentOverviewPage.clickAccountDropdowninRR();
    }

    @Then("^I select following company with accounts from drop down and validate Accounts dropdown text in Recurring Report$")
    public void i_select_multiple_accounts_in_recurring_report(DataTable table) throws Exception {
        this.shipmentOverviewPage.SelectMultipleCompanyAccountDDRR(table);
    }

    @Then("^I verify accounts dropdown options in Recurring Report$")
    public void verify_button_status_accounts_dropdown_in_recurring_report(DataTable table) throws Exception {
        this.shipmentOverviewPage.verifyAccountsDropdownBtnStatusRR(table);
    }

    @Then("^I verify \"([^\"]*)\" section is \"([^\"]*)\" in Recurring Report$")
    public void accounts_section_recurring_report(String section, String state) {
        if (section.equals("Work Group")) {
            Assert.assertTrue(this
                    .findElements(this.getByusingString(
                            this.shipmentOverviewPage.companyWorkgroupChevron + "/preceding-sibling::span/../.."))
                    .get(1).getAttribute("class").contains("selection-not-allowed"));
        }
        this.JavaScriptClick(this.shipmentOverviewPage.CompanyAccddXpathRR);
    }

    @Then("I click on one report from the report history page")
    public void iClickOnOneReportFromTheReportHistoryPage() {
        reportCenter.SelectFileFromList();
    }

    @Then("I verify Download Icon of the report and click the download option")
    public void iVerifyDownloadIconOfTheReportAndClickTheDownloadOption() {
        reportCenter.VerifyDwnloadIcn();
    }

    @Then("I select Multiple files from the list")
    public void iSelectMultipleFilesFromTheList() {
        reportCenter.SelectMultipleCheckbox();
    }

    @Then("I verify the error message as {string} when selected more than ten files")
    public void iVerifyTheErrorMessageAsWhenSelectedMoreThanTenFiles(String arg0) {
        reportCenter.VerifyErrorMsgforDwnloadoptn();
    }

    @Then("I click on Hamburger menu and verify that Download Selected option is not available")
    public void iClickOnHamburgerMenuAndVerifyThatDownloadSelectedOptionIsNotAvailable() {
        reportCenter.VerifyDeleteSelectedOption();
    }

    @Then("I select multiple checkboxes of reports from the list and verify the selected report count in Download Selected option")
    public void iSelectMultipleCheckboxesOfReportsFromTheListAndVerifyTheSelectedReportCountInDownloadSelectedOption() {
        reportCenter.verifySelectedCountinMenu();
    }

    @Then("I click on Download Selected option from hamburger menu")
    public void iClickOnDownloadSelectedOptionFromHamburgerMenu() {
        reportCenter.selectDownloadSelected();
    }

    @Then("report should start downloading and verify report will be the zip file")
    public void reportShouldStartDownloadingAndVerifyReportWillBeTheZipFile() {
        reportCenter.verifyDownloadedZipFile();
    }

    @Then("I click on Delete Selected option and verify confirmation pop up message, Delete and cancel options")
    public void iClickOnDeleteSelectedOptionAndVerifyConfirmationPopUpMessageDeleteAndCancelOptions() {
        reportCenter.selectDeleteSelected();
    }

    @And("I click on cancel button to close popup")
    public void iClickOnCancelButtonToClosePopup() {
        JavaScriptClick(accountAlias.cancelBtnInMultipleAccAlias);
    }

    @And("I enter text in create alias textBox {string}")
    public void iEnterTextInCreateAliasTextBox(String arg0) {
        this.commonHelpers.thinkTimer(3000);
        this.enterText(accountAlias.createAliasInputNameMultipleAcc, arg0);
    }

    @And("I click on select dropDown")
    public void iClickOnSelectDropDown() {
        JavaScriptClick(accountAlias.selectAccountMultipleAccAlias);
    }

    @And("I validate selectAll functionality")
    public void iValidateSelectAllFunctionality() {
        accountAlias.validateSelectAllCheckBox();
    }


    @And("I validate already associated {string} account numbers are greyed out and are not available for next multiple account alias")
    public void iValidateAlreadyAssociatedAccountNumbersAreGreyedOutAndAreNotAvailableForNextMultipleAccountAlias(String arg0) {
        accountAlias.ValidateAccountNumsAssociatedScenario(arg0);
    }

    @And("I validate search account number results {string}")
    public void iValidateSearchAccountNumberResults(String arg0) {
        accountAlias.searchAccountNumberResultInMultipleAccountAlias(arg0);
    }

    @And("I search account by entering text {string}")
    public void iSearchAccountByEnteringText(String arg0) {
        this.enterText(accountAlias.searchBoxInsideSelectAccountNumber, arg0);
    }


    @And("I validate edit scenario of single account alias {string}")
    public void iValidateEditScenarioOfSingleAccountAlias(String arg0, DataTable table) {
        accountAlias.updatingSingleAccountAlias(table.asList(), arg0);
    }

    @And("I validate clicking on other edit without saving scenario alias {string}")
    public void iValidateClickingOnOtherEditWithoutSavingScenarioAlias(String arg0, DataTable table) {
        accountAlias.editSingleAccountAliasWithouSaving(table.asList(), arg0);
    }

    @And("I validate clicking on other add alias button without saving scenario alias {string}")
    public void iValidateClickingOnOtherAddAliasButtonWithoutSavingScenarioAlias(String arg0) {
        accountAlias.editAddAnAliasWithoutApplying(arg0);
    }


    @And("I validate editing with below values on single account alias {string}")
    public void iValidateEditingWithBelowValuesOnSingleAccountAlias(String arg0, DataTable table) {
        List<String> listOfAliasName = new ArrayList<>();
        listOfAliasName.add(arg0);
        accountAlias.editAccountAliasWithValues(listOfAliasName, table);
    }

    @And("validate the sorting for {string}")
    public void validateTheSortingFor(String ColumnName) {
        accountAlias.verifyTheIsSortable(ColumnName);
    }

    @Then("Validate the search functionality for AccountAlias with {string}")
    public void validateTheSearchFunctionalityForAccountAliasWith(String SearchText) {
        accountAlias.ValidateSearchAccountNumberOrAliasSaved(SearchText);
    }

    @Then("Validate the WaterMark for Search box")
    public void validateTheWaterMarkForSearchBox() {
        accountAlias.validateWaterMarkforSearchBar();
    }

    @And("I get UI Account And Alias")
    public void iGetUIAccountAndAlias() {
        accountAlias.storeAccountNumberAliasMapInContextStore();
    }


    @And("enter text in search box and validate the search results")
    public void enterTextInSearchBoxAndValidateTheSearchResults(DataTable table) {
        List<String> listOfSearches = table.asList();
        for (String search : listOfSearches) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.enterText(shipmentOverviewPage.filterSearchInput, search);
            this.commonHelpers.thinkTimer(6000);
            int sizeOfSearchList = this.findElements(accountAlias.aliasNamesInBillToSearchBox).size();
            accountAlias.searchBoxValidation(search, sizeOfSearchList);
        }
    }

    @And("I click on cancel button to close search box")
    public void iClickOnCancelButtonToCloseSearchBox() {
        JavaScriptClick(shipmentOverviewPage.filterCancelButton);
    }

    @And("I validate Search box is closed")
    public void iValidateSearchBoxIsClosed() {
        Assert.assertEquals(0, getCount(accountAlias.searchPopUpBox));
    }

    @And("I enter  continuous special charecter {string}")
    public void iEnterContinuousSpecialCharecter(String arg0) {
        this.enterText(shipmentOverviewPage.filterSearchInput, arg0);

    }

    @And("I validate alias name {string} is displayed beside account number")
    public void iValidateAliasNameIsDisplayedBesideAccountNumber(String arg0) {
        Assert.assertEquals(true, getText(By.xpath(String.format(accountAlias.aliasNameInSubscribedAccountsWRTAliasName, this.commonHelpers.getValuefromContextStore(arg0)))).contains(arg0));
    }

    @And("I click on aliasname {string} in Subscribed Accounts")
    public void iClickOnAliasnameInSubscribedAccounts(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.aliasNameInSubscribedAccountsWRTAliasName, this.commonHelpers.getValuefromContextStore(arg0))));
    }

    @And("I validate cross button icon and aliasname {string} in popup")
    public void iValidateCrossButtonIconAndAliasnameInPopup(String arg0) {
        Assert.assertEquals(true, elementIsPresent(accountAlias.deleteAliasModelPopupCloseIcn) && elementIsPresent(By.xpath(String.format(accountAlias.aliasNameInEditPopupSubscribedAccounts, arg0))));

    }


    @And("I validate aliasname {string} is selected")
    public void iValidateAliasnameIsSelected(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.selectedRowAliasNameSA, arg0))));
    }

    @And("I edit single account alias {string} with {string}")
    public void iEditSingleAccountAliasWith(String arg0, String arg1) {
        String accountNumber = (String) this.commonHelpers.getValuefromContextStore(arg0);
        accountAlias.editSingleAccountAlias(accountNumber, arg0, arg1);
        this.commonHelpers.AddToContextStore(arg1, accountNumber);
    }

    @And("I validate {string} edit is updated in Subscribed Accounts")
    public void iValidateEditIsUpdatedInSubscribedAccounts(String arg0) {
        String accountNumber = (String) this.commonHelpers.getValuefromContextStore(arg0);
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.aliasNameInSubscribedAccountsWRTAliasName, accountNumber))));
    }


    @And("I click on first add alias link and tag as {string}")
    public void iClickOnFirstAddAliasLinkAndTagAs(String arg0) {
        this.commonHelpers.AddToContextStore(arg0, getText(accountAlias.accountNumWRTFirstAddAliasLinkSA).split("[|, ?.@]+", 2)[0]);
        JavaScriptClick(accountAlias.addAliasFirstLinkSA);
    }

    @And("I validate account and alias name of {string} is separated by bar")
    public void iValidateAccountAndAliasNameOfIsSeparatedByBar(String arg0) {
        Assert.assertEquals(this.commonHelpers.getValuefromContextStore(arg0) + " | Add Alias", getText(accountAlias.accountNumVerticalBaraliasName));
    }

    @And("I validate pop up window closed")
    public void iValidatePopUpWindowClosed() {
        Assert.assertEquals(false, elementIsPresent(accountAlias.deletePopUpWindow));

    }

    @And("I validate {string} is selected")
    public void iValidateIsSelected(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.selectedRowAccountNumberSA, this.commonHelpers.getValuefromContextStore(arg0)))));
    }

    @And("I create Single account alias {string} for account number corresponding to {string}")
    public void iCreateSingleAccountAliasForAccountNumberCorrespondingTo(String arg0, String arg1) {
        String accountNum = (String) this.commonHelpers.getValuefromContextStore(arg1);
        JavaScriptClick(By.xpath(String.format(accountAlias.addAliasBtnWRTAccNum, accountNum)));
        this.enterText(accountAlias.inputAddAliasName, arg0);
        JavaScriptClick(accountAlias.applyButtonEnabled);
        this.commonHelpers.AddToContextStore(arg0, accountNum);
    }

    @And("I get UI Data from Account Alias Page")
    public void iGetUIDataFromAccountAliasPage() {
        accountAlias.getAccounAliasTable();
    }

    @And("I validate both UI Data Subscribed Account page")
    public void iValidateBothUIDataSubscribedAccountPage() {
        accountAlias.validate_details_AccountAlias_And_SubscribeAccounts();
    }

    @Then("I Navigate or Apply filters by {string} filter options")
    public void iNavigateOrApplyFiltersByFilterOptions(String arg0) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.selectFilterOptions(arg0);
        }
    }

    @Then("Hover on the Export Option and the validate the {string} question mark Hyperlink and Popup or New Page Screen for 60000 Records")
    public void hoverOnTheExportOptionAndTheValidateTheQuestionMarkHyperlinkAndPopupNewPageScreen(String FieldName) {
        this.shipmentDetails.validateExportQuestionIcon_Popup(FieldName);
    }

    @Then("Hover on the Export Option and the validate the {string} question mark Hyperlink and Popup or New Page Screen for greater than 60000 Records")
    public void hoverOnTheExportOptionAndTheValidateTheQuestionMarkHyperlinkAndPopupOrNewPageScreenForGreaterThanRecords(String FieldName) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentDetails.validateExportQuestionIcon_PopupInvalidScenario(FieldName);
        }
    }

    @And("remove the filter bubble")
    public void removeTheFilterBubble() {
        this.shipmentDetails.removebubble();
    }

    @And("I validate Alias And Account Numbers from Account alias Page to My Shipments page")
    public void iValidateAliasAndAccountNumbersFromAccountAliasPageToMyShipmentsPage() {
        accountAlias.validateValuesAliasNameFromAccountAliasToShipment();

    }

    @When("^I click on the \"([^\"]*)\" button for combined files$")
    public void i_click_on_the_button_for_combined_files(String buttonText) {
        this.shipmentDetails.clickOnDownloadButton(buttonText);
    }

    @When("I click on {string} link and add a location for OD pair")
    public void iClickOnLinkAndAddALocationForODPair(String link, DataTable table) throws Throwable {
        commonHelpers.thinkTimer(2000);
        this.ScrollToTop();
        List<String> cities = table.asList(String.class);
        for (String city : cities) {
            //   this.advisoryPage.clickOnLocationLink(link);
            this.advisoryPage.addODPairLocation(link, city);
        }
    }

    @And("I click on {string} link in OD pair")
    public void iClickOnLinkInODPair(String link) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.advisoryPage.clickOnApplyButton(link);
            this.waitUntilNotVisible(this.loadingIndicator);
            ScrollByOffset("0", "300");
            this.commonHelpers.thinkTimer(4000);
        }
    }

    @Then("I {string} filter options for OD pair")
    public void iFilterOptionsForODPair(String cancelOrApply, DataTable dataTable) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.advisoryPage.selectOrDeselectODFilter(cancelOrApply, dataTable);
        }
    }

    @When("I click on the {string} option for record {string}")
    public void iClickOnTheOption(String filterOption, String record) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (record.contains("Context-")) {
                record = String.valueOf(this.commonHelpers.getValuefromContextStore(record));
            }
            this.advisoryPage.clickOnOption(filterOption, record);
        }
    }

    @Then("I verify a search box appears with placeholder {string} and search icon for OD pair")
    public void iVerifyASearchBoxAppearsWithPlaceholderAndSearchIconForODPair(String placeholderText) throws Throwable {
        Assert.assertTrue(this.advisoryPage.validateODFilterSearchTextAndIcon(placeholderText));
    }

    @And("I search for below in filter search and validate result for OD pair")
    public void iSearchForInFilterSearchAndValidateResultForODPair(DataTable table) throws Throwable {
        this.advisoryPage.validateODFilterSearchAndResult(table);
    }

    @Then("I verify filter bubble in OD page")
    public void iVerifyFilterBubbleInODPage(DataTable table) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            Assert.assertTrue("Filter Bubble verification failed",
                    this.advisoryPage.ValidateFilterBubble(table));
        }
    }

    @Then("I verify the error message as {string} when wrong OD pair is provided")
    public void iVerifyTheErrorMessageAsWhenWrongODPairIsProvided(DataTable dataTable) throws Throwable {
        Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
        Assert.assertTrue("OD pair Not Macthed",
                this.advisoryPage.VerifyErrorMsgODPair("WrongODPair",
                        messageTable.get("WrongODPair")));
    }

    @And("Verify error message for OD pair")
    public void verifyErrorMessageForODPair(DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Map<String, String> messageTable = dataTable.asMap(String.class, String.class);
            for (String expkey : messageTable.keySet()) {
                Assert.assertTrue("Error Message not matched",
                        this.advisoryPage.VerifyErrorMsgODPair(expkey, messageTable.get(expkey)));
            }
        }
    }

    @When("I click on {string} link and remove a location for OD pair")
    public void iClickOnLinkAndRemoveALocationForODPair(String link) throws Throwable {
        commonHelpers.thinkTimer(2000);
        this.ScrollToTop();
        this.advisoryPage.removeODPairLocation(link);
    }

    @When("I click on the {string} link")
    public void iClickOnTheLink(String linkText) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            ScrollByOffset("0", "300");
            this.advisoryPage.clickOnlink(linkText);
        }
    }

    @And("I verify {string} icon is {string} in OD pair page")
    public void iVerifyIconIsInODPairPage(String icon, String check) throws Throwable {
        Assert.assertTrue(icon + ": Icon is not matched with shipments records",
                this.advisoryPage.verifyODIcon(icon, check));
    }

    @When("I verify element {string} with index {string} is present")
    public void iVerifyElementWithIndexSPresent(String text, String index) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (text.contains("Context-")) {
                text = String.valueOf(this.commonHelpers.getValuefromContextStore(text));
            }
            this.elementIsPresentWithIndex(text, index);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @Then("I fetch ODPairResultCount {string} for OD pair")
    public void fetchODPairResultCountForODPair(String ODPairResult)
            throws Throwable {
        this.advisoryPage.pairODCount(ODPairResult);
    }

    @And("I verify {string} column is present")
    public void iVerifyColumnIsPresent(String arg0) {
        boolean flag = false;
        List<WebElement> listOfcolumnHeader = this.findElements(shipmentOverviewPage.columnHeaders);
        for (WebElement element : listOfcolumnHeader) {
            flag = flag || (getText(element).equalsIgnoreCase(arg0));
        }
        Assert.assertEquals(true, flag);
    }

    @And("I verify {string} checkBox is disabled")
    public void iVerifyCheckBoxIsDisabled(String arg0) {
        Assert.assertEquals(1, getCount(By.xpath(String.format(shipmentOverviewPage.disabledCheckBox, arg0))));
    }

    @And("I verify {string} checkBox is enabled")
    public void iVerifyCheckBoxIsEnabled(String arg0) {
        Assert.assertEquals(0, getCount(By.xpath(String.format(shipmentOverviewPage.disabledCheckBox, arg0))));
    }

    @And("I verify tool tip text inside search box {string}")
    public void iVerifyToolTipTextInsideSearchBox(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(shipmentOverviewPage.containerConsInputTextSearchBox, arg0))));

    }

    @And("I verify search functionality of the filter")
    public void iVerifySearchFunctionalityOfTheFilter(DataTable table) {
        List<String> listOfValuesToBeSearched = table.asList();
        shipmentOverviewPage.verifySearchedResultsOfContainerColumns(listOfValuesToBeSearched);
    }

    @And("I verify Contains Cols link")
    public void iVerifyContainsColsLink() {
        List<WebElement> listOfLinks = this.findElements(shipmentOverviewPage.containerColumnsLinks);
        for (WebElement element : listOfLinks) {
            Assert.assertEquals(true, getAttributeValue(element, "href").contains(getText(element)));
        }
    }

    @And("I select difference and verify date range shown in format {string}")
    public void iSelectDifferenceAndVerifyDateRangeShownInFormat(String arg0) {
        advisoryPage.selectingDaysAndvalidateDates(arg0);
    }

    @And("I click on the new kebab icon")
    public void iClickOnTheNewKebabIcon() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.Mouse_MoveToElement(this.findElement(advisoryPage.kebabIcn));
        }
    }

    @And("I move to {string} menu")
    public void iMoveToMenu(String arg0) {
        this.Mouse_MoveToElement(By.xpath(String.format(advisoryPage.scheduleReportMenuLink, arg0)));
        Assert.assertEquals(true, elementIsDisplayed(By.xpath(String.format(advisoryPage.scheduleReportMenuLink, arg0))));

    }

    @And("I click on link beside schedule reports")
    public void iClickOnLinkBesideScheduleReports() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.Mouse_MoveToElementClick(advisoryPage.ScheduleReportLink);
        }
    }

    @And("I select {string} days span from dropdown")
    public void iSelectDaysSpanFromDropdown(String arg0) {
        this.selectDropdown(advisoryPage.selectDrpDownDays, "text", arg0);

    }

    @And("I verify if there is {string} Text In grid")
    public void iVerifyIfThereIsTextInGrid(String arg0) {
        if (elementIsDisplayed(this.getByusingString(this.buildGenericXpathForString(arg0, "")))) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }


    @And("I give report name as {string}")
    public void iGiveReportNameAs(String arg0) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.enterText(reportCenter.scr_TxtBox_Report_ReportName, arg0);
            this.commonHelpers.thinkTimer(6000);
        }
    }

    @And("I click on delete button")
    public void iClickOnDeleteButton() {
        JavaScriptClick(reportCenter.scr_btn_delete);
    }

    @And("I {string} the filters with selected days {string} using below conditions for advisories")
    public void iTheFiltersWithSelectedDaysUsingBelowConditionsForAdvisories(String cancelOrApply, String date, DataTable table)
            throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            // Assert.assertTrue("Something went wrong in selection of filter in UI");
            this.advisoryPage.SelectFilterforAdvisorieswithDate(cancelOrApply, table, date);
        }
    }

    @Given("^I select the filters using below conditions and verify filter Bubble$")
    public void i_select_the_filters_using_below_conditions_and_verify_filter_Bubble(DataTable table) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Something went wrong in selection of filter in UI or during filter bubble validation",
                    this.shipmentOverviewPage.SelectFilter(table));
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("Select the Account as per search result")
    public void selectTheAccountAsPerSearchResult() {
        this.accountAlias.click_checkbox();
    }

    @Then("I verify filter bubble {string}")
    public void iVerifyFilterBubble(String filtername) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.accountAlias.bubbleFilter(filtername);
    }

    @And("I validate exceldata with Search text {string}")
    public void iValidateExceldataWithSearchText(String arg0) throws IOException {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.accountAlias.ValidateValuesfromExcel_IgnoringBlankCells(arg0);
    }

    @And("I validate exceldata and count for sheet {string}")
    public void iValidateExceldataAndCountForSheet(String SheetName) throws IOException {
        int count = this.accountAlias.validateExcelWithCount(SheetName);
        String viewcount = this.shipmentDetails.getViewingCount();
        Assert.assertEquals(count, Integer.parseInt(viewcount));
    }

    @And("I click on clustered OD pair map")
    public void iClickOnClusteredODPairMap() throws Throwable {
        this.commonHelpers.thinkTimer(2000);
        ScrollByOffset("0", "90");
        this.advisoryPage.JavaScriptClick(this.advisoryPage.ODclustermap);
        this.commonHelpers.thinkTimer(6000);
    }

    @And("I click on the expand icon beside multiple account alias {string}")
    public void iClickOnTheExpandIconBesideMultipleAccountAlias(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.accountAliasNameExpansionBtn, arg0)));
    }

    @And("I validate {string} button is disabled")
    public void iValidateButtonIsDisabled(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.disabledButton, arg0))));
    }

    @And("I click on first linked account number in multiple account alias {string}")
    public void iClickOnFirstLinkedAccountNumberInMultipleAccountAlias(String arg0) {
        JavaScriptClick(By.xpath(String.format(accountAlias.firstCheckBoxAccNumOfSavedMultipleAccountAlias, arg0)));
    }

    @And("I validate {string} button is enabled")
    public void iValidateButtonIsEnabled(String arg0) {
        Assert.assertEquals(true, elementIsPresent(By.xpath(String.format(accountAlias.enabledButton, arg0))));

    }

    @And("I click on element account number dropdown")
    public void iClickOnElementAccountNumberDropdown() {
        JavaScriptClick(accountAlias.accountNumberDropDownExpandAndCollapse);
    }

    @And("I validate no change in account numbers")
    public void iValidateNoChangeInAccountNumbers() {
        List<WebElement> selectedAccountNums = this.findElements(accountAlias.listOfEnabledChkedChkBox);
        for (WebElement element : selectedAccountNums)
            Assert.assertEquals(true, this.commonHelpers.verifyKeyinContextStore(element.getAttribute("value")));
    }

    @And("validate the default Message in filter popup")
    public void validateTheDefaultMessageInFilterPopup() {
        this.reportCenter.defaultMessageInFilter();
    }

    @And("I select checkBox in My Shipment Filters having value {string}")
    public void iSelectCheckBoxInMyShipmentFiltersHavingValue(String arg0) {
        this.commonHelpers.AddToContextStore(arg0, getAttributeValue(By.xpath(String.format(shipmentOverviewPage.checkBoxMyShipmentsFilterAliasName, arg0)), "value"));
        JavaScriptClick(By.xpath(String.format(shipmentOverviewPage.checkBoxMyShipmentsFilterAliasName, arg0)));
    }

    @And("I add single account allias on random account number")
    public void iAddSingleAccountAlliasOnRandomAccountNumber(DataTable table) {
        accountAlias.addSingleAccountAlias(table.asList());
    }

    @Then("I validate column Shipper Account Number column")
    public void iValidateColumnShipperAccountNumberColumn() {
        List<WebElement> listOfElements = this.findElements(shipmentOverviewPage.shipperAccountNumberColumnData);
        for (WebElement element : listOfElements) {
            if (element.getText().length() > 0 && !(element.getText().contains("x"))) {
                String accountNum = element.getText().split("[|, ?.@]+", 2)[0];
                String aliasName = element.getText().split("[|, ?.@]+", 2)[1];
                Assert.assertEquals(true, this.commonHelpers.verifyKeyInContextStore(accountNum) && this.commonHelpers.getValuefromContextStore(accountNum).toString().contains(aliasName));
            }
        }
    }

    @And("I validate column Bill To \\(Transportation) column")
    public void iValidateColumnBillToTransportationColumn() {
        for (WebElement element : this.findElements(shipmentOverviewPage.billToColumn)) {
            if (element.getText().length() > 0 && !(element.getText().contains("x"))) {
                String accountNum = element.getText().split("[|, ?.@]+", 2)[0];
                String aliasName = element.getText().split("[|, ?.@]+", 2)[1];
                Assert.assertEquals(true, this.commonHelpers.verifyKeyInContextStore(accountNum) && this.commonHelpers.getValuefromContextStore(accountNum).toString().contains(aliasName));
            }
        }
    }

    @And("I remove all filters")
    public void iRemoveAllFilters() {
        int count = getCount(shipmentOverviewPage.filterCloseCrossIcn);
        for (int iter = 0; iter < count; iter++) {
            if (elementIsPresent(shipmentOverviewPage.filterCloseCrossIcn)) {
                JavaScriptClick(shipmentOverviewPage.firstfilterCloseIcon);
                this.commonHelpers.thinkTimer(2000);
            } else break;
        }
    }


    @And("I validate all checkboxes are selected")
    public void iValidateAllCheckboxesAreSelected() {
        List<WebElement> ListOfChecBoxes = this.findElements(accountAlias.accountAliasCheckBox);
        for (WebElement element : ListOfChecBoxes) {
            Assert.assertEquals(true, getAttributeValue(element, "aria-checked").contains("true"));
        }
    }

    @And("I get account number for valid export icon active {string}")
    public void iGetAccountNumberForValidExportIconActive(String arg0) {
        shipmentOverviewPage.findRecordsForExportIcnEnabled(arg0);
    }


    @And("I validate excel column {string} in excel with sheetname {string}")
    public void iValidateExcelColumnInExcelWithSheetname(String arg0, String arg1) throws IOException {
        shipmentOverviewPage.validateExcelColumn(arg0, arg1);
    }


    @And("I validate CSV column {string} in csv")
    public void iValidateCSVColumnInCsv(String arg0) throws IOException, CsvException {
        shipmentOverviewPage.validateCSVDataColumn(arg0);
    }

    @And("I click on first Tracking number")
    public void iClickOnFirstTrackingNumber() {
        if (elementIsDisplayed(shipmentOverviewPage.firstTrackingNum)) {
            this.commonHelpers.AddToContextStore("TrackingNum", getText(shipmentOverviewPage.firstTrackingNum));
            JavaScriptClick(shipmentOverviewPage.firstTrackingNum);
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @And("I store Shipper account number information")
    public void iStoreShipperAccountNumberInformation() {
        String Tnum = (String) this.commonHelpers.getValuefromContextStore("TrackingNum");
        this.commonHelpers.AddToContextStore("TrackingNum", Tnum + "|" + getText(shipmentOverviewPage.shipmentTrackingAccNumAliasNameInfo));
    }

    @And("I click on the link beside account number")
    public void iClickOnTheLinkBesideAccountNumber() {
        JavaScriptClick(shipmentOverviewPage.aliasNameLink);
    }

    @And("I modify alias name with that account number with {string}")
    public void iModifyAliasNameWithThatAccountNumberWith(String arg0) {
        shipmentOverviewPage.modifyAliasName(arg0);
    }

    @And("I validate details in shipment account number section")
    public void iValidateDetailsInShipmentAccountNumberSection() {
        String accountNumber = this.commonHelpers.getValuefromContextStore("TrackingNumNew").toString().split("[|,?.@]+")[1];
        String aliasName = this.commonHelpers.getValuefromContextStore("TrackingNumNew").toString().split("[|,?.@]+")[2];
        Assert.assertEquals(true, getText(shipmentOverviewPage.shipmentAccNumInfo).contains(accountNumber) && getText(shipmentOverviewPage.shipmentAliasNameInfo).contains(aliasName));
    }

    @And("I click on element {string}")
    public void iClickOnElement(String arg0) {
        JavaScriptClick(shipmentOverviewPage.yesBtnInPopUp);
    }


    @And("I check the count in My shipments is more than zero {string}")
    public void iCheckTheCountInMyShipmentsIsMoreThanZero(String arg0, DataTable table) {
        shipmentOverviewPage.checkAndApplyFilters(arg0, table);
    }

    @And("I wait for loading indicator")
    public void iWaitForLoadingIndicator() {
        this.waitUntilNotVisible(this.loadingIndicator);
    }

    @And("I validate End Date is greater Than Start Date in grid")
    public void iValidateEndDateIsGreaterThanStartDateInGrid() {
        shipmentOverviewPage.validateTimeInColumn();
    }

    @And("I click on element {string} checkBox")
    public void iClickOnElementCheckBox(String arg0) {
        JavaScriptClick(shipmentOverviewPage.noCheckBox);
    }

    @And("I delete {string} file in download center")
    public void iDeleteFileInDownloadCenter(String fileName) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            waitUntilNotVisible(loadingIndicator);
            JavaScriptClick(By.xpath(String.format(shipmentOverviewPage.deleteIcnBesideFileName, fileName)));
            JavaScriptClick(shipmentOverviewPage.deleteBtnInPopUp);
        }
    }

    @And("I store date for first tracking number")
    public void iStoreDateForFirstTrackingNumber() {
        shipmentOverviewPage.storeFirstTrackingNumberDetails();
    }

    @And("I validate details {string} section")
    public void iValidateDetailsSection(String arg0) {
        if (!(this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps))) {
            if (this.commonHelpers.getValuefromContextStore("DateTrackingNum").toString().length() > 0) {
                Assert.assertEquals(true, getText(By.xpath(String.format(shipmentOverviewPage.scheduledDeliveryText, arg0))).contains(this.commonHelpers.getValuefromContextStore("DateTrackingNum").toString()));
            }
        }
    }

    @And("Validate the below text not displayed on purplebar")
    public void validateTheBelowTextNotDisplayedOnPurplebar(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                Assert.assertFalse("The value : " + validation + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForStringforPurpleBar(validation, ""))));

            }

        }
    }

    @And("Validate the below text on the purplebar")
    public void validateTheBelowTextOnThePurplebar(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            commonHelpers.thinkTimer(500);
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                if (!genericFunObj.locale.equalsIgnoreCase(Constants.EN_US)) {
                    validation = this.genericFunObj.getLocalizedValue(validation);
                }
                Assert.assertTrue("The value : " + validation + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForStringforPurpleBar(validation, "")), false));
            }
        }

    }

    @And("Validate the below text on the Audit table")
    public void validateTheBelowTextOnTheAuditTable(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            commonHelpers.thinkTimer(500);
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                if (!genericFunObj.locale.equalsIgnoreCase(Constants.EN_US)) {
                    validation = this.genericFunObj.getLocalizedValue(validation);
                }
                this.scrollHorizontalBarOnPage("900");
                commonHelpers.thinkTimer(500);
                if (validation == "FAVORITE") {
                    Assert.assertTrue("The value : " + validation + " Doesnot matches ", this.getText(this.reportCenter.Auditfavname).contains("FAVORITE"));
                } else if (validation == "VIEW") {
                    Assert.assertTrue("The value : " + validation + " Doesnot matches ", this.getText(this.reportCenter.Auditviewname).contains("VIEW"));
                }

            }
        }
    }


    @And("I click on first hyperlink in the report list")
    public void iClickOnFirstHyperlinkInTheReportList() {
        this.commonHelpers.thinkTimer(2500);
        JavaScriptClick(shipmentDetails.first_SC_report_HyperLink);
    }

    @And("I click on edit icon with index {string}")
    public void iClickOnEditIconWithIndex(String arg0) {
        this.commonHelpers.thinkTimer(2500);
        JavaScriptClick(By.xpath(String.format(shipmentDetails.editPencilIcnInReportPage, arg0)));
    }

    @And("I validate Report Type field is not editable")
    public void iValidateReportTypeFieldIsNotEditable() {
        this.selectDropdown(shipmentDetails.reportTypeDrpDwn, "value", "1: Pre-Shipment Weather Advisory Report");
        Assert.assertEquals(false, this.findElement(shipmentDetails.preShipmentOptionReportTypeDrpDwn).isSelected());
    }

    @And("I validate View Field is not editable")
    public void iValidateViewFieldIsNotEditable() {
        JavaScriptClick(shipmentDetails.chooseViewDrpDwn);
        Assert.assertEquals(false, elementIsPresent(shipmentDetails.chooseViewSearchBox));
    }

    @And("I click on the kebab icon beside favorite {string}")
    public void iClickOnTheKebabIconBesideFavorite(String arg0) {
        advisoryPage.clickOnKebabIcnOfFavorites(arg0);
    }

    @And("I click on trash icn for favorite")
    public void iClickOnTrashIcnForFavorite() {
        JavaScriptClick(advisoryPage.trashIcnToDeleteFavorite);
    }

    @And("I enter new name {string}")
    public void iEnterNewName(String favName) {
        this.enterText(By.xpath(advisoryPage.FavNameInput), favName);
    }

    @When("I Verify the Column for {string} is as per the format FName LName FedExID")
    public void iVerifyTheColumnForWithIndexIsAsPerTheFormatFNameLNameFedExID(String text) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (text.contains("Context-")) {
                text = String.valueOf(this.commonHelpers.getValuefromContextStore(text));
            }
            this.reportCenter.columnName(text);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("I add below OD  Pair {string} and {string}")
    public void iAddBelowODPairAnd(String arg0, String arg1, DataTable table) {
        advisoryPage.addOriginAndDestination(arg0, arg1, table);
    }

    @And("I validate purple location have {string} pointers")
    public void iValidatePurpleLocationHavePointers(String arg0) {
        Assert.assertTrue("Validation for count of Pair of OD Pairs location pointer", getText(advisoryPage.ODClustorPurplePoint).toString().contains(arg0));
    }

    @And("I click on purple location pointer")
    public void iClickOnPurpleLocationPointer() {
        JavaScriptClick(advisoryPage.ODClustorPurplePoint);
        Assert.assertTrue(" Validation for flyout to open", elementIsDisplayed(advisoryPage.mapFlyOutPopUp));
    }

    @And("I validate count of flyout is {string}")
    public void iValidateCountOfFlyoutIs(String arg0) {
        Assert.assertTrue("Validation for number of flyouts with pair of od pairs", getCount(advisoryPage.flyOutHeader) == Integer.parseInt(arg0));
    }

    @And("I validate order of flyouts")
    public void iValidateOrderOfFlyouts(DataTable table) {
        advisoryPage.validateOrderOfFlyouts(table);
    }

    @And("I validate flyouts headers with origin and destination location")
    public void iValidateFlyoutsHeadersWithOriginAndDestinationLocation() {
        advisoryPage.validateHeaderAddressWithOriginAndDestination();
    }

    @And("I click on purple location pointer until flyout popup and verify header")
    public void iClickOnPurpleLocationPointerUntilFlyoutPopupAndVerifyHeader() {
        advisoryPage.clickUntilFlyoutPopUpAndVerify();
    }

    @And("verify the column name in Shipment page {string}")
    public void verifyTheColumnNameInShipmentPage(String colName) throws InterruptedException {
        this.shipmentOverviewPage.getColumnNames(colName);
    }

    @Then("validating the Recipient Address as per the format")
    public void validatingTheRecipientAddressAsPerTheFormat() throws InterruptedException {
        this.shipmentOverviewPage.RecipientAddressValidation();
    }

    @And("I validate flyout is opened")
    public void iValidateFlyoutIsOpened() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            JavaScriptClick(advisoryPage.ODClustorPurplePoint);
            advisoryPage.validateFlyOutExpand();
        }
    }

    @And("I get the count of links and validate with number of sevice types")
    public void iGetTheCountOfLinksAndValidateWithNumberOfSeviceTypes() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.commonHelpers.AddToContextStore("numberOfServiceTypes", Integer.parseInt(getText(advisoryPage.countOfServices).split(" ")[0].substring(1)));
            JavaScriptClick(advisoryPage.countOfServices);
            Assert.assertTrue("Validation of count of service types", getText(advisoryPage.listOfServicesTxt).split(",").length == (Integer) this.commonHelpers.getValuefromContextStore("numberOfServiceTypes") + 1);
        }
    }

    @And("I validate service types are sorted alphabetically")
    public void iValidateServiceTypesAreSortedAlphabetically() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            advisoryPage.validateSortingOfServices();
        }
    }

    @And("I select {string} accounts from dropdown")
    public void iSelectAccountsFromDropdown(String arg0) {
        accountAlias.selectAccountNumber(Integer.parseInt(arg0));
    }

    @Then("Verify the {string} Button is Disabled on Get Status Updates page")
    public void verifyTheButtonIsDisabledOnGetStatusUpdatesPage(String Button) {
        this.shipmentDetails.ValidateTheButtonIsDisabled(Button);
    }

    @And("Verify the Error Field Validation message for Name and Email field")
    public void verifyTheErrorFieldValidationMessageForNameAndEmailField() {
        this.shipmentDetails.validationforNameEmailField();
    }

    @And("Verify the SUBMIT Button on Get Status Updates page")
    public void verifyTheSUBMITButtonOnGetStatusUpdatesPage() {
        this.shipmentDetails.ValidateTheSubmitButton();
    }

    @And("Verify the CANCEL Button on Get Status Updates page")
    public void verifyTheCANCELButtonOnGetStatusUpdatesPage() {
        this.shipmentDetails.ValidateTheCancelButton();
    }

    @And("Validate the {string} text on the screen")
    public void validateTheTextOnTheScreen(String text) {
        this.shipmentDetails.LabelValidationInGetStatusUpdates(text);
    }

    @And("I select {string} region from dropdown")
    public void iSelectRegionFromDropdown(String Region) throws Throwable {
        this.shipmentOverviewPage.SelectValuesFromRegionDD(Region);
    }

    @And("I click on edit icon on my view {string}")
    public void iClickOnEditIconOnMyView(String viewName) {
        this.shipmentOverviewPage.clickOnEditIconView(viewName);
    }

    @And("I validate order of columns")
    public void iValidateOrderOfColumns() {
        shipmentOverviewPage.verifyAlphabeticallyOrdersInColumnsInGrid();
    }

    @And("validate the {string} button status is {string}")
    public void validateButtonStatus(String button, String state) {
        this.shipmentOverviewPage.validatetheButtonStatus(state, button);
    }

    @Then("validate the SearchBar label Search e.g. HEX or HOPS")
    public void validateTheSearchBarLabelSearchEGHEXOrHOPS() {
        this.shipmentOverviewPage.SearchBarValidation();
    }

    @And("Enter text in Search field {string} and validate the Search Results")
    public void enterTextInSearchFieldAndValidateTheSearchResults(String searchtext) {
        this.shipmentOverviewPage.SearchResultsValidation(searchtext);
    }

    @Then("I verify {string} filter in my shipments page with {string}")
    public void iVerifyFilterInMyShipmentsPageWith(String Filter, String SearchText) {
        this.shipmentOverviewPage.LastEventFilterValidation(Filter, SearchText);
    }

    @Then("I click on {string} button of delete confirmation pop up on pre shipment screen")
    public void iClickOnButtonOfDeleteConfirmationPopUpOnPreShipmentScreen(String button) {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.advisoryPage.clickOnCancelOrDeleteElementofDeleteFavorite(button);
    }

    @Then("Verify the column {string} is displayed in my shipment page")
    public void verifyTheColumnIsDisplayedInMyShipmentPage(String ColumnName) throws ParseException {
        this.shipmentOverviewPage.verifyTheIsDisplayedForEachColumn(ColumnName);
    }

    @And("I click on column header {string} in My Shipments")
    public void iClickOnColumnHeaderInMyShipments(String arg0) {
        JavaScriptClick(By.xpath(String.format(shipmentOverviewPage.columnHeader, arg0)));
    }


    @When("I click on {string} for OD pair")
    public void iClickOnForODPair(String link, DataTable table) {
        commonHelpers.thinkTimer(2000);
        this.ScrollToTop();
        List<String> cities = table.asList(String.class);
        for (String city : cities) {
            this.advisoryPage.ODPairLocation(link, city);
        }
    }

    @And("I click on report type dropdown")
    public void iClickOnReportTypeDropdown() {
        this.reportCenter.reportTypeDropdown();
    }

    @Then("I verify Delete, Set as Default, Clear Default options for in kebab menu")
    public void iVerifyDeleteSetAsDefaultClearDefaultOptionsForInKebabMenu() {
        this.advisoryPage.KebobMenuButtons();
    }

    @Then("I verify {string} favorite is {string} in the favorites list")
    public void iVerifyFavoriteIsInTheFavoritesList(String FavName, String Action) {
        this.advisoryPage.FavName(FavName, Action);
    }

    @When("I click on CheckBox {string} with index {string} to make it {string}")
    public void iClickOnCheckBoxWithIndex(String text, String index, String Action) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (text.contains("Context-")) {
                text = String.valueOf(this.commonHelpers.getValuefromContextStore(text));
            }
            this.verifyCheckBox_PerformAction(this.getByusingString(this.buildGenericXpathForString(text, index)), Action);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("I verify number of records is valid")
    public void iVerifyNumberOfRecordsIsValid() {
        if (getText(shipmentOverviewPage.getViewCount).split("/")[0].trim().equals("0") || getText(shipmentOverviewPage.getViewCount).split("/")[0].trim().length() > 4) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Then("Validate the links View on Dashboard, View Account Summary, View in My Shipments on the overview page")
    public void validateTheLinksViewOnDashboardViewAccountSummaryViewInMyShipmentsOnTheOverviewPage() {
        this.shipmentOverviewPage.OverViewPageLinksValidation();
    }

    @Then("validate the count wrt to {string} page")
    public void validateTheCountWrtToPage(String name) {
        this.shipmentOverviewPage.validationofCountWrtOverViewpage_otherPage(name);
    }


    @When("I verify the default dropdown is selected as Shipment Report")
    public void iVerifyTheDefaultDropdownIsSelectedAsShipmentReport() {
        this.reportCenter.verifyReportTypeDefaultValue();
    }


    @Then("I verify the options in ReportType dropdown")
    public void iVerifyTheOptionsInReportTypeDropdown(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> options = table.asList(String.class);
            this.reportCenter.VerifydropdownoptionsforReportType(options);
        }
    }

    @And("I click on the Edit Icon for {string}")
    public void iClickOnTheEditIconFor(String FieldName) {
        this.reportCenter.EditIconInScheduledReportDetails(FieldName);
    }

    @Then("validate the errormessage with pre-existing report name {string}")
    public void validateTheErrormessageWithPreExistingReportName(String reportname) {
        this.reportCenter.validateReportNameError(reportname);
    }

    @And("Verify the More Arrow is pointed {string}")
    public void verifyTheMoreArrowIsPointed(String Action) {
        this.advisoryPage.validatetheMoreArrow(Action);
    }

    @Then("validate the Filter count {string} clicking on more")
    public void validateTheFilterCountClickingOnMore(String Action) {
        this.advisoryPage.validatetheFilterCount(Action);
    }

    @Then("user saves the first displayed Record with Name {string} in pre-shipment advisory")
    public void userSavesTheFirstDisplayedRecordWithNameInPreShipmentAdvisory(String name) {
        this.advisoryPage.storeFirstRecord(name);
    }

    @And("I click on Set as Default icn for favorite")
    public void iClickOnSetAsDefaultIcnForFavorite() {
        JavaScriptClick(advisoryPage.SetasDefToFavorite);
    }

    @Then("I click on {string} button on pre shipment page popup")
    public void iClickOnButtonOnPreShipmentPagePopup(String Action) {
        this.advisoryPage.ActioninPreshipmentPopup(Action);
    }

    @And("Remove the Filter for {string}")
    public void removeTheFilterFor(String FilterName) {
        this.advisoryPage.RemoveFilterBasedonName(FilterName);
    }

    @When("I verify key {string} with value {string}")
    public void iVerifyKeyWithValue(String Key, String value) {
        this.reportCenter.getvalueBasedOnKey(Key, value);
    }

    @Then("I select filter options for Advisories")
    public void iFilterOptionsForAdvisories(DataTable dataTable) throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.advisoryPage.selectFilterWithCritera(dataTable);
        }
    }

    @Then("I verify and validate the State or Territory are displayed in {string} view and validate the records")
    public void iVerifyAndValidateTheStateOrTerritoryAreDisplayedInViewAndValidateTheRecords(String arg0) {
        this.commonHelpers.thinkTimer(2000);
        String state = this.getText(advisoryPage.CurrentStateName);
        JavaScriptClick(advisoryPage.advisories_LocationSearch);
        this.enterText(advisoryPage.advisories_LocationSearch, state.trim());
        this.JavaScriptClick(advisoryPage.searchResult);
        this.waitUntilNotVisible(this.loadingIndicator);
        advisoryPage.verifySlider();
        this.commonHelpers.thinkTimer(5000);
        this.advisoryPage.validateTheResult(state);
    }

    @Then("validate {string} option is {string}")
    public void validateOptionIs(String Option, String status) {
        this.advisoryPage.validatetheButtonStatus(Option, status);
    }

    @Then("Click on {string} link in Pre-shipment advisories page")
    public void clickOnLinkInPreShipmentAdvisoriesPage(String linkname) {
        this.advisoryPage.validateTheLandingPageforKebablinks(linkname);
    }

    @When("I verify the ReportType is non-editable")
    public void iVerifyTheReportTypeIsNonEditable() {
        this.reportCenter.verifyNonEditableForReportType();
    }

    @And("I click on the {string} quick card")
    public void iClickOnTheQuickCard(String cardname) {
        this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.clilckQuickView, cardname)));
        this.waitUntilNotVisible(this.loadingIndicator);
    }


    @Then("user saves the first displayed Shipper Account Record with Name {string}")
    public void userSavesTheFirstDisplayedShipperAccountRecordWithName(String name) {
        this.shipmentDetails.getShipperAccountNumber(name);
    }

    @Then("I search Record {string} in Accounts Alias page")
    public void iSearchRecordInAccountsAliasPage(String recordname) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (recordname.contains("Context-")) {
                recordname = String.valueOf(this.commonHelpers.getValuefromContextStore(recordname));
            }
            this.accountAlias.searchAccountNumberOrAliasSaved(recordname);
            this.waitUntilNotVisible(this.loadingIndicator);
        }
    }

    @And("I save single account alias with {string}")
    public void iSaveSingleAccountAliasWith(String AliasName) {
        this.commonHelpers.thinkTimer(5000);
        JavaScriptClick(accountAlias.addAnAliasFirstBtn);
        this.commonHelpers.thinkTimer(5000);
        this.enterText(accountAlias.inputAddAliasName, AliasName);
        this.commonHelpers.thinkTimer(5000);
        JavaScriptClick(accountAlias.applyButtonEnabled);
    }

    @And("Validate the below text not displayed on Audit table")
    public void validateTheBelowTextNotDisplayedOnAuditTable(DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> validationText = table.asList(String.class);
            for (String validation : validationText) {
                Assert.assertFalse("The value : " + validation + " Doesnot matches ", this.elementIsDisplayed(this.getByusingString(this.buildGenericXpathForStringforAuditTable(validation, ""))));

            }

        }
    }


    @And("I add second account allias with name valid values")
    public void iClickOnSecondAccountAlias(DataTable table) {
        accountAlias.editSecondAddAnAliasWithApplying(table);
    }

    @And("I verify Add An Alias name is present beside account number")
    public void iVerifyAddAnAliasNameIsPresentBesideAccountNumber() {
        preferencePage.verifyAccountAliasName();
    }

    @Then("I verify the number of Additional Filter {string}")
    public void iVerifyTheNumberOfAdditionalFilter(String FilterCount) {
        this.reportCenter.FilterStatus(FilterCount);

    }

    @Given("^I verify the below column headers are displayed in My Shipment$")
    public void i_verify_the_below_column_headers_are_displayed_in_myShipment(DataTable table) {
        Assert.assertTrue("Headers validation of the CE dashboard is failed",
                this.ceDashboard.ValidateColumnHeaders(table));
    }

    @And("I click on collapse full screen")
    public void iClickOnCollapseFullScreen() {
        JavaScriptClick(this.shipmentOverviewPage.collapseFullScreen);
    }


    @Then("I enter Report Type {string} {string}")
    public void iEnterReportType(String reportType, String account) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.enterReportType(reportType, account);
        }
    }

    @And("I choose view {string} under report tab")
    public void iChooseViewUnderReportTab(String view) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.selectViewUnderReportTab(view);
        }
    }

    @And("I validate the view {string} in report")
    public void iValidateViewInReport(String view) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.validateViewUnderReportTab(view);
        }
    }

    @And("I enter Report Name {string} {string} {string}")
    public void IEnterReportNameUnderReportTab(String reportName, String reportKey, String prefix) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.enterNameUnderReportTab(reportName, reportKey, prefix);
        }
    }

    @Then("I select Report format {string}")
    public void ISelectReportFormat(String format) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.selectFormatUnderReportTab(format);
        }
    }

    @Then("I verify the Email Message and is not editable")
    public void IVerifyEmailMessageisNotEditable() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.verifyEmailMessageIsNotEditable();
        }
    }

    @Then("I Verify the Report Name in the form of Prefix+date+extension {string} {string}")
    public void IVerifyReportNameIsFormOfPrefixDateAndExtension(String prefix, String format) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            reportCenter.verifyReportNameIsCombinationOfPrefixAndDateAndExtension(prefix, format);
        }
    }

    @Then("I Verify if prefix change in edit same should appear in Report name {string} {string}")
    public void verifyPrefixChangeShouldChangeInReportName(String prefix, String button) {
        reportCenter.verifyPrefixChangeShouldChangeInReportName(prefix, button);
    }

    @Then("I verify the Email Body and is not editable")
    public void IVerifyEmailBodyIsNotEditable() {
        reportCenter.verifyEmailBodyIsNotEditable();
    }

    @Then("Validate Add Accounts SearchBox under Accounts")
    public void validateAddAccountsSearchBoxUnderAccounts() {
        accountAlias.validateAddAccountAliasSearchBoxInAccountFilter();
    }

    @And("I verify Add An Alias Button is present beside account number in accounts filter")
    public void iVerifyAddAnAliasButtonIsPresentBesideAccountNumberInAccountsFilter() {
        accountAlias.verifyAddAliasBtnBesideAccountNumberInAccountFilter();
    }

    @Then("I validate Accounts Filter Bubble {string}")
    public void iValidateAccountsFilterBubble(String addAlias) {
        this.accountAlias.validateAccountColumnFilterBubble(addAlias);
    }

    @Then("I validate Delay Reason Filter Bubble {string} with {string}")
    public void iValidateDelayReasonFilter(String delayReasonType, String delayReasonValue) {
        this.shipmentOverviewPage.validateDelayReasonColumnFilterBubble(delayReasonType, delayReasonValue);
    }

    @Then("^I validate column data for \"([^\"]*)\"$")
    public void iValidateColumnFilterData(String columnName, DataTable expectedValues) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.validateColumnFilterDataInShipmentPage(columnName, expectedValues);
        }
    }


    @Then("^I validate no filter/views available in My Shipments page$")
    public void iValidateNoFilter_ViewsAvailable() {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.validateNoFiltersAvailableInMyshipmentPage();
        }
    }


    @Then("I click on {string} button dropdown")
    public void iClickOnButtonDropdown(String buttonname) {
        ScrollByOffset("0", "100");
        this.advisoryPage.JavaScriptClick(getByusingString(String.format(shipmentOverviewPage.filtername, buttonname)));

    }

    @And("I enter below text in {string} filters and validate the search results")
    public void iEnterBelowTextInFiltersAndValidateTheSearchResults(String buttonname, DataTable table) {


        List<String> listOfSearches = table.asList();
        for (String search : listOfSearches) {
            this.waitUntilNotVisible(this.loadingIndicator);
            this.enterText(shipmentOverviewPage.searchForColumnInput, search);
            this.commonHelpers.thinkTimer(6000);
            int sizeOfSearchList = this.findElements(shipmentOverviewPage.searchlistcolumn).size();
            shipmentOverviewPage.searchBoxValidation(search, sizeOfSearchList);
        }

    }


    @Then("I click on search result {string}")
    public void iClickOnSearchResult(String search) {
        List<WebElement> searchlist = this.findElements(shipmentOverviewPage.searchlistcolumn);
        for (WebElement item : searchlist) {
            if (item.getText().equalsIgnoreCase(search)) {
                item.click();
            }
        }
    }

    @And("I verify quick view card color for {string}")
    public void validateViewCardColor(String qvc) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            shipmentOverviewPage.ValidateQuickViewCardColor(qvc);
        }
    }

    @Then("Validate the format of data in {string} column with {string} type")
    public void i_validate_column_data_format(String data, String fedExCompany) {
        Assert.assertTrue("Data is not in expected format", this.shipmentOverviewPage.validateColumnDataFormatInShipmentPage(data, fedExCompany));
    }


    @Then("I validated filters options are disabled when i select {string}")
    public void validate_delayReason_filter(String filterOption) {
        this.shipmentOverviewPage.validateDelayReasonFilter(filterOption);
    }

    @Then("I {string} filter using below conditions for searchBox filter")
    public void i_apply_filter_for_searchbox(String cancelOrApply, DataTable dataTable) {
        this.waitUntilNotVisible(this.loadingIndicator);
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.shipmentOverviewPage.selectOrDeselectDelayReasonFilter(cancelOrApply, dataTable);
        }
    }

    @Then("I verify column {string} with data {string} should display {string}")
    public void i_validate_column_data_for_filter(String column, String data, String isDisplay) {
        if (isDisplay.equalsIgnoreCase("True")) {
            Assert.assertTrue("Data is not displayed as expected", this.shipmentOverviewPage.validateColumnDataForFilter(column, data, isDisplay));
        } else {
            Assert.assertFalse("Data is not displayed as expected", this.shipmentOverviewPage.validateColumnDataForFilter(column, data, isDisplay));

        }
    }


    @And("I validated {string} filter UI search box and radio buttons")
    public void i_validate_specificDelayReason_searchBox_RadioButtons(String filterOption, DataTable table) {
        this.shipmentOverviewPage.validateFilterUIForSpecificDelayReason(filterOption, table);
    }

    @And("I Sort the Account number in {string}")
    public void iSortTheAccountNumberIn(String order) {
        this.waitUntilClickable(getByusingString(this.shipmentOverviewPage.account));

        // this.clickOnElement(getByusingString(this.shipmentOverviewPage.account));
        this.JavaScriptClick(this.findElement(getByusingString(this.shipmentOverviewPage.account)));
        this.commonHelpers.thinkTimer(2000);
        WebElement orders = this.findElement(getByusingString(this.shipmentOverviewPage.AccountNumber));
        String clasname = orders.getAttribute("class");
        log.info(clasname + "...checking order");
        log.info(this.shipmentOverviewPage.AccountNumber + order + "...checking order");
        Assert.assertTrue((clasname).contains(order));
    }


    @And("I add multiple Account Alias {string} and Validate AccountNumbers associated")
    public void iAddMultipleAccountAliasAndValidateAccountNumbersAssociated(String arg0) {
        HashMap<String, String> listOfAccNum = accountAlias.addMultipleAccountAlias(arg0, 2);
        accountAlias.blueDotAndAccountNumberValidationAfterEdit(arg0, listOfAccNum);
    }

    @And("I delete the multiple alias {string}")
    public void iDeleteTheMultipleAlias(String arg0) {
        accountAlias.deleteMultipleAccountAlias(arg0);
    }

    @And("I Sort the Account number")
    public void iSortTheAccountNumber() {
        // this.javaScriptClickOnElementEvent(getByusingString(this.shipmentOverviewPage.AccountNumber));
        this.shipmentOverviewPage.sortaliasAccount();

    }

    @And("I get UI Account And Alias and store it {string}")
    public void iGetUIAccountAndAliasAndStoreIt(String aliasname) {
        accountAlias.storeAccountNumberAliasMapInContextStore(aliasname);
        String alis = this.commonHelpers
                .getValuefromContextStore(aliasname).toString();
    }

    @Then("I verify data in {string} sheet with column name as {string} and value as {string} for {string} file")
    public void iVerifyDataInSheetWithColumnNameAsAndValueAsForFile(String sheetname, String columnName, String value, String type) throws IOException {
        this.shipmentOverviewPage.getcoloumndata(sheetname, columnName, value);
    }

    @And("I validate {string} alias name in Shipment data tab")
    public void iValidateAliasNameInShipmentDataTab(String aliasName) {
        this.waitUntilVisible((shipmentOverviewPage.shipmentAliasNameInfo));
        Assert.assertTrue(getText(shipmentOverviewPage.shipmentAliasNameInfo).contains(aliasName));

    }

    @And("I click on alias {string} in Shipment data tab")
    public void iClickOnAliasInShipmentDataTab(String arg0) {

        this.JavaScriptClick(this.findElement(By.xpath(shipmentOverviewPage.editaliasinshipmentdata)));

    }

    @Then("I get Date filter bubble")
    public void i_verify_filter_bubble() throws Throwable {
        this.waitUntilNotVisible(this.loadingIndicator);
        this.shipmentOverviewPage.validateFilterBubbleValue();
    }

    @And("I Clicks on {string} in the portal")
    public void iClicksOnInThePortal(String link) {
        this.JavaScriptClick(this.getByusingString("(" + (this.buildXpathForString(link)) + ")[2]"));

    }


    @And("I wait for {long} milli seconds")
    public void iWaitForSeconds(long seconds) {
        this.commonHelpers.thinkTimer(seconds);
    }

    @Then("validate the locale breadcrumb {string}")
    public void validateTheLocaleBreadcrumb(String value) {
        reportCenter.Locale_breadcrumb_validation(value);
    }

    @And("I click on ok button after refresh if exists")
    public void iClickOnOkButtonAfterRefresh() {
        try {
            this.JavaScriptClick(shipmentOverviewPage.okButtonAfterRefresh);
        } catch (Exception e) {
            log.info("No refresh pop up is displayed");
        }
    }

    @Then("I verify shipment ID")
    public void i_Verify_ShipmentID() {
        Object trackingNum = this.shipmentOverviewPage.trackingNumCellValue;
        if (elementIsDisplayed(this.shipmentOverviewPage.trackingNumCellValue)) {
            Assert.assertTrue(trackingNum != null);
        } else {
            Assert.assertTrue(trackingNum == null);
        }
    }


    @Then("I verify below values are shown on the Choose View dropdown")
    public void iVerifyBelowValuesAreShownOnTheChooseViewDropdown(DataTable table) {
        Assert.assertTrue("Dropdown values is not visible on the Country Territory dropdown",
                this.reportCenter.VerifyDropdownValuesVisible(table));
    }
    @And("I click on Choose View dropdown")
    public void iClickOnChooseViewDropdown() {
        this.reportCenter.clickChooseViewDropdown();
    }

    @Then("I refreshes the page")
    public void iRefreshesThePage() {
        this.Refresh_Page(1);
    }


    @Then("I verify the full screen view is displayed")
    public void iVerifyFullScreen(){
        this.shipmentOverviewPage.verifyFullScreen();

    }

    @Then("I click on close full screen")
    public void iCloseFullScreen(){
        this.shipmentOverviewPage.closeFullScreen();
    }

    @Then("^I get the viewing count and store it in \"([^\"]*)\"$")
    public void iGetTheViewingCountAndStoreItInContextStoreViewingCount(String contextKey) {
        String viewingCount = shipmentDetails.getViewingCount();
        this.commonHelpers.AddToContextStore(contextKey, viewingCount);
    }


    @And("I validate count is matching with {string} after switching")
    public void iValidateCountIsMatchingAfterSwitching(String contextName) {
        int storedCount = Integer.parseInt(this.commonHelpers.getValuefromContextStore(contextName).toString());
        int currentCount = Integer.parseInt(shipmentDetails.getViewingCount());
        Assert.assertEquals("The counts before and after switching do not match.", storedCount, currentCount);
    }

    @And("I validate {string} button is disabled in shipment view")
    public void validateButtonIsDisabledInShipment(String button) {
            switch (button){
                case "Reset":
                    Assert.assertTrue("Button is not disabled", this.elementIsDisplayed(this.shipmentOverviewPage.resetDisableButton));
                    break;
                case "BULK":
                    String lang  = GenericFunction.ReadConfigFile("LANG");
                    if(!lang.equalsIgnoreCase("en-us")){
                        button=this.genericFunObj.getLocalizedValue(button);
                    }
                    Assert.assertTrue("Button is not disabled", this.elementIsDisplayed(By.xpath(String.format(this.shipmentOverviewPage.headerButton, button))));
                    break;
                case "Save View":
                    Assert.assertTrue("Button is not disabled", this.elementIsDisplayed(this.shipmentOverviewPage.saveViewDisableButton));
                    break;
                case "Export List":
                    int count=Integer.parseInt(this.shipmentOverviewPage.getViewingCount());
                    if(count>100000) {
                        this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(button)));
                        this.commonHelpers.thinkTimer(3000);
                        Assert.assertTrue("Button is not disabled", this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP"))));
                        break;
                    }else{
                        this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(button)));
                        this.commonHelpers.thinkTimer(3000);
                        Assert.assertTrue("Button is not disabled", this.elementIsDisplayed(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP"))));
                        break;
                    }
            }

    }

    @And("I validate {string} button is disabled in shipment view if count is more than 100000")
    public void validateExportButtonInShipment(String button){
        int count=Integer.parseInt(this.shipmentOverviewPage.getViewingCount());
        if(count>100000) {
            this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(button)));
            this.commonHelpers.thinkTimer(3000);
            Assert.assertTrue("Button is not disabled", this.elementIsNotDisplayed(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP"))));
        }else{
            this.Mouse_MoveToElement(this.getByusingString(this.buildXpathForString(button)));
            this.commonHelpers.thinkTimer(3000);
            Assert.assertTrue("Button is not disabled", this.elementIsDisplayed(this.getByusingString(this.buildXpathForString("EXPORT LIST POPUP"))));
        }
    }


   @And("^I click on cluster to verify it breaks into multiple small clusters$")
    public void iClickOnClusterToVerifyItBreaksIntoMultipleSmallClusters() {
        commonHelpers.thinkTimer(5000);
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
        js.executeScript("window.scrollBy(0, 400)");
        commonHelpers.thinkTimer(5000);
        WebElement clusterElement = this.findElements(advisoryPage.clusters).get(0);
        String clusterCount=clusterElement.getText().trim();
        System.out.println("count is "+clusterCount);
        commonHelpers.thinkTimer(5000);
        WebElement clusterElement1 = this.findElements(advisoryPage.clusters).get(0);
        this.JavaScriptClick(clusterElement1);
        commonHelpers.thinkTimer(5000);
        int smallClusterCount = this.findElements(advisoryPage.clusters).size();
       Assert.assertTrue("Cluster did not break into multiple small clusters.",smallClusterCount>0);
        js.executeScript("window.scrollBy(0, -400)");
    }


    @Then("^I get the search text in Search box and store it in \"([^\"]*)\"$")
    public void iGetTheSearchTextInSearchBoxAndStoreItIn(String contextKey) {
        String searchText=this.findElement(advisoryPage.advisories_LocationSearch).getText();
        this.commonHelpers.AddToContextStore(contextKey, searchText);
    }

     @And("^I validate search text in Search box with \"([^\"]*)\" after switching$")
    public void iValidateSearchTextInSearchBoxWithAfterSwitching(String contextKey) {
        String expectedSearchText = commonHelpers.getValuefromContextStore(contextKey).toString();
        String actualSearchText=this.findElement(advisoryPage.advisories_LocationSearch).getText();
        Assert.assertEquals("The search text in the search box does not match the expected text after switching.", expectedSearchText, actualSearchText);
    }


    @Then("User should see {string} option below {string} setting")
    public void iVerifyOptionUnderPreference(String option,String setting){
       Assert.assertTrue("User shouldn't able to see the "+option+" option",this.preferencePage.verifyOptionUnderPreference(option,setting));
    }

   @And("{string} dropdown should have {string} as the default option")
    public void iValidateDefaultOptionForSetting(String setting,String option){
        Assert.assertTrue("Default option is not "+option,this.preferencePage.verifyDefaultOptionForSetting(setting,option));
    }


    @And("{string} dropdown should have options")
    public void iValidateOptionsForSetting(String setting,DataTable table){
        this.preferencePage.verifyOptionsForSetting(setting,table);
    }

    @When("User selects {string} from {string} dropdown")
    public void iSelectOptionFromSetting(String option,String setting){
        this.preferencePage.selectOptionFromSetting(setting,option);
    }


    @Then("I validate the {string} page is not displayed")
    public void iValidateThePageIsDisplayed(String page) {
        Assert.assertTrue("The "+page+" page is not displayed",this.shipmentOverviewPage.validatePageIsDisplayed(page));
    }

    @Then("click on {string} weather advisories value")
    public void clickonWeatherAdvisoriesValue(String link){
        this.advisoryPage.clickWeatherAdvisory(link);
    }

    @Then("I retrieve {string} value from advisories page")
    public void getWeatherCountFromAdvisoryPage(String key) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            // Retrieve the view count and add it to the context store
            int viewCount = this.advisoryPage.getAdvisoryViewCount(key);
            System.out.println("Retrieved view count for key " + key + ": " + viewCount);
        } else {
            System.out.println("Skipping retrieval of advisory view count due to skipSteps flag.");
        }
    }


    @Then("I verify {string} advisory weather-shipmentPage viewing count")
    public void verifyViewingCount_advisoryPage_shipmentPage(String contextStoreKey) {
        this.waitUntilNotVisible(this.loadingIndicator);
        String ExpectedCount = this.commonHelpers.getAdvisoryCountValuefromContextStore(contextStoreKey).toString();
        String actualCount = String.valueOf(this.shipmentOverviewPage.getViewCount());
        if(ExpectedCount==null) {
            this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps);
        }else{
            this.commonHelpers.AssertCountswithCorrection(Integer.parseInt(ExpectedCount),
                    Integer.parseInt(actualCount));
        }

    }

    @And("I select first tracking number from myshipment page")
    public void selectFirstTrackingNum(){
        this.waitUntilNotVisible(this.loadingIndicator);
        if(elementIsDisplayed(this.shipmentDetails.firstTrackingNumberInList)) {
            this.shipmentDetails.clickOnFirstTrackingNumberInList();
        }else{
            this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps);
        }
    }

    @Then("^I validate column \"([^\"]*)\" is not empty$")
    public void iValidateColumnIsNotEmpty(String columnName) {
       // String columnContent = this.shipmentOverviewPage.getColumnContentByColumnName(columnName);
        if (this.shipmentOverviewPage.getColumnContentByColumnName(columnName).equalsIgnoreCase("false")) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Then("I verify filter {string} option is disabled")
    public void iVerifyFilterIsNotClickable(String filterName){
        this.commonHelpers.thinkTimer(300);
        this.shipmentOverviewPage.verifyFilterOptionDisabled(filterName);
//        Assert.assertTrue("element is enabled", this.shipmentOverviewPage.verifyFilterOptionDisabled(filterName));
//        String searchTextBox=By.xpath((String.format(String.valueOf(this.shipmentOverviewPage.filterIsNotDisplayed), filterName))).getAttr;
//
//        String actualLink = this.findElement(this.getByusingString(this.buildXpathForString(SupportTeam)))
//                .getAttribute("href");
//
//        System.out.println(searchTextBox.getAttribute(""));
//        System.out.println(IsElementEnabled(By.xpath((String.format(String.valueOf(this.shipmentOverviewPage.filterIsNotDisplayed), filterName)))));
    }

    @Then("I search the below option in the {string} filter searchBox")
    public void iSearchTheBelowOptionInTheFilterSearchBox(String columnFilter,DataTable options) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            String[] filter = columnFilter.split("-");
            List<String> optionList = options.asList(String.class);
            for (String option : optionList) {
                String[] filterOption = option.split(":");
                this.enterText(By.xpath(String.format(this.shipmentOverviewPage.filterSearchBar, filter[0], filter[1])), filterOption[0]);
                this.commonHelpers.thinkTimer(5000);
                this.keyBoardEvent(Keys.TAB);
                filterOption[1] = filterOption[1].replaceAll("\\s+", " ");
                this.commonHelpers.thinkTimer(10000);
                if (this.elementIsNotDisplayed(By.xpath(String.format(this.shipmentOverviewPage.SelectSearchResults, filterOption[1].trim())))) {
                    this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                    break;
                }
                this.JavaScriptClick(By.xpath(String.format(this.shipmentOverviewPage.SelectSearchResults, filterOption[1].trim())));
                this.JavaScriptClick(
                        this.findElement(this.getByusingString(String.format(this.shipmentOverviewPage.applyButton, this.shipmentOverviewPage.applyUpperCase))));
            }
        }
    }


    @And("^I verify edit icon of \"([^\"]*)\" view$")
    public void iClickOnEditIconOfView(String viewName) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            boolean isElementNotVisible = !elementIsDisplayed(By.xpath(String.format(this.shipmentOverviewPage.renameViewIconShipmentPage, viewName)));
            Assert.assertTrue("Element is visible when it should not be", isElementNotVisible);
        }
    }

    @Then("I validate the viewing and total count should be same on first load")
    public void validateViewingAndTotalCountOnFirstLoad() {
        this.waitUntilNotVisible(this.loadingIndicator);
        int viewingCount = Integer.parseInt(this.shipmentOverviewPage.getViewingCount());
         int totalCount = Integer.parseInt(this.shipmentOverviewPage.getTotalCount());
         Assert.assertEquals("Viewing count and total count should be the same on first load", viewingCount, totalCount);
    }

    @Then("^I validate column column is \"([^\"]*)\" in my shipment page with offset \"([^\"]*)\"$")
    public void iValidateColumnColumnIsInTheMyShipmentPageWithOffset(String visiblity,String offset,DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            if (visiblity.equalsIgnoreCase("visible")) {
                Assert.assertTrue(this.shipmentOverviewPage.isShipmentColumnPresentWithOffset(offset,dataTable));
            } else if (visiblity.equalsIgnoreCase("invisible")) {
                Assert.assertFalse(this.shipmentOverviewPage.isShipmentColumnPresentWithOffset(offset,dataTable));
            }
        }
    }

    @Then("I validate the hover text on Types column")
    public void validateHoverTextOnTypesColumn() {
        WebElement typesColumn = this.findElements(this.shipmentOverviewPage.typesColumn).get(0);
        Actions actions = new Actions(DriverManager.getDrv());
        actions.moveToElement(typesColumn).perform();
        WebElement hoverTextElement = DriverManager.getDrv().findElement(this.shipmentOverviewPage.typesHover);
        String hoverText = hoverTextElement.getText();
        System.out.println("Hover text is :"+hoverText);
        Assert.assertTrue("Unable to hover", hoverText.length()>0);
    }

    @Then("I validate vertical and horizontal scroll on shipment list")
    public void iValidateVerticalAndHorizontalScroll(){
        //vertical scroll
        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDrv();
          this.scrollInternalScrollBarOnPage("500");
          long scrollTop = (Long) ((JavascriptExecutor) DriverManager.getDrv()).executeScript("return document.getElementsByClassName('ag-body-viewport ag-layout-auto-height ag-row-no-animation')[0].scrollTop");
        long scrollHeight = (Long) ((JavascriptExecutor) DriverManager.getDrv()).executeScript("return document.getElementsByClassName('ag-body-viewport ag-layout-auto-height ag-row-no-animation')[0].scrollHeight");
        Assert.assertTrue("Vertical scroll should be successful", scrollTop > 0 && scrollTop <= scrollHeight);

        //horizontal scroll
        this.scrollHorizontalBarOnPage("500");
        long scrollLeft = (Long) ((JavascriptExecutor) DriverManager.getDrv()).executeScript("return document.getElementsByClassName('ag-body-horizontal-scroll-viewport')[0].scrollLeft");
        long scrollWidth = (Long) ((JavascriptExecutor) DriverManager.getDrv()).executeScript("return document.getElementsByClassName('ag-body-horizontal-scroll-viewport')[0].scrollWidth");
        Assert.assertTrue("Horizontal scroll should be successful", scrollLeft > 0 && scrollLeft <= scrollWidth);
    }

}









