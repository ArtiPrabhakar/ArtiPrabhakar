package stepDefinitions;

import API.RequestModels.Icalled;
import API.RequestModels.*;
import API.ResponseModels.Comment;
import API.ResponseModels.*;
import com.jayway.jsonpath.JsonPath;
import common.CommonHelpers;
import common.HttpClientFactory;
import common.JSONHelpers;
import genericfunctions.API_GenericFun;
import genericfunctions.Constants;
import genericfunctions.DateTimeUtils;
import genericfunctions.GenericFunction;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import pageObjects.AdvisoryPage;
import pageObjects.HomePage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class TestAPI {
    static String APIResponse = "";
    static String APIJSON = "";
    public CommonHelpers commonHelpers;
    API_GenericFun apiobj;
    Response response = null;
    GenericFunction gfobj = new GenericFunction();
    SoftAssertions softly = new SoftAssertions();
    HttpClientFactory httpClientFactory = new HttpClientFactory();
    HomePage homePage;
    AdvisoryPage advPage;
    ShipmentsOverview shipmentsOverview = new ShipmentsOverview();
    DateTimeUtils dateTimeUtils;
    View view = new View();
    // Shipment shipment = new ShipmentsOverview().new Shipment();
    List<FilterList> filters = new ArrayList<>();
    List<QuickViewList> quickviewfilters = new ArrayList<>();
    List<SortList> sortList = new ArrayList<>();
    List<SearchFilterList> searchFilterList = new ArrayList<>();

    public TestAPI(CommonHelpers commonHelpers) {
        this.commonHelpers = commonHelpers;
        this.apiobj = new API_GenericFun(this.commonHelpers);
        homePage = new HomePage(this.commonHelpers);
        advPage = new AdvisoryPage(this.commonHelpers);
        dateTimeUtils = new DateTimeUtils();
    }

    @Given("^I fetch the access token$")
    public void i_fetch_the_access_token() {
        this.apiobj.GenerateBearerToken();
    }

    // *** GET CALLS ****
    // BEGIN

    @Then("^I Get the \"([^\"]*)\" using resource \"([^\"]*)\"$")
    public void i_Get_the_using_resource(String context, String endPointKey) {
        this.apiobj.WhenIMakegetCall(endPointKey);
    }

    @Then("^I Get the \"([^\"]*)\" using resource \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_Get_the_using_resource_for_the_user(String context, String endPointKey, String userId) {
        this.apiobj.SetCookies(userId);
        this.apiobj.WhenIMakegetCall(endPointKey);
    }

    @Then("^I GET the \"([^\"]*)\" flag using resource \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_Get_the_flag_using_resource_for_the_user(String flagname, String endPointKey, String user)
            throws Exception {
        this.apiobj.SetCookies(user);
        this.apiobj.WhenIMakegetCall(endPointKey);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        FeatureFlags featureFlags = this.commonHelpers.unMarshall(resp.asString(), FeatureFlags.class);
        if (flagname.equals("sustainabilityFeatureEnabled"))
            this.commonHelpers.AddToContextStore(flagname, featureFlags.isSustainabilityFeatureEnabled());
        else if (flagname.equals("tntFeatureEnabled"))
            this.commonHelpers.AddToContextStore(flagname, featureFlags.isTntFeatureEnabled());

    }

    @Given("^I Get the shipment details using \"([^\"]*)\" using \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_Get_the_shipment_details_using_using_for_the_user(String endPointkey, String trackingId,
            String userContext) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                this.apiobj.SetCookies(userContext);
                this.apiobj.WhenIMakegetCall(endPointkey, trackingId);
            } catch (Exception e) {
                log.error(
                        "**EXCEPTION** " + trackingId + " field is not present in the context store" + e.getMessage());
                Assert.fail(trackingId + " field is not present in the context store");
            }
        }

    }

    @Given("^I Get the shipment details using \"([^\"]*)\"$")
    public void GetCECompanyHierarchyAndStoreCompanyDetails(String endPointKey) throws Throwable {
        this.apiobj.WhenIMakegetCall(endPointKey);
        List<CompanyHierarchy> companieslist = new ArrayList<>();
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        List<CompanyHierarchy> companies = this.commonHelpers.unMarshall(resp, CompanyHierarchy[].class);
        for (CompanyHierarchy board : companies) {
            if (board.getCompanyName().equalsIgnoreCase(GenericFunction.ReadConfigFile("CE_COMPANY"))) {
                companieslist.add(board);
            }
        }
        log.info("Companies List size is--> " + companieslist.size());
        int index = this.commonHelpers.GenerateRandomNumber(companieslist.size());
        CompanyHierarchy randomCompany = companieslist.get(index);
        log.info("Company Selected is --> " + randomCompany.getCompanyName());
        this.commonHelpers.AddToContextStore("CompanyName", randomCompany.getCompanyName());
        this.commonHelpers.AddToContextStore("CompanyCode", randomCompany.getCompanyCode());
        this.commonHelpers.AddToContextStore("CompanyAccHierarchy", this.apiobj
                .CompanyAccountMapping(companieslist.get(0).getCompanyCode(), companieslist.get(0).getAccountId()));
    }

    // GENERIC POST call using the USERID and RESOURCE
    // RESOURCE variable which has an equivalent path parameter defined in
    // endpointCollection.json
    @Then("^I POST the \"([^\"]*)\" using resource \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_POST_the_using_resource_for_the_user(String context, String endPointKey, String userId)
            throws Throwable {
        if (userId.equalsIgnoreCase("CE")) {
            if (endPointKey.equals("CE_FedEx_Accounts_All_Companies") ) {
                // Getting the payload value set in previous steps as we don't want to pass the
                // default company which we pass in all cases
                this.commonHelpers.AddToRequestPayloadCollection(endPointKey,
                        this.commonHelpers.getValuefromContextStore(endPointKey));
            } else {
                CompanyAndAccountHierarchy companyAndAccountHierarchy = this.commonHelpers.unMarshall(
                        this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString(),
                        CompanyAndAccountHierarchy.class);
                this.shipmentsOverview.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);
                this.commonHelpers.AddToRequestPayloadCollection(endPointKey, this.shipmentsOverview);
                System.out.printf("Payload for %s is: %s %n", endPointKey,
                        this.commonHelpers.Marshall(this.shipmentsOverview));
            }
        }
        this.apiobj.WhenIMakepostCall(endPointKey);
    }

    @Given("^I click on \"([^\"]*)\" in weather pane$")
    public void i_click_on_in_weather_pane(String link) {
        this.advPage.ClickWeatherPaneLinks(link);
    }

    @Then("^I store missing status in \"([^\"]*)\" to validate grey pins from \"([^\"]*)\" response$")
    public void i_store_missing_status_in_to_validate_grey_pins_from_response(String KeyToStore, String endPointKey) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        String responseString = resp.asString();
        List<String> statuses = JsonPath.parse(responseString).read("$..cityStatuses..status");
        Set<String> uniqueStatuses = new HashSet<>(statuses);
        TreeSet<String> treeSet = new TreeSet<>(uniqueStatuses);
        log.info("Number of unique weather impacted status: " + uniqueStatuses.size());
        if (uniqueStatuses.size() > 0) {
            // for (String status : Constants.ActiveStatusesDomestic) {
            for (String weatherStatus : Constants.ActiveStatusesDomestic) {
                if (!treeSet.contains(weatherStatus)) {
                    if (KeyToStore.contains("ContextStore-")) {
                        this.commonHelpers.AddToContextStore(KeyToStore.split("-")[1], weatherStatus);
                        log.info("The option which we will select for getting the grey pin is ---> "
                                + KeyToStore.split("-")[1] + " with status = " + weatherStatus);
                    }
                    break;
                }
            }
            // break;
            // }
            if (!this.commonHelpers.verifyKeyinContextStore(KeyToStore.split("-")[1])) {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        } else {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }
    }

    @Given("^I validate the \"([^\"]*)\" with API response for below fields$")
    public void i_validate_the_with_API_response_for_below_fields(String Validationcontext, DataTable table) {
        Assert.assertTrue("Validation of the weather pane with API values is failed",
                this.advPage.ValidateWeatherAlertsInfo(Validationcontext, table));
    }

    @Then("^I Get the \"([^\"]*)\" using resource \"([^\"]*)\" for the user \"([^\"]*)\" with below params$")
    public void i_Get_the_using_resource_for_the_user_with_below_params(String context, String endPointKey,
            String userId, DataTable dataTable) throws Throwable {
        this.apiobj.SetCookies(userId);
        Map<String, String> queryParams = dataTable.asMap(String.class, String.class);
        if (queryParams.size() > 0) {
            this.apiobj.setQueryParams(queryParams);
            if (endPointKey.contains("CE_Shipments_Search")) {
                CompanyAndAccountHierarchy companyAndAccountHierarchy = this.commonHelpers.unMarshall(
                        this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString(),
                        CompanyAndAccountHierarchy.class);
                this.shipmentsOverview.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);
                this.shipmentsOverview.setContext("Within Selected Accounts");
                this.commonHelpers.AddToRequestPayloadCollection(endPointKey, this.shipmentsOverview);
                // To separate out request from each other
                log.info("---------------------------");
                System.out.printf("Payload for %s is: %s %n", endPointKey,
                        this.commonHelpers.Marshall(this.shipmentsOverview));
                this.apiobj.PostCallwithQueryparmsandPayload(endPointKey);
            } else if (!endPointKey.contains("Advisories_weatherInfo")) {
                this.apiobj.PostCallwithQueryparms(endPointKey);
            } else {
                this.apiobj.GetCallwithQueryparms(endPointKey);
            }
        }
    }

    @Given("^I select \"([^\"]*)\" from \"([^\"]*)\" and store in \"([^\"]*)\"$")
    public void i_select_from_and_store_in(String KeyToSearch, String endPointKey, String ContextStoreVar)
            throws Throwable {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        SearchResults searchResults = this.commonHelpers.unMarshall(resp.asString(), SearchResults.class);
        if (KeyToSearch.equalsIgnoreCase("shipmentId")) {
            this.commonHelpers.AddToContextStore(ContextStoreVar, searchResults.getShipmentId());
        }
    }

    // This function is there also in SeleniumGeneric function, so whenever changing
    // this
    // that one should also be changed.
    // Since this does not inherits that class so had to write here
    public Map<String, String> getFirstValueOfDataTableifNotEmpty(DataTable dataTable) {
        try {
            Map<String, String> expectedKV = dataTable.asMap(String.class, String.class);
            return expectedKV;
        } catch (Exception e) {
            log.info("Looks like there is an empty datatable was sent. So handling it differently");
            List<Map<String, String>> expectedKVList = dataTable.asMaps();
            if (expectedKVList.size() == 0) {
                return null;
            }
            return expectedKVList.get(0);
        }

    }

    @Then("^I verify response \"([^\"]*)\" is having the status code as \"([^\"]*)\" with response having below values$")
    public void i_verify_response_is_having_the_status_code_as_with_response_having_below_values(String endPointKey,
            String StatusCode, DataTable dataTable) throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> expectedKV = getFirstValueOfDataTableifNotEmpty(dataTable);
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (virtualizationFlag && (endPointKey.equalsIgnoreCase("FedEx_UserInfo")
                || endPointKey.equalsIgnoreCase("FedEx_TrackingProfile"))) {
            endPointKey = "VIRTUAL_Login";
        }
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);

        boolean flag1 = true;
        switch (endPointKey) {
            case "MS_FedEx_Accounts":
                FedExAccounts fedExAccounts = this.commonHelpers.unMarshall(resp.asString(), FedExAccounts.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        switch (expkey) {
                            case "surroundEligibilityType":
                                for (Datum account : fedExAccounts.getData()) {
                                    String accType = account.getSurroundEligibilityType();
                                    if (accType.equals("Digital")) {
                                        flag1 = account.getOnlyDigital();
                                        if (!flag1) {
                                            break;
                                        }
                                    } else if (accType.contains("Monitoring")) {
                                        flag1 = account.getOnlyMonitored();
                                        if (!flag1) {
                                            break;
                                        }
                                    }
                                }
                                break;
                            case "Type":
                                for (Datum account : fedExAccounts.getData()) {
                                    for (String expValue : expectedKV.values()) {
                                        switch (expValue) {
                                            case "onlyDigital":
                                                flag1 = account.getOnlyDigital();
                                                if (!flag1) {
                                                    break;
                                                }
                                                break;
                                            case "onlyMonitored":
                                                // the only monitored condition would be true in case its not Select
                                                // for Select (digital) it can be false
                                                if (!account.getSurroundEligibilityType().contains("Select")) {
                                                    flag1 = account.getOnlyMonitored();
                                                    if (!flag1) {
                                                        break;
                                                    }
                                                }
                                                break;

                                        }
                                    }
                                }
                                break;

                        }
                    } else {
                        break;
                    }
                }
                break;
            case "CE_FedEx_Accounts":
                fedExAccounts = this.commonHelpers.unMarshall(resp.asString(), FedExAccounts.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        switch (expkey) {
                            case "Type":
                                for (Datum account : fedExAccounts.getData()) {
                                    flag1 = account.getOnlyMonitored();
                                    if (!flag1)
                                        break;
                                }
                                break;
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "MS_Shipments_Overview":
                JSONObject listObj = JSONHelpers.StringtoJObject(resp.asString());
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        switch (expkey) {
                            case "totalRecords":
                                flag1 = listObj.getInt(expkey) > 1;
                                break;
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "FedEx_TrackingProfile":
                TPAPIResponse tpapiResponse = this.commonHelpers.unMarshall(resp.asString(), TPAPIResponse.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expkey.contains("userFirstName")) {
                            Assertions.assertThat(tpapiResponse.getOutput().getUserFirstName())
                                    .isEqualToIgnoringCase(
                                            this.commonHelpers.getValuefromContextStore(expectedKV.get(expkey))
                                                    .toString());
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "MS_Shipments_Details":
                ShipmentTrackingDetails ShipmentTrackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                        ShipmentTrackingDetails.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expectedKV.get(expkey).contains("Tracking Number")) {
                            if (virtualizationFlag) {
                                flag1 = ShipmentTrackingDetails.getShipmentDto().getTrackingNumber().equalsIgnoreCase(
                                        this.commonHelpers.getValuefromContextStore(expectedKV.get(expkey)).toString());
                            } else
                                flag1 = ShipmentTrackingDetails.getTrackingApiDto().getTrackingNbr().equalsIgnoreCase(
                                        this.commonHelpers.getValuefromContextStore(expectedKV.get(expkey)).toString());
                        }
                    } else {
                        break;
                    }
                }

                break;
            case "MS_Advisories_shipments":
                Shipments shipments = this.commonHelpers.unMarshall(resp.asString(), Shipments.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expectedKV.get(expkey).contains("Integer")) {
                            flag1 = shipments.getAllShipment() % 1 == 0;
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "MS_Shipments_Search":
                SearchResults searchResults = this.commonHelpers.unMarshall(resp.asString(), SearchResults.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expkey.contains("count")) {
                            if (expectedKV.get(expkey).contains("Integer")) {
                                flag1 = searchResults.getCount() % 1 == 0;
                            }
                        } else if (expkey.contains("Tracking Number")) {
                            flag1 = searchResults.getShipmentId().equalsIgnoreCase(
                                    this.commonHelpers.getValuefromContextStore(expectedKV.get(expkey)).toString());
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "MS_Preferences_user":
                break;
            case "FedEx_UserInfo":
                Userinfo userInfo = this.commonHelpers.unMarshall(resp.asString(), Userinfo.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expkey.contains("transactionId")) {
                            flag1 = this.commonHelpers.isGUID(userInfo.getTransactionId());
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "MS_Advisories_weather":
                OverallAlert alert = this.commonHelpers.unMarshall(resp.asString(), OverallAlert.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expkey.contains("id")) {
                            flag1 = alert.getId().getClass().toString().contains(expectedKV.get(expkey));
                        }
                    } else {
                        break;
                    }
                }
                break;
            case "CE_Advisories_weather":
                OverallAlert CEalert = this.commonHelpers.unMarshall(resp.asString(), OverallAlert.class);
                for (String expkey : expectedKV.keySet()) {
                    if (flag1) {
                        if (expkey.contains("allShipment")) {
                            flag1 = CEalert.getCountries().size() >= 0;
                        }
                    } else {
                        break;
                    }
                }
                break;
        }

        Assert.assertEquals("Status Code is not 200 ", Integer.parseInt(StatusCode), resp.getStatusCode());
        Assert.assertTrue("Validation of " + endPointKey + " API is failed", flag1);
    }

    @Given("^I select \"([^\"]*)\" tracking number from the list and store in \"([^\"]*)\"$")
    public void i_select_tracking_number_from_the_list_and_store_in(String index, String keyToStore) throws Throwable {
        try {
            Response resp = this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")
                    ? this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Overview")
                    : this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
            ShipmentList sl = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            Integer filteredRec = sl.getTotalFilteredRecords();
            ShipmentDetailsResponse shipmentData = new ShipmentDetailsResponse();
            if (filteredRec > 0) {
                if (index.equalsIgnoreCase("random")) {
                    int randomnumber = this.commonHelpers.GenerateRandomNumber(sl.getData().size());
                    shipmentData = sl.getData().get(randomnumber);
                    if (keyToStore.contains("Tracking")) {
                        this.commonHelpers.AddToContextStore("Tracking Number", shipmentData.getTrackingNumber());
                        this.commonHelpers.AddToContextStore("Status", shipmentData.getStatus());
                        this.commonHelpers.AddToContextStore("ShipmentId", shipmentData.getShipmentId());
                    }
                } else if (index.equalsIgnoreCase("multiTrackRandomNumber")) {
                    int randomnumber = this.commonHelpers.GenerateRandomNumber(sl.getData().size());
                    List<String> listTracks = new ArrayList<>();
                    for (int i = 0; i < randomnumber; i++) {
                        shipmentData = sl.getData().get(i);
                        if (shipmentData.getTrackingNumber().length() >= 11) {
                            listTracks.add(shipmentData.getTrackingNumber());
                        }
                    }
                    if (keyToStore.contains("Tracking")) {
                        this.commonHelpers.AddToContextStore("Tracking Number", listTracks);
                    }
                } else if (index.equalsIgnoreCase("multimasterTrackingNumber")) {
                    int randomnumber = this.commonHelpers.GenerateRandomNumber(sl.getData().size());
                    List<String> listTracks = new ArrayList<>();
                    for (int i = 0; i < randomnumber; i++) {
                        shipmentData = sl.getData().get(i);
                        String data = (String) shipmentData.getMasterTrackingNumber();
                        listTracks.add(data);
                        this.commonHelpers.AddToContextStore("masterTrackingNumber" + i, data);
                    }
                    if (keyToStore.contains("masterTrackingNumber")) {
                        this.commonHelpers.AddToContextStore("masterTrackingNumber", listTracks);
                    }
                } else if (index.equalsIgnoreCase("masterTrackingNumber")) {
                    boolean virtualizationFlag = Boolean
                            .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
                    if (!virtualizationFlag || this.commonHelpers.getValuefromContextStore("UserContext").toString()
                            .equalsIgnoreCase("CE")) {
                        shipmentData = this.SelectMasterTrackingNumber(sl);
                        if (keyToStore.contains("mastertrackingNumber")) {
                            this.commonHelpers.AddToContextStore("shipmentId", shipmentData.getShipmentId());
                            this.commonHelpers.AddToContextStore(keyToStore.split("-")[1],
                                    shipmentData.getMasterTrackingNumber());
                            this.commonHelpers.AddToContextStore("Status", shipmentData.getStatus());
                            this.commonHelpers.AddToContextStore("Tracking Number", shipmentData.getTrackingNumber());
                        }
                    } else {
                        this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                    }
                } else if (index.contains("Total-")) {
                    int randomnumber = Integer.valueOf(index.split("-")[1]);
                    List<String> listTracks = new ArrayList<>();
                    for (int i = 0; i < randomnumber; i++) {
                        shipmentData = sl.getData().get(i);
                        String data = shipmentData.getTrackingNumber();
                        listTracks.add(data);
                        this.commonHelpers.AddToContextStore("Tracking Number" + i, data);
                    }
                    if (keyToStore.contains("Tracking")) {
                        this.commonHelpers.AddToContextStore("Tracking Number", listTracks);
                    }
                } else {
                    shipmentData = sl.getData().get(Integer.valueOf(index));
                    if (keyToStore.contains("Tracking")) {
                        this.commonHelpers.AddToContextStore("Tracking Number", shipmentData.getTrackingNumber());
                        this.commonHelpers.AddToContextStore("Status", shipmentData.getStatus());
                        this.commonHelpers.AddToContextStore("ShipmentId", shipmentData.getShipmentId());
                    }
                }
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }

        } catch (Exception e) {
            log.error(" **EXCEPTION** " + e.getMessage());
            if (index.equalsIgnoreCase("masterTrackingNumber")) {
                Assert.fail("Unable to find the MPS shipment, Hence failed" + e.getMessage());
            } else {
                Assert.fail("Something went wrong in the selection of random tracking number" + e.getMessage());
            }
        }

    }

    public ShipmentDetailsResponse SelectMasterTrackingNumber(ShipmentList shipmentList) {
        ShipmentDetailsResponse shipmentData = new ShipmentDetailsResponse();
        try {
            String endPoint = this.commonHelpers.getValuefromContextStore("UserContext").toString()
                    .equalsIgnoreCase("CE") ? "CE_Shipments_Overview" : "MS_Shipments_Overview";
            boolean flag = false;
            while (!flag) {
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    if (response.getMasterTrackingNumber() != null && response.getShipmentRelationships().size() > 0) {
                        shipmentData = response;
                        flag = true;
                        break;
                    }
                }
                if (!flag) {
                    if (shipmentList.getData().size() != 0) {
                        this.RetryWithIncrementedPageSize();
                        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPoint);
                        shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
                    } else {
                        flag = true;
                        break;
                    }

                }
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in SelectMasterTrackingNumber: "
                    + (e.getMessage() == null ? "MPS is not found" : e.getMessage()));
            Assert.fail("Unable to find the MPS shipment");
        }
        return shipmentData;
    }

    public void RetryWithIncrementedPageSize() {
        String endPoint = this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")
                ? "CE_Shipments_Overview"
                : "MS_Shipments_Overview";
        ShipmentsOverview shipment = (ShipmentsOverview) this.commonHelpers.GetrequestPayload(endPoint);
        // log.info("Making call to MS_Shipments_Overview with incrementing of
        // page size: "
        // + (shipment.getCurrentPage() + 1));
        // shipment.setCurrentPage(shipment.getCurrentPage() + 1);
        this.commonHelpers.AddToRequestPayloadCollection(endPoint, shipment);
        this.apiobj.WhenIMakepostCall(endPoint);
    }

    public void CreatePayloadforDefaultHierarchy(String endPointKey) throws Throwable {
        DefaultHierarchy defaultHierarchy = new DefaultHierarchy();
        CompanyAndAccountHierarchy companyAndAccountHierarchy = this.commonHelpers.unMarshall(
                this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString(),
                CompanyAndAccountHierarchy.class);

        defaultHierarchy.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);
        defaultHierarchy.setWorkgroups(new ArrayList());
        this.commonHelpers.AddToRequestPayloadCollection(endPointKey, defaultHierarchy);
    }

    @Given("^I configure view for \"([^\"]*)\" with below properties$")
    public void i_configure_view_for_with_below_properties(String endPointKey, DataTable dataTable) throws Throwable {
        try {
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            for (String key : table.keySet()) {
                switch (key) {
                    case "Name":
                        this.view.setName(table.get(key));
                        break;
                    case "Columns":
                        this.setColumnsinaView(table.get(key));
                        break;
                    case "Shared":
                        this.view.setShared(table.get(key).equals("true"));

                }

            }
            this.view.setFilterList(this.filters);
            this.view.setQuickViewList(this.quickviewfilters);
            this.view.setSearchFilterList(this.searchFilterList);
            this.view.setSortList(this.sortList);
            this.commonHelpers.AddToRequestPayloadCollection(endPointKey, this.view);
            System.out.printf("Payload for %s is: %s %n", endPointKey, this.commonHelpers.Marshall(this.view));

        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in the payload configuration of views");
        }
    }

    public void setColumnsinaView(String columns) {
        String persona = this.commonHelpers.getValuefromContextStore("UserContext").toString();
        switch (columns) {
            case "All Columns":
                this.view.setColumnList(
                        persona.equalsIgnoreCase("CE") ? Constants.CEAllColumns : Constants.CustomerAllColumns);
                break;
            case "All Shipment":
                break;
            case "All Shipper":
                break;
            case "All Recipient":
                break;
            case "Default":
                this.view.setColumnList(
                        persona.equalsIgnoreCase("CE") ? Constants.CEDefaultColumns : Constants.CustomerDefaultColumns);
                break;
        }
    }

    @Given("^I add \"([^\"]*)\" attribute for the quickViewfilterlist payload which is for overview$")
    public void i_add_attribute_for_the_quickViewfilterlist_payload_which_is_for_overview(String count,
            DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                this.quickviewfilters.clear();
                if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                    return;
                Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                int initialCount = Integer.parseInt(count);
                int countValue = Integer.parseInt(count);
                while (countValue > 0) {
                    QuickViewList quickViewlist = new QuickViewList();
                    for (String key : table.keySet()) {
                        String contentData = table.get(key).split(":")[initialCount - countValue];
                        if (key.contains("field")) {
                            quickViewlist.setField(contentData);
                        } else if (key.contains("valueList")) {
                            if (contentData.contains("Today")) {
                                quickViewlist.setValueList(this.SetRangeValueList(contentData));
                            } else {
                                contentData = contentData.contains("ContextStore")
                                        ? this.commonHelpers.getValuefromContextStore(contentData).toString()
                                        : contentData;
                                quickViewlist.setValueList(
                                        contentData.split(",").length > 1 ? Arrays.asList(contentData.split(","))
                                                : new ArrayList<String>(Arrays.asList(contentData)));
                            }

                        } else if (key.contains("type")) {
                            quickViewlist.setType(contentData);
                        } else if (key.contains("displayField")) {
                            if (contentData.equalsIgnoreCase("NA")) {
                                quickViewlist.setDisplayField("");
                            } else {
                                quickViewlist.setDisplayField(contentData);
                            }
                        }
                    }
                    this.quickviewfilters.add(quickViewlist);
                    countValue--;
                }

            } catch (Exception e) {
                log.error(
                        "**EXCEPTION** Something went wrong in i_add_attribute_for_the_quick view filterlist_payload_which_is_for_overview: "
                                + e.getMessage());
                Assert.fail();
            }
        }

    }

    @Then("^I delete all available views for the user \"([^\"]*)\"$")
    public void i_delete_all_available_views_for_the_user(String user) throws Throwable {
        String context = user.equalsIgnoreCase("CE") ? "CE_GET_Views" : "MS_User_Views";
        this.apiobj.WhenIMakegetCall(context);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(context);
        List<GetView> getAllViews = this.commonHelpers.unMarshall(resp, GetView[].class);
        if (getAllViews.size() > 0) {
            for (GetView getView : getAllViews) {
                if(getView.getviewType().equalsIgnoreCase("custom")){
                    this.apiobj.DeleteWatchlistwithQueryparms(
                            (user.equalsIgnoreCase("CE") ? "CE_DELETE_view" : "MS_DELETE_view"), getView.getId());
                }
            }
        }
    }

    @Then("^I delete \"([^\"]*)\" available views for the user \"([^\"]*)\"$")
    public void i_delete_available_view_for_the_user(String view,String user) throws Throwable {
        String context = user.equalsIgnoreCase("CE") ? "CE_GET_Views" : "MS_User_Views";
        this.apiobj.WhenIMakegetCall(context);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(context);
        List<GetView> getAllViews = this.commonHelpers.unMarshall(resp, GetView[].class);
        if (getAllViews.size() > 0) {
            for (GetView getView : getAllViews) {
                if(view.equalsIgnoreCase(getView.getName())) {
                    this.apiobj.DeleteWatchlistwithQueryparms(
                            (user.equalsIgnoreCase("CE") ? "CE_DELETE_view" : "MS_DELETE_view"), getView.getId());
                }
            }
        }
    }


    @Then("^I delete \"([^\"]*)\" available views for the endpoint \"([^\"]*)\" in PreshipmentAdvisories$")
    public void i_delete_available_view_for_the_users(String view,String endPoint) throws Throwable {
//        String context = "MS_DELETE_PREF_view";
        this.apiobj.WhenIMakegetCall(endPoint);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPoint);
        JSONArray listObj = JSONHelpers.StringtoJArray(resp.asString());
        for (Object expkey : listObj) {
            if(view.equalsIgnoreCase(((JSONObject) expkey).getString("name"))) {
                this.apiobj.DeleteWatchlistwithQueryparms(
                        endPoint, ((JSONObject) expkey).getString("id"));
            }
        }
    }


     @Then("^I delete all available files from dc for the user \"([^\"]*)\"$")
    public void i_delete_all_available_files_from_dc_for_the_user(String user) throws Throwable {
        String context = user.equalsIgnoreCase("CE") ? "CE_User_DCFiles" : "MS_User_DCFiles";
        this.apiobj.WhenIMakegetCall(context);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(context);
        List<GetDCFiles> getAllFiles = this.commonHelpers.unMarshall(resp, GetDCFiles[].class);
        if (getAllFiles.size() > 0) {
            for (GetDCFiles getfile : getAllFiles) {
                this.apiobj.DeleteWatchlistwithQueryparms(
                        (user.equalsIgnoreCase("CE") ? "CE_DELETE_file" : "MS_DELETE_file"), getfile.getId());
            }
        }
    }

    @Given("^I add \"([^\"]*)\" attribute for the \"([^\"]*)\" payload for Views payload$")
    public void i_add_attribute_for_the_payload_for_Views_payload(String count, String context, DataTable dataTable)
            throws Throwable {
        switch (context) {
            case "filterlist":
                this.i_add_attribute_for_the_filterlist_payload_which_is_for_overview(count, dataTable);
                break;
            case "sortlist":
                this.i_add_attribute_for_the_sortlist_payload_which_is_for_overview(count, dataTable);
                break;
            case "quickViewfilterlist":
                this.i_add_attribute_for_the_quickViewfilterlist_payload_which_is_for_overview(count, dataTable);
                break;
            case "searchfilterlist":
                this.i_add_attribute_for_the_searchfilterlist_payload_which_is_for_overview(count, dataTable);
                break;
        }
    }

    @When("^I add \"([^\"]*)\" attribute for the filterlist payload which is for overview$")
    public void i_add_attribute_for_the_filterlist_payload_which_is_for_overview(String count, DataTable dataTable) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                this.filters.clear();
                if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                    return;
                Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                int initialCount = Integer.parseInt(count);
                int countValue = Integer.parseInt(count);
                while (countValue > 0) {
                    FilterList filterlist = new FilterList();
                    for (String key : table.keySet()) {
                        if (!(key.contains("dateOptions") || key.contains("timeOptions"))) {
                            String contentData = table.get(key).split(":")[initialCount - countValue];
                            if (key.contains("field")) {
                                filterlist.setField(contentData);
                            } else if (key.contains("valueList")) {
                                if (contentData.contains("Today")) {
                                    filterlist.setValueList(this.SetRangeValueList(contentData));
                                } else if (contentData.contains("FromNowDateTime")) {
                                    filterlist.setValueList(this.SetRangeValueListWithDateandTime(contentData));
                                } else {
                                    contentData = contentData.contains("ContextStore")
                                            ? this.commonHelpers.getValuefromContextStore(contentData).toString()
                                            : contentData;
                                    filterlist.setValueList(
                                            contentData.split(",").length > 1
                                                    ? Arrays.asList(contentData.trim().split(","))
                                                    : new ArrayList<String>(Arrays.asList(contentData)));
                                }

                            } else if (key.contains("type")) {
                                filterlist.setType(contentData);
                            } else if (key.contains("displayText")) {
                                if (contentData.equalsIgnoreCase("NA")) {
                                    filterlist.setDisplayText("");
                                } else if (contentData.contains("Today")) {
                                    String temp = "";
                                    for (int k = 0; k < filterlist.getValueList().size() - 1; ++k) {
                                        if (k != 1) {
                                            temp += filterlist.getValueList().get(k) + " - ";
                                        } else {
                                            temp += filterlist.getValueList().get(k);
                                        }
                                    }
                                    filterlist.setDisplayText(temp);
                                } else if ((contentData.contains("Special Handling"))
                                        || (contentData.contains("Package Weight"))
                                        || (contentData.contains("Total Weight"))
                                        || (contentData.contains("Recipient Country/ Territory"))) {
                                    String contentDataStatic = table.get(key).split(",")[0];
                                    String contentDataCS = table.get(key).split(",")[1];
                                    contentDataCS = contentDataCS.contains("ContextStore")
                                            ? this.commonHelpers.getValuefromContextStore(contentDataCS).toString()
                                            : contentDataCS;
                                    contentData = contentDataStatic + ":" + contentDataCS;
                                    filterlist.setDisplayText(contentData);
                                    continue;
                                } else if (contentData.contains("ContextStore")) {
                                    contentData = contentData.contains("ContextStore")
                                            ? this.commonHelpers.getValuefromContextStore(contentData).toString()
                                            : contentData;
                                    filterlist.setDisplayText(contentData);
                                } else {
                                    filterlist.setDisplayText(contentData);
                                }
                            } else if (key.contains("displayField")) {
                                if (contentData.contains("Today")) {
                                    filterlist.setDisplayField(contentData);
                                } else if (contentData.contains("NA")) {
                                    filterlist.setDisplayField("");
                                } else {
                                    filterlist.setDisplayField(contentData);
                                }
                            } else if (key.contains("isType")) {
                                if (contentData.contains("NA")) {
                                    filterlist.setIsType(false);
                                } else {
                                    filterlist.setIsType(Boolean.parseBoolean(contentData));
                                }
                            } else if (key.contains("isAdvanceSearch")) {
                                if (contentData.contains("NA")) {
                                    filterlist.setIsAdvanceSearch(false);
                                } else {
                                    filterlist.setIsAdvanceSearch(Boolean.parseBoolean(contentData));
                                }
                            } else if (key.contains("pastOptions")) {
                                if (contentData.contains("NA")) {
                                    filterlist.setPastOptions(false);
                                } else {
                                    filterlist.setPastOptions(Boolean.parseBoolean(contentData));
                                }
                            }
                        } else if (key.contains("dateOptions") || key.contains("timeOptions")) {
                            String contentData = table.get(key).split(":")[(initialCount - countValue) + 1];
                            if (key.contains("dateOptions")) {
                                DateOptions dateOptions = new DateOptions();
                                dateOptions.setLast(Integer.parseInt(contentData));
                                filterlist.setDateOptions(dateOptions);
                            } else if (key.contains("timeOptions")) {
                                TimeOptions timeOptions = new TimeOptions();
                                timeOptions.setLast(Integer.parseInt(contentData));
                                filterlist.setTimeOptions(timeOptions);
                            }

                        }
                    }
                    this.filters.add(filterlist);
                    countValue--;
                }

            } catch (Exception e) {
                log.error(
                        "**EXCEPTION** Something went wrong in i_add_attribute_for_the_filterlist_payload_which_is_for_overview: "
                                + e.getMessage());
                Assert.fail();
            }
        }

    }

    @Given("^I add \"([^\"]*)\" attribute for the searchfilterlist payload which is for overview$")
    public void i_add_attribute_for_the_searchfilterlist_payload_which_is_for_overview(String count,
            DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                this.searchFilterList.clear();
                if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                    return;
                Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                int initialCount = Integer.parseInt(count);
                int countValue = Integer.parseInt(count);
                while (countValue > 0) {
                    SearchFilterList searchFilter = new SearchFilterList();
                    for (String key : table.keySet()) {
                        String contentData = table.get(key).split(":")[initialCount - countValue];
                        if (key.contains("field")) {
                            searchFilter.setField(contentData);
                        } else if (key.contains("valueList")) {
                            contentData = contentData.contains("ContextStore")
                                    ? this.commonHelpers.getValuefromContextStore(contentData).toString()
                                    : contentData;
                            searchFilter.setValueList(
                                    contentData.split(",").length > 1 ? Arrays.asList(contentData.split(","))
                                            : new ArrayList<String>(Arrays.asList(contentData)));
                        } else if (key.contains("type")) {
                            searchFilter.setType(contentData);
                        } else if (key.contains("displayText")) {
                            searchFilter.setDisplayText(contentData);
                        } else if (key.contains("displayField")) {
                            searchFilter.setDisplayField(contentData);
                        }
                    }
                    this.searchFilterList.add(searchFilter);
                    countValue--;
                }

            } catch (Exception e) {
                log.error(
                        "**EXCEPTION** Something went wrong in i_add_attribute_for_the_filterlist_payload_which_is_for_overview: "
                                + e.getMessage());
                Assert.fail();
            }
        }
    }

    public List<String> SetRangeValueList(String timerange) {
        List<String> datesArray = new ArrayList<>();
        List<String> multipleDates = new ArrayList<>();
        try {
            if (timerange.contains(",")) {
                multipleDates = Arrays.asList(timerange.split(","));
                for (String dt : multipleDates) {
                    if (dt.contains("="))
                        multipleDates = Arrays.asList(timerange.split("="));
                }
            } else if (timerange.contains("=")) {
                multipleDates = Arrays.asList(timerange.split("="));
            }
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date myDate = new Date(System.currentTimeMillis());
            Calendar cal = Calendar.getInstance();
            for (String date : multipleDates) {
                if (date.contains("-")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, Integer.parseInt("-" + date.split("-")[1]));
                } else if (date.equalsIgnoreCase("Today")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, 0);
                } else if (date.contains("+")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, Integer.parseInt(date.split("\\+")[1]));
                }

                if (!date.equals(("Specific Date"))) {
                    datesArray.add(dateFormat.format(cal.getTime()));
                }
            }
            if (!timerange.contains("Specific Date")) {
                datesArray.add("-330");
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Failed in SetRangeValueList: " + timerange);
            Assert.fail("Failed in SetRangeValueList: " + timerange);
        }

        return datesArray;
    }

    @Given("^I add \"([^\"]*)\" attribute for the sortlist payload which is for overview$")
    public void i_add_attribute_for_the_sortlist_payload_which_is_for_overview(String count, DataTable dataTable)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.sortList.clear();
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            int initialCount = Integer.parseInt(count);
            int countValue = Integer.parseInt(count);
            SortList sortslist = new SortList();
            while (countValue > 0) {
                for (String key : table.keySet()) {
                    String contentData = table.get(key).split(":")[initialCount - countValue];
                    if (key.contains("field")) {
                        sortslist.setField(contentData);
                    } else if (key.contains("order")) {
                        sortslist.setOrder(contentData);
                    }
                }
                this.sortList.add(sortslist);
                countValue--;
            }
        }
    }

    @Given("^Get the user preferences using \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void get_the_user_preferences_using_for_the_user(String endPointKey, String userContext) throws Throwable {
        this.apiobj.SetCookies(userContext);
        this.apiobj.WhenIMakegetCall(endPointKey);
    }

    @Given("^I update user preferences using \"([^\"]*)\" for the user \"([^\"]*)\" with below values$")
    public void i_update_user_preferences_using_for_the_user_with_below_values(String endPointKey, String userContext,
            DataTable dataTable) throws Throwable {
        this.apiobj.SetCookies(userContext);
        userContext = userContext.equalsIgnoreCase("CE") ? "CE" : "MS";
        this.CreatePayloadforPref(userContext.concat("_Preferences_user"), endPointKey, "UpdatePreferences", dataTable);
        this.apiobj.WhenIMakeputCall(endPointKey);
    }

    @Given("^I clear all user preferred locations using \"([^\"]*)\" using \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_clear_all_user_preferred_locations_using_using_for_the_user(String payloadStore, String endPoint,
            String userContext) throws Throwable {
        this.apiobj.SetCookies(userContext);
        DataTable dataTable = null;
        this.CreatePayloadforPref(payloadStore, endPoint, "RemovePreferredCities", dataTable);
        this.apiobj.WhenIMakeputCall(endPoint);
    }

    public void CreatePayloadforPrefRole(String refPayloadEPKey, String endPointkey, String purpose) throws Exception {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(refPayloadEPKey);
        RolePreference rolePreference = new RolePreference();
        UserPreferences userPreferences = this.commonHelpers.unMarshall(resp.asString(), UserPreferences.class);
        DefaultImageRole defaultImageRole = new DefaultImageRole();
        SelectedImageRole selectedImageRole = new SelectedImageRole();
        defaultImageRole.setDisplayName(Constants.IRDisplayName);
        defaultImageRole.setRoleName(Constants.ImageRoleName);
        selectedImageRole.setDisplayName(Constants.IRDisplayName);
        selectedImageRole.setRoleName(Constants.ImageRoleName);
        if (purpose.equalsIgnoreCase("AssignDefaultRoles")) {
            rolePreference.setDefaultImageRole(defaultImageRole);
            rolePreference.setSelectedImageRole(selectedImageRole);
        }
        this.commonHelpers.AddToRequestPayloadCollection(endPointkey, rolePreference);
    }

    public void CreatePayloadforPref(String refPayloadEPKey, String endPointkey, String purpose, DataTable dataTable)
            throws Exception {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(refPayloadEPKey);
        List<PreferredDestinationCity> preferredDestinationCities = new ArrayList();
        DefaultImageRole defaultImageRoles = new DefaultImageRole();
        SelectedImageRole selectedImageRole = new SelectedImageRole();
        List<PreferredOriginCity> preferredOriginCities = new ArrayList();
        PreferredDestinationCity preferredDestinationCity = new PreferredDestinationCity();
        PreferredOriginCity preferredOriginCity = new PreferredOriginCity();
        UserPreferences userPreferences = this.commonHelpers.unMarshall(resp.asString(), UserPreferences.class);
        if (purpose.equalsIgnoreCase("RemovePreferredCities")) {
            userPreferences.setAutoSelectCities(true);
            userPreferences.setPreferredDestinationCities(null);
            userPreferences.setPreferredOriginCities(null);
        } else if (purpose.equalsIgnoreCase("UpdatePreferences")) {
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            for (String key : table.keySet()) {
                switch (key) {
                    case "preferredDateFormat":
                        userPreferences.setPreferredDateFormat(table.get(key));
                        this.commonHelpers.AddToContextStore(key, table.get(key));
                        break;
                    case "preferredTimeFormat":
                        userPreferences.setPreferredTimeFormat(table.get(key));
                        this.commonHelpers.AddToContextStore(key, table.get(key));
                        break;
                    case "preferredTempFormat":
                        userPreferences.setPreferredTemperatureFormat(table.get(key));
                        break;
                    case "releaseForWhatsNew":
                        if (!table.get(key).equals(this.commonHelpers.getValuefromContextStore("releaseVersion")))
                            userPreferences.setReleaseForWhatsNew(table.get(key));
                        break;
                    case "QuickViewCardsPreference":
                        if (table.get(key).equalsIgnoreCase("All Eight Set 1")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet1));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 2")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet2));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 3")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet3));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 4")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet4));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 5")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet5));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 6")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet6));
                        } else if (table.get(key).equalsIgnoreCase("All Eight Set 7")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet7));
                        }else if (table.get(key).equalsIgnoreCase("All Eight Set 8")) {
                            userPreferences.setQuickViewCardsPreference(Arrays.asList(Constants.allQuickViewCardsSet8));
                        }
                        userPreferences.setHideQuickView(false);
                        userPreferences.setSavedViewCardsPreference(null);
                        break;
                    case "defaultImageRole":
                        defaultImageRoles.setRoleName(GenericFunction.ReadConfigFile(table.get(key).split(":")[1]));
                        defaultImageRoles.setDisplayName(table.get(key).split(":")[0]);
                        userPreferences.setDefaultImageRole(defaultImageRoles);
                        break;
                    case "selectedImageRole":
                        selectedImageRole.setRoleName(GenericFunction.ReadConfigFile(table.get(key).split(":")[1]));
                        selectedImageRole.setDisplayName(table.get(key).split(":")[0]);
                        userPreferences.setSelectedImageRole(selectedImageRole);
                        break;
                }
            }
        } else if (purpose.equalsIgnoreCase("AddPreferredCities")) {
            if (this.commonHelpers.verifyKeyInContextStore("CityCode")) {
                userPreferences.setAutoSelectCities(false);
                preferredDestinationCity
                        .setCityId(Integer.valueOf(this.commonHelpers.getValuefromContextStore("CityCode").toString()));
                preferredDestinationCity
                        .setCityName(this.commonHelpers.getValuefromContextStore("CityName").toString());
                preferredDestinationCity
                        .setStateInitial(this.commonHelpers.getValuefromContextStore("StateName").toString());
                preferredDestinationCity
                        .setCountryInitial(this.commonHelpers.getValuefromContextStore("CountryName").toString());
                preferredOriginCity
                        .setCityId(Integer.valueOf(this.commonHelpers.getValuefromContextStore("CityCode").toString()));
                preferredOriginCity
                        .setCityName(this.commonHelpers.getValuefromContextStore("CityName").toString());
                preferredOriginCity
                        .setStateInitial(this.commonHelpers.getValuefromContextStore("StateName").toString());
                preferredOriginCity
                        .setCountryInitial(this.commonHelpers.getValuefromContextStore("CountryName").toString());
                preferredDestinationCities.add(preferredDestinationCity);
                preferredOriginCities.add(preferredOriginCity);
                userPreferences.setPreferredDestinationCities(preferredDestinationCities);
                userPreferences.setPreferredOriginCities(preferredOriginCities);
            }

        }
        this.commonHelpers.AddToRequestPayloadCollection(endPointkey, userPreferences);
    }

    @When("^I create payload for \"([^\"]*)\" using below values$")
    public void i_create_payload_for_using_below_values(String endPoint, DataTable dataTable) {
        boolean companyFlag = false;
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                    return;
                Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                for (String key : table.keySet()) {
                    if (key.contains("currentPage")) {
                        this.shipmentsOverview.setCurrentPage(Integer.parseInt(table.get(key)));
                    } else if (key.contains("pageSize")) {
                        this.shipmentsOverview.setPageSize(Integer.parseInt(table.get(key)));
                    } else if (key.contains("company")) {
                        if (table.get(key).equalsIgnoreCase("ContextStore-CompanyCode")) {
                            this.shipmentsOverview
                                    .setCompany(this.commonHelpers.getValuefromContextStore(table.get(key)).toString());
                        } else {
                            this.shipmentsOverview.setCompany(table.get(key));
                        }
                    }
                    if (key.contains("CompanyAccHierarchy")) {
                        if (this.commonHelpers.verifyKeyInContextStore("CompanyAccHierarchy")) {
                            this.SetCompanyContext(table.get(key));
                            CompanyAndAccountHierarchy companyAndAccountHierarchy = this.commonHelpers.unMarshall(
                                    this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString(),
                                    CompanyAndAccountHierarchy.class);
                            this.shipmentsOverview.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);
                            companyFlag = true;
                        }
                    }
                    if (key.contains("data")) {
                        this.shipmentsOverview.setData();
                    }
                }
                this.shipmentsOverview.setSortList(this.sortList);
                this.shipmentsOverview.setFilterList(this.filters);
                if (this.commonHelpers.verifyKeyInContextStore("CompanyAccHierarchy") && !companyFlag) {
                    CompanyAndAccountHierarchy companyAndAccountHierarchy = this.commonHelpers.unMarshall(
                            this.commonHelpers.getValuefromContextStore("CompanyAccHierarchy").toString(),
                            CompanyAndAccountHierarchy.class);
                    this.shipmentsOverview.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);
                }
                if (this.commonHelpers.verifyKeyInContextStore("workgroupIdList") && !companyFlag) {
                    List<String> wgList = new ArrayList<>();
                    wgList.add((String) this.commonHelpers.getValuefromContextStore("workgroupIdList"));
                    this.shipmentsOverview.setWorkGroupIdList(wgList);
                    // Set default company to null
                    if (this.shipmentsOverview.getCompanyAndAccountHierarchy() != null) {
                        this.shipmentsOverview.getCompanyAndAccountHierarchy().set15603292(null);
                    }
                }
                this.commonHelpers.AddToRequestPayloadCollection(endPoint, this.shipmentsOverview);
                System.out.printf("Payload for %s is: %s %n", endPoint,
                        this.commonHelpers.Marshall(this.shipmentsOverview));

            } catch (Exception e) {
                log.error(" **EXCEPTION** Something went wrong in i_create_payload_for_using_below_values: " + e);
            }
        }
    }

    public void SetCompanyContext(String CompanyName) throws Exception {
        List<CompanyHierarchy> companieslist = new ArrayList<>();
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_CompanyHierarchy");
        List<CompanyHierarchy> companies = this.commonHelpers.unMarshall(resp, CompanyHierarchy[].class);
        for (CompanyHierarchy board : companies) {
            if (board.getCompanyName().equalsIgnoreCase(CompanyName)) {
                companieslist.add(board);
            }
        }
        log.info("Companies list size is " + companieslist.size());
        int index;
        if (companieslist.size() >= 1) {
            index = this.commonHelpers.GenerateRandomNumber(companieslist.size());
        } else
            index = 0;

        if (!(index == 0)) {
            CompanyHierarchy randomCompany = companieslist.get(index);
            log.info("Company Selected is --> " + randomCompany.getCompanyName());
            this.commonHelpers.AddToContextStore("CompanyName", randomCompany.getCompanyName());
            this.commonHelpers.AddToContextStore("CompanyCode", randomCompany.getCompanyCode());
            this.commonHelpers.AddToContextStore("CompanyAccHierarchy", this.apiobj
                    .CompanyAccountMapping(companieslist.get(0).getCompanyCode(), companieslist.get(0).getAccountId()));
        } else {
            log.info("Could not set the company name / code or CompanyAccHierarchy");
        }
    }

    @Then("^I make a POST request to resource \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_make_a_POST_request_to_resource_for_the_user(String endPointKey, String userId) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.apiobj.SetCookies(userId);
            this.apiobj.WhenIMakepostCall(endPointKey);
        }
    }

    @Given("^I update \"([^\"]*)\" view title as \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_update_view_title_as_for_the_user(String ViewName, String UpdatedViewName, String user)
            throws Throwable {
        String context = user.equalsIgnoreCase("CE") ? "CE_GET_Views" : "MS_User_Views";
        this.apiobj.WhenIMakegetCall(context);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(context);
        List<GetView> getAllViews = this.commonHelpers.unMarshall(resp, GetView[].class);
        if (getAllViews.size() > 0) {
            for (GetView view : getAllViews) {
                if (view.getName().equalsIgnoreCase(ViewName)) {
                    view.setName(UpdatedViewName);
                    this.commonHelpers.AddToRequestPayloadCollection("CE_User_Views", view);
                    this.commonHelpers.AddToContextStore("ViewId", view.getId());
                    break;
                }
            }
        }
        this.apiobj.WhenIMakeputCall("CE_User_Views");
    }

    @Given("^I delete a view with viewId as \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_delete_a_view_with_viewId_as_for_the_user(String ViewId, String user) throws Throwable {
        String viewId = this.commonHelpers.getValuefromContextStore("ViewId").toString();
        this.apiobj.DeleteWatchlistwithQueryparms(
                (user.equalsIgnoreCase("CE") ? "CE_DELETE_view" : "MS_DELETE_view"), viewId);
    }

    @Then("^I create a payload for \"([^\"]*)\" using below parameters for \"([^\"]*)\"$")
    public void i_create_a_payload_for_using_below_parameters_for(String commentType, String endPointKey,
            DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            try {
                AddComment addComment = new AddComment();
                API.RequestModels.Comment comment = new API.RequestModels.Comment();
                if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                    return;
                Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                for (String field : table.keySet()) {
                    if (field.equalsIgnoreCase("shipmentId")) {
                        addComment.setShipmentId(
                                this.commonHelpers.getValuefromContextStore(table.get(field)).toString());
                    } else if (field.equalsIgnoreCase("message")) {
                        comment.setMessage(table.get(field));
                        addComment.setComment(comment);
                    } else if (field.equalsIgnoreCase("ICalled")) {
                        Icalled icalled = new Icalled();
                        Recipient recipient = new Recipient();
                        recipient.setCallStatus(table.get(field));
                        icalled.setRecipient(recipient);
                        addComment.setIcalled(icalled);
                    } else if (field.equalsIgnoreCase("id")) {
                        addComment.setId(this.commonHelpers.getValuefromContextStore(table.get(field)).toString());
                    } else if (field.equalsIgnoreCase("isRepeatLastComment")) {
                        comment.setIsRepeatLastComment(table.get(field));
                        addComment.setComment(comment);
                    }
                }
                this.commonHelpers.AddToRequestPayloadCollection(endPointKey, addComment);
            } catch (Exception e) {
                log.error(" **EXCEPTION** Something went wrong in create payload for add comment method: "
                        + e.getMessage());
                e.printStackTrace();
                Assert.fail();
            }
        }

    }

    // Step only applicable to CE as there we have multiple accounts and there the
    // API for CE_CompanyHierarchy would be called
    @Then("^I create a payload for more than one company with \"([^\"]*)\" using below parameters for Accounts$")
    public void i_create_a_Payload_for_more_than_one_company(String endPointKey, DataTable dataTable) throws Throwable {
        try {
            List<String> allValues = dataTable.asList(String.class);

            // Get data from company Hierarchy to get the accountid based on the name of the
            // company
            Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_CompanyHierarchy");

            CompanyAndAccountHierarchy companyAndAccountHierarchy = new CompanyAndAccountHierarchy();

            List<CompanyHierarchy> companies = this.commonHelpers.unMarshall(resp, CompanyHierarchy[].class);
            for (String key : allValues) {
                List<CompanyHierarchy> company = companies.stream()
                        .filter(s -> s.getCompanyName().equalsIgnoreCase(key)).collect(Collectors.toList());
                if (company.size() == 0)
                    Assert.fail("The company passed is not found in list of companies");

                switch (company.get(0).getCompanyName()) {
                    case "Medtronic":
                        companyAndAccountHierarchy.set15603292(company.get(0).getAccountId());
                        break;
                    case "Abbott Laboratories":
                        companyAndAccountHierarchy.set485745989(company.get(0).getAccountId());
                        break;
                    case "adidas AG":
                        companyAndAccountHierarchy.set547768362(company.get(0).getAccountId());
                        break;
                    case "*I/B*BASF (CHINA) COMPANY LTD":
                        companyAndAccountHierarchy.set223346297(company.get(0).getAccountId());
                        break;
                    case "**TTS*CHINES PEPTIDE CO.,LTD":
                        companyAndAccountHierarchy.set264243718(company.get(0).getAccountId());
                        break;
                }

            }
            DefaultHierarchy defaultHierarchy = new DefaultHierarchy();
            defaultHierarchy.setCompanyAndAccountHierarchy(companyAndAccountHierarchy);

            this.commonHelpers.AddToContextStore(endPointKey, defaultHierarchy);
        } catch (Exception e) {
            log.error(
                    "**EXCEPTION** While creating the payload for CE_CompanyHierarchy inside i_create_a_Payload_for_more_than_one_company "
                            + e.getStackTrace());
        }
    }

    @Then("^I make a PUT request to resource \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_make_a_PUT_request_to_resource_for_the_user(String endPointKey, String user) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            this.apiobj.WhenIMakeputCall(endPointKey,
                    this.commonHelpers.getValuefromContextStore("ContextStore-ShipmentId").toString());
        }
    }

    @Given("^I delete the comment using \"([^\"]*)\" using below fields$")
    public void i_delete_the_comment_using_using_below_fields(String endPointKey, DataTable dataTable) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            String id = "";
            String shipmentId = "";
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            for (String field : table.keySet()) {
                if (field.equalsIgnoreCase("id")) {
                    id = this.commonHelpers.getValuefromContextStore(table.get(field)).toString();
                } else if (field.equalsIgnoreCase("shipmentId")) {
                    shipmentId = this.commonHelpers.getValuefromContextStore(table.get(field)).toString();
                }
            }
            this.apiobj.DeleteComment(endPointKey, id, shipmentId);
        }
    }

    @Given("^I store below values from \"([^\"]*)\" of \"([^\"]*)\" endpoint$")
    public void i_store_below_values_from_of_endpoint(String model, String endPointKey, DataTable dataTable)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            switch (endPointKey) {
                case "CE_AddComment":
                    Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
                    AddCommentResponse addCommentResponse = this.commonHelpers.unMarshall(resp.asString(),
                            AddCommentResponse.class);
                    if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                        return;
                    Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
                    for (String field : table.keySet()) {
                        if (field.equalsIgnoreCase("id")) {
                            this.commonHelpers.AddToContextStore(table.get(field), addCommentResponse.getId());
                        }
                    }
                    break;
            }
        }
    }

    @Given("^I Add \"([^\"]*)\" city from \"([^\"]*)\" as my preferred city using \"([^\"]*)\"$")
    public void i_Add_city_from_as_my_preferred_city_using(String countOfCities, String fromEndPoint,
            String endPointKey) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(fromEndPoint);
        try {
            OverallAlert alert = this.commonHelpers.unMarshall((resp.asString()), OverallAlert.class);
            Country country = alert.getCountries().get(0);
            List<City> cities = country.getCities();
            if (cities.size() >= Integer.parseInt(countOfCities)) {
                for (int index = 0; index < Integer.parseInt(countOfCities); ++index) {
                    if (cities.get(index).getWeatherAlerts().size() > 0) {
                        String CityStateCountry = String.format("%s,%s,%s", cities.get(index).getName(),
                                cities.get(index).getStateName(), cities.get(index).getCountry());
                        this.commonHelpers.AddToContextStore("CityName", cities.get(index).getName());
                        this.commonHelpers.AddToContextStore("StateName", cities.get(index).getStateName());
                        this.commonHelpers.AddToContextStore("CountryName", cities.get(index).getCountry());
                    }
                }
                DataTable dataTable = null;
                this.apiobj.WhenIMakegetCall("MS_GlobalCities",
                        this.commonHelpers.getValuefromContextStore("CityName").toString());
                Response GCresp = this.commonHelpers.GetValueFromResponseCollection("MS_GlobalCities");
                List<GlobalCity> citiesList = this.commonHelpers.unMarshall(GCresp, GlobalCity[].class);
                for (GlobalCity gc : citiesList) {
                    if (gc.getLocalizedName()
                            .equalsIgnoreCase(this.commonHelpers.getValuefromContextStore("CityName").toString())
                            && gc.getAdministrativeArea().getId().equalsIgnoreCase(
                                    this.commonHelpers.getValuefromContextStore("StateName").toString())
                            && gc.getCountry().getId().equalsIgnoreCase(
                                    this.commonHelpers.getValuefromContextStore("CountryName").toString())) {
                        this.commonHelpers.AddToContextStore("CityCode", gc.getKey());
                    }
                }
                this.CreatePayloadforPref("MS_Preferences_user", "MS_Preferences_Update", "AddPreferredCities",
                        dataTable);
                this.apiobj.WhenIMakeputCall("MS_Preferences_Update");
            }

        } catch (Exception e) {
            log.error("**EXCEPTION** in the function i_Add_city_from_as_my_preferred_city_using " + e);
        }
    }

    @Then("^I validate response of \"([^\"]*)\" is having below results$")
    public void i_validate_response_of_is_having_below_results(String endPointKey, DataTable table) throws Throwable {
        Boolean flag = true;
        List<String> AppendedValues = table.asList(String.class);
        int counter = 0;
        StringBuilder sBuilder = new StringBuilder();
        for (String cke : AppendedValues) {
            sBuilder.append(
                    counter == AppendedValues.size() - 1 ? this.commonHelpers.getValuefromContextStore(cke).toString()
                            : this.commonHelpers.getValuefromContextStore(cke).toString() + ", ");
            counter++;
        }
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
        List<String> Searchresults = this.commonHelpers.unMarshall(resp.asString(), List.class);
        for (String result : Searchresults) {
            if (flag) {
                flag = result.toUpperCase().contains(sBuilder.toString().toUpperCase());
                if (flag)
                    break;
            }
        }
        Assert.assertTrue("Validation of the search results is failed", flag);
    }

    @Given("^I Create \"([^\"]*)\" views using \"([^\"]*)\" for the user \"([^\"]*)\"$")
    public void i_Create_views_using_for_the_user(String noOfViews, String endPointKey, String userId) {
        int views = Integer.parseInt(noOfViews);
        View viewPayload = (View) this.commonHelpers.GetrequestPayload(endPointKey);
        String viewName = viewPayload.getName();
        for (int count = 1; count <= views; ++count) {
            viewPayload.setName(count + " " + viewName);
            this.commonHelpers.AddToRequestPayloadCollection(endPointKey, viewPayload);
            this.apiobj.WhenIMakepostCall(endPointKey);
        }
    }

    @Then("^I validate whether the shipments are intervened based on the given CER type using \"([^\"]*)\"$")
    public void i_validate_whether_the_shipment_are_intervened_based_on_the_given_CER_type_using(String endPointKey) {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            Assert.assertTrue("Shipments are intervened based on the cer type validation failed",
                    VerifyShipmentsAreIntervnedBasedOnCERType(endPointKey));
        }
    }

    public boolean VerifyShipmentsAreIntervnedBasedOnCERType(String endPointKey) {
        HashSet<Boolean> flags = new HashSet<>();
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            if (shipmentList.getTotalFilteredRecords() != 0
                    && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    for (Comment comment : response.getComments()) {
                        if (comment.getCustomerExceptionRequestDto() != null) {
                            if (Constants.cerTypes.contains(comment.getCustomerExceptionRequestDto().getCerType())
                                    && response.getIsIntervened()) {
                                flags.add(true);
                            } else
                                flags.add(false);
                        }
                    }
                }
            } else {
                log.info("** WARNING ** there are 0 results in the API results");
                // flags.add(false);
            }

        } catch (Exception e) {
            log.error("**EXCEPTION** Shipments are intervened based on the cer type validation failed: "
                    + e.getMessage());
            e.printStackTrace();
            flags.add(false);
        }
        return !flags.contains(false);
    }

    public boolean ValidateAPIDatainUI(String endPointKey, DataTable table) {
        boolean flag = true;
        try {
            List<String> attributesToSearch = table.asList(String.class);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            switch (endPointKey) {
                case "MS_Advisories_weather":
                    OverallAlert alert = this.commonHelpers.unMarshall(resp.asString(), OverallAlert.class);
                    for (String attribute : attributesToSearch) {
                        if (flag) {
                            flag = this.advPage.ValidateAPIwithUIforWeatherAlert(alert, attribute);
                        }
                    }
                    break;
                case "MS_Advisories_shipments":
                    Shipments shipments = this.commonHelpers.unMarshall(resp.asString(), Shipments.class);
                    for (String attribute : attributesToSearch) {
                        if (flag) {
                            flag = this.homePage.ValidateAPIwithUIforShipments(shipments, attribute);
                        }
                    }
                    break;
                case "MS_Preferences_user":
                    String preference_res = resp.asString();
                    for (String attribute : attributesToSearch) {
                        if (flag) {
                            flag = preference_res.contains(attribute);
                        }
                    }
                    break;
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in ValidateAPIDatainUI: " + e.getMessage());
            e.printStackTrace();
        }
        return flag;
    }

    public boolean validateCountOnCityOrCluster(String endPointKey, String city, String filter) {
        String expectedCount = null;
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            OverallAlert alert = this.commonHelpers.unMarshall((resp.asString()), OverallAlert.class);
            Country country = alert.getCountries().get(0);
            List<City> cities = country.getCities();
            if (city.equalsIgnoreCase("random")) {
                int index = this.commonHelpers.GenerateRandomNumber(cities.size());
                City cityAPI = cities.get(index);
                if (filter.contains("+")) {
                    int count = cityAPI.getInbound() + cityAPI.getOutbound();
                    expectedCount = String.valueOf(count);
                } else {
                    expectedCount = filter.equalsIgnoreCase("Inbound") ? cityAPI.getInbound().toString()
                            : cityAPI.getOutbound().toString();
                }
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in validateCountOnCityOrCluster: " + e.getMessage());
            e.printStackTrace();
        }
        String actualCount = this.advPage.validateCountOnPin(city);
        return expectedCount.equalsIgnoreCase(actualCount);
    }

    @Then("^I get the \"([^\"]*)\" and store the below values in context store for the user \"([^\"]*)\"$")
    public void i_get_the_and_store_the_below_values_in_context_store_for_the_user(String endPointKey,
            String userContext, DataTable table) throws Throwable {
        this.apiobj.SetCookies(userContext);
        boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (!virtualizationFlag) {
            this.apiobj.WhenIMakegetCall(endPointKey);
        } else {
            endPointKey = endPointKey.equalsIgnoreCase("FedEx_UserInfo")
                    || endPointKey.equalsIgnoreCase("FedEx_TrackingProfile") ? "VIRTUAL_Login" : endPointKey;
            if (!endPointKey.equalsIgnoreCase("VIRTUAL_Login")) {
                this.apiobj.WhenIMakegetCall(endPointKey);
            }
        }
        this.getValuesfromResp(endPointKey, table);
    }

    public void SetCEPrerequisites(String userContext) throws Throwable {
        this.apiobj.SetCEHeaderParams();
        this.GetCECompanyHierarchyAndStoreCompanyDetails("CE_CompanyHierarchy");
        this.CreatePayloadforDefaultHierarchy("CE_PreferencesHierarchy_Update");
        this.apiobj.SetCookies(userContext);
    }

    public void SetAccountIds(String userContext) {
        try {
            boolean virtualizationFlag = Boolean
                    .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
            if (!virtualizationFlag) {
                if (!GenericFunction.ENV.equalsIgnoreCase("PROD")) {
                    this.apiobj.SetShipperHeaderParams();
                    this.apiobj.SetCookies(userContext);
                    // this.apiobj.WhenIMakegetCall("FedEx_UserAccounts");
                    // Response resp =
                    // this.commonHelpers.GetValueFromResponseCollection("FedEx_UserAccounts");
                    // UserAccounts userAccounts = this.commonHelpers.unMarshall(resp.asString(),
                    // UserAccounts.class);
                    // List<String> userAccountsArray = new ArrayList<>();
                    // for (CustomerAccountList customerAccountList :
                    // userAccounts.getOutput().getCustomerAccountList()) {
                    // userAccountsArray.add(
                    // customerAccountList.getAccount().getAccountIdentifier().getAccountNumber().getValue());
                    // }
                    // this.commonHelpers.AddToContextStore("AccountIds", userAccountsArray);
                }
            } else {
                this.apiobj.SetVirtualizedCookies(userContext);
                this.commonHelpers.AddToContextStore("UserContext", userContext);
                this.commonHelpers.AddToContextStore("AccountIds", this.commonHelpers.SetMockAccIds(userContext));
            }
        } catch (Exception e) {
            log.error(" **EXCEPTION** Failed in set account Ids method : " + e.getMessage());
            Assert.fail("Something went wrong SetAccountIds");
        }

    }

    public void getValuesfromResp(String endPointKey, DataTable table) throws Exception {
        List<String> attributesToStore = table.asList(String.class);
        if (attributesToStore.size() > 0) {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            switch (endPointKey) {
                case "FedEx_UserInfo":
                    Userinfo userInfo = this.commonHelpers.unMarshall(resp.asString(), Userinfo.class);
                    for (String attribute : attributesToStore) {
                        switch (attribute) {
                            case "FirstName":
                                this.commonHelpers.AddToContextStore(attribute, userInfo.getOutput().getUserProfile()
                                        .getUserProfileAddress().getContact().getPersonName().getFirstName());
                                break;
                        }
                    }
                    break;
                case "VIRTUAL_Login":
                    VirtualizedResp virtualizedResp = this.commonHelpers.unMarshall(resp.asString(),
                            VirtualizedResp.class);
                    for (String attribute : attributesToStore) {
                        if (attribute != null) {
                            switch (attribute) {
                                case "FirstName":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            virtualizedResp.getOutput().getUserProfile()
                                                    .getRegisteredContactAndAddress().getContact().getPersonName()
                                                    .getFirstName());
                                    break;
                            }
                        }
                    }
                    break;
                case "MS_Shipments_Details":
                    ShipmentTrackingDetails trackingDetails = this.commonHelpers.unMarshall(resp.asString(),
                            ShipmentTrackingDetails.class);
                    List<String> attributeToStore = table.asList(String.class);
                    boolean virtualizationFlag = Boolean
                            .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
                    if (!virtualizationFlag) {
                        for (String attribute : attributeToStore) {
                            switch (attribute) {
                                case "keyStatus":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            trackingDetails.getTrackingApiDto().getKeyStatus());
                                    break;
                                case "mainStatus":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            trackingDetails.getTrackingApiDto().getMainStatus());
                                    break;
                                case "ShipperAddress":
                                    if (trackingDetails.getTrackingApiDto().getShipperAddress().getStreetLines()
                                            .size() == 0) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperAddress());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute, "");
                                    }
                                    break;
                                case "ShipperCity":
                                    if (trackingDetails.getTrackingApiDto().getShipperAddress().getCity().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperCity());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getShipperAddress().getCity());
                                    }
                                    break;

                                case "ShipperState":
                                    if (trackingDetails.getTrackingApiDto().getShipperAddress()
                                            .getStateOrProvinceCode().equalsIgnoreCase("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperState());

                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getShipperAddress()
                                                        .getStateOrProvinceCode());
                                    }
                                    break;

                                case "ShipperCountry":
                                    if (trackingDetails.getTrackingApiDto().getShipperAddress().getCountryCode()
                                            .equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperCountyOrTerritory());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute, "");
                                    }
                                    break;
                                case "ShipperCompany":
                                    if (trackingDetails.getTrackingApiDto().getShipperCmpnyName().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperCompany());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getShipperCmpnyName());
                                    }
                                    break;
                                case "ShipperName":
                                    if (trackingDetails.getTrackingApiDto().getShipperName().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperName());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getShipperName());
                                    }
                                    break;
                                case "ShipperContactPhone":
                                    if (trackingDetails.getTrackingApiDto().getShipperPhoneNbr().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getShipperContactPhone());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getShipperPhoneNbr());
                                    }
                                    break;
                                case "RecipAddress":
                                    if (trackingDetails.getTrackingApiDto().getRecipientAddress().getStreetLines()
                                            .size() == 0) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipAddress());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute, "");
                                    }
                                    break;
                                case "RecipientCity":
                                    if (trackingDetails.getTrackingApiDto().getRecipientAddress().getCity()
                                            .equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipCity());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipientAddress().getCity());
                                    }
                                    break;

                                case "RecipientState":
                                    if (trackingDetails.getTrackingApiDto().getRecipientAddress()
                                            .getStateOrProvinceCode().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipState());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipientAddress()
                                                        .getStateOrProvinceCode());
                                    }
                                    break;

                                case "RecipientCountry":
                                    if (trackingDetails.getTrackingApiDto().getRecipientAddress().getCountryCode()
                                            .equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipCountryOrTerritory());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipientAddress()
                                                        .getCountryCode());
                                    }
                                    break;

                                case "RecipCompany":
                                    if (trackingDetails.getTrackingApiDto().getRecipCompany().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipCompany());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipCompany());
                                    }
                                    break;

                                case "RecipContactName":
                                    if (trackingDetails.getTrackingApiDto().getRecipientName().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipContactName());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipientName());
                                    }
                                    break;
                                case "RecipientContactNumberOrEmail":
                                    if (trackingDetails.getTrackingApiDto().getRecipientPhoneNbr().equals("")) {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getShipmentDto().getRecipientContactNumberOrEmail());
                                    } else {
                                        this.commonHelpers.AddToContextStore(attribute,
                                                trackingDetails.getTrackingApiDto().getRecipientPhoneNbr());
                                    }
                                    break;
                                case "estimatedDeliveryDate":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            this.commonHelpers.TransformDatetoFormatPipe(
                                                    trackingDetails.getTrackingApiDto().getEstDeliveryDt(), "date"));
                                    break;
                                case "estimatedDeliveryTime":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            this.commonHelpers.TransformDatetoFormatPipe(
                                                    trackingDetails.getTrackingApiDto().getEstDeliveryDt(), "time"));
                                    break;
                                case "dateDelivered":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            this.commonHelpers.TransformDatetoFormatPipe(
                                                    trackingDetails.getTrackingApiDto().getDateDelivered(), "date"));
                                    break;
                                case "deliveredTime":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            this.commonHelpers.TransformDatetoFormatPipe(
                                                    trackingDetails.getTrackingApiDto().getDateDelivered(), "time"));
                                    break;
                                case "senseAwareJourneyId":
                                    this.commonHelpers.AddToContextStore(attribute,
                                            trackingDetails.getShipmentDto().getSenseAwareJourneyId());
                                    break;
                            }
                        }
                    } else {
                        this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                    }
                    break;
                case "MS_Preferences_user":
                    UserPreferences userPrefInfo = this.commonHelpers.unMarshall(resp.asString(),
                            UserPreferences.class);
                    List<String> attribute = table.asList(String.class);
                    for (String attributeElement : attribute) {
                        switch (attributeElement) {
                            case "PreferredDateFormat":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getPreferredDateFormat());
                                break;
                            case "PreferredTimeFormat":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getPreferredTimeFormat());
                                break;
                            case "dateOfDeploymentUnixTimeStampInSeconds":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getDateOfDeploymentUnixTimeStampInSeconds());
                                break;
                            case "daysToHighlightWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getDaysToHighlightWhatsNew());
                                break;
                            case "showWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement, userPrefInfo.getShowWhatsNew());
                                break;
                            case "releaseForWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getReleaseForWhatsNew());
                                break;
                            case "releaseVersion":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        userPrefInfo.getReleaseVersion());
                                break;
                            case "customerPortalShowUSInboundShipments":
                                this.commonHelpers.AddToContextStore("customerPortalFlag",
                                        userPrefInfo.getCustomerPortalShowUSInboundShipments());
                                break;
                            case "cePortalShowGlobalShipments":
                                this.commonHelpers.AddToContextStore("cePortalGlobalShipmentsFlag",
                                        userPrefInfo.getCePortalShowGlobalShipments());
                                break;
                            case "fusionAllowUSCanadaDomesticShipmentsOnly":
                                this.commonHelpers.AddToContextStore("fusionDomesticFlag",
                                        userPrefInfo.getFusionAllowUSCanadaDomesticShipmentsOnly());
                                break;
                        }
                    }
                    break;
                case "CE_Preferences_user":
                    UserPreferences ceuserPrefInfo = this.commonHelpers.unMarshall(resp.asString(),
                            UserPreferences.class);
                    for (String attributeElement : attributesToStore) {
                        switch (attributeElement) {
                            case "PreferredDateFormat":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getPreferredDateFormat());
                                break;
                            case "dateOfDeploymentUnixTimeStampInSeconds":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getDateOfDeploymentUnixTimeStampInSeconds());
                                break;
                            case "daysToHighlightWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getDaysToHighlightWhatsNew());
                                break;
                            case "showWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getShowWhatsNew());
                                break;
                            case "releaseForWhatsNew":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getReleaseForWhatsNew());
                                break;
                            case "releaseVersion":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getReleaseVersion());
                                break;
                            case "defaultImageRole":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getDefaultImageRole());
                                break;
                            case "selectedImageRole":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getSelectedImageRole());
                                break;
                            case "availableImageRoles":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getAvailableImageRoles());
                                break;
                            case "preferredHierarchy":
                                this.commonHelpers.AddToContextStore(attributeElement,
                                        ceuserPrefInfo.getpreferredHierarchy());
                                break;
                        }
                    }
                    break;
            }
        }
    }

    public int getMostImpactedCount(String filter, String endpointKey) {
        int max = 0;
        int count;
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        try {
            OverallAlert alert = this.commonHelpers.unMarshall((resp.asString()), OverallAlert.class);
            Country country = alert.getCountries().get(0);
            List<City> cities = country.getCities();
            City mostImpacted = new City();

            for (City cityList : cities) {
                if (filter.contains("+")) {
                    count = cityList.getTotalCount();
                } else {
                    count = filter.equalsIgnoreCase("Destination") ? cityList.getInbound()
                            : cityList.getOutbound();
                }
                if (count > max) {
                    max = count;
                    mostImpacted = cityList;
                }
            }
            this.commonHelpers.AddToContextStore("WeatherEffectedCity",
                    mostImpacted.getName() + ", " + mostImpacted.getStateName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return max;
    }

    /**
     * This method gives Total count from Weather API
     *
     * @param filter
     * @param endpointKey
     * @return
     */
    public HashMap<String, Integer> getListofCitieswithCountFromAdvisoriesShipments(String filter, String endpointKey) {
        int count = 0;
        HashMap<String, Integer> totalList = new HashMap<>();
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        try {
            OverallAlert alert = this.commonHelpers.unMarshall((resp.asString()), OverallAlert.class);
            Country country = alert.getCountries().get(0);
            List<City> cities = country.getCities();

            for (City cityList : cities) {
                if (filter.contains("+")) {
                    count = cityList.getTotalCount();
                    totalList.put(cityList.getName(), count);

                } else {
                    count = filter.equalsIgnoreCase("Inbound") ? cityList.getInbound()
                            : cityList.getOutbound();
                    totalList.put(cityList.getName(), count);
                }

            }

        } catch (

        Exception e) {
            e.printStackTrace();
        }
        return totalList;
    }

    /**
     * This method gives Total count from Advisories Preferred location API
     *
     * @param filter
     * @param endpointKey
     * @return
     */
    public HashMap<String, Integer> getListofCitieswithCountFromPreferredLocations(String filter, String endpointKey) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        HashMap<String, Integer> totalList = new HashMap<String, Integer>();
        try {
            List<AdvisoriesPreferredLocations> pf = this.commonHelpers.unMarshall(resp,
                    AdvisoriesPreferredLocations[].class);
            for (AdvisoriesPreferredLocations loc : pf) {
                totalList.put(loc.getName(), loc.getTotalCount());
            }

        } catch (Exception e1) {

            e1.printStackTrace();
        }

        return totalList;
    }

    public void VerifyCountofQCcardsinUIandAPI(String cardName, String endPointKey) {
        int expectedValue = 0;
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentList respShipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            if (cardName.equalsIgnoreCase("Total Records")) {
                expectedValue = respShipmentList.getTotalRecords();
            } else {
                expectedValue = respShipmentList.getTotalFilteredRecords();
                if (expectedValue == 0) {
                    this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                }
            }
            this.commonHelpers.AddToContextStore(cardName, String.valueOf(expectedValue));
        } catch (Exception e) {
            log.error(
                    " ** EXCEPTION ** -- > Something went wrong in VerifyCountofQCcardsinUIandAPI: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Integer totalNumberOfRecordInMyShipment() {
        Response resp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
        ShipmentList respShipmentList = new ShipmentList();
        try {
            respShipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return respShipmentList.getTotalRecords();
    }

    public Integer pageSize() {
        Response resp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
        ShipmentList respShipmentList = new ShipmentList();
        try {
            respShipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // return respShipmentList.getPageSize();
        return 0;
    }

    public Integer totalPageCount() {
        int pageSize = this.pageSize();
        int records = this.totalNumberOfRecordInMyShipment();

        return records % pageSize == 0 ? records / pageSize : records / pageSize + 1;
    }

    public void GetScanEventWithException(String shipmentId, String endpointKey, boolean... exception)
            throws Throwable {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
        Boolean virtualizationFlag = Boolean
                .parseBoolean(this.commonHelpers.getValuefromContextStore("VIRTUALIZATION").toString());
        if (virtualizationFlag) {
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }else {
            for (ShipmentDetailsResponse shipments : shipmentList.getData()) {

                this.i_Get_the_shipment_details_using_using_for_the_user("MS_Shipments_Details",
                        shipments.getShipmentId(), null);
                Response trackingResp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Details");
                ShipmentTrackingDetails trackingResponse = this.commonHelpers.unMarshall(trackingResp.asString(),
                        ShipmentTrackingDetails.class);
                if (exception.length > 0 && exception != null) {
                    List<ScanEventList> events = trackingResponse.getTrackingApiDto().getScanEventList();
                    int i = 0;
                    for (ScanEventList event : events) {
                        if (event.getException().equals(true)) {
                            this.commonHelpers.AddToContextStore(shipmentId,
                                    trackingResponse.getTrackingApiDto().getTrackingNbr());
                            this.commonHelpers.AddToContextStore("ScanEventCount",
                                    String.valueOf(trackingResponse.getTrackingApiDto().getScanEventList().size()));
                            if (i == trackingResponse.getTrackingApiDto().getScanEventList().size()) {
                                this.commonHelpers.AddToContextStore("ScanEventCountWithException", "last");
                            } else {
                                this.commonHelpers.AddToContextStore("ScanEventCountWithException",
                                        String.valueOf(i + 1));
                            }
                            break;
                        }
                        i++;
                    }
                    break;
                } else {
                    if (trackingResponse.getTrackingApiDto().getScanEventList().size() > 1) {
                        this.commonHelpers.AddToContextStore(shipmentId,
                                trackingResponse.getTrackingApiDto().getTrackingNbr());
                        this.commonHelpers.AddToContextStore("ScanEventCount",
                                String.valueOf(trackingResponse.getTrackingApiDto().getScanEventList().size()));
                        break;
                    }
                    break;
                }


            }
        }
    }

    public void GetCommonAccountFromBillToAndShipperAccounts(DataTable table, String endPointKey) {
        // List<String> billToAccounts;
        // List<String> shipperAccounts;
        String commonAccount = "";

        List<String> fields = table.asList(String.class);
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            AccountData respAccountData = this.commonHelpers.unMarshall(resp.asString(),
                    AccountData.class);
            if (respAccountData.getData().getAccounts().size() > 0) {
                commonAccount = respAccountData.getData().getAccounts().get(0);
            }
            commonAccount = respAccountData.getData().getAccounts().get(0);
            for (String field : fields) {
                this.commonHelpers.AddToContextStore(field, String.valueOf(commonAccount));
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in getting common account from shipper and bill to accounts: "
                    + e.getMessage());
            e.printStackTrace();
        }
    }

    @Then("^I get \"([^\"]*)\" for scan event from \"([^\"]*)\"$")
    public void i_get_for_scan_event_from(String shipmentId, String endpointKey) throws Throwable {
        GetScanEventWithException(shipmentId, endpointKey);
    }

    @Then("^I get \"([^\"]*)\" for scan event from \"([^\"]*)\" with Exception$")
    public void i_get_for_scan_event_from_with_Exception(String shipmentId, String endpointKey) throws Throwable {
        GetScanEventWithException(shipmentId, endpointKey, true);
    }

    public HashMap<String, String> GetScanEvent(String endpointKey, String event, boolean... exception)
            throws Throwable {
        Response trackingResp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        ShipmentTrackingDetails trackingResponse = this.commonHelpers.unMarshall(trackingResp.asString(),
                ShipmentTrackingDetails.class);
        HashMap<String, String> scanEventApi = new HashMap<String, String>();
        Response prefResp = this.commonHelpers.GetValueFromResponseCollection("MS_Preferences_user");
        UserPreferences usp = this.commonHelpers.unMarshall(prefResp.asString(), UserPreferences.class);
        List<ScanEventList> events = trackingResponse.getTrackingApiDto().getScanEventList();
        int eventNumber = event.equalsIgnoreCase("last") ? events.size() : Integer.parseInt(event);
        eventNumber = eventNumber == 0 ? eventNumber : eventNumber - 1; // array in json start with 0
        if (exception.length > 0 && exception != null) {
            scanEventApi.put("date",
                    this.dateTimeUtils.setDateFormat(events.get(eventNumber).getDate(), usp.getPreferredDateFormat(),
                            true));
            // remove '0' from month
            int position = scanEventApi.get("date").split(" ")[0].length() + 1;
            // Removed as per the new CR
            // String newDate = this.gfobj.RemoveZeroInDate(usp.getPreferredDateFormat(),
            // scanEventApi.get("date"),
            // position, "D");
            // newDate = this.gfobj.RemoveZeroInDate(usp.getPreferredDateFormat(), newDate,
            // position, "M");
            // scanEventApi.replace("date", scanEventApi.get("date"), newDate);
        }
        scanEventApi.put("location", events.get(eventNumber).getScanLocation());
        scanEventApi.put("status", events.get(eventNumber).getStatus());
        scanEventApi.put("additionalInfo", trackingResponse.getTrackingApiDto().getSubStatus());
        return scanEventApi;
    }

    public HashMap<String, String> shipmentRecord(List<String> headerColumn, String columnName, String ColumnValue,
            String endpointKey) {
        Response response = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        HashMap<String, String> recordFromApi = new HashMap<String, String>();
        try {
            ShipmentList shipmentList = this.commonHelpers.unMarshall(response.asString(), ShipmentList.class);
            for (ShipmentDetailsResponse record : shipmentList.getData()) {
                if (columnName.equalsIgnoreCase("Tracking Number")
                        && record.getTrackingNumber().equalsIgnoreCase(ColumnValue)) {
                    for (String header : headerColumn) {
                        header = this.gfobj.convert(header);
                        String value = GetApiField(header, record);
                        if (value != null && value != "") {
                            recordFromApi.put(header, value);
                        }
                    }
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return recordFromApi;
    }

    public String GetApiField(String column, UserPreferences preferences) {
        String value = null;
        switch (column) {
            case "cePortalShowGlobalShipments":
                value = preferences.getCePortalShowGlobalShipments().toString();
                break;
            case "customerPortalShowUSInboundShipments":
                value = preferences.getCustomerPortalShowUSInboundShipments().toString();
                break;
        }
        return value;
    }

    public String GetApiField(String column, ShipmentDetailsResponse shipmentRecord) {
        String value = null;
        switch (column) {

            case "cerNumbers":
                value = shipmentRecord.getCerNumbers();
                break;
            case "industryVerticalName":
                value = shipmentRecord.getIndustryVerticalName();
                break;
            case "shippedTo":
                value = shipmentRecord.getShippedTo();
                break;
            case "interventionStatus":
                value = shipmentRecord.getInterventionStatus();
                break;
            case "packageType":
                value = shipmentRecord.getPackageType();
                break;
            case "recipCity":
                value = shipmentRecord.getRecipCity();
                break;
            case "recipCountryOrTerritory":
                value = shipmentRecord.getRecipCountryOrTerritory();
                break;
            case "recipPostal":
                value = shipmentRecord.getRecipPostal();
                break;
            case "recipState":
                value = shipmentRecord.getRecipState();
                break;
            case "recipContactName":
                value = shipmentRecord.getRecipContactName();
                break;
            case "recipCompany":
                value = shipmentRecord.getRecipCompany();
                break;
            case "serviceType":
                value = shipmentRecord.getServiceType();
                break;
            case "shipperAccountNumber":
                value = shipmentRecord.getShipperAccountNumber();
                break;
            case "shipperCity":
                value = shipmentRecord.getShipperCity();
                break;
            case "shipperCountryOrTerritory":
                value = shipmentRecord.getShipperCountryOrTerritory();
                break;
            case "shipperPostal":
                value = shipmentRecord.getShipperPostal();
                break;
            case "shipperState":
                value = shipmentRecord.getShipperState();
                break;
            case "shipperName":
                value = shipmentRecord.getShipperName();
                break;
            case "shipperCompany":
                value = shipmentRecord.getShipperCompany();
                break;
            case "Tracking Number":
                value = shipmentRecord.getTrackingNumber();
                break;
            case "Status":
                value = shipmentRecord.getStatus();
                break;
            case "Date Delivered":
                value = shipmentRecord.getDateDelivered();
                break;
            case "Package Delay Status":
                value = shipmentRecord.getPackageDelayStatus();
                break;
            case "Intervention Status":
                value = shipmentRecord.getInterventionStatus();
                break;
            case "Recip Company":
                value = shipmentRecord.getRecipCompany();
                break;
            case "Recip Contact Name":
                value = shipmentRecord.getRecipContactName();
                break;
            case "Reference":
                value = shipmentRecord.getReference();
                break;
            case "Scheduled Delivery Date":
                break;
            case "Scheduled Delivery Time By":
                break;
            case "Shipper Name":
                value = shipmentRecord.getShipperName();
                break;
            case "Shipper Account Number":
                value = shipmentRecord.getShipperAccountNumber();
                break;
            case "Shipper Company":
                value = shipmentRecord.getShipperCompany();
                break;
            case "Shipper Contact Phone":
                value = shipmentRecord.getShipperContactPhone();
                break;
            case "FedEx Company":
                value = shipmentRecord.getFedExCompany();
                break;
            case "Recipient Contact Number/Email":
                value = shipmentRecord.getRecipientContactNumberOrEmail();
                break;
            case "Commit Timer":
                value = shipmentRecord.getCommitTimer();
                break;
            case "Recip City":
                value = shipmentRecord.getRecipCity();
                break;
            case "Recipient Name":
                value = shipmentRecord.getRecipContactName();
                break;
            case "fedExDestinationLocation":
                value = shipmentRecord.getFedExDestinationLocation();
                break;
            case "fedExOriginLocation":
                value = shipmentRecord.getFedExOriginLocation();
                break;
            case "shipmentId":
                value = shipmentRecord.getShipmentId();
                break;
            case "accountId":
                value = shipmentRecord.getAccountId();
                break;
            case "codRemittanceNumber":
                value = shipmentRecord.getCodRemittanceNumber();
                break;
            case "returnShipment":
                value = shipmentRecord.getReturnShipment();
                break;
            case "returnToShipperTrkNo":
                value = shipmentRecord.getReturnToShipperTrkNo().toString();
                break;
            case "isSenseAwareId":
                value = shipmentRecord.getIsSenseAwareId().toString();
                break;
            case "senseAwareIdDeviceStatuses":
                value = shipmentRecord.getSenseAwareIdDeviceStatuses();
                break;
            case "billToAccount":
                value = shipmentRecord.getBillToAccount();
                break;
            case "isPayer":
                value = shipmentRecord.getIsPayer().toString();
                break;
            case "lastKnownLocation":
                value = shipmentRecord.getLastKnownLocation();
                break;
            case "lastKnownLocationState":
                value = shipmentRecord.getLastKnownLocationState();
                break;
            case "departmentNumber":
            Object departmentNumber = shipmentRecord.getDepartmentNumber();
                if(departmentNumber !=null)
                {
                value = departmentNumber.toString();
                }
                break;
            case "latestContainerId":
                value = shipmentRecord.getLatestContainerId();
                break;
            case "purchaseOrderNumber":
                value = shipmentRecord.getPurchaseOrderNumber();
                break;
            case "latestFlightNumber":
                value = shipmentRecord.getLatestFlightNumber();
                break;
            case "latestVesselCONS":
                value = shipmentRecord.getLatestVesselCONS();
                break;
            case "invoiceNumber":
                value = shipmentRecord.getInvoiceNumber().toString();
                break;
            case "latestEvent":
                value = shipmentRecord.getLatestEvent();
                break;
            case "lastKnownRamp":
                value = shipmentRecord.getLastKnownRamp();
                break;
            case "lastKnownFedexFacility":
                value = shipmentRecord.getLastKnownFedexFacility().toString();
                break;
            case "specialHandling":
                value = shipmentRecord.getSpecialHandling();
                break;
            case "reference":
                value = shipmentRecord.getReference();
                break;
            case "shipperReference":
                value = shipmentRecord.getShipperReference().toString();
                break;
            case "damagedPackage":
                value = shipmentRecord.getDamagedPackage().toString();
                break;
            case "latestPrimaryEvent":
                value = shipmentRecord.getLatestPrimaryEvent();
                break;
            case "rma":
                value = shipmentRecord.getRma().toString();
                break;
            case "personalNotesMessage":
                value = shipmentRecord.getPersonalNotesMessage().toString();
                break;
            case "deliveredTo":
                value = shipmentRecord.getDeliveredTo();
                break;
            case "addressCorrection":
                value = shipmentRecord.getAddressCorrection().toString();
                break;
            case "podException":
                value = shipmentRecord.getPodException().toString();
                break;
            case "exceptionReason":
                value = shipmentRecord.getExceptionReason().toString();
                break;
            case "supportUpdate":
                value = shipmentRecord.getSupportUpdate().toString();
                break;
            case "lastComment":
                value = shipmentRecord.getLastComment().toString();
                break;
            case "commodityInformation":
                value = shipmentRecord.getCommodityInformation().toString();
                break;
            case "commodities":
                value = shipmentRecord.getCommodities().toString();
                this.commonHelpers.AddToContextStore("commodities_obj", shipmentRecord.getCommodities());
                break;
            case "appointmentDelivery":
                value = shipmentRecord.getAppointmentDelivery().toString();
                break;
            case "senseAwareJourneyId":
                value = shipmentRecord.getSenseAwareJourneyId().toString();
                break;
            case "senseAwareIdStatus":
                value = shipmentRecord.getSenseAwareIdStatus().toString();
                break;
            case "receivedBy":
                if (shipmentRecord.getReceivedBy() == null)
                    value = " ";
                else
                    value = shipmentRecord.getReceivedBy().toString();
                break;
            case "masterTrackingNumber":
                value = shipmentRecord.getMasterTrackingNumber().toString();
                break;
            case "noOfPackages":
                value = shipmentRecord.getNoOfPackages();
                break;
            case "labelCreatedDate":
                value = shipmentRecord.getlabelCreatedDate().toString();
                break;
            case "shipDate":
                value = shipmentRecord.getShipDate();
                break;
            case "standardTransitDate":
                value = shipmentRecord.getStandardTransitDate();
                break;
            case "deliveryAttempts":
                value = shipmentRecord.getDeliveryAttempts().toString();
                break;
            case "isShipper":
                value = shipmentRecord.getIsShipper().toString();
                break;
            case "pkgWtLbs":
                value = shipmentRecord.getPkgWtLbs() != null ? shipmentRecord.getPkgWtLbs().toString() : "";
                break;
            case "pkgWtKg":
                value = shipmentRecord.getPkgWtKg() != null ? shipmentRecord.getPkgWtKg().toString() : "";
                break;
            case "totalWtLbs":
                value = shipmentRecord.getTotalWtLbs() != null ? shipmentRecord.getTotalWtLbs().toString() : "";
                break;
            case "totalWtKg":
                value = shipmentRecord.getTotalWtKg() != null ? shipmentRecord.getTotalWtKg().toString() : "";
                break;
            case "cerCount":
                value = shipmentRecord.getCerCount();
                break;
            case "packageDimsCm":
                value = shipmentRecord.getPackageDimsCm() != null ? shipmentRecord.getPackageDimsCm().toString() : "";
                break;
            case "packageDimsIn":
                value = shipmentRecord.getPackageDimsIn() != null ? shipmentRecord.getPackageDimsIn().toString() : "";
                break;
            case "packageDimsLengthIn":
                value = shipmentRecord.getPackageDimsLengthIn();
                break;
            case "packageDimsWidthIn":
                value = shipmentRecord.getPackageDimsWidthIn();
                break;
            case "packageDimsHeightIn":
                value = shipmentRecord.getPackageDimsHeightIn();
                break;
            case "scheduledDeliveryDateTimeBy":
                value = shipmentRecord.getScheduledDeliveryDateTimeBy();
                break;
            case "coldStorageTemperatureMaxC":
                value = shipmentRecord.getColdStorageTemperatureMaxC();
                break;
            case "coldStorageTemperatureMinC":
                value = shipmentRecord.getColdStorageTemperatureMinC();
                break;
            case "dryIceAddedKgs":
                value = shipmentRecord.getDryIceAddedKgs();
                break;
            case "dryIceAddedLbs":
                value = shipmentRecord.getDryIceAddedLbs();
                break;
            case "gelPackQuantity":
                value = shipmentRecord.getGelPackQuantity();
                break;
            case "estimatedDeliveryTimeWindow":
                value = shipmentRecord.getEstimatedDeliveryTimeWindow();
                break;
            case "scheduledDeliveryDateDestTZ":
                value = shipmentRecord.getScheduledDeliveryDateDestTZ();
                break;
            case "workgroups":
                value = shipmentRecord.getWorkgroup() != null ? shipmentRecord.getWorkgroup().toString() : "";
                break;
        }
        log.info("Value from the API field " + column + " is = " + value);
        return value;
    }

    public int filteredRecordsFromShipment(String endpointKey) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        ShipmentList records = null;
        try {
            records = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return records.getTotalFilteredRecords();
    }

    @Then("^I get \"([^\"]*)\" having value for \"([^\"]*)\" field from \"([^\"]*)\"$")
    public void i_get_having_value_for_field_from(String trackingNum, String field, String endpointKey)
            throws Throwable {
        GetTrackingNumForSpecifiedFieldValue(trackingNum, field, endpointKey);
    }

    public void GetTrackingNumForSpecifiedFieldValue(String trackingNum, String field, String endpointKey)
            throws Throwable {
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            Boolean flag = false;
            while (!flag) {
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    String value = GetApiField(field, response);
                    if (!value.equals("") || value != null) {
                        this.commonHelpers.AddToContextStore(trackingNum, response.getTrackingNumber());
                        this.commonHelpers.AddToContextStore(field, value);
                        flag = true;
                        break;
                    }
                }
                if (!flag) {
                    if (shipmentList.getData().size() != 0) {
                        this.RetryWithIncrementedPageSize();
                        resp = this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
                        shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
                    } else {
                        flag = true;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("**EXCEPTION** Something went wrong in selecting track id which has value for field " + field
                    + " scan events"
                    + (e.getMessage() == null ? "Track Id not found for field value " + field : e.getMessage()));
            Assert.fail("Unable to find the track Id");
        }
    }

    @Then("^I unwatch \"([^\"]*)\" shipments for \"([^\"]*)\" from \"([^\"]*)\"$")
    public void i_unwatch_shipments_from(String number, String shipment, String endpointKey, DataTable dataTable)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int unwatchShipments = Integer.valueOf(number);
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            List<String> shipmentIdList = new ArrayList<String>();
            boolean flag = false;
            while (!flag) {
                if (shipmentList.getData().size() == 0) {
                    flag = true;
                }
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    for (String field : table.keySet()) {
                        String value = GetApiField(field, response);
                        if (value != null) {
                            shipmentIdList.add(value);
                            if (shipmentIdList.size() >= unwatchShipments) {
                                flag = true;
                                break;
                            }
                        }
                    }
                    if (flag) {
                        break;
                    }
                }
                if (!flag) {
                    if (shipmentList.getData().size() != 0) {
                        this.RetryWithIncrementedPageSize();
                        resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
                        shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
                    } else {
                        flag = true;
                        break;
                    }
                }
            }

            // Delete shipment ids collected from all the pages CE_Watchlist
            for (String shipmentId : shipmentIdList) {
                apiobj.DeleteWatchlistwithQueryparms(shipment, shipmentId);
            }
        }
    }

    @Given("^I validate the response of \"([^\"]*)\" is having below values$")
    public void i_validate_the_response_of_is_having_below_values(String endpointKey, DataTable dataTable)
            throws Throwable {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
        List<Boolean> filterflags = new ArrayList<>();
        if (shipmentList.getTotalFilteredRecords() != 0
                && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            for (ShipmentDetailsResponse response : shipmentList.getData()) {
                if (filterflags.isEmpty() || !filterflags.contains(false)) {
                    for (String field : table.keySet()) {
                        switch (field) {
                            case "accountId":
                                filterflags.add(response.getAccountId().equalsIgnoreCase(table.get(field)));
                                break;
                            case "billToAccount":
                                if (response.getBillToAccount() != null)
                                    filterflags.add(response.getBillToAccount().equalsIgnoreCase(table.get(field)));
                                break;
                            case "isPayer":
                                filterflags.add(response.getIsPayer() == (Boolean.parseBoolean(table.get(field))));
                                break;
                            case "isShipper":
                                filterflags.add(response.getIsShipper() == (Boolean.parseBoolean(table.get(field))));
                                break;
                        }
                    }
                }
            }
        }
        Assert.assertFalse("validation of API response with expected value is failed", filterflags.contains(false));

    }

    @Then("^I get \"([^\"]*)\" field from \"([^\"]*)\" with value$")
    public void i_get_field_from_with_value(String trkNbr, String endpointKey, DataTable dataTable) throws Throwable {
        if (!this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
        if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
            return;
        Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
        String value = "";
        int i = 1;
        if (endpointKey.contains("MS_FedEx_Accounts")) {
            FedExAccounts fedExAccounts = this.commonHelpers.unMarshall(resp.asString(), FedExAccounts.class);
            for (String field : table.keySet()) {
                for (Datum account : fedExAccounts.getData()) {
                    switch (field) {
                        case "sepEnabled":
                            if (account.getSepDataVisibleToCustomer() == Boolean.parseBoolean(table.get(field))) {
                                if (trkNbr.equalsIgnoreCase("AccountNumber")) {
                                    log.info("SEP Enabled Account: " + account.getAccountId());
                                    this.commonHelpers.AddToContextStore("AccountNumber", account.getAccountId());
                                }
                            }
                            break;
                        case "AccountNumber":
                            if (trkNbr.equalsIgnoreCase("AccountNumber")) {
                                log.info("Getting Account Id: " + account.getAccountId());
                                this.commonHelpers.AddToContextStore("AccountNumber" + (i++), account.getAccountId());
                            }
                            break;
                    }
                }
            }
        } else if (endpointKey.contains("_Preferences_user")
                && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            UserPreferences userPreferences = this.commonHelpers.unMarshall(resp.asString(), UserPreferences.class);
            for (String field : table.keySet()) {
                value = GetApiField(field, userPreferences);
                if (value != "") {
                    this.commonHelpers.AddToContextStore(field, value);
                }
            }

        } else {
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            List<Boolean> filterflags = new ArrayList<Boolean>();
            if (shipmentList.getTotalFilteredRecords() != 0
                    && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
                first: for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    for (String field : table.keySet()) {
                        try{
                        value = GetApiField(field, response);
                        }
                        catch(Exception e){
                            log.info("No data available for the field asked");
                        }

                        if (field.equalsIgnoreCase("noOfPackages")) {
                            int val = Integer.parseInt(value);
                            if (val < 2 || val > 10) {
                                value = null;
                            }
                        }
                        if (field.equalsIgnoreCase("Tracking Number")) {
                            if (value.length() < 12) {
                                value = null;
                            }
                        }
                        if (field.equals("receivedBy")) {
                            if (!(value.matches("^[a-zA-Z]*$")))
                                continue first;
                        }
                        if (value != null) {
                            // Sometimes we are getting single char/letter values for recipContactName so
                            // added below check. If we get similar issue for other filters then we can add
                            // all such filters in a constant variable and use them
                            if (!(Constants.Min3CharactersFilters.contains(field)
                                    && value.length() < 3)) {
                                if (table.get(field) != null) {

                                    filterflags.add(
                                            value.equals(table.get(field)) || table.get(field).equals(""));
                                }
                                System.out.printf("Added field and value = %s : %s%n", field, value);
                            } else {
                                filterflags.add(false);
                            }

                        } else {
                            filterflags.add(false);
                        }

                    }
                    if (!filterflags.contains(false)) {
                        this.commonHelpers.AddToContextStore(trkNbr, response.getTrackingNumber());
                        log.info("Tracking number is --> " + response.getTrackingNumber());
                        for (String key : table.keySet()) {
                            this.commonHelpers.AddToContextStore(key, GetApiField(key, response));
                            if (key.contains("coldStorageTemperature")) {
                                value = value.split("\\.")[0];
                                this.commonHelpers.AddToContextStore(key, value);
                            }
                            if (key.equalsIgnoreCase("lastKnownLocation")) {
                                String lastKnownLocation = GetApiField(key, response);
                                String[] lastKnownLocations = lastKnownLocation.split(",");
                                this.commonHelpers.AddToContextStore("lastKnownLocationCity", lastKnownLocations[0]);
                                this.commonHelpers.AddToContextStore("lastKnownLocationState", lastKnownLocations[1]);
                                this.commonHelpers.AddToContextStore("lastKnownLocationCountry", lastKnownLocations[2]);
                            } else if (key.equalsIgnoreCase("specialHandling")) {
                                String specialHandlingValue = GetApiField(key, response);
                                String[] specialHandlingArray = specialHandlingValue.split(",");
                                this.commonHelpers.AddToContextStore(key, specialHandlingArray[0]);
                            } else if (table.containsKey("returnToShipperTrkNo")) {
                                String returnToShipperTrkNo = GetApiField(key, response);
                                this.commonHelpers.AddToContextStore("returnToShipperTrkNo", returnToShipperTrkNo);
                            }
                        }
                        this.commonHelpers.AddToContextStore("Status", response.getStatus());
                        break;
                    }
                    filterflags.clear();
                }

                if (!this.commonHelpers.verifyKeyinContextStore(trkNbr)) {
                    this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                }
                if (table.containsKey("senseAwareIdDeviceStatuses")) {
                    if (!this.commonHelpers.verifyKeyinContextStore("senseAwareIdDeviceStatuses")) {
                        this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
                    }
                }
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        }
    }
    }

    @Then("^I get \"([^\"]*)\" field from \"([^\"]*)\" with below values$")
    public void i_get_field_from_with_below_values(String trkNbr, String endpointKey, DataTable dataTable)
            throws Throwable {
        int count = 0;
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            if (getFirstValueOfDataTableifNotEmpty(dataTable) == null)
                return;
            Map<String, String> table = getFirstValueOfDataTableifNotEmpty(dataTable);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            boolean flag = false;
            for (ShipmentDetailsResponse response : shipmentList.getData()) {
                String user = this.commonHelpers.getValuefromContextStore("UserContext").toString();
                String context = user.equalsIgnoreCase("CE") ? "CE" : "MS";
                this.i_Get_the_shipment_details_using_using_for_the_user(String.format("%s_Shipments_Details", context),
                        response.getShipmentId(), null);
                Response resp1 = this.commonHelpers
                        .GetValueFromResponseCollection(String.format("%s_Shipments_Details", context));
                ShipmentTrackingDetails shipmentTrackingDetails = this.commonHelpers.unMarshall(resp1.asString(),
                        ShipmentTrackingDetails.class);
                if (shipmentTrackingDetails.getShipmentDto().getTrackingNumber().equals(response.getTrackingNumber())) {
                    for (String field : table.keySet()) {
                        if (field.equalsIgnoreCase("isReturnShipmentIdAvailable")) {
                            if (shipmentTrackingDetails.getShipmentDto().getIsReturnShipmentIdAvailable() != null
                                    && (shipmentTrackingDetails.getShipmentDto()
                                            .getIsReturnShipmentIdAvailable() == Boolean
                                                    .parseBoolean(table.get(field).toLowerCase()))) {
                                this.commonHelpers.AddToContextStore("returnTrackingNumber",
                                        shipmentTrackingDetails.getShipmentDto().getMasterTrackingNumber());
                                this.commonHelpers.AddToContextStore(trkNbr, response.getTrackingNumber());
                                flag = true;
                                break;
                            }
                        } else if (field.equalsIgnoreCase("isSenseAwareId")) {
                            if (shipmentTrackingDetails.getShipmentDto().getIsSenseAwareId() == Boolean
                                    .parseBoolean(table.get(field).toLowerCase())) {
                                this.commonHelpers.AddToContextStore("senseAwareIdSerial",
                                        shipmentTrackingDetails.getShipmentDto().getSenseAwareIdSerial());
                                this.commonHelpers.AddToContextStore(trkNbr, response.getTrackingNumber());
                                flag = true;
                                break;
                            }
                        } else if (field.equalsIgnoreCase("scanHistory")) {
                            log.info(String.valueOf(count++));
                            if (shipmentTrackingDetails.getShipmentDto().getScanHistory() != null) {
                                if (shipmentTrackingDetails.getShipmentDto().getScanHistory().size() >= Integer
                                        .parseInt(table.get(field))) {
                                    this.commonHelpers.AddToContextStore(trkNbr, response.getTrackingNumber());
                                    flag = true;
                                    break;
                                }
                            }
                        } else if (field.equalsIgnoreCase("comments")) {
                            log.info(String.valueOf(count++));
                            if (shipmentTrackingDetails.getShipmentDto().getComments() != null) {
                                this.commonHelpers.AddToContextStore(trkNbr, response.getTrackingNumber());
                                this.commonHelpers.AddToContextStore("comment", shipmentTrackingDetails.getShipmentDto()
                                        .getComments().get(0).getComment().getMessage());
                                flag = true;
                                break;
                            }
                        }
                    }
                    if (flag)
                        break;
                }
            }
        }
    }

    public Map<String, String> GetApiData(List<String> fields, String trkNbr) {
        Map<String, String> apiData = new HashMap<>();
        trkNbr = this.commonHelpers.getValuefromContextStore(trkNbr).toString();
        apiData.put("Tracking Number", trkNbr);
        // apiData.put("Status",
        // this.commonHelpers.GetValuefromContextStore("Status").toString());
        for (String field : fields) {
            String value = this.commonHelpers.getValuefromContextStore(field).toString();
            if (value.contains("hr")) {
                apiData.put(field, value.split("r")[0]);
            } else {
                apiData.put(field, value);
            }
        }
        return apiData;
    }

    public Map<String, String> GetApiDataWithoutStatus(List<String> fields, String trkNbr) {
        Map<String, String> apiData = new HashMap<>();
        trkNbr = this.commonHelpers.getValuefromContextStore(trkNbr).toString();
        apiData.put("Tracking Number", trkNbr);
        for (String field : fields) {
            String value = this.commonHelpers.getValuefromContextStore(field).toString();
            if (value.contains("hr")) {
                apiData.put(field, value.split("r")[0]);
            } else {
                apiData.put(field, value);
            }
        }
        return apiData;
    }

    @Then("^I watch \"([^\"]*)\" shipments for \"([^\"]*)\" from \"([^\"]*)\"$")
    public void i_watch_shipments_from(String number, String shipment, String endpointKey) throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            int watchShipments = Integer.parseInt(number);
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            boolean flag = false;
            int counter = 0;
            while (!flag) {
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    if (!response.getIsWatched()) {
                        AddToWatchlist addToWatchList = new AddToWatchlist();
                        addToWatchList.setShipmentId(GetApiField("shipmentId", response));
                        addToWatchList.setAccount(GetApiField("accountId", response));
                        if (endpointKey.contains("CE")) {
                            addToWatchList.setGlobalEntityNumber(
                                    this.commonHelpers.getValuefromContextStore("ContextStore-CompanyCode").toString());
                        }
                        this.commonHelpers.AddToRequestPayloadCollection(shipment, addToWatchList);
                        // Add shipment to watchlist
                        this.apiobj.WhenIMakeputCall(shipment);
                        ++counter;
                        if (counter == watchShipments) {
                            flag = true;
                            break;
                        }
                    }
                }
                if (!flag) {
                    if (shipmentList.getData().size() != 0) {
                        this.RetryWithIncrementedPageSize();
                        resp = this.commonHelpers.GetValueFromResponseCollection(endpointKey);
                        shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
                    } else {
                        flag = true;
                        break;
                    }
                }
            }
        }
    }

    public List<ShipmentDetailsResponse> getResponseDataOfShipmentlist(String endPointKey) {
        List<ShipmentDetailsResponse> shipmentData = new ArrayList<ShipmentDetailsResponse>();
        try {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentList respShipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            shipmentData = respShipmentList.getData();
        } catch (Exception e) {
            log.error(" **EXCEPTION** Something went wrong in ShipmentDetails: " + e.getMessage());
            e.printStackTrace();
        }
        return shipmentData;
    }

    public List<History> getHistoryOfShipments(ShipmentDetailsResponse shipmentData) {
        List<History> shipmentDataHistory = new ArrayList<History>();
        shipmentDataHistory = shipmentData.getHistory();
        return shipmentDataHistory;
    }

    @Then("^I validate the scan code \"([^\"]*)\" for shipments in the API \"([^\"]*)\"$")
    public void i_validate_the_scan_code_for_shipments_in_the_API(String scanCode, String endPointKey)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            for (ShipmentDetailsResponse shipmentDetails : getResponseDataOfShipmentlist(endPointKey)) {
                List<String> shipmentScanCodes = new ArrayList<String>();
                for (History shipmentDetailsHistory : getHistoryOfShipments(shipmentDetails)) {
                    shipmentScanCodes.add(shipmentDetailsHistory.getScanCode());
                }
                Assert.assertTrue(
                        String.format("Shipment does not contains RS scan code for the shipment \"%s\",shipmenet",
                                shipmentDetails.getShipmentId()),
                        shipmentScanCodes.contains(scanCode));
            }
        }
    }

    @Then("^I validate all listed shipments SenseAware equipped in the API \"([^\"]*)\"$")
    public void i_validate_all_listed_shipments_SenseAware_equipped_in_the_API(String endPointKey) {
        boolean flag = true;
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            for (ShipmentDetailsResponse shipmentDetails : getResponseDataOfShipmentlist(endPointKey)) {
                if (!shipmentDetails.getIsSenseAwareId()) {
                    flag = false;
                }
            }
        }
        Assert.assertTrue("All or few shipments are not SenseAware Euipped", flag);
    }

    @Then("^I get common account number from bill to account and shipper account numbers using \"([^\"]*)\"$")
    public void i_get_common_account_number_from_bill_to_account_and_shipper_account_numbers_using(String endPointKey,
            DataTable table) {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            this.GetCommonAccountFromBillToAndShipperAccounts(table, endPointKey);
        }
    }

    public List<History> getScanHistoryOfShipments(ShipmentDetailsResponse shipmentData) {
        List<History> shipmentScanHistory;
        shipmentScanHistory = shipmentData.getHistory();
        return shipmentScanHistory;
    }

    @Then("^I validate the scan history of \"([^\"]*)\" of \"([^\"]*)\" for shipments in the API \"([^\"]*)\"$")
    public void iValidateTheScanHistoryOfOfForShipmentsInTheAPI(String eventValue, String trackingNumber,
            String endPointKey) throws Throwable {
        String expectedScanCode;
        String expectedTime;
        String expectedLocationId;
        String expectedFedexId;
        String expectedValue = this.commonHelpers.verifyKeyInContextStore(eventValue)
                ? this.commonHelpers.getValuefromContextStore(eventValue).toString()
                : eventValue;

        expectedScanCode = expectedValue.split("@")[0];
        expectedTime = expectedValue.split("@")[1].split("\\(")[0].split(" ")[1];
        expectedLocationId = expectedValue.split("-")[1].replace(")", "");
        expectedFedexId = expectedValue.split("\\(")[1].split("-")[0];
        String trckNumber = this.commonHelpers.verifyKeyInContextStore(trackingNumber)
                ? this.commonHelpers.getValuefromContextStore(trackingNumber).toString()
                : trackingNumber;

        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            Response resp = this.commonHelpers.GetValueFromResponseCollection(endPointKey);
            ShipmentTrackingDetails respShipmentDetails = this.commonHelpers.unMarshall(resp.asString(),
                    ShipmentTrackingDetails.class);
            ShipmentDto shipmentDto = respShipmentDetails.getShipmentDto();
            List<ScanHistory> scanHistory = shipmentDto.getScanHistory();
            for (int index = scanHistory.size() - 1; index >= 0; index--) {
                if (Constants.LatestFXEventFilters.contains(scanHistory.get(index).getScanCode())) {
                    Assert.assertTrue(scanHistory.get(index).getScanCode().equalsIgnoreCase(expectedScanCode));
                    Assert.assertTrue(scanHistory.get(index).getScanEventDateTime().contains(expectedTime));
                    Assert.assertTrue(
                            scanHistory.get(index).getScanEventLocationId().equalsIgnoreCase(expectedLocationId));
                    if (!expectedFedexId.equalsIgnoreCase("N/A"))
                        Assert.assertTrue(scanHistory.get(index).getEmployeeId().equalsIgnoreCase(expectedFedexId));
                    return;
                }
            }

        }
    }

    public List<String> SetRangeValueListWithDateandTime(String timerange) {
        List<String> datesArray = new ArrayList<>();
        List<String> multipleDates = new ArrayList<>();
        try {
            if (timerange.contains(",")) {
                multipleDates = Arrays.asList(timerange.split(","));
                for (String dt : multipleDates) {
                    if (dt.contains("="))
                        multipleDates = Arrays.asList(timerange.split("="));
                }
            } else if (timerange.contains("=")) {
                multipleDates = Arrays.asList(timerange.split("="));
            }
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00");
            Date myDate = new Date(System.currentTimeMillis());
            Calendar cal = Calendar.getInstance();
            for (String date : multipleDates) {
                if (date.contains("-")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, Integer.parseInt("-" + date.split("-")[1]));
                } else if (date.equalsIgnoreCase("FromNowDateTime")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, 0);
                } else if (date.contains("+")) {
                    cal.setTime(myDate);
                    cal.add(Calendar.DATE, Integer.parseInt(date.split("\\+")[1]));
                }
                datesArray.add(dateFormat.format(cal.getTime()));
            }
            datesArray.add("-330");
        } catch (Exception e) {
            log.error(" **EXCEPTION** Failed in SetRangeValueList: " + timerange);
            Assert.fail("Failed in SetRangeValueList: " + timerange);
        }
        return datesArray;
    }

    @Then("^I get the scan history for shipments in the API \"([^\"]*)\"$")
    public void i_validate_the_scan_history_for_shipments_in_the_api_something(String endpoint, DataTable table)
            throws Throwable {
        Map<String, String> dataMap = table.asMap(String.class, String.class);
        for (Map.Entry field : dataMap.entrySet()) {
            String expField = (String) field.getKey();
            String condition = (String) field.getValue();
            this.getDataFromScanHistoryAPIBasedOnCondition(expField, condition, endpoint);
        }
    }

    public void getDataFromScanHistoryAPIBasedOnCondition(String field, String condition,
            String endPointKey) throws Throwable {
        boolean flag = false;
        String[] condValues = condition.split(":");
        String condField = condValues[0];
        String condValue = condValues[1];
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            for (ShipmentDetailsResponse shipmentDetails : getResponseDataOfShipmentlist(endPointKey)) {
                try {
                    for (ScanHistory shipmentDetailsHistory : getScanHistoryOfShipment(shipmentDetails)) {
                        if (shipmentDetailsHistory.getConsContainerTypeCd().equals(condValue)) {
                            this.commonHelpers.AddToContextStore(field, shipmentDetailsHistory.getStatusDetail());
                            flag = true;
                            break;
                        }
                    }
                } catch (Exception e) {
                    log.error("**EXCEPTION** Scan History object not available");
                }
                if (flag) {
                    break;
                }
            }
        }
    }

    public List<ScanHistory> getScanHistoryOfShipment(ShipmentDetailsResponse shipmentData) {
        List<ScanHistory> shipmentScanHistory = new ArrayList<ScanHistory>();
        shipmentScanHistory = shipmentData.getScanHistory();
        return shipmentScanHistory;
    }

    @Then("^I delete all available workgroups for the user \"([^\"]*)\"$")
    public void i_delete_all_available_groups_for_the_user(String user) throws Throwable {
        String context = user.equalsIgnoreCase("CE") ? "CE_GET_WorkGroups" : "MS_GET_WorkGroups";
        this.apiobj.WhenIMakegetCall(context);
        Response resp = this.commonHelpers.GetValueFromResponseCollection(context);
        List<GetWorkGroup> getAllWorkGroups = this.commonHelpers.unMarshall(resp, GetWorkGroup[].class);
        if (getAllWorkGroups.size() > 0) {
            for (GetWorkGroup getWorkGroup : getAllWorkGroups) {
                this.apiobj.DeleteWatchlistwithQueryparms(
                        (user.equalsIgnoreCase("CE") ? "CE_DELETE_WorkGroup" : "MS_DELETE_WorkGroup"),
                        getWorkGroup.getRegion() + "/" + getWorkGroup.getId());
            }
        }
    }

    /**
     * @param index
     * @param keyToStore
     * @param tableData
     */
    @When("^I select \"([^\"]*)\" tracking number from the list and store in \"([^\"]*)\" using below value$")
    public void i_select_tracking_number_from_the_list_using_value(String index, String keyToStore, DataTable tableData)
            throws Throwable {
        try {
            Response resp = this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")
                    ? this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Overview")
                    : this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
            ShipmentList sl = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            Integer filteredRec = sl.getTotalFilteredRecords();
            ShipmentDetailsResponse shipmentData = new ShipmentDetailsResponse();
            List<String> listTracks = new ArrayList<>();
            Map<String, String> table = tableData.asMap(String.class, String.class);
            ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);
            List<Boolean> filterflags = new ArrayList<Boolean>();
            String value = "";
            if (shipmentList.getTotalFilteredRecords() != 0
                    && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
                for (ShipmentDetailsResponse response : shipmentList.getData()) {
                    for (String field : table.keySet()) {
                        List<String> fieldData = new ArrayList<>();
                        value = GetApiField(field, response);
                        if (index.equalsIgnoreCase("multiTrackRandomNumber") && field.equalsIgnoreCase("accountId")) {
                            int randomnumber = this.commonHelpers.GenerateRandomNumber(sl.getData().size());
                            String expValue = table.get(field);
                            if (expValue.contains(("ContextStore-"))) {
                                expValue = (String) this.commonHelpers.getValuefromContextStore(expValue.split("-")[1]);
                            }

                            for (int i = 0; i < randomnumber; i++) {
                                shipmentData = sl.getData().get(i);
                                String accountId = shipmentData.getAccountId();
                                if (expValue.equals(accountId))
                                    listTracks.add(shipmentData.getTrackingNumber());
                                if (listTracks.size() == 15) {
                                    break;
                                }
                            }
                        } else {
                            int counter = Integer.valueOf(index);
                            if (sl.getData().size() < counter) {
                                counter = sl.getData().size();
                            }
                            for (int i = 0; i < counter; i++) {
                                shipmentData = sl.getData().get(i);
                                String val = "";
                                switch (field) {
                                    case "dryIceAddedKgs":
                                        val = shipmentData.getDryIceAddedKgs();
                                        break;
                                    case "dryIceAddedLbs":
                                        val = shipmentData.getDryIceAddedLbs();
                                        break;
                                    default:
                                        log.error(" **Provided API field not found** ");
                                        Assert.fail();
                                }
                                listTracks.add(shipmentData.getTrackingNumber());
                                if (field.contains("dryIceAdded")) {
                                    if (Float.valueOf(val) % 1 == 0) {
                                        val = String.valueOf(Math.round(Float.valueOf(val)));
                                    }
                                }
                                fieldData.add(val);
                            }
                            // Add Highest and lowest values for Dry Ice Added filter
                            if (field.contains("dryIceAdded")) {
                                Collections.sort(fieldData);
                                this.commonHelpers.AddToContextStore(table.get(field) + "High",
                                        fieldData.get(fieldData.size() - 1));
                                this.commonHelpers.AddToContextStore(table.get(field) + "Low", fieldData.get(0));
                            }
                            this.commonHelpers.AddToContextStore(table.get(field), fieldData);
                        }
                        if (listTracks.size() == 0) {
                            value = null;
                        }
                        if (keyToStore.contains("Tracking")) {
                            this.commonHelpers.AddToContextStore("Tracking Number", listTracks);
                        }
                    }
                    if (value != null) {
                        filterflags.add(true);
                    } else {
                        filterflags.add(false);
                    }
                    if (!filterflags.contains(false)) {
                        break;
                    }
                    filterflags.clear();
                }
            } else {
                this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
            }
        } catch (Exception e) {
            log.error(" **EXCEPTION** " + e.getMessage());
            this.commonHelpers.AddToContextStore(Constants.skipSteps, true);
        }

    }

    @Then("^I verify \"([^\"]*)\" is updated in \"([^\"]*)\" response as per below value$")
    public void verify_key_in_response(String field, String endPointKey, DataTable dataTable) throws Throwable {
        Map<String, String> data = dataTable.asMap(String.class, String.class);
        this.i_store_below_values_from_of_endpoint("response", endPointKey, dataTable);
        Assert.assertTrue(this.commonHelpers.getValuefromContextStore(data.get("id")).toString()
                .contains((String) this.commonHelpers.getValuefromContextStore("ShipmentId")));
    }

    public void SetWorkGroupContext(String workGroup) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_GetWorkGroup");
        List<Map<String, String>> compList = resp.jsonPath().getList("$");
        String workgroupName;
        String workgroupId = "";
        List<String> workgroupIdList = new ArrayList<>();
        for (Map<String, String> cmp : compList) {
            workgroupName = cmp.get("groupName");
            workgroupId = cmp.get("id");
            if (workgroupName.equals(workGroup)) {
                workgroupIdList.add(workgroupId);
                this.commonHelpers.AddToContextStore("companyCount", String.valueOf(cmp.get("count")));
                break;
            }
        }
        this.commonHelpers.AddToContextStore("WorkGroupName", workGroup);
        this.commonHelpers.AddToContextStore("workgroupIdList", workgroupId);
        this.commonHelpers.removeKeyinContextStore("CompanyAccHierarchy");
        this.commonHelpers.removeKeyinContextStore("CompanyCode");
        this.commonHelpers.removeRequestPayloadCollection("companyAndAccountHierarchy");
    }

    @Then("^I verify data in Api for Tracking Number$")
    public void i_verify_data_in_Api_and_Shipment_detail_page_for(DataTable tableData) throws Throwable {
        Response resp = this.commonHelpers.getValuefromContextStore("UserContext").toString().equalsIgnoreCase("CE")
                ? this.commonHelpers.GetValueFromResponseCollection("CE_Shipments_Overview")
                : this.commonHelpers.GetValueFromResponseCollection("MS_Shipments_Overview");
        Map<String, String> table = tableData.asMap(String.class, String.class);
        ShipmentList shipmentList = this.commonHelpers.unMarshall(resp.asString(), ShipmentList.class);

        String value = "";
        boolean trackinNumberFound = false;
        if (shipmentList.getTotalFilteredRecords() != 0
                && !this.commonHelpers.verifyKeyInContextStore(Constants.skipSteps)) {
            for (ShipmentDetailsResponse response : shipmentList.getData()) {
                if (response.getTrackingNumber()
                        .equals(this.commonHelpers.getValuefromContextStore("Tracking Number").toString())) {
                    trackinNumberFound = true;
                    for (String field : table.keySet()) {
                        value = GetApiField(field, response);
                        Assert.assertEquals(value, table.get(field));
                    }
                }
                if (trackinNumberFound) {
                    break;
                }
            }
        }
    }

    public void getWorkGroupCompnies(String workGroup) {
        Response resp = this.commonHelpers.GetValueFromResponseCollection("CE_GetWorkGroup");
        List<Map<String, Object>> compList = resp.jsonPath().getList("$");
        String workgroupName = "";
        Map<String, Object> groupDetails = new HashMap<>();
        for (Map<String, Object> cmp : compList) {
            workgroupName = cmp.get("groupName").toString();
            if (workgroupName.equals(workGroup)) {
                List<Map<String, Object>> companies = (List<Map<String, Object>>) cmp.get("companyHirerachy");
                for (Map<String, Object> company : companies) {
                    groupDetails.put((String) company.get("companyName"), company.get("accountId"));
                }
                this.commonHelpers.AddToContextStore("company", groupDetails);
                break;
            }
        }
    }

    @Then("^I validate the role and display names for selected image role against expected values$")
    public void i_validate_the_role_and_display_names_for_selected_image_role_against_expected_values(
            DataTable dataTable)
            throws Throwable {
        if (!this.commonHelpers.verifyKeyinContextStore(Constants.skipSteps)) {
            List<String> expectedImageRoleValues = dataTable.asList(String.class);
            SelectedImageRole selectedImageRole = new SelectedImageRole();
            selectedImageRole = (SelectedImageRole) this.commonHelpers.getValuefromContextStore("selectedImageRole");
            String roleName = selectedImageRole.getRoleName();
            String displayName = selectedImageRole.getDisplayName();
            Assertions.assertThat(expectedImageRoleValues.get(0))
                    .withFailMessage("\nSelected image role name does not match API response value but is --> "
                            + expectedImageRoleValues.get(0))
                    .isEqualTo(roleName);
            Assertions.assertThat(expectedImageRoleValues.get(1))
                    .withFailMessage("\nSelected image role display name does not match API response value but is --> "
                            + expectedImageRoleValues.get(0))
                    .isEqualTo(displayName);
        }

    }
}
