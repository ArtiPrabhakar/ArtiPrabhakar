package constants;

import genericfunctions.GenericFunction;

public class EnvConstants {

    String env;
    private String user;
    private String userRole;

    public String GetUser(String userName) {
        env = GenericFunction.ENV;
        this.user = System.getProperty(userName.toUpperCase());
        if (this.user == null) {
            userName = env + userName.toUpperCase(); // FDXQA+USER1
            this.user = GenericFunction.ReadConfigFile(userName);
        }
//        else if (this.user == null) {
//            this.user = GenericFunction.ReadConfigFile(userName.toUpperCase()); // read USER1 directlty
//        }
        return this.user;
    }

    public String GetUserRole() {
        return this.userRole;
    }

    public String GetOrgName(String loginId) {
        return null;
    }
}