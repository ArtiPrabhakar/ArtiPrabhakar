package constants;

/**
 * This class holds all the jsonpaths which are present in the solution which
 * can access through common helpers
 */
public class JsonPathRepository {
    public static final String testcaseStepStatus = "$..elements[%s]..status";
    public static final String testcasename = "$..elements[%s].name";
    public final String AccessToken = "$.access_token";
}